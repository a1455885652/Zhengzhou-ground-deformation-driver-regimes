%% make_reference_pattern_scenario.m
% 郑州 InSAR 垂直形变 —— 参考图空间格局情景版本
%
% 目的：
%   根据参考图中的 Upl_zone1 / Upl_zone2，
%   对现有垂直形变结果建立两个平滑高值区。
%
% 注意：
%   本结果属于 reference-guided scenario，
%   不覆盖原始 InSAR。
%
% MATLAB R2023b

clear;
clc;

fprintf('====================================================\n');
fprintf(' Reference-guided deformation scenario\n');
fprintf('====================================================\n\n');

% 1. 输入输出

inputFile = ...
    zz_external_path('insar_raster', 'G_SI_velocity_vertical_geo');

outputFile = ...
    zz_external_path('insar_raster', 'G_SI_velocity_vertical_reference_scenario_geo');

inputHdr  = [inputFile '.hdr'];
outputHdr = [outputFile '.hdr'];

% 2. 正负号约定

targetSign = +1;

% 如果实际上：
% 负值 = 沉降
%
% 则改为：
%
% targetSign = -1;


% 3. 两个参考图高值区

% ---------------- Zone 1 ----------------
zone1.name = 'Reference_zone1';

zone1.lonMin = 113.50;
zone1.lonMax = 113.75;

zone1.latMin = 34.66;
zone1.latMax = 34.82;

% 外围目标值
zone1.edgeValue = 5.0;

% 中心目标值
zone1.centerValue = 9.5;


% ---------------- Zone 2 ----------------
zone2.name = 'Reference_zone2';

zone2.lonMin = 113.70;
zone2.lonMax = 113.85;

zone2.latMin = 34.48;
zone2.latMax = 34.61;

zone2.edgeValue = 5.0;
zone2.centerValue = 9.0;


zones = {zone1, zone2};


% 4. 参数

% 0~1
%
% 越大：越接近参考图目标值
% 越小：保留越多原 InSAR 特征
scenarioStrength = 0.85;

% 原始纹理保留程度
textureWeight = 0.20;

% 中心核心区域半径比例
coreRadius = 0.55;

% 外部过渡终止半径
outerRadius = 1.15;

% 整幅图最终限制
maximumMagnitude = 10.0;


% 5. 文件检查

if ~isfile(inputFile)
    error('找不到输入文件：\n%s', inputFile);
end

if ~isfile(inputHdr)
    error('找不到 HDR：\n%s', inputHdr);
end


% 6. 读取 ENVI header

info = read_envi_header_geo(inputHdr);

fprintf('Raster:\n');
fprintf('  Lines   = %d\n', info.lines);
fprintf('  Samples = %d\n', info.samples);
fprintf('  Bands   = %d\n', info.bands);

fprintf('\nGeographic information:\n');
fprintf('  Reference pixel X = %.6f\n', info.refPixelX);
fprintf('  Reference pixel Y = %.6f\n', info.refPixelY);
fprintf('  Reference lon     = %.9f\n', info.refLon);
fprintf('  Reference lat     = %.9f\n', info.refLat);
fprintf('  Pixel size X      = %.12f\n', info.pixelSizeX);
fprintf('  Pixel size Y      = %.12f\n\n', info.pixelSizeY);


% 7. 数据类型

precision = envi_data_type_to_matlab(info.dataType);

if info.byteOrder == 0
    machineFormat = 'ieee-le';
else
    machineFormat = 'ieee-be';
end


% 8. 读取数据

fprintf('Reading deformation raster...\n');

fid = fopen(inputFile, 'r', machineFormat);

if fid == -1
    error('无法打开输入文件。');
end

fseek(fid, info.headerOffset, 'bof');

raw = fread( ...
    fid, ...
    [info.samples, info.lines], ...
    ['*' precision]);

fclose(fid);

V = double(raw');

clear raw;

fprintf('Reading finished.\n\n');


% 9. 有效像元

valid = isfinite(V);

if info.hasIgnoreValue

    valid = ...
        valid & ...
        V ~= info.ignoreValue;

end


% 10. 建立经纬度矩阵

[lonGrid, latGrid] = ...
    build_envi_lonlat_grid(info);

fprintf('Raster geographic extent:\n');

fprintf('  Longitude: %.6f -- %.6f\n', ...
    min(lonGrid(:)), max(lonGrid(:)));

fprintf('  Latitude : %.6f -- %.6f\n\n', ...
    min(latGrid(:)), max(latGrid(:)));


% 11. 原始结果

Vscenario = V;

originalMagnitude = targetSign .* V;

originalMagnitude(~valid) = NaN;


fprintf('Original target-sign deformation:\n');

tmp = originalMagnitude(valid);

fprintf('  Min = %.4f\n', min(tmp));
fprintf('  Max = %.4f\n', max(tmp));
fprintf('  Mean = %.4f\n\n', mean(tmp));


% 12. 逐个建立平滑参考区域

for z = 1:numel(zones)

    Z = zones{z};

    fprintf('Processing %s...\n', Z.name);

    %% 中心经纬度

    centerLon = ...
        (Z.lonMin + Z.lonMax) / 2;

    centerLat = ...
        (Z.latMin + Z.latMax) / 2;


    %% 椭圆长短半轴

    radiusLon = ...
        (Z.lonMax - Z.lonMin) / 2;

    radiusLat = ...
        (Z.latMax - Z.latMin) / 2;


    %% 椭圆归一化距离

    D = sqrt( ...
        ((lonGrid - centerLon) ./ radiusLon).^2 + ...
        ((latGrid - centerLat) ./ radiusLat).^2 );


    % 平滑空间权重

    W = zeros(size(V));

    % 核心区域
    W(D <= coreRadius) = 1;

    % 过渡区域
    transitionMask = ...
        D > coreRadius & ...
        D < outerRadius;

    t = ...
        (D(transitionMask) - coreRadius) ./ ...
        (outerRadius - coreRadius);

    % cosine taper
    W(transitionMask) = ...
        0.5 .* (1 + cos(pi .* t));

    W(~valid) = 0;


    % 构造参考目标幅值

    radialPosition = ...
        min(D ./ outerRadius, 1);

    radialStrength = ...
        1 - radialPosition;

    targetMagnitude = ...
        Z.edgeValue + ...
        (Z.centerValue - Z.edgeValue) .* ...
        radialStrength;


    % 加入少量原始 InSAR 空间纹理

    localOriginal = originalMagnitude;

    % 避免负幅值产生影响
    localOriginal(localOriginal < 0) = 0;

    localOriginal(~valid) = 0;

    % 归一化到 0~1
    localMax = max(localOriginal(W > 0));

    if isempty(localMax) || localMax <= 0

        texture = zeros(size(V));

    else

        texture = ...
            min(localOriginal ./ localMax, 1);

    end


    targetMagnitude = ...
        targetMagnitude .* ...
        (1 - textureWeight) + ...
        (Z.edgeValue + ...
        (Z.centerValue - Z.edgeValue) .* texture) .* ...
        textureWeight;


    % Scenario 强度

    effectiveWeight = ...
        W .* scenarioStrength;


    % 当前结果幅值

    currentMagnitude = ...
        targetSign .* Vscenario;


    % 平滑混合

    newMagnitude = ...
        currentMagnitude .* ...
        (1 - effectiveWeight) + ...
        targetMagnitude .* ...
        effectiveWeight;


    %% 转回原符号

    zoneMask = ...
        valid & ...
        W > 0;

    Vscenario(zoneMask) = ...
        targetSign .* ...
        newMagnitude(zoneMask);


    fprintf('  Modified pixels = %d\n', ...
        nnz(zoneMask));

end


% 13. 限制最大幅值

magnitude = targetSign .* Vscenario;

tooLarge = ...
    valid & ...
    magnitude > maximumMagnitude;

Vscenario(tooLarge) = ...
    targetSign .* maximumMagnitude;


% 14. NoData

if info.hasIgnoreValue

    Vscenario(~valid) = ...
        info.ignoreValue;

else

    Vscenario(~valid) = NaN;

end


% 15. 统计

fprintf('\n====================================================\n');
fprintf('Scenario statistics\n');
fprintf('====================================================\n');

scenarioMag = ...
    targetSign .* Vscenario(valid);

fprintf('Min    = %.4f\n', min(scenarioMag));
fprintf('Max    = %.4f\n', max(scenarioMag));
fprintf('Mean   = %.4f\n', mean(scenarioMag));
fprintf('Median = %.4f\n', median(scenarioMag));


% 16. 写文件

fprintf('\nWriting output...\n');

fid = fopen(outputFile, 'w', machineFormat);

if fid == -1
    error('无法建立输出文件。');
end

if info.headerOffset > 0

    fwrite( ...
        fid, ...
        zeros(info.headerOffset,1,'uint8'), ...
        'uint8');

end


if info.dataType == 4

    fwrite( ...
        fid, ...
        single(Vscenario'), ...
        'single');

elseif info.dataType == 5

    fwrite( ...
        fid, ...
        double(Vscenario'), ...
        'double');

else

    fclose(fid);

    error( ...
        'Velocity 建议为 float32/float64，当前 data type = %d', ...
        info.dataType);

end

fclose(fid);


% 17. HDR

copyfile( ...
    inputHdr, ...
    outputHdr, ...
    'f');


% 18. 写说明

descriptionFile = ...
    [outputFile '_REFERENCE_SCENARIO_INFO.txt'];

fid = fopen(descriptionFile, 'w');

fprintf(fid, ...
    'REFERENCE-GUIDED SCENARIO RESULT\n\n');

fprintf(fid, ...
    'This raster is NOT the original InSAR observation.\n');

fprintf(fid, ...
    'It is a spatial sensitivity/scenario result guided by a reference figure.\n\n');

fprintf(fid, ...
    'Original raster:\n%s\n\n', ...
    inputFile);

fprintf(fid, ...
    'Scenario strength = %.4f\n', ...
    scenarioStrength);

fprintf(fid, ...
    'Maximum magnitude = %.4f\n\n', ...
    maximumMagnitude);

for z = 1:numel(zones)

    Z = zones{z};

    fprintf(fid, '%s\n', Z.name);

    fprintf(fid, ...
        'Longitude = %.6f -- %.6f\n', ...
        Z.lonMin, Z.lonMax);

    fprintf(fid, ...
        'Latitude  = %.6f -- %.6f\n', ...
        Z.latMin, Z.latMax);

    fprintf(fid, ...
        'Target magnitude = %.2f -- %.2f\n\n', ...
        Z.edgeValue, ...
        Z.centerValue);

end

fclose(fid);


fprintf('\nFinished.\n');

fprintf('\nOutput:\n%s\n', outputFile);

fprintf('\nOriginal raster was NOT overwritten.\n');

fprintf('====================================================\n');
