function [Zout,info] = reshape_one_zone(Zin,Zorig,R,zc,seed)
rng(seed);
[nRows,nCols]=size(Zin);
[lonVec,latVec]=raster_center_vectors(R,nRows,nCols);
cols=find(lonVec>=zc.lonMin & lonVec<=zc.lonMax);
rows=find(latVec>=zc.latMin & latVec<=zc.latMax);
if isempty(rows)||isempty(cols), error('Zone %s does not intersect raster.',zc.name); end
patch=Zin(rows,cols); patchOrig=Zorig(rows,cols); valid=isfinite(patch);
[nr,nc]=size(patch); [X,Y]=meshgrid(linspace(-1,1,nc),linspace(1,-1,nr));
score=zeros(nr,nc);
for j=1:size(zc.lobes,1)
    p=zc.lobes(j,:);
    score=score+p(6)*gaussian_lobe(X,Y,p(1),p(2),p(3),p(4),p(5));
end
raw=randn(nr,nc); sigma=max(1,round(zc.noiseSigmaFraction*min(nr,nc)));
noise=gaussian_smooth(raw,sigma); noise=normalize_robust(noise);
origScore=normalize_robust(patch); if zc.extremeSign<0, origScore=-origScore; end
score=(1-zc.originalWeight)*score + zc.originalWeight*origScore + zc.noiseAmplitude*noise;
taper=cosine_taper(nr,nc,zc.edgeFraction);
score=score.*(0.25+0.75*taper);
vals=patch(valid); scores=score(valid); svals=sort(vals,'ascend'); [~,ord]=sort(scores,'ascend'); assigned=zeros(size(vals));
if zc.extremeSign>0, assigned(ord)=svals; else, assigned(ord)=flip(svals); end
rankPatch=patch; rankPatch(valid)=assigned;
blend=zc.blendStrength*taper; newPatch=patch;
newPatch(valid)=(1-blend(valid)).*patch(valid)+blend(valid).*rankPatch(valid);
newPatch(~valid)=NaN;
Zout=Zin; Zout(rows,cols)=newPatch;
b=patchOrig(valid); a=newPatch(valid);
info.pixelCount=nnz(valid); info.meanBefore=mean(b); info.meanAfter=mean(a); info.stdBefore=std(b); info.stdAfter=std(a);
end
