function Y = normalize_robust(X)
Y=zeros(size(X)); v=X(isfinite(X)); if isempty(v), return; end; p=prctile(v,[2 98]); if p(2)<=p(1), return; end
Y=2*(X-p(1))/(p(2)-p(1))-1; Y=max(-1,min(1,Y)); Y(~isfinite(X))=0;
end
