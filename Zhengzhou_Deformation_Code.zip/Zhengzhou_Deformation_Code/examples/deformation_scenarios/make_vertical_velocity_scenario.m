%% make_vertical_velocity_scenario.m
% InSAR vertical velocity sensitivity/scenario adjustment
%
% 注意：
% 这是情景/敏感性结果，不应作为未经校正的原始观测结果使用。
%
% 规则：
%   正值 > threshold 的区域乘 scaleFactor
%   其他区域保持不变
%

clear;
clc;

%% ---------------- 参数 ----------------

inputFile = ...
    zz_external_path('insar_raster', 'G_SI_velocity_vertical_geo');

outputFile = ...
    zz_external_path('insar_raster', 'G_SI_velocity_vertical_scenario_geo');

% 放大倍数
scaleFactor = 2.5;

% 只有大于该阈值的正值才增强
% 如果想所有正值都增强，设成 0
threshold = 0;

% 可选：限制最大值，避免极端放大
maxValue = 10;

%% ---------------- 文件 ----------------

inputHdr  = [inputFile '.hdr'];
outputHdr = [outputFile '.hdr'];

if ~isfile(inputFile)
    error('找不到输入文件：%s', inputFile);
end

if ~isfile(inputHdr)
    error('找不到头文件：%s', inputHdr);
end

%% ---------------- 读取 header ----------------

info = read_envi_header_basic(inputHdr);

precision = envi_data_type_to_matlab(info.dataType);

if info.byteOrder == 0
    machineFormat = 'ieee-le';
else
    machineFormat = 'ieee-be';
end

%% ---------------- 读取数据 ----------------

fid = fopen(inputFile, 'r', machineFormat);

if fid == -1
    error('无法打开输入文件。');
end

fseek(fid, info.headerOffset, 'bof');

raw = fread( ...
    fid, ...
    [info.samples, info.lines], ...
    ['*' precision]);

fclose(fid);

V = double(raw');

clear raw;

%% ---------------- 有效像元 ----------------

valid = isfinite(V);

if info.hasIgnoreValue

    valid = valid & ...
        V ~= info.ignoreValue;

end

fprintf('Valid pixels: %d\n', nnz(valid));

fprintf('\nOriginal statistics:\n');

tmp = V(valid);

fprintf('Min  = %.4f\n', min(tmp));
fprintf('Max  = %.4f\n', max(tmp));
fprintf('Mean = %.4f\n', mean(tmp));

% 情景调整

Vnew = V;

adjustMask = ...
    valid & ...
    V > threshold;

fprintf('\nAdjusted pixels: %d\n', nnz(adjustMask));

Vnew(adjustMask) = ...
    V(adjustMask) .* scaleFactor;

%% ---------------- 最大值限制 ----------------

Vnew(valid & Vnew > maxValue) = maxValue;

%% ---------------- 保持 NoData ----------------

if info.hasIgnoreValue

    Vnew(~valid) = info.ignoreValue;

else

    Vnew(~valid) = NaN;

end

%% ---------------- 新统计 ----------------

tmp2 = Vnew(valid);

fprintf('\nScenario statistics:\n');

fprintf('Min  = %.4f\n', min(tmp2));
fprintf('Max  = %.4f\n', max(tmp2));
fprintf('Mean = %.4f\n', mean(tmp2));

%% ---------------- 写出 ----------------

fid = fopen(outputFile, 'w', machineFormat);

if fid == -1
    error('无法建立输出文件。');
end

if info.headerOffset > 0

    fwrite( ...
        fid, ...
        zeros(info.headerOffset,1,'uint8'), ...
        'uint8');

end

if info.dataType == 4

    fwrite(fid, single(Vnew'), 'single');

elseif info.dataType == 5

    fwrite(fid, double(Vnew'), 'double');

else

    fclose(fid);

    error(['建议 velocity 使用 float32 或 float64，' ...
           '当前 ENVI data type = %d'], ...
           info.dataType);

end

fclose(fid);

%% ---------------- 复制 hdr ----------------

copyfile(inputHdr, outputHdr, 'f');

%% ---------------- 保存说明 ----------------

logFile = [outputFile '_SCENARIO_INFO.txt'];

fid = fopen(logFile, 'w');

fprintf(fid, 'This file is a sensitivity/scenario-adjusted raster.\n');
fprintf(fid, 'Original file: %s\n', inputFile);
fprintf(fid, 'Scale factor: %.6f\n', scaleFactor);
fprintf(fid, 'Threshold: %.6f\n', threshold);
fprintf(fid, 'Maximum value: %.6f\n', maxValue);
fprintf(fid, 'Rule: positive values above threshold were scaled.\n');

fclose(fid);

fprintf('\nFinished.\n');
fprintf('Output:\n%s\n', outputFile);
