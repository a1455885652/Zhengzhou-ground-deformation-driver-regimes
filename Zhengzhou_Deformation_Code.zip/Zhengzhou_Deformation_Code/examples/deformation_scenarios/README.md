# Synthetic deformation scenarios

This directory contains the supplied scenario-generation and reshaping utilities. They construct or modify deformation patterns; their outputs are synthetic scenarios, not independent observations or measured validation data.

The entry is `RUN_RESHAPE_DEFORMATION_SCENARIO.m`. Settings are in `config_reshape_deformation_scenario.m`. The script also needs the raster helpers in `../../preprocessing/raster_tools` and the shared `../../runtime` directory on the MATLAB path.

These files are retained for source completeness. They are excluded from the registered experiment sequence and are not called to regenerate the paper's result tables or final figures.
