function cfg = config_reshape_deformation_scenario()
cfg.inputRaster = zz_external_path('insar_raster', 'G_SI_velocity_vertical_scenario_geo');
cfg.outputFolder = zz_external_path('insar_raster', 'Irregular_Shape_Scenario');
cfg.randomSeed = 20260903;
cfg.plotCLim = [-28 10];

z1.name='Central_zone'; z1.lonMin=113.460; z1.lonMax=113.760; z1.latMin=34.660; z1.latMax=34.840;
z1.extremeSign=+1; z1.blendStrength=0.92; z1.edgeFraction=0.16; z1.originalWeight=0.18;
z1.noiseAmplitude=0.34; z1.noiseSigmaFraction=0.055;
z1.lobes=[-0.48 0.08 0.48 0.18 -10 0.90; -0.05 0.00 0.40 0.16 4 1.15; 0.38 -0.12 0.34 0.18 18 0.80; 0.08 -0.42 0.24 0.15 -18 0.36];

z2.name='Southeast_zone'; z2.lonMin=113.698; z2.lonMax=113.871; z2.latMin=34.484; z2.latMax=34.606;
z2.extremeSign=+1; z2.blendStrength=0.90; z2.edgeFraction=0.17; z2.originalWeight=0.20;
z2.noiseAmplitude=0.40; z2.noiseSigmaFraction=0.060;
z2.lobes=[-0.30 0.14 0.40 0.22 22 1.00; 0.24 -0.12 0.32 0.17 -20 0.84; 0.03 -0.44 0.21 0.14 10 0.30];

cfg.zones=[z1 z2];
end
