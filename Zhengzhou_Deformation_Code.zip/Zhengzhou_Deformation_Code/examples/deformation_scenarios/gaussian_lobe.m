function G = gaussian_lobe(X,Y,xc,yc,sx,sy,angleDeg)
t=deg2rad(angleDeg); X0=X-xc; Y0=Y-yc; XR=cos(t).*X0+sin(t).*Y0; YR=-sin(t).*X0+cos(t).*Y0;
G=exp(-0.5*((XR./sx).^2+(YR./sy).^2));
end
