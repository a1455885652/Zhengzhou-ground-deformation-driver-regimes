function plot_compare(Z0,Z1,cfg)
fig=figure('Color','w','Units','centimeters','Position',[2 2 24 10]);
subplot(1,2,1); imagesc(Z0); axis image off; caxis(cfg.plotCLim); title('Original');
subplot(1,2,2); imagesc(Z1); axis image off; caxis(cfg.plotCLim); title('Irregular shape scenario');
colormap(turbo(256));
print(fig,fullfile(cfg.outputFolder,'QuickLook_Original_vs_Scenario.png'),'-dpng','-r250'); if ~zz_show_figures(), close(fig); end
end
