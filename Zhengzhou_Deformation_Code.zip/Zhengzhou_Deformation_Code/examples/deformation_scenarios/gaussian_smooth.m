function Y = gaussian_smooth(X,sigma)
r=max(2,ceil(3*sigma)); v=-r:r; g=exp(-(v.^2)/(2*sigma^2)); g=g/sum(g); Y=conv2(conv2(X,g,'same'),g','same');
end
