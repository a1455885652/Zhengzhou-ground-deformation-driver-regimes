function W = cosine_taper(nRows,nCols,edgeFraction)
r=min((0:nRows-1)',(nRows-1:-1:0)'); c=min(0:nCols-1,nCols-1:-1:0);
rw=max(1,edgeFraction*(nRows-1)); cw=max(1,edgeFraction*(nCols-1)); wr=ones(nRows,1); wc=ones(1,nCols);
mr=r<rw; mc=c<cw; wr(mr)=0.5-0.5*cos(pi*r(mr)/rw); wc(mc)=0.5-0.5*cos(pi*c(mc)/cw); W=wr*wc;
end
