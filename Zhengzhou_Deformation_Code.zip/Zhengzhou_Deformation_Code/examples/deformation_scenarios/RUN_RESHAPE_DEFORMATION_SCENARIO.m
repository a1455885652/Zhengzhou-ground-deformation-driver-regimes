%% RUN_RESHAPE_DEFORMATION_SCENARIO.m
clear; clc;
cfg = config_reshape_deformation_scenario();
[Z,R] = read_input_raster(cfg.inputRaster);
Z = double(Z);
Znew = Z;
for k = 1:numel(cfg.zones)
    [Znew,info] = reshape_one_zone(Znew,Z,R,cfg.zones(k),cfg.randomSeed+100*k);
    fprintf('%s: pixels=%d, mean %.3f -> %.3f, std %.3f -> %.3f\n', ...
        cfg.zones(k).name,info.pixelCount,info.meanBefore,info.meanAfter,info.stdBefore,info.stdAfter);
end
Znew(~isfinite(Z)) = NaN;
if ~exist(cfg.outputFolder,'dir'), mkdir(cfg.outputFolder); end
outFile = fullfile(cfg.outputFolder,'G_SI_velocity_vertical_irregular_shape_scenario.tif');
diffFile = fullfile(cfg.outputFolder,'G_SI_velocity_vertical_irregular_shape_difference.tif');
geotiffwrite(outFile,single(Znew),R,'CoordRefSysCode',4326);
geotiffwrite(diffFile,single(Znew-Z),R,'CoordRefSysCode',4326);
plot_compare(Z,Znew,cfg);
fprintf('Done.\n%s\n',outFile);
