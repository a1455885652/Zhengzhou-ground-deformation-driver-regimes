function value = zz_project_path(varargin)
% Resolve a path within the configured data and result tree.
cfg = zz_config();
parts = cellfun(@(s) strrep(char(s), '\', filesep), varargin, 'UniformOutput', false);
value = fullfile(cfg.project_root, parts{:});
end
