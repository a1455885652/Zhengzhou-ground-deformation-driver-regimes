function zz_call_python(script, args)
% Call the configured interpreter and preserve its diagnostic output.
if nargin < 2, args = {}; end
parts = [{zz_python_executable(), script}, args];
quoted = cellfun(@quote_argument, parts, 'UniformOutput', false);
command = strjoin(quoted, ' ');
[status, ~] = system(command, '-echo');
if status ~= 0
    error('Python exited with status %d. See the error above.', status);
end
end

function text = quote_argument(value)
value = char(value);
if ispc
    assert(~contains(value, '"'), 'A command argument contains a double quote.');
    text = ['"' value '"'];
else
    quote = char(39);
    escapedQuote = [quote char(34) quote char(34) quote];
    text = [quote strrep(value, quote, escapedQuote) quote];
end
end
