function value = zz_absolute_path(value, repo)
% Resolve a relative configuration path against the repository root.
value = char(value);
absolute = startsWith(value, '/') || startsWith(value, '\\') || ...
    ~isempty(regexp(value, '^[A-Za-z]:[\\/]', 'once'));
if ~absolute, value = fullfile(repo, value); end
end
