@echo off
for /f "usebackq tokens=1,* delims==" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0export_paths.ps1"`) do set "%%A=%%B"
if not defined ZZ_PROJECT_ROOT exit /b 1
exit /b 0
