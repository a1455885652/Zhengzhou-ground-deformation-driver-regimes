function zz_execute_script(scriptFile)
% Run scripts in an isolated workspace so their clear statements stay local.
run(scriptFile);
end
