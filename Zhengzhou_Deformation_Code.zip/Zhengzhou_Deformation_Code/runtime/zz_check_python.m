function zz_check_python()
% Check imports using the same interpreter that will run the analysis.
repo = fileparts(fileparts(mfilename('fullpath')));
zz_call_python(fullfile(repo, 'tools', 'check_environment.py'));
end
