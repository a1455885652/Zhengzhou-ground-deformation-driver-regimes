function zz_restore_environment(previousPath, previousFolder)
% Restore MATLAB's search path and working folder after a stage.
path(previousPath);
cd(previousFolder);
end
