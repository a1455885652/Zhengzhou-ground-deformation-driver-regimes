function value = zz_show_figures()
% Use ZZ_PREVIEW for a temporary batch-export override.
override = getenv('ZZ_PREVIEW');
if isempty(override)
    cfg = zz_config(); value = logical(cfg.preview);
else
    value = ~any(strcmpi(override, {'0','false','no'}));
end
end
