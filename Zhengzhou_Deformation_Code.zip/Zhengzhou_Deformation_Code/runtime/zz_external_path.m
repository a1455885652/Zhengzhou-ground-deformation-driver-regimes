function value = zz_external_path(key, varargin)
% Resolve an external raster, vector or coordinate input.
cfg = zz_config();
if ~isfield(cfg.external_paths, key) || isempty(cfg.external_paths.(key))
    error('Zhengzhou:ExternalPath', 'Set external_paths.%s in config/paths.json.', key);
end
value = zz_absolute_path(cfg.external_paths.(key), cfg.repository);
parts = cellfun(@(s) strrep(char(s), '\', filesep), varargin, 'UniformOutput', false);
value = fullfile(value, parts{:});
end
