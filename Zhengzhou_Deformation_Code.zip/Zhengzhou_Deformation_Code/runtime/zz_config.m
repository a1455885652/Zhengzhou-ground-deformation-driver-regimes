function cfg = zz_config()
% Read the shared path and preview settings.
repo = fileparts(fileparts(mfilename('fullpath')));
file = getenv('ZHENGZHOU_CONFIG');
if isempty(file), file = fullfile(repo, 'config', 'paths.json'); end
cfg = jsondecode(fileread(file));
cfg.repository = repo;
override = getenv('ZHENGZHOU_PROJECT_ROOT');
if ~isempty(override), cfg.project_root = override; end
override = getenv('ZHENGZHOU_PYTHON');
if ~isempty(override), cfg.python_exe = override; end
cfg.project_root = zz_absolute_path(cfg.project_root, repo);
cfg.figure_output = zz_absolute_path(cfg.figure_output, repo);
end
