function value = zz_figure_visibility()
% Figure visibility for interactive and unattended runs.
if zz_show_figures(), value = 'on'; else, value = 'off'; end
end
