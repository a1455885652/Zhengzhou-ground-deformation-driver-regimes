$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$repo = Split-Path $PSScriptRoot -Parent
$configFile = if ($env:ZHENGZHOU_CONFIG) { $env:ZHENGZHOU_CONFIG } else { Join-Path $repo 'config\paths.json' }
$config = Get-Content -Raw -Encoding UTF8 $configFile | ConvertFrom-Json

function Resolve-ProjectPath([string]$value) {
    if ($value.StartsWith('@')) { return $value }
    $expanded = [Environment]::ExpandEnvironmentVariables($value)
    if ([IO.Path]::IsPathRooted($expanded)) { return $expanded }
    return [IO.Path]::GetFullPath((Join-Path $repo $expanded))
}

$root = if ($env:ZHENGZHOU_PROJECT_ROOT) { $env:ZHENGZHOU_PROJECT_ROOT } else { $config.project_root }
$values = [ordered]@{
    ZZ_PROJECT_ROOT = Resolve-ProjectPath $root
    ZZ_FIGURE_OUTPUT = Resolve-ProjectPath $config.figure_output
    ZZ_CUMULATIVE_XYZ = Resolve-ProjectPath $config.external_paths.cumulative_xyz
    ZZ_BOUNDARY = Resolve-ProjectPath $config.external_paths.boundary_shapefile
    ZZ_VELOCITY_TIF = Resolve-ProjectPath $config.external_paths.velocity_raster
    ZZ_VELOCITY_XYZ = Resolve-ProjectPath $config.external_paths.velocity_xyz
    ZZ_DEM = Resolve-ProjectPath $config.external_paths.basemap_dem
}
foreach ($item in $values.GetEnumerator()) {
    if ($item.Value.Contains('"') -or $item.Value.Contains("`n")) { throw 'Invalid path in configuration.' }
    Write-Output ($item.Key + '=' + $item.Value)
}
