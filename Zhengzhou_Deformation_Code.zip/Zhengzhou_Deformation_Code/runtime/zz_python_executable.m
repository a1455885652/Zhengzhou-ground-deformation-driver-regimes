function executable = zz_python_executable()
% Select one configured interpreter for every Python subprocess.
cfg = zz_config();
if ~isempty(cfg.python_exe)
    executable = zz_absolute_path(cfg.python_exe, cfg.repository);
elseif ispc
    executable = fullfile(cfg.repository, '.venv', 'Scripts', 'python.exe');
else
    executable = fullfile(cfg.repository, '.venv', 'bin', 'python');
end
if ~isfile(executable)
    error('Zhengzhou:Python', ['Python interpreter not found: %s\n' ...
        'Run the environment setup script once, or set python_exe in config/paths.json.'], executable);
end
end
