function zz_invoke(entry, isFunction)
% Run an existing plotting component without clearing the caller workspace.
if isFunction
    feval(entry);
else
    zz_execute_script(which(entry));
end
end
