"""Project paths shared by the analysis and figure entry points."""

from __future__ import annotations

import json
import os
from pathlib import Path

REPOSITORY = Path(__file__).resolve().parents[1]


def configuration() -> dict:
    config_file = Path(
        os.environ.get("ZHENGZHOU_CONFIG", REPOSITORY / "config/paths.json")
    )
    with config_file.open(encoding="utf-8-sig") as stream:
        return json.load(stream)


def absolute_path(value: str) -> Path:
    path = Path(os.path.expandvars(value)).expanduser()
    return path if path.is_absolute() else REPOSITORY / path


def project_path(*parts: str) -> Path:
    root = os.environ.get("ZHENGZHOU_PROJECT_ROOT") or configuration()["project_root"]
    return absolute_path(root).joinpath(*[p.replace("\\", "/") for p in parts])


def external_path(key: str, *parts: str) -> Path:
    paths = configuration().get("external_paths", {})
    if not paths.get(key):
        raise ValueError(f"Set external_paths.{key} in config/paths.json.")
    return absolute_path(paths[key]).joinpath(*parts)


def figure_path(name: str = "") -> Path:
    path = absolute_path(configuration()["figure_output"]) / name
    path.mkdir(parents=True, exist_ok=True)
    return path


def python_executable() -> Path:
    configured = os.environ.get("ZHENGZHOU_PYTHON") or configuration().get("python_exe")
    path = (
        absolute_path(configured)
        if configured
        else REPOSITORY
        / ".venv"
        / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    )
    if not path.is_file():
        raise FileNotFoundError(
            f"Python interpreter not found: {path}\n"
            "Run setup_environment.bat or setup_environment.sh once, "
            "or set python_exe in config/paths.json."
        )
    return path


def show_figures() -> bool:
    value = os.environ.get("ZZ_PREVIEW")
    return (
        value.lower() not in {"0", "false", "no"}
        if value is not None
        else bool(configuration().get("preview", True))
    )
