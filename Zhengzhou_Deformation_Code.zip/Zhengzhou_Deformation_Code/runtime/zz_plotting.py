"""Common export settings for manuscript figures."""

from pathlib import Path


def choose_font(preferred="Times New Roman"):
    """Use an installed manuscript font with a portable fallback."""
    from matplotlib import font_manager

    available = {font.name for font in font_manager.fontManager.ttflist}
    if preferred in available:
        return preferred
    return "DejaVu Sans" if preferred == "Arial" else "DejaVu Serif"


def save_figure(figure, output, stem):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    for suffix in ("png", "pdf", "tif"):
        options = {"dpi": 600, "bbox_inches": "tight", "facecolor": "white"}
        if suffix == "tif":
            options["pil_kwargs"] = {"compression": "tiff_lzw"}
        figure.savefig(output / f"{stem}.{suffix}", **options)
    print(output / f"{stem}.png")
