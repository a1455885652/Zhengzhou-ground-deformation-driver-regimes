function value = zz_figure_dir(name)
% Return the output directory for one figure or figure group.
cfg = zz_config();
if nargin < 1, name = ''; end
value = fullfile(cfg.figure_output, name);
if ~isfolder(value), mkdir(value); end
end
