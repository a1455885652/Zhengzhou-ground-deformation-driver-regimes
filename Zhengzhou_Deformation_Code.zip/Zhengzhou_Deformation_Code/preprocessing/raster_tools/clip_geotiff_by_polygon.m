function clip_geotiff_by_polygon( ...
    inputTif, outputTif, boundaryLon, boundaryLat)
%CLIP_GEOTIFF_BY_POLYGON
% 将一个地理坐标 GeoTIFF：
% 1) 裁到多边形外接矩形；
% 2) 将多边形外像元设置为 NaN；
% 3) 保持像元原始数值，不进行空间插值。

if ~isfile(inputTif)
    error('输入 GeoTIFF 不存在：%s', inputTif);
end

[A, R] = readgeoraster(inputTif);

if ndims(A) > 2
    if size(A,3) ~= 1
        error('当前代码要求单波段形变栅格：%s', inputTif);
    end
    A = A(:,:,1);
end

A = single(A);

% 将 GeoTIFF 中定义的 NoData 转为 NaN。
try
    rInfo = georasterinfo(inputTif);

    if isprop(rInfo, 'MissingDataIndicator')
        nodata = rInfo.MissingDataIndicator;
    elseif isfield(rInfo, 'MissingDataIndicator')
        nodata = rInfo.MissingDataIndicator;
    else
        nodata = [];
    end

    if ~isempty(nodata)
        nodata = double(nodata(1));

        if isfinite(nodata)
            A(double(A) == nodata) = NaN;
        end
    end
catch
    % 若读不到 MissingDataIndicator，则保持原值。
end

% 该项目的 geocoding raster 应为经纬度地理栅格。
if ~contains(class(R), 'Geographic', 'IgnoreCase', true)
    error([ ...
        '当前输入栅格不是 Geographic raster reference：\n%s\n' ...
        '本代码按经纬度 GeoTIFF 编写。'], inputTif);
end

minLon = min(boundaryLon, [], 'omitnan');
maxLon = max(boundaryLon, [], 'omitnan');
minLat = min(boundaryLat, [], 'omitnan');
maxLat = max(boundaryLat, [], 'omitnan');

% 与输入栅格范围求交，避免 geocrop 越界。
lonlim = [ ...
    max(minLon, R.LongitudeLimits(1)), ...
    min(maxLon, R.LongitudeLimits(2))];

latlim = [ ...
    max(minLat, R.LatitudeLimits(1)), ...
    min(maxLat, R.LatitudeLimits(2))];

if lonlim(1) >= lonlim(2) || latlim(1) >= latlim(2)
    error('郑州边界与输入栅格没有空间交集：%s', inputTif);
end

% 先裁到郑州的最小外接矩形。
[Acrop, Rcrop] = geocrop(A, R, latlim, lonlim);

% 得到裁剪后每个像元中心的经纬度。
[latGrid, lonGrid] = geographicGrid(Rcrop);

% 构建郑州市行政边界掩膜。
inside = false(size(Acrop));

% boundaryLon / boundaryLat 中 NaN 分隔多个要素。
nanBreak = isnan(boundaryLon) | isnan(boundaryLat);
breakIdx = find(nanBreak);

startIdx = 1;

for b = 1:numel(breakIdx)

    stopIdx = breakIdx(b) - 1;

    if stopIdx >= startIdx

        lonPart = boundaryLon(startIdx:stopIdx);
        latPart = boundaryLat(startIdx:stopIdx);

        validPart = isfinite(lonPart) & isfinite(latPart);

        lonPart = lonPart(validPart);
        latPart = latPart(validPart);

        if numel(lonPart) >= 3
            inside = inside | ...
                inpolygon(lonGrid, latGrid, lonPart, latPart);
        end
    end

    startIdx = breakIdx(b) + 1;
end

% 防止最后一个部件后面没有 NaN。
if startIdx <= numel(boundaryLon)

    lonPart = boundaryLon(startIdx:end);
    latPart = boundaryLat(startIdx:end);

    validPart = isfinite(lonPart) & isfinite(latPart);

    lonPart = lonPart(validPart);
    latPart = latPart(validPart);

    if numel(lonPart) >= 3
        inside = inside | ...
            inpolygon(lonGrid, latGrid, lonPart, latPart);
    end
end

% 郑州市边界以外全部置 NaN。
Acrop(~inside) = NaN;

% 保留原始 GeoTIFF 坐标系统。
try
    tifInfo = geotiffinfo(inputTif);

    if isfield(tifInfo, 'GeoTIFFTags') && ...
       isfield(tifInfo.GeoTIFFTags, 'GeoKeyDirectoryTag')

        geotiffwrite( ...
            outputTif, ...
            Acrop, ...
            Rcrop, ...
            'GeoKeyDirectoryTag', ...
            tifInfo.GeoTIFFTags.GeoKeyDirectoryTag);

    else
        geotiffwrite(outputTif, Acrop, Rcrop);
    end

catch ME
    error('写出 GeoTIFF 失败：\n%s\n%s', outputTif, ME.message);
end

fprintf('  -> %s\n', outputTif);

end
