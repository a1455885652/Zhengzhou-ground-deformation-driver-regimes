function [boundaryLon, boundaryLat] = read_shapefile_lonlat(shpFile)
%READ_SHAPEFILE_LONLAT
% 读取多边形 shapefile，并统一转换为经纬度坐标。
%
% 输出 boundaryLon / boundaryLat 使用 NaN 分隔不同多边形或部件。

if ~isfile(shpFile)
    error('Shapefile 不存在：%s', shpFile);
end

S = shaperead(shpFile);

if isempty(S)
    error('Shapefile 中没有读取到任何要素：%s', shpFile);
end

info = shapeinfo(shpFile);

crs = [];
if isfield(info, 'CoordinateReferenceSystem')
    crs = info.CoordinateReferenceSystem;
end

boundaryLon = [];
boundaryLat = [];

for k = 1:numel(S)

    if ~isfield(S, 'X') || ~isfield(S, 'Y')
        error('Shapefile 中不存在 X/Y 坐标字段。');
    end

    x = double(S(k).X(:));
    y = double(S(k).Y(:));

    if isempty(crs)

        % CRS 信息缺失时，根据坐标范围判断是否为经纬度。
        validXY = isfinite(x) & isfinite(y);

        if any(validXY) && ...
           max(abs(x(validXY))) <= 180 && ...
           max(abs(y(validXY))) <= 90

            lon = x;
            lat = y;

        else
            error([ ...
                'Shapefile 没有 CRS 信息，而且坐标不像经纬度。\n' ...
                '请先为 shp 定义正确的坐标参考系。']);
        end

    elseif isa(crs, 'geocrs')

        lon = x;
        lat = y;

    elseif isa(crs, 'projcrs')

        lon = nan(size(x));
        lat = nan(size(y));

        validXY = isfinite(x) & isfinite(y);

        [lat(validXY), lon(validXY)] = ...
            projinv(crs, x(validXY), y(validXY));

    else

        % 对部分 MATLAB 版本/旧 shp 元数据做保守处理。
        validXY = isfinite(x) & isfinite(y);

        if any(validXY) && ...
           max(abs(x(validXY))) <= 180 && ...
           max(abs(y(validXY))) <= 90

            lon = x;
            lat = y;

        else
            error('无法识别 Shapefile 的坐标参考系。');
        end
    end

    boundaryLon = [boundaryLon; lon; NaN]; %#ok<AGROW>
    boundaryLat = [boundaryLat; lat; NaN]; %#ok<AGROW>
end

if all(isnan(boundaryLon)) || all(isnan(boundaryLat))
    error('未得到有效的郑州边界经纬度。');
end

end
