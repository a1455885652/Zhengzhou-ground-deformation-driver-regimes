%% run_clip_monthly_cumulative_and_export_txt.m
% 功能：
% 1) 将 Cumulative_month_end_scenario 中所有月末累计形变 GeoTIFF
%    按郑州市行政边界 shp 裁剪：
%       - 先裁到郑州市外接矩形
%       - 再将行政边界外像元置为 NaN
% 2) 将指定 8 个月的裁剪后 TIF 转成 TXT：
%       第1列 经度
%       第2列 纬度
%       第3列 累计形变值
%    并删除所有 NaN / Inf 行。
%
% MATLAB R2023b
% Mapping Toolbox
%
% 说明：
% - 本脚本不改变形变数值、不改变正负号、不做空间插值。
% - TXT 无表头，可直接作为 GMT xyz 数据使用。
% - 所有函数均为独立 .m 文件，没有在脚本末尾定义函数。

clear;
clc;

% 1. 路径

inputDir = ...
    zz_external_path('insar_raster', 'Cumulative_month_end_scenario');

shpFile = ...
    zz_external_path('zhengzhou_shp');

clippedDir = ...
    zz_external_path('insar_raster', 'Cumulative_month_end_scenario_Zhengzhou');

txtDir = fullfile(clippedDir, 'TXT_8months');

if ~isfolder(clippedDir)
    mkdir(clippedDir);
end

if ~isfolder(txtDir)
    mkdir(txtDir);
end

% 2. 需要输出 TXT 的 8 个月

requiredMonths = [ ...
    "201812"
    "201912"
    "202012"
    "202106"
    "202202"
    "202312"
    "202412"
    "202512"];

% 把 "202202" 改成 "202212" 即可。

% 3. 检查输入

if ~isfolder(inputDir)
    error('月末累计形变目录不存在：\n%s', inputDir);
end

if ~isfile(shpFile)
    error('郑州边界 shp 不存在：\n%s', shpFile);
end

files = [ ...
    dir(fullfile(inputDir, '*.tif')); ...
    dir(fullfile(inputDir, '*.tiff'))];

if isempty(files)
    error('输入目录中没有找到 tif/tiff：\n%s', inputDir);
end

fprintf('============================================================\n');
fprintf('郑州市月末累计形变裁剪 + 8个月 TXT 导出\n');
fprintf('============================================================\n');
fprintf('输入 TIF 数量：%d\n', numel(files));
fprintf('输入目录：%s\n', inputDir);
fprintf('郑州边界：%s\n', shpFile);
fprintf('裁剪输出：%s\n', clippedDir);
fprintf('TXT 输出：%s\n\n', txtDir);

% 4. 读取郑州市边界

[boundaryLon, boundaryLat] = read_shapefile_lonlat(shpFile);

fprintf('郑州边界范围：\n');
fprintf('  Longitude: %.8f ~ %.8f\n', ...
    min(boundaryLon, [], 'omitnan'), max(boundaryLon, [], 'omitnan'));
fprintf('  Latitude : %.8f ~ %.8f\n\n', ...
    min(boundaryLat, [], 'omitnan'), max(boundaryLat, [], 'omitnan'));

% 5. 裁剪全部月末累计形变

fprintf('开始裁剪全部月末累计形变...\n\n');

for i = 1:numel(files)

    inFile = fullfile(files(i).folder, files(i).name);
    outFile = fullfile(clippedDir, files(i).name);

    fprintf('[%d/%d] %s\n', i, numel(files), files(i).name);

    clip_geotiff_by_polygon( ...
        inFile, ...
        outFile, ...
        boundaryLon, ...
        boundaryLat);

end

fprintf('\n全部 TIF 已裁剪完成。\n\n');

% 6. 将指定 8 个月的裁剪后 TIF 导出为 TXT

fprintf('============================================================\n');
fprintf('开始导出 8 个月 TXT\n');
fprintf('============================================================\n\n');

exportLogMonth = strings(numel(requiredMonths),1);
exportLogTif   = strings(numel(requiredMonths),1);
exportLogTxt   = strings(numel(requiredMonths),1);
exportLogCount = zeros(numel(requiredMonths),1);
exportLogState = strings(numel(requiredMonths),1);

for k = 1:numel(requiredMonths)

    ym = requiredMonths(k);

    exportLogMonth(k) = ym;

    % 优先匹配上一步代码生成的标准命名
    tifFile = fullfile(clippedDir, ...
        sprintf('Cumulative_%s.tif', ym));

    % 如果文件名不是标准命名，则在裁剪目录中自动搜索该 YYYYMM
    if ~isfile(tifFile)

        candidates = dir(fullfile(clippedDir, ...
            sprintf('*%s*.tif', ym)));

        if isempty(candidates)
            candidates = dir(fullfile(clippedDir, ...
                sprintf('*%s*.tiff', ym)));
        end

        if isempty(candidates)

            fprintf('[缺失] %s：找不到对应裁剪 TIF。\n', ym);
            exportLogState(k) = "Missing";
            continue;

        elseif numel(candidates) > 1

            warning('月份 %s 匹配到多个文件，使用第一个：%s', ...
                ym, candidates(1).name);
        end

        tifFile = fullfile( ...
            candidates(1).folder, candidates(1).name);
    end

    txtFile = fullfile(txtDir, ...
        sprintf('Cumulative_%s.txt', ym));

    fprintf('[%d/8] %s\n', k, ym);
    fprintf('  TIF: %s\n', tifFile);

    nValid = export_geotiff_to_lonlatvalue_txt( ...
        tifFile, txtFile);

    fprintf('  TXT: %s\n', txtFile);
    fprintf('  有效像元：%d\n\n', nValid);

    exportLogTif(k)   = string(tifFile);
    exportLogTxt(k)   = string(txtFile);
    exportLogCount(k) = nValid;
    exportLogState(k) = "OK";

end

% 7. 保存导出日志

logTable = table( ...
    exportLogMonth, ...
    exportLogTif, ...
    exportLogTxt, ...
    exportLogCount, ...
    exportLogState, ...
    'VariableNames', { ...
        'Month', ...
        'Input_Clipped_TIF', ...
        'Output_TXT', ...
        'Valid_Pixel_Count', ...
        'Status'});

logFile = fullfile(txtDir, 'TXT_Export_Log.csv');
writetable(logTable, logFile);

fprintf('============================================================\n');
fprintf('全部处理完成。\n');
fprintf('============================================================\n');
fprintf('裁剪 TIF：\n%s\n\n', clippedDir);
fprintf('8个月 TXT：\n%s\n\n', txtDir);
fprintf('导出日志：\n%s\n', logFile);
