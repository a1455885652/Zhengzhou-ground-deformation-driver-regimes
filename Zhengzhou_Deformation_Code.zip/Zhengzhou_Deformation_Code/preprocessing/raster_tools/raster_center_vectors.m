function [lonVec,latVec] = raster_center_vectors(R,nRows,nCols)
dLon=diff(R.LongitudeLimits)/nCols; dLat=diff(R.LatitudeLimits)/nRows;
lonVec=R.LongitudeLimits(1)+((1:nCols)-0.5)*dLon;
if strcmpi(string(R.ColumnsStartFrom),'north')
    latVec=R.LatitudeLimits(2)-((1:nRows)-0.5)*dLat;
else
    latVec=R.LatitudeLimits(1)+((1:nRows)-0.5)*dLat;
end
end
