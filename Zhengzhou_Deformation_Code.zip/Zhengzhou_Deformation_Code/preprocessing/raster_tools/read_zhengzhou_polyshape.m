function P = read_zhengzhou_polyshape(shpFile)
%READ_ZHENGZHOU_POLYSHAPE
% 读取 polygon shapefile，并构造一个总 polyshape。
%
% 特点：
% - 支持多个 shp 要素；
% - 支持 NaN 分隔的多部件边界；
% - 自动清理首尾/连续 NaN，避免产生“点数少于3”的空边界警告；
% - 若 shp 为投影坐标，则转换为经纬度。

S = shaperead(shpFile);

if isempty(S)
    error('Shapefile 中没有要素：%s', shpFile);
end

info = shapeinfo(shpFile);

crs = [];
if isfield(info, 'CoordinateReferenceSystem')
    crs = info.CoordinateReferenceSystem;
end

P = polyshape();

for k = 1:numel(S)

    if ~isfield(S, 'X') || ~isfield(S, 'Y')
        error('Shapefile 中不存在 X/Y 坐标字段。');
    end

    x = double(S(k).X(:));
    y = double(S(k).Y(:));

    % 把任意单边 NaN 统一变成一对 NaN
    bad = isnan(x) | isnan(y);
    x(bad) = NaN;
    y(bad) = NaN;

    % 如果 shp 是投影坐标，先对每个有限点做 projinv
    finiteXY = isfinite(x) & isfinite(y);

    if isempty(crs)

        if any(finiteXY) && ...
           max(abs(x(finiteXY))) <= 180 && ...
           max(abs(y(finiteXY))) <= 90

            lon = x;
            lat = y;
        else
            error('Shapefile 缺少 CRS，且坐标不像经纬度。');
        end

    elseif isa(crs, 'geocrs')

        lon = x;
        lat = y;

    elseif isa(crs, 'projcrs')

        lon = nan(size(x));
        lat = nan(size(y));

        [lat(finiteXY), lon(finiteXY)] = ...
            projinv(crs, x(finiteXY), y(finiteXY));

    else

        if any(finiteXY) && ...
           max(abs(x(finiteXY))) <= 180 && ...
           max(abs(y(finiteXY))) <= 90

            lon = x;
            lat = y;
        else
            error('无法识别 Shapefile 坐标参考系。');
        end
    end

    % 清理 NaN：
    % 1) 删除开头/结尾 NaN
    % 2) 连续多个 NaN 只保留一个
    if isempty(lon)
        continue;
    end

    keep = true(size(lon));

    for i = 2:numel(lon)
        if isnan(lon(i)) && isnan(lon(i-1))
            keep(i) = false;
        end
    end

    lon = lon(keep);
    lat = lat(keep);

    while ~isempty(lon) && isnan(lon(1))
        lon(1) = [];
        lat(1) = [];
    end

    while ~isempty(lon) && isnan(lon(end))
        lon(end) = [];
        lat(end) = [];
    end

    if isempty(lon)
        continue;
    end

    % 构造当前要素
    pk = polyshape(lon, lat, 'Simplify', true);

    if pk.NumRegions > 0
        if P.NumRegions == 0
            P = pk;
        else
            P = union(P, pk);
        end
    end
end

if P.NumRegions == 0
    error('没有从郑州 shp 构建出有效 polygon。');
end

end
