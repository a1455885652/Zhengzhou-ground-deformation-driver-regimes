%% run_clip_8months_zhengzhou_v3.m
% 仅处理 8 个目标月份：
% 2018-12, 2019-12, 2020-12,
% 2021-06, 2022-02, 2023-12,
% 2024-12, 2025-12
%
% 功能：
% 1) 只读取这 8 个月的月末累计形变 GeoTIFF；
% 3) 行政边界外设为 NaN；
% 4) 郑州掩膜只计算一次，后续 7 幅直接复用；
% 5) 不使用 polyshape / isinterior，避免复杂边界导致内存爆炸；
% 6) 使用“分块 inpolygon”建立掩膜，内存占用很低；
% 7) 每幅裁剪后的 TIF 同时导出 TXT：
%       第1列 Longitude
%       第2列 Latitude
%       第3列 Value
%    自动删除所有 NaN / Inf。
%
% MATLAB R2023b + Mapping Toolbox
%
% 注意：
% 当前按 2022-02 处理。

clear;
clc;

% 1. 路径

inputDir = ...
    zz_external_path('insar_raster', 'Cumulative_month_end_scenario');

shpFile = ...
    zz_external_path('zhengzhou_shp');

outputDir = ...
    zz_external_path('insar_raster', 'Cumulative_8months_Zhengzhou');

txtDir = fullfile(outputDir, 'TXT_8months');

if ~isfolder(outputDir)
    mkdir(outputDir);
end

if ~isfolder(txtDir)
    mkdir(txtDir);
end

% 2. 仅处理这 8 个月

requiredMonths = [ ...
    "201812"
    "201912"
    "202012"
    "202106"
    "202202"
    "202312"
    "202412"
    "202512"];

% 3. 分块大小
% 每次只对这么多行计算 inpolygon。
% 256 一般已经很省内存。
% 如果仍觉得内存高，可以改成 128 或 64。

blockRows = 256;

% 4. 输入检查

if ~isfolder(inputDir)
    error('输入目录不存在：\n%s', inputDir);
end

if ~isfile(shpFile)
    error('郑州市边界 shp 不存在：\n%s', shpFile);
end

fprintf('============================================================\n');
fprintf('8个月累计形变：郑州裁剪 + TXT导出（低内存版）\n');
fprintf('============================================================\n\n');

% 5. 自动寻找 8 个输入 TIF

inputFiles = strings(numel(requiredMonths),1);

for k = 1:numel(requiredMonths)

    ym = requiredMonths(k);

    % 优先匹配标准命名
    f = fullfile(inputDir, sprintf('Cumulative_%s.tif', ym));

    if isfile(f)
        inputFiles(k) = string(f);
        continue;
    end

    % 否则搜索包含 YYYYMM 的 tif/tiff
    candidates = [ ...
        dir(fullfile(inputDir, sprintf('*%s*.tif', ym))); ...
        dir(fullfile(inputDir, sprintf('*%s*.tiff', ym)))];

    if isempty(candidates)
        error('找不到月份 %s 对应的 TIF：\n%s', ym, inputDir);
    end

    if numel(candidates) > 1
        warning('月份 %s 匹配到多个文件，使用第一个：%s', ...
            ym, candidates(1).name);
    end

    inputFiles(k) = string(fullfile( ...
        candidates(1).folder, candidates(1).name));
end

fprintf('目标文件：\n');
for k = 1:numel(requiredMonths)
    fprintf('  %s -> %s\n', requiredMonths(k), inputFiles(k));
end
fprintf('\n');

% 6. 读取郑州边界为经纬度

fprintf('[准备 1/2] 读取郑州市 shp...\n');

[boundaryLon, boundaryLat] = ...
    read_zhengzhou_boundary_lonlat(shpFile);

minLon = min(boundaryLon, [], 'omitnan');
maxLon = max(boundaryLon, [], 'omitnan');
minLat = min(boundaryLat, [], 'omitnan');
maxLat = max(boundaryLat, [], 'omitnan');

fprintf('  Lon: %.8f ~ %.8f\n', minLon, maxLon);
fprintf('  Lat: %.8f ~ %.8f\n\n', minLat, maxLat);

% 7. 第一幅影像：确定裁剪范围和统一空间参考

fprintf('[准备 2/2] 建立郑州市行政区掩膜...\n');

[firstA, R0] = readgeoraster(char(inputFiles(1)));

if ndims(firstA) > 2
    firstA = firstA(:,:,1);
end

if ~contains(class(R0), 'Geographic', 'IgnoreCase', true)
    error(['累计形变 TIF 不是 Geographic 经纬度栅格。\n' ...
           '当前代码按经纬度 GeoTIFF 编写。']);
end

latlim = [ ...
    max(minLat, R0.LatitudeLimits(1)), ...
    min(maxLat, R0.LatitudeLimits(2))];

lonlim = [ ...
    max(minLon, R0.LongitudeLimits(1)), ...
    min(maxLon, R0.LongitudeLimits(2))];

if latlim(1) >= latlim(2) || lonlim(1) >= lonlim(2)
    error('郑州 shp 与累计形变栅格没有空间交集。');
end

% 先只裁到郑州外接矩形，不做任何重采样。
[firstCrop, Rcrop] = geocrop(single(firstA), R0, latlim, lonlim);

fprintf('  外接矩形裁剪后尺寸：%d × %d\n', ...
    size(firstCrop,1), size(firstCrop,2));

% 低内存地建立真实行政边界 mask。
insideMask = build_mask_inpolygon_chunked( ...
    Rcrop, boundaryLon, boundaryLat, blockRows);

fprintf('  郑州市行政区内像元：%d\n\n', nnz(insideMask));

clear firstA firstCrop boundaryLon boundaryLat;

% 8. 逐月裁剪并导出

logMonth = strings(numel(requiredMonths),1);
logTif   = strings(numel(requiredMonths),1);
logTxt   = strings(numel(requiredMonths),1);
logCount = zeros(numel(requiredMonths),1);

for k = 1:numel(requiredMonths)

    ym = requiredMonths(k);
    inFile = char(inputFiles(k));

    outTif = fullfile(outputDir, ...
        sprintf('Cumulative_%s_Zhengzhou.tif', ym));

    outTxt = fullfile(txtDir, ...
        sprintf('Cumulative_%s_Zhengzhou.txt', ym));

    fprintf('------------------------------------------------------------\n');
    fprintf('[%d/8] %s\n', k, ym);

    [A, R] = readgeoraster(inFile);

    if ndims(A) > 2
        A = A(:,:,1);
    end

    A = single(A);

    % NoData -> NaN
    try
        rasterInfo = georasterinfo(inFile);
        nodata = rasterInfo.MissingDataIndicator;

        if ~isempty(nodata)
            nodata = double(nodata(1));

            if isfinite(nodata)
                A(double(A) == nodata) = NaN;
            end
        end
    catch
    end

    % 检查 8 幅影像网格完全一致
    sameGrid = ...
        isequal(R.RasterSize, R0.RasterSize) && ...
        max(abs(R.LatitudeLimits - R0.LatitudeLimits)) < 1e-10 && ...
        max(abs(R.LongitudeLimits - R0.LongitudeLimits)) < 1e-10;

    if ~sameGrid
        error(['月份 %s 的栅格网格与第一幅影像不一致。\n' ...
               '为避免裁剪错位，程序停止。'], ym);
    end

    % 仅裁到外接矩形
    [Acrop, Rthis] = geocrop(A, R, latlim, lonlim);

    if ~isequal(size(Acrop), size(insideMask))
        error('月份 %s 的裁剪尺寸与郑州掩膜不一致。', ym);
    end

    % 行政区外设为 NaN
    Acrop(~insideMask) = NaN;

    % 写裁剪 TIF
    write_geotiff_keep_crs(inFile, outTif, Acrop, Rthis);

    % 直接从内存中的 Acrop 写 TXT，避免再读一次 TIF
    nValid = export_cropped_grid_to_txt_lowmem( ...
        Acrop, Rthis, outTxt, blockRows);

    fprintf('  TIF : %s\n', outTif);
    fprintf('  TXT : %s\n', outTxt);
    fprintf('  有效点数：%d\n', nValid);

    logMonth(k) = ym;
    logTif(k)   = string(outTif);
    logTxt(k)   = string(outTxt);
    logCount(k) = nValid;

    clear A Acrop R Rthis;
end

% 9. 日志

T = table( ...
    logMonth, ...
    logTif, ...
    logTxt, ...
    logCount, ...
    'VariableNames', { ...
        'Month', ...
        'Clipped_TIF', ...
        'TXT', ...
        'Valid_Point_Count'});

logFile = fullfile(outputDir, 'Eight_Months_Export_Log.csv');
writetable(T, logFile);

fprintf('\n============================================================\n');
fprintf('全部完成。\n');
fprintf('============================================================\n');
fprintf('裁剪 TIF：\n%s\n\n', outputDir);
fprintf('TXT：\n%s\n\n', txtDir);
fprintf('日志：\n%s\n', logFile);
