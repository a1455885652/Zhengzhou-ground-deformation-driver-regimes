function dateCode = parse_sarscape_disp_date(fileName)
% PARSE_SARSCAPE_DISP_DATE
% G_SI_YYYYMMDD_XXX_disp_geo -> YYYYMMDD

token = regexp( ...
    char(string(fileName)), ...
    'G_SI_(\d{8})_', ...
    'tokens', ...
    'once');

if isempty(token)
    error('无法解析日期：%s', string(fileName));
end

dateCode = string(token{1});

end
