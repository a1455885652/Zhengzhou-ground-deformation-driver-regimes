function value = read_envi_numeric_field(textData, fieldName)
% READ_ENVI_NUMERIC_FIELD

pattern = ...
    ['(?im)^\s*' ...
    regexptranslate('escape', fieldName) ...
    '\s*=\s*([^\r\n]+)'];

token = regexp( ...
    textData, ...
    pattern, ...
    'tokens', ...
    'once');

if isempty(token)
    error('ENVI header 中找不到字段：%s', fieldName);
end

valueText = strtrim(token{1});
valueText = erase(valueText, '{');
valueText = erase(valueText, '}');

value = str2double(valueText);

if ~isfinite(value)
    error('无法解析字段 %s：%s', ...
        fieldName, valueText);
end

end
