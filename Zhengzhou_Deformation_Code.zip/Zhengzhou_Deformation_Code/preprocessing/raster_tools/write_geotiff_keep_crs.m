function write_geotiff_keep_crs(sourceTif, outputTif, A, R)
%WRITE_GEOTIFF_KEEP_CRS
% 写出 GeoTIFF，并尽量保留源文件 CRS。

try
    info = geotiffinfo(sourceTif);

    if isfield(info, 'GeoTIFFTags') && ...
       isfield(info.GeoTIFFTags, 'GeoKeyDirectoryTag')

        geotiffwrite( ...
            outputTif, ...
            A, ...
            R, ...
            'GeoKeyDirectoryTag', ...
            info.GeoTIFFTags.GeoKeyDirectoryTag);
    else
        geotiffwrite(outputTif, A, R);
    end

catch ME
    error('写出 GeoTIFF 失败：\n%s\n%s', ...
        outputTif, ME.message);
end

end
