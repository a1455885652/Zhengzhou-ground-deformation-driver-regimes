function nValid = export_cropped_grid_to_txt_lowmem( ...
    A, R, txtFile, blockRows)
%EXPORT_CROPPED_GRID_TO_TXT_LOWMEM
% 低内存导出：
% 第1列 Longitude
% 第2列 Latitude
% 第3列 Value
%
% 分块生成经纬度并立即写入 TXT，不创建全图 coordinate grids。
% 自动删除 NaN / Inf，无表头。

nRows = size(A,1);
nCols = size(A,2);

fid = fopen(txtFile, 'w');

if fid < 0
    error('无法创建 TXT：%s', txtFile);
end

cleaner = onCleanup(@() fclose(fid));

nValid = 0;
nBlocks = ceil(nRows / blockRows);

for ib = 1:nBlocks

    r1 = (ib-1)*blockRows + 1;
    r2 = min(ib*blockRows, nRows);
    rows = r1:r2;

    blockA = double(A(rows,:));

    [colGrid, rowGrid] = meshgrid(1:nCols, rows);

    [latBlock, lonBlock] = intrinsicToGeographic( ...
        R, colGrid, rowGrid);

    valid = ...
        isfinite(blockA) & ...
        isfinite(lonBlock) & ...
        isfinite(latBlock);

    if any(valid(:))

        lon = lonBlock(valid);
        lat = latBlock(valid);
        val = blockA(valid);

        fprintf(fid, '%.8f\t%.8f\t%.6f\n', ...
            [lon(:), lat(:), val(:)].');

        nValid = nValid + numel(val);
    end

    clear blockA colGrid rowGrid latBlock lonBlock valid lon lat val;
end

end
