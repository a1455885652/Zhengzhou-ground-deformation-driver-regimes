function nValid = export_cropped_grid_to_txt(A, R, txtFile)
%EXPORT_CROPPED_GRID_TO_TXT
% 将已经裁剪好的栅格直接输出为 GMT 可读 XYZ TXT：
%
% 第1列：Longitude
% 第2列：Latitude
% 第3列：Value
%
% 删除全部 NaN / Inf。
% 无表头。

A = double(A);

[latGrid, lonGrid] = geographicGrid(R);

valid = ...
    isfinite(lonGrid) & ...
    isfinite(latGrid) & ...
    isfinite(A);

lon = lonGrid(valid);
lat = latGrid(valid);
val = A(valid);

nValid = numel(val);

fid = fopen(txtFile, 'w');

if fid < 0
    error('无法创建 TXT：%s', txtFile);
end

cleaner = onCleanup(@() fclose(fid));

if nValid == 0
    return;
end

% 一次性按列写出，速度比逐行循环快。
fprintf(fid, '%.8f\t%.8f\t%.6f\n', ...
    [lon(:), lat(:), val(:)].');

end
