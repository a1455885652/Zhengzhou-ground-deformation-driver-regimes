function nValid = export_geotiff_to_lonlatvalue_txt(tifFile, txtFile)
%EXPORT_GEOTIFF_TO_LONLATVALUE_TXT
% 将地理坐标 GeoTIFF 导出为无表头 TXT：
%
% 第1列：Longitude
% 第2列：Latitude
% 第3列：Value
%
% 自动删除：
% - NaN
% - +Inf
% - -Inf

if ~isfile(tifFile)
    error('GeoTIFF 不存在：%s', tifFile);
end

[A, R] = readgeoraster(tifFile);

if ndims(A) > 2
    if size(A,3) ~= 1
        error('当前代码只支持单波段栅格：%s', tifFile);
    end
    A = A(:,:,1);
end

A = double(A);

if ~contains(class(R), 'Geographic', 'IgnoreCase', true)
    error([ ...
        '栅格不是地理经纬度参考，无法直接输出经纬度：\n%s'], ...
        tifFile);
end

% NoData -> NaN
try
    rInfo = georasterinfo(tifFile);

    if isprop(rInfo, 'MissingDataIndicator')
        nodata = rInfo.MissingDataIndicator;
    elseif isfield(rInfo, 'MissingDataIndicator')
        nodata = rInfo.MissingDataIndicator;
    else
        nodata = [];
    end

    if ~isempty(nodata)
        nodata = double(nodata(1));

        if isfinite(nodata)
            A(A == nodata) = NaN;
        end
    end
catch
end

[latGrid, lonGrid] = geographicGrid(R);

valid = ...
    isfinite(lonGrid) & ...
    isfinite(latGrid) & ...
    isfinite(A);

lon = lonGrid(valid);
lat = latGrid(valid);
val = A(valid);

nValid = numel(val);

if nValid == 0
    warning('没有有效像元：%s', tifFile);

    fid = fopen(txtFile, 'w');
    if fid >= 0
        fclose(fid);
    end
    return;
end

fid = fopen(txtFile, 'w');

if fid < 0
    error('无法创建 TXT：%s', txtFile);
end

cleaner = onCleanup(@() fclose(fid));

% 无表头，适合 GMT xyz 数据输入。
% 经度/纬度 8 位小数，形变值 6 位小数。
fprintf(fid, '%.8f\t%.8f\t%.6f\n', ...
    [lon(:), lat(:), val(:)].');

end
