function [boundaryLon, boundaryLat] = read_zhengzhou_boundary_lonlat(shpFile)
%READ_ZHENGZHOU_BOUNDARY_LONLAT
% 读取 polygon shapefile，并统一转成经纬度。
% 不使用 polyshape。
% 不同要素/部件用 NaN 分隔。

S = shaperead(shpFile);

if isempty(S)
    error('Shapefile 中没有读取到任何要素：%s', shpFile);
end

info = shapeinfo(shpFile);

crs = [];
if isfield(info, 'CoordinateReferenceSystem')
    crs = info.CoordinateReferenceSystem;
end

boundaryLon = [];
boundaryLat = [];

for k = 1:numel(S)

    if ~isfield(S, 'X') || ~isfield(S, 'Y')
        error('Shapefile 中不存在 X/Y 字段。');
    end

    x = double(S(k).X(:));
    y = double(S(k).Y(:));

    % X/Y 中只要有一个为 NaN，就都设为 NaN。
    invalid = isnan(x) | isnan(y);
    x(invalid) = NaN;
    y(invalid) = NaN;

    finiteXY = isfinite(x) & isfinite(y);

    if isempty(crs)

        if any(finiteXY) && ...
           max(abs(x(finiteXY))) <= 180 && ...
           max(abs(y(finiteXY))) <= 90

            lon = x;
            lat = y;
        else
            error('Shapefile 缺少 CRS，而且坐标不像经纬度。');
        end

    elseif isa(crs, 'geocrs')

        lon = x;
        lat = y;

    elseif isa(crs, 'projcrs')

        lon = nan(size(x));
        lat = nan(size(y));

        [lat(finiteXY), lon(finiteXY)] = ...
            projinv(crs, x(finiteXY), y(finiteXY));

    else

        if any(finiteXY) && ...
           max(abs(x(finiteXY))) <= 180 && ...
           max(abs(y(finiteXY))) <= 90

            lon = x;
            lat = y;
        else
            error('无法识别 Shapefile 坐标参考系。');
        end
    end

    % 清理连续 NaN，避免空部件
    keep = true(size(lon));

    for i = 2:numel(lon)
        if isnan(lon(i)) && isnan(lon(i-1))
            keep(i) = false;
        end
    end

    lon = lon(keep);
    lat = lat(keep);

    % 删除头尾 NaN
    while ~isempty(lon) && isnan(lon(1))
        lon(1) = [];
        lat(1) = [];
    end

    while ~isempty(lon) && isnan(lon(end))
        lon(end) = [];
        lat(end) = [];
    end

    if isempty(lon)
        continue;
    end

    boundaryLon = [boundaryLon; lon; NaN]; %#ok<AGROW>
    boundaryLat = [boundaryLat; lat; NaN]; %#ok<AGROW>
end

if isempty(boundaryLon)
    error('没有获得有效郑州边界坐标。');
end

end
