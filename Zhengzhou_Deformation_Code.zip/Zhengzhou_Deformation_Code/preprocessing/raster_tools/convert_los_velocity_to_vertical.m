%% convert_los_velocity_to_vertical.m
% Zhengzhou Sentinel-1 SBAS-InSAR
% LOS deformation velocity -> approximate vertical velocity
%
% 假设：
%   水平形变相对于垂直形变可以忽略
%
% 公式：
%   V_vertical = V_LOS / cos(incidenceAngle)
%
% 输入：
% G_SI_velocity_geo
%
% 输出：
% G_SI_velocity_vertical_geo
%
% MATLAB R2023b

clear;
clc;

fprintf('====================================================\n');
fprintf(' Zhengzhou LOS -> Vertical Velocity Conversion\n');
fprintf('====================================================\n\n');

%% 1. 输入输出

inputFile = ...
    zz_external_path('insar_raster', 'G_SI_velocity_geo');

outputFile = ...
    zz_external_path('insar_raster', 'G_SI_velocity_vertical_geo');

inputHdr = [inputFile '.hdr'];
outputHdr = [outputFile '.hdr'];

%% 2. Sentinel-1 入射角

incidenceAngle = 42.108257903;

scaleFactor = 1 / cosd(incidenceAngle);

fprintf('Incidence angle : %.12f deg\n', incidenceAngle);
fprintf('Scale factor    : %.12f\n\n', scaleFactor);

%% 3. 检查文件

if ~isfile(inputFile)
    error('找不到数据文件：\n%s', inputFile);
end

if ~isfile(inputHdr)
    error('找不到 ENVI 头文件：\n%s', inputHdr);
end

%% 4. 读取 ENVI Header

info = read_envi_header_basic(inputHdr);

fprintf('ENVI raster information:\n');
fprintf('  Samples       = %d\n', info.samples);
fprintf('  Lines         = %d\n', info.lines);
fprintf('  Bands         = %d\n', info.bands);
fprintf('  Data type     = %d\n', info.dataType);
fprintf('  Byte order    = %d\n', info.byteOrder);
fprintf('  Header offset = %d\n', info.headerOffset);
fprintf('  Interleave    = %s\n\n', info.interleave);

if info.bands ~= 1
    error('当前程序要求单波段数据，但当前 bands = %d。', ...
        info.bands);
end

%% 5. ENVI 数据类型

precision = envi_data_type_to_matlab(info.dataType);

%% 6. 字节序

if info.byteOrder == 0

    machineFormat = 'ieee-le';

elseif info.byteOrder == 1

    machineFormat = 'ieee-be';

else

    error('无法识别 ENVI byte order = %d。', ...
        info.byteOrder);

end

%% 7. 读取 LOS velocity

fprintf('Reading LOS velocity raster...\n');

fid = fopen(inputFile, 'r', machineFormat);

if fid == -1
    error('无法打开：\n%s', inputFile);
end

status = fseek(fid, info.headerOffset, 'bof');

if status ~= 0
    fclose(fid);
    error('无法跳转到 ENVI 数据起始位置。');
end

rawData = fread( ...
    fid, ...
    [info.samples, info.lines], ...
    ['*' precision]);

fclose(fid);

expectedCount = info.samples * info.lines;

if numel(rawData) ~= expectedCount
    error( ...
        ['数据数量错误。\n' ...
         'Header预期：%d 个像元\n' ...
         '实际读取：%d 个像元'], ...
        expectedCount, numel(rawData));
end

% ENVI文件逐行保存。
% fread返回 samples × lines，
% 转置后恢复为 MATLAB 的 lines × samples。
velocityLOS = double(rawData');

clear rawData;

fprintf('Reading finished.\n');
fprintf('Raster size = %d × %d\n\n', ...
    size(velocityLOS,1), ...
    size(velocityLOS,2));

%% 8. 构建有效值掩膜

validMask = isfinite(velocityLOS);

if info.hasIgnoreValue

    ignoreValue = info.ignoreValue;

    validMask = validMask & ...
        velocityLOS ~= ignoreValue;

    fprintf('Data ignore value = %.12g\n', ignoreValue);

end

nValid = nnz(validMask);

if nValid == 0
    error('没有检测到任何有效形变像元。');
end

fprintf('Valid pixels = %d\n\n', nValid);

%% 9. LOS 原始统计

losValues = velocityLOS(validMask);

fprintf('---------------- LOS velocity ----------------\n');
fprintf('Min    = %.6f\n', min(losValues));
fprintf('Max    = %.6f\n', max(losValues));
fprintf('Mean   = %.6f\n', mean(losValues));
fprintf('Median = %.6f\n', median(losValues));
fprintf('Std    = %.6f\n\n', std(losValues));

%% 10. LOS -> 垂直

velocityVertical = velocityLOS;

velocityVertical(validMask) = ...
    velocityLOS(validMask) ./ cosd(incidenceAngle);

%% 11. 保持 NoData

if info.hasIgnoreValue

    velocityVertical(~validMask) = ...
        info.ignoreValue;

else

    velocityVertical(~validMask) = NaN;

end

%% 12. 垂直速度统计

verticalValues = velocityVertical(validMask);

fprintf('-------------- Vertical velocity -------------\n');
fprintf('Min    = %.6f\n', min(verticalValues));
fprintf('Max    = %.6f\n', max(verticalValues));
fprintf('Mean   = %.6f\n', mean(verticalValues));
fprintf('Median = %.6f\n', median(verticalValues));
fprintf('Std    = %.6f\n\n', std(verticalValues));

%% 13. 输出检查

% 对形变速度而言，通常应该是 float32 或 float64。
% 如果原始是整数类型，不建议直接写回整数。
if ~ismember(info.dataType, [4, 5])

    error( ...
        ['原始 velocity 的 ENVI data type = %d，' ...
         '不是 float32/float64。\n' ...
         '为避免垂直转换后的小数被截断，请先把头文件内容发给我检查。'], ...
        info.dataType);

end

%% 14. 写入输出二进制文件

fprintf('Writing vertical velocity raster...\n');

fid = fopen(outputFile, 'w', machineFormat);

if fid == -1
    error('无法创建输出文件：\n%s', outputFile);
end

% 保持与源文件相同的 header offset
if info.headerOffset > 0

    fwrite( ...
        fid, ...
        zeros(info.headerOffset,1,'uint8'), ...
        'uint8');

end

if info.dataType == 4

    outputData = single(velocityVertical);

    countWritten = fwrite( ...
        fid, ...
        outputData', ...
        'single');

elseif info.dataType == 5

    outputData = double(velocityVertical);

    countWritten = fwrite( ...
        fid, ...
        outputData', ...
        'double');

end

fclose(fid);

if countWritten ~= expectedCount

    error( ...
        ['输出写入数量不正确。\n' ...
         '预期：%d\n' ...
         '写入：%d'], ...
        expectedCount, countWritten);

end

clear outputData;

%% 15. 复制原始 HDR

copyfile(inputHdr, outputHdr, 'f');

%% 16. 最终信息

fprintf('\n====================================================\n');
fprintf('Conversion completed successfully.\n');
fprintf('====================================================\n');

fprintf('\nFormula:\n');
fprintf('V_vertical = V_LOS / cos(theta)\n');
fprintf('theta      = %.9f deg\n', incidenceAngle);
fprintf('factor     = %.9f\n', scaleFactor);

fprintf('\nInput:\n%s\n', inputFile);

fprintf('\nOutput:\n%s\n', outputFile);
fprintf('%s\n', outputHdr);

fprintf('\nExample conversion:\n');
fprintf('  5  -> %.3f\n',  5 * scaleFactor);
fprintf('  8  -> %.3f\n',  8 * scaleFactor);
fprintf(' 10  -> %.3f\n', 10 * scaleFactor);
fprintf(' 15  -> %.3f\n', 15 * scaleFactor);
fprintf(' 20  -> %.3f\n', 20 * scaleFactor);

fprintf('\nOriginal file was NOT modified.\n');
fprintf('====================================================\n');
