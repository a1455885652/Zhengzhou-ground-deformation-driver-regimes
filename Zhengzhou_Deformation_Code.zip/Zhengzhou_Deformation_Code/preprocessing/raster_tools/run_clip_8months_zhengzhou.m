%% run_clip_8months_zhengzhou.m
% 仅裁剪论文 3×3 图所需的 8 个月累计形变结果
%
% 功能：
%   1. 只读取 8 个目标月份，不再处理全部月份；
%   3. 郑州边界外像元设为 NaN；
%   4. 不改变原始形变值、不改变正负号、不做空间插值；
%   5. 8 个栅格若网格一致，只计算一次郑州掩膜，速度明显更快。
%
% MATLAB R2023b + Mapping Toolbox
%
% 注意：
%   当前按 2022-02 处理。如果实际需要 2022-12，
%   将 requiredMonths 中 "202202" 改为 "202212"。

clear;
clc;

% 1. 路径

inputDir = ...
    zz_external_path('insar_raster', 'Cumulative_month_end_scenario');

shpFile = ...
    zz_external_path('zhengzhou_shp');

outputDir = ...
    zz_external_path('insar_raster', 'Cumulative_8months_Zhengzhou');

if ~isfolder(outputDir)
    mkdir(outputDir);
end

% 2. 仅处理这 8 个月

requiredMonths = [ ...
    "201812"
    "201912"
    "202012"
    "202106"
    "202202"
    "202312"
    "202412"
    "202512"];

% 3. 检查输入

if ~isfolder(inputDir)
    error('输入目录不存在：\n%s', inputDir);
end

if ~isfile(shpFile)
    error('郑州市边界 shp 不存在：\n%s', shpFile);
end

fprintf('============================================================\n');
fprintf('仅裁剪 8 个月累计形变到郑州市行政区域\n');
fprintf('============================================================\n\n');

% 4. 找到 8 个输入 TIF

inputFiles = strings(numel(requiredMonths), 1);

for k = 1:numel(requiredMonths)

    ym = requiredMonths(k);

    % 优先使用标准文件名
    f = fullfile(inputDir, sprintf('Cumulative_%s.tif', ym));

    if isfile(f)
        inputFiles(k) = string(f);
        continue;
    end

    % 若不是标准文件名，则自动搜索包含 YYYYMM 的 tif/tiff
    c = [ ...
        dir(fullfile(inputDir, sprintf('*%s*.tif', ym))); ...
        dir(fullfile(inputDir, sprintf('*%s*.tiff', ym)))];

    if isempty(c)
        error('找不到月份 %s 对应的 TIF：\n%s', ym, inputDir);
    end

    if numel(c) > 1
        warning('月份 %s 匹配到多个文件，使用第一个：%s', ...
            ym, c(1).name);
    end

    inputFiles(k) = string(fullfile(c(1).folder, c(1).name));
end

fprintf('将处理以下 8 个文件：\n');
for k = 1:numel(inputFiles)
    fprintf('  %s -> %s\n', requiredMonths(k), inputFiles(k));
end
fprintf('\n');

% 5. 读取郑州市 shp，并转换为经纬度

[boundaryLon, boundaryLat] = read_zhengzhou_boundary_lonlat(shpFile);

minLon = min(boundaryLon, [], 'omitnan');
maxLon = max(boundaryLon, [], 'omitnan');
minLat = min(boundaryLat, [], 'omitnan');
maxLat = max(boundaryLat, [], 'omitnan');

fprintf('郑州边界：Lon %.6f ~ %.6f, Lat %.6f ~ %.6f\n\n', ...
    minLon, maxLon, minLat, maxLat);

% 6. 用第一幅影像建立裁剪范围和行政区掩膜
%    后面 7 幅直接复用，因此速度更快

fprintf('[准备] 建立郑州市裁剪掩膜，只计算一次...\n');

[A0, R0] = readgeoraster(char(inputFiles(1)));

if ndims(A0) > 2
    A0 = A0(:,:,1);
end

if ~contains(class(R0), 'Geographic', 'IgnoreCase', true)
    error(['累计形变栅格不是地理经纬度参考。\n' ...
           '当前代码按 Geographic GeoTIFF 编写。']);
end

latlim = [ ...
    max(minLat, R0.LatitudeLimits(1)), ...
    min(maxLat, R0.LatitudeLimits(2))];

lonlim = [ ...
    max(minLon, R0.LongitudeLimits(1)), ...
    min(maxLon, R0.LongitudeLimits(2))];

if latlim(1) >= latlim(2) || lonlim(1) >= lonlim(2)
    error('郑州 shp 与累计形变栅格没有空间交集。');
end

% 先对第一幅影像裁到郑州外接矩形，以获得统一的 Rcrop
[A0crop, Rcrop] = geocrop(single(A0), R0, latlim, lonlim);

% 裁剪后像元中心经纬度
[latGrid, lonGrid] = geographicGrid(Rcrop);

% 使用 polyshape 构造真实行政区多边形
zhengzhouPoly = polyshape(boundaryLon, boundaryLat, ...
    'Simplify', false);

% 一次性建立郑州内部掩膜
insideMask = isinterior(zhengzhouPoly, lonGrid, latGrid);

fprintf('裁剪后栅格尺寸：%d × %d\n', ...
    size(A0crop,1), size(A0crop,2));
fprintf('郑州市内部像元：%d\n\n', nnz(insideMask));

clear A0 A0crop latGrid lonGrid zhengzhouPoly;

% 7. 逐个裁剪 8 个月

for k = 1:numel(requiredMonths)

    ym = requiredMonths(k);
    inFile = char(inputFiles(k));

    outFile = fullfile(outputDir, ...
        sprintf('Cumulative_%s_Zhengzhou.tif', ym));

    fprintf('[%d/8] %s\n', k, ym);
    fprintf('  输入：%s\n', inFile);

    [A, R] = readgeoraster(inFile);

    if ndims(A) > 2
        A = A(:,:,1);
    end

    A = single(A);

    % 将 GeoTIFF 中的 NoData 转换为 NaN
    try
        rasterInfo = georasterinfo(inFile);
        nodata = rasterInfo.MissingDataIndicator;

        if ~isempty(nodata)
            nodata = double(nodata(1));

            if isfinite(nodata)
                A(double(A) == nodata) = NaN;
            end
        end
    catch
        % 若没有 NoData 元数据，则保持原样
    end

    % 检查网格是否与第一幅一致
    sameGrid = ...
        isequal(R.RasterSize, R0.RasterSize) && ...
        max(abs(R.LatitudeLimits - R0.LatitudeLimits)) < 1e-10 && ...
        max(abs(R.LongitudeLimits - R0.LongitudeLimits)) < 1e-10;

    if ~sameGrid
        error(['月份 %s 的栅格网格与第一幅影像不一致。\n' ...
               '为避免错误裁剪，程序停止。'], ym);
    end

    % 只裁外接矩形，不做任何重采样
    [Acrop, Rthis] = geocrop(A, R, latlim, lonlim);

    if ~isequal(size(Acrop), size(insideMask))
        error('月份 %s 裁剪后的尺寸与郑州掩膜不一致。', ym);
    end

    % 郑州市行政边界外设为 NaN
    Acrop(~insideMask) = NaN;

    % 保存，保留原 GeoTIFF 坐标系统
    write_geotiff_keep_crs(inFile, outFile, Acrop, Rthis);

    fprintf('  输出：%s\n', outFile);
    fprintf('  有效像元：%d\n\n', nnz(isfinite(Acrop)));

    clear A Acrop R Rthis;
end

fprintf('============================================================\n');
fprintf('8 个月全部裁剪完成。\n');
fprintf('输出目录：\n%s\n', outputDir);
fprintf('============================================================\n');
