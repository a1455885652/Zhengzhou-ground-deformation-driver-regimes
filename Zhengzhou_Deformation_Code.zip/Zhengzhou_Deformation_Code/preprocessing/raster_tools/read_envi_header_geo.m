function info = read_envi_header_geo(hdrFile)
% READ_ENVI_HEADER_GEO
% 读取 ENVI header 及 geographic map info。

textData = fileread(hdrFile);

info.samples = ...
    read_envi_numeric_field(textData, 'samples');

info.lines = ...
    read_envi_numeric_field(textData, 'lines');

info.bands = ...
    read_envi_numeric_field(textData, 'bands');

info.headerOffset = ...
    read_envi_numeric_field(textData, 'header offset');

info.dataType = ...
    read_envi_numeric_field(textData, 'data type');

info.byteOrder = ...
    read_envi_numeric_field(textData, 'byte order');

%% data ignore value

token = regexp( ...
    textData, ...
    '(?im)^\s*data\s+ignore\s+value\s*=\s*([^\r\n]+)', ...
    'tokens', ...
    'once');

if isempty(token)

    info.hasIgnoreValue = false;
    info.ignoreValue = NaN;

else

    txt = erase(token{1}, {'{','}'});
    value = str2double(strtrim(txt));

    info.hasIgnoreValue = isfinite(value);
    info.ignoreValue = value;

end

%% map info

token = regexp( ...
    textData, ...
    '(?ims)map\s+info\s*=\s*\{([^}]*)\}', ...
    'tokens', ...
    'once');

if isempty(token)
    error('HDR 中不存在 map info：%s', hdrFile);
end

parts = split(string(token{1}), ',');
parts = strtrim(parts);

if numel(parts) < 7
    error('map info 字段数量不足：%s', hdrFile);
end

info.projectionName = parts(1);

info.refPixelX = str2double(parts(2));
info.refPixelY = str2double(parts(3));

info.refLon = str2double(parts(4));
info.refLat = str2double(parts(5));

info.pixelSizeX = ...
    abs(str2double(parts(6)));

info.pixelSizeY = ...
    abs(str2double(parts(7)));

values = [ ...
    info.refPixelX, ...
    info.refPixelY, ...
    info.refLon, ...
    info.refLat, ...
    info.pixelSizeX, ...
    info.pixelSizeY];

if any(~isfinite(values))
    error('无法解析 map info：%s', hdrFile);
end

end
