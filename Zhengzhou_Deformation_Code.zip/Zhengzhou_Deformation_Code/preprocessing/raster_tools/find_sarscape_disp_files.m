function fileList = find_sarscape_disp_files(folderPath)
% FIND_SARSCAPE_DISP_FILES
% 查找 G_SI_*_disp_geo，排除 hdr。

if ~isfolder(folderPath)
    error('目录不存在：%s', folderPath);
end

D = dir(fullfile(folderPath, 'G_SI_*_disp_geo'));

names = strings(0,1);

for k = 1:numel(D)

    if D(k).isdir
        continue;
    end

    name = string(D(k).name);

    if endsWith(lower(name), ".hdr")
        continue;
    end

    names(end+1,1) = name; %#ok<AGROW>
end

if isempty(names)
    fileList = {};
    return;
end

dateNumbers = nan(numel(names),1);

for k = 1:numel(names)
    dateText = parse_sarscape_disp_date(names(k));
    dateNumbers(k) = str2double(dateText);
end

[~, order] = sort(dateNumbers);

names = names(order);

fileList = cell(numel(names),1);

for k = 1:numel(names)
    fileList{k} = fullfile(folderPath, char(names(k)));
end

end
