# Raster preparation and coordinate export

These are the supplied MATLAB raster readers, masking, aggregation and coordinate-export utilities. The original geospatial operations are preserved.

Entry scripts include `run_resample_latest_insar_to_1km.m`, `run_clip_monthly_cumulative_and_export_txt.m`, `run_clip_8months_zhengzhou_v3.m` and `RUN_EXPORT_001DEG_TIFS_TO_TXT.m`. Earlier clipping variants are retained with their original version suffixes because they use different file-selection rules.

Open the repository root in MATLAB, add `runtime` and this directory, and inspect the selected script's configuration before running it. Paths are resolved through `zz_project_path` and `zz_external_path`. Inputs are original rasters and a study boundary; outputs are derived rasters and longitude/latitude/value tables. Original raster inputs are not included.

These utilities prepare data. They are not a substitute for the saved numerical results used by the manuscript figures.
