%% run_clip_8months_zhengzhou_v2.m
% 仅处理论文 3×3 图所需的 8 个月：
% 2018-12, 2019-12, 2020-12,
% 2021-06, 2022-02, 2023-12,
% 2024-12, 2025-12
%
% 功能：
% 1. 只读取这 8 个“月末累计形变” GeoTIFF；
% 3. 行政边界外设为 NaN；
% 4. 郑州掩膜只计算一次，后续 7 幅直接复用；
% 5. 每幅裁剪 TIF 自动转成 TXT：
%       第1列 经度
%       第2列 纬度
%       第3列 累计形变值
%    并删除所有 NaN / Inf 行。
%
% MATLAB R2023b + Mapping Toolbox
%
% 修复：
% 原版本 polyshape/isinterior 报错是因为 isinterior 要求查询点
% x/y 为同尺寸向量。本版使用 lonGrid(:), latGrid(:)，之后 reshape。
%
% 注意：
% 当前按 2022-02 处理。
% 如果实际需要 2022-12，把 "202202" 改为 "202212"。

clear;
clc;

% 1. 路径

inputDir = ...
    zz_external_path('insar_raster', 'Cumulative_month_end_scenario');

shpFile = ...
    zz_external_path('zhengzhou_shp');

outputDir = ...
    zz_external_path('insar_raster', 'Cumulative_8months_Zhengzhou');

txtDir = fullfile(outputDir, 'TXT_8months');

if ~isfolder(outputDir)
    mkdir(outputDir);
end

if ~isfolder(txtDir)
    mkdir(txtDir);
end

% 2. 只处理这 8 个月

requiredMonths = [ ...
    "201812"
    "201912"
    "202012"
    "202106"
    "202202"
    "202312"
    "202412"
    "202512"];

% 3. 检查输入

if ~isfolder(inputDir)
    error('输入目录不存在：\n%s', inputDir);
end

if ~isfile(shpFile)
    error('郑州市边界 shp 不存在：\n%s', shpFile);
end

fprintf('============================================================\n');
fprintf('仅处理 8 个月：郑州裁剪 + TXT 导出\n');
fprintf('============================================================\n\n');

% 4. 自动寻找 8 个输入 TIF

inputFiles = strings(numel(requiredMonths), 1);

for k = 1:numel(requiredMonths)

    ym = requiredMonths(k);

    % 优先匹配标准命名
    f = fullfile(inputDir, sprintf('Cumulative_%s.tif', ym));

    if isfile(f)
        inputFiles(k) = string(f);
        continue;
    end

    % 否则匹配文件名中包含 YYYYMM 的 tif/tiff
    c = [ ...
        dir(fullfile(inputDir, sprintf('*%s*.tif', ym))); ...
        dir(fullfile(inputDir, sprintf('*%s*.tiff', ym)))];

    if isempty(c)
        error('找不到月份 %s 对应的 TIF：\n%s', ym, inputDir);
    end

    if numel(c) > 1
        warning('月份 %s 匹配到多个文件，使用第一个：%s', ...
            ym, c(1).name);
    end

    inputFiles(k) = string(fullfile(c(1).folder, c(1).name));
end

fprintf('将处理以下 8 个文件：\n');
for k = 1:numel(inputFiles)
    fprintf('  %s -> %s\n', requiredMonths(k), inputFiles(k));
end
fprintf('\n');

% 5. 读取郑州 shp，建立 polygon

fprintf('[准备] 读取郑州市行政边界...\n');

zhengzhouPoly = read_zhengzhou_polyshape(shpFile);

[xb, yb] = boundary(zhengzhouPoly);

minLon = min(xb, [], 'omitnan');
maxLon = max(xb, [], 'omitnan');
minLat = min(yb, [], 'omitnan');
maxLat = max(yb, [], 'omitnan');

fprintf('郑州边界范围：\n');
fprintf('  Lon %.8f ~ %.8f\n', minLon, maxLon);
fprintf('  Lat %.8f ~ %.8f\n\n', minLat, maxLat);

% 6. 用第一幅影像建立唯一一次裁剪范围和郑州掩膜

fprintf('[准备] 建立郑州市裁剪掩膜，只计算一次...\n');

[A0, R0] = readgeoraster(char(inputFiles(1)));

if ndims(A0) > 2
    A0 = A0(:,:,1);
end

if ~contains(class(R0), 'Geographic', 'IgnoreCase', true)
    error(['累计形变栅格不是 Geographic 经纬度 GeoTIFF。\n' ...
           '当前程序按经纬度栅格处理。']);
end

latlim = [ ...
    max(minLat, R0.LatitudeLimits(1)), ...
    min(maxLat, R0.LatitudeLimits(2))];

lonlim = [ ...
    max(minLon, R0.LongitudeLimits(1)), ...
    min(maxLon, R0.LongitudeLimits(2))];

if latlim(1) >= latlim(2) || lonlim(1) >= lonlim(2)
    error('郑州 shp 与累计形变栅格没有空间交集。');
end

% 只为获得统一的裁剪后空间参考
[A0crop, Rcrop] = geocrop(single(A0), R0, latlim, lonlim);

% 每个像元中心的纬度/经度
[latGrid, lonGrid] = geographicGrid(Rcrop);

% 关键修复：
% polyshape.isinterior 要求查询 x/y 是大小相同的向量。
% geographicGrid 返回二维矩阵，所以必须先 (:)，再 reshape。
insideVector = isinterior( ...
    zhengzhouPoly, ...
    lonGrid(:), ...
    latGrid(:));

insideMask = reshape(insideVector, size(lonGrid));

fprintf('裁剪后栅格尺寸：%d × %d\n', ...
    size(A0crop,1), size(A0crop,2));

fprintf('郑州市行政区内部像元：%d\n\n', nnz(insideMask));

clear A0 A0crop lonGrid latGrid insideVector xb yb zhengzhouPoly;

% 7. 逐月：裁剪 + 写 TIF + 导出 TXT

logMonth = strings(numel(requiredMonths),1);
logTif   = strings(numel(requiredMonths),1);
logTxt   = strings(numel(requiredMonths),1);
logCount = zeros(numel(requiredMonths),1);

for k = 1:numel(requiredMonths)

    ym = requiredMonths(k);
    inFile = char(inputFiles(k));

    outTif = fullfile(outputDir, ...
        sprintf('Cumulative_%s_Zhengzhou.tif', ym));

    outTxt = fullfile(txtDir, ...
        sprintf('Cumulative_%s_Zhengzhou.txt', ym));

    fprintf('------------------------------------------------------------\n');
    fprintf('[%d/8] %s\n', k, ym);
    fprintf('输入：%s\n', inFile);

    [A, R] = readgeoraster(inFile);

    if ndims(A) > 2
        A = A(:,:,1);
    end

    A = single(A);

    %% NoData -> NaN
    try
        rasterInfo = georasterinfo(inFile);
        nodata = rasterInfo.MissingDataIndicator;

        if ~isempty(nodata)
            nodata = double(nodata(1));

            if isfinite(nodata)
                A(double(A) == nodata) = NaN;
            end
        end
    catch
        % 若没有 MissingDataIndicator，则保持原值
    end

    %% 检查 8 幅影像是否同网格
    sameGrid = ...
        isequal(R.RasterSize, R0.RasterSize) && ...
        max(abs(R.LatitudeLimits - R0.LatitudeLimits)) < 1e-10 && ...
        max(abs(R.LongitudeLimits - R0.LongitudeLimits)) < 1e-10;

    if ~sameGrid
        error(['月份 %s 的栅格与第一幅影像网格不一致。\n' ...
               '为避免错位，程序停止。'], ym);
    end

    %% 裁到郑州外接矩形，不重采样
    [Acrop, Rthis] = geocrop(A, R, latlim, lonlim);

    if ~isequal(size(Acrop), size(insideMask))
        error('月份 %s 裁剪后尺寸与郑州掩膜不一致。', ym);
    end

    %% 郑州行政边界外 -> NaN
    Acrop(~insideMask) = NaN;

    %% 写出裁剪 TIF
    write_geotiff_keep_crs(inFile, outTif, Acrop, Rthis);

    %% 直接从当前 Acrop 导出 TXT，避免重新读取 TIF
    nValid = export_cropped_grid_to_txt(Acrop, Rthis, outTxt);

    fprintf('裁剪 TIF：%s\n', outTif);
    fprintf('TXT      ：%s\n', outTxt);
    fprintf('有效点数 ：%d\n\n', nValid);

    logMonth(k) = ym;
    logTif(k)   = string(outTif);
    logTxt(k)   = string(outTxt);
    logCount(k) = nValid;

    clear A Acrop R Rthis;
end

% 8. 保存日志

T = table( ...
    logMonth, ...
    logTif, ...
    logTxt, ...
    logCount, ...
    'VariableNames', { ...
        'Month', ...
        'Clipped_TIF', ...
        'TXT', ...
        'Valid_Point_Count'});

logFile = fullfile(outputDir, 'Eight_Months_Export_Log.csv');
writetable(T, logFile);

fprintf('============================================================\n');
fprintf('全部完成。\n');
fprintf('============================================================\n');
fprintf('裁剪 TIF：\n%s\n\n', outputDir);
fprintf('TXT：\n%s\n\n', txtDir);
fprintf('日志：\n%s\n', logFile);
