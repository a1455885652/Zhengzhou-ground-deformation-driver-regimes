function [Z,R] = read_input_raster(filePath)
[~,~,ext]=fileparts(filePath);
if any(strcmpi(ext,{'.tif','.tiff'}))
    [Z,R]=readgeoraster(filePath); if ndims(Z)>2, Z=Z(:,:,1); end
else
    hdr=[filePath '.hdr']; if ~isfile(hdr), error('Missing ENVI header: %s',hdr); end
    txt=fileread(hdr);
    samples=parse_scalar(txt,'samples'); lines=parse_scalar(txt,'lines'); bands=parse_scalar(txt,'bands');
    dtype=parse_scalar(txt,'data type'); byteOrder=parse_scalar(txt,'byte order'); interleave=parse_string(txt,'interleave');
    precision=envi_precision(dtype); machine='ieee-le'; if byteOrder~=0, machine='ieee-be'; end
    Z3=multibandread(filePath,[lines samples bands],precision,0,interleave,machine); Z=Z3(:,:,1);
    tok=regexp(txt,'map\s+info\s*=\s*\{([^}]*)\}','tokens','once','ignorecase');
    if isempty(tok), error('No map info in ENVI header.'); end
    p=strtrim(strsplit(tok{1},',')); refCol=str2double(p{2}); refRow=str2double(p{3}); xRef=str2double(p{4}); yRef=str2double(p{5}); dx=str2double(p{6}); dy=abs(str2double(p{7}));
    x11=xRef-(refCol-1)*dx; y11=yRef+(refRow-1)*dy;
    lonMin=x11-0.5*dx; lonMax=x11+(samples-0.5)*dx; latMax=y11+0.5*dy; latMin=y11-(lines-0.5)*dy;
    R=georefcells([latMin latMax],[lonMin lonMax],[lines samples],'ColumnsStartFrom','north');
end
end

function value=parse_scalar(txt,key)
pat=['(?im)^\s*' regexptranslate('escape',key) '\s*=\s*([^\r\n]+)']; tok=regexp(txt,pat,'tokens','once'); value=str2double(strtrim(tok{1}));
end

function value=parse_string(txt,key)
pat=['(?im)^\s*' regexptranslate('escape',key) '\s*=\s*([^\r\n]+)']; tok=regexp(txt,pat,'tokens','once'); value=lower(strtrim(tok{1})); value=erase(value,'{'); value=erase(value,'}');
end

function p=envi_precision(code)
switch code
case 1, p='uint8'; case 2, p='int16'; case 3, p='int32'; case 4, p='single'; case 5, p='double'; case 12, p='uint16'; case 13, p='uint32'; otherwise, error('Unsupported ENVI type %d',code); end
end
