clc;
clear;


% 将三个 0.001° GeoTIFF 转换为 GMT XYZ TXT
%
% TXT格式：
% Longitude    Latitude    Value
%
% 删除所有 NaN
%
% MATLAB R2023b

%% 1. 输入目录

inputDir = ...
    zz_project_path('Figure/Mechanism_GMT6/GeoTIFF_0p001deg');

mechanismTif = fullfile(inputDir, ...
    'Mechanism_Type_K4_0p001deg.tif');

confidenceTif = fullfile(inputDir, ...
    'Assignment_Confidence_K4_0p001deg.tif');

uncertaintyTif = fullfile(inputDir, ...
    'Assignment_Uncertainty_K4_0p001deg.tif');

%% 2. 输出目录

outputDir = ...
    zz_project_path('Figure/Mechanism_GMT6/TXT_0p001deg');

if ~exist(outputDir,'dir')
    mkdir(outputDir);
end

mechanismTxt = fullfile(outputDir, ...
    'Mechanism_Type_K4_0p001deg.txt');

confidenceTxt = fullfile(outputDir, ...
    'Assignment_Confidence_K4_0p001deg.txt');

uncertaintyTxt = fullfile(outputDir, ...
    'Assignment_Uncertainty_K4_0p001deg.txt');

%% 3. 检查输入

inputFiles = {
    mechanismTif
    confidenceTif
    uncertaintyTif
    };

for k = 1:numel(inputFiles)

    if ~isfile(inputFiles{k})
        error('找不到输入文件：\n%s',inputFiles{k});
    end

end

fprintf('\n===============================================\n');
fprintf(' Export 0.001-degree GeoTIFFs to XYZ TXT\n');
fprintf('===============================================\n\n');

%% 4. Mechanism Type

fprintf('[1/3] Exporting Mechanism Type...\n');

exportGeoTiffToXYZTxt( ...
    mechanismTif, ...
    mechanismTxt, ...
    'categorical');

%% 5. Assignment Confidence

fprintf('\n[2/3] Exporting Assignment Confidence...\n');

exportGeoTiffToXYZTxt( ...
    confidenceTif, ...
    confidenceTxt, ...
    'continuous');

%% 6. Assignment Uncertainty

fprintf('\n[3/3] Exporting Assignment Uncertainty...\n');

exportGeoTiffToXYZTxt( ...
    uncertaintyTif, ...
    uncertaintyTxt, ...
    'continuous');

%% 7. 完成

fprintf('\n===============================================\n');
fprintf(' Finished.\n');
fprintf('===============================================\n');

fprintf('\nOutput folder:\n%s\n\n',outputDir);

fprintf('1. %s\n',mechanismTxt);
fprintf('2. %s\n',confidenceTxt);
fprintf('3. %s\n',uncertaintyTxt);
