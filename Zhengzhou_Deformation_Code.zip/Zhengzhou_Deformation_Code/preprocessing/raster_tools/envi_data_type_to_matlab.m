function precision = envi_data_type_to_matlab(dataType)
% ENVI_DATA_TYPE_TO_MATLAB

switch dataType
    case 1
        precision = 'uint8';
    case 2
        precision = 'int16';
    case 3
        precision = 'int32';
    case 4
        precision = 'single';
    case 5
        precision = 'double';
    case 12
        precision = 'uint16';
    case 13
        precision = 'uint32';
    case 14
        precision = 'int64';
    case 15
        precision = 'uint64';
    otherwise
        error('暂不支持 ENVI data type = %d。', dataType);
end

end
