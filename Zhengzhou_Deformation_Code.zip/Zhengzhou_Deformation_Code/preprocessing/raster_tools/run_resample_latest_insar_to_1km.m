%% run_resample_latest_insar_to_1km.m
% 郑州最新 InSAR 高分辨率结果 -> 最终 1 km 掩膜格网
%
% 处理内容：
%   1. 最新垂直速率结果 -> 1 km
%   2. 最新累计形变全部时相 -> 1 km
%
% 目标格网：
%
% 聚合方法：
%   每个 1 km 目标像元内所有有效高分辨率 InSAR 像元取算术平均。
%
% 重要：
%   - 不使用 NDVI 是否有值决定有效范围；
%   - 目标矩阵尺寸、R 对象、经纬度范围完全继承最终掩膜；
%   - 不 transpose；
%   - 不 flipud；
%   - 不 fliplr；
%   - xIntrinsic -> Column；
%   - yIntrinsic -> Row。
%
% MATLAB R2023b
% 所有函数均单独保存为 .m 文件。

clear;
clc;

fprintf('====================================================================\n');
fprintf(' Zhengzhou latest InSAR -> final 1 km mask grid\n');
fprintf('====================================================================\n\n');

% 1. 配置

cfg.maskFile = ...
    zz_project_path('yanmo/Zhengzhou_mask_1km.tif');

% 最新、已经确认满意的垂直速率
cfg.velocityFile = ...
    zz_external_path('insar_raster', 'G_SI_velocity_vertical_reference_scenario_geo');

% 根据最新速率修改后的全部累计形变
cfg.cumulativeFolder = ...
    zz_external_path('insar_raster', 'Cumulative_vertical_reference_scenario');

% 为避免直接覆盖旧数据，先写到新的目录
cfg.outputRoot = ...
    zz_project_path('InSAR_1km_latest');

cfg.velocityOutputFolder = ...
    fullfile(cfg.outputRoot, '04_Velocity_1km');

cfg.cumulativeOutputFolder = ...
    fullfile(cfg.outputRoot, '01_Acquisition_Cumulative_1km');

% 最终速率文件名
cfg.velocityOutputFile = ...
    fullfile(cfg.velocityOutputFolder, ...
    'InSAR_Velocity_vertical_reference_1km.tif');

% 聚合方法
cfg.aggregationMethod = 'mean';

% 至少需要多少个有效高分辨率源像元才输出一个目标像元。
% 设为1，和之前的空间聚合思想一致：
% 目标格网内只要存在有效 InSAR 观测，就计算均值。
cfg.minimumSourcePixels = 1;

% 掩膜中 0 视为掩膜外
cfg.maskZeroIsOutside = true;

% 输出坐标系
cfg.epsg = 4326;

% 2. 创建目录

if ~exist(cfg.outputRoot, 'dir')
    mkdir(cfg.outputRoot);
end

if ~exist(cfg.velocityOutputFolder, 'dir')
    mkdir(cfg.velocityOutputFolder);
end

if ~exist(cfg.cumulativeOutputFolder, 'dir')
    mkdir(cfg.cumulativeOutputFolder);
end

% 3. 读取最终1 km掩膜 = 唯一目标格网

fprintf('Target mask:\n%s\n\n', cfg.maskFile);

[maskData, Rtarget] = readgeoraster(cfg.maskFile);
maskData = double(maskData);

if ndims(maskData) > 2
    maskData = maskData(:,:,1);
end

maskValid = isfinite(maskData);

if cfg.maskZeroIsOutside
    maskValid = maskValid & (maskData ~= 0);
end

targetSize = size(maskValid);
nTarget = numel(maskValid);

fprintf('Target raster size      : %d x %d\n', ...
    targetSize(1), targetSize(2));

fprintf('Valid mask cells        : %d\n', ...
    nnz(maskValid));

fprintf('Longitude limits        : %.12f -- %.12f\n', ...
    Rtarget.LongitudeLimits(1), ...
    Rtarget.LongitudeLimits(2));

fprintf('Latitude limits         : %.12f -- %.12f\n\n', ...
    Rtarget.LatitudeLimits(1), ...
    Rtarget.LatitudeLimits(2));

% 4. 先建立一次“高分辨率源像元 -> 1 km目标格网”的空间映射
%
% 速率和所有累计形变来自相同 SARscape geocoding 格网时，
% 后续所有时相可重复使用映射，速度更快。

fprintf('Building source-to-target spatial mapping...\n');

[~, sourceInfo] = ...
    read_envi_singleband_geo(cfg.velocityFile);

mapping = build_source_to_target_mapping( ...
    sourceInfo, ...
    Rtarget, ...
    targetSize);

fprintf('Source raster size      : %d x %d\n', ...
    sourceInfo.lines, sourceInfo.samples);

fprintf('Source pixels in target extent : %d\n\n', ...
    nnz(mapping.insideTarget));

% 5. 聚合最新速率

fprintf('--------------------------------------------------------------------\n');
fprintf('Resampling latest velocity to 1 km\n');
fprintf('--------------------------------------------------------------------\n');

[velocityHigh, velocityInfo] = ...
    read_envi_singleband_geo(cfg.velocityFile);

assert_same_source_grid(sourceInfo, velocityInfo, cfg.velocityFile);

[velocity1km, velocityCount] = ...
    aggregate_source_to_target( ...
    velocityHigh, ...
    velocityInfo, ...
    mapping, ...
    targetSize, ...
    cfg.minimumSourcePixels, ...
    cfg.aggregationMethod);

% 最终掩膜外无条件 NaN
velocity1km(~maskValid) = NaN;
velocityCount(~maskValid) = 0;

geotiffwrite( ...
    cfg.velocityOutputFile, ...
    single(velocity1km), ...
    Rtarget, ...
    'CoordRefSysCode', cfg.epsg);

fprintf('Velocity output:\n%s\n', ...
    cfg.velocityOutputFile);

fprintf('Valid 1 km velocity cells: %d\n\n', ...
    nnz(isfinite(velocity1km)));

% 输出每个1 km格网包含的源像元数量
velocityCountFile = fullfile( ...
    cfg.velocityOutputFolder, ...
    'InSAR_Velocity_1km_SourcePixelCount.tif');

geotiffwrite( ...
    velocityCountFile, ...
    uint16(min(velocityCount, double(intmax('uint16')))), ...
    Rtarget, ...
    'CoordRefSysCode', cfg.epsg);

% 6. 查找最新累计形变

fprintf('--------------------------------------------------------------------\n');
fprintf('Searching latest cumulative deformation epochs\n');
fprintf('--------------------------------------------------------------------\n');

dispFiles = find_sarscape_disp_files(cfg.cumulativeFolder);

nEpochs = numel(dispFiles);

fprintf('Found %d cumulative deformation files.\n\n', nEpochs);

if nEpochs == 0
    error('没有找到 G_SI_*_disp_geo 累计形变文件。');
end

% 7. 逐时相聚合到同一个1 km格网

summaryInputName = strings(nEpochs,1);
summaryDate = strings(nEpochs,1);
summaryValidCells = zeros(nEpochs,1);
summaryMeanSourcePixels = nan(nEpochs,1);
summaryMin = nan(nEpochs,1);
summaryMax = nan(nEpochs,1);
summaryMean = nan(nEpochs,1);
summaryOutputFile = strings(nEpochs,1);

for k = 1:nEpochs

    inputFile = dispFiles{k};

    [~, baseName, ~] = fileparts(inputFile);

    dateCode = parse_sarscape_disp_date(baseName);

    fprintf('[%d/%d] %s\n', ...
        k, nEpochs, baseName);

    [Dhigh, currentInfo] = ...
        read_envi_singleband_geo(inputFile);

    assert_same_source_grid( ...
        sourceInfo, ...
        currentInfo, ...
        inputFile);

    [D1km, count1km] = ...
        aggregate_source_to_target( ...
        Dhigh, ...
        currentInfo, ...
        mapping, ...
        targetSize, ...
        cfg.minimumSourcePixels, ...
        cfg.aggregationMethod);

    % 只允许最终掩膜区域
    D1km(~maskValid) = NaN;
    count1km(~maskValid) = 0;

    outputName = sprintf( ...
        'InSAR_Cumulative_1km_%s.tif', ...
        dateCode);

    outputFile = fullfile( ...
        cfg.cumulativeOutputFolder, ...
        outputName);

    geotiffwrite( ...
        outputFile, ...
        single(D1km), ...
        Rtarget, ...
        'CoordRefSysCode', cfg.epsg);

    validOut = isfinite(D1km);

    values = D1km(validOut);

    summaryInputName(k) = string(baseName);
    summaryDate(k) = string(dateCode);
    summaryValidCells(k) = nnz(validOut);

    if any(validOut(:))
        summaryMeanSourcePixels(k) = ...
            mean(count1km(validOut));

        summaryMin(k) = min(values);
        summaryMax(k) = max(values);
        summaryMean(k) = mean(values);
    end

    summaryOutputFile(k) = string(outputFile);

end

% 8. 汇总

T = table( ...
    summaryInputName, ...
    summaryDate, ...
    summaryValidCells, ...
    summaryMeanSourcePixels, ...
    summaryMin, ...
    summaryMax, ...
    summaryMean, ...
    summaryOutputFile, ...
    'VariableNames', { ...
    'InputName', ...
    'DateYYYYMMDD', ...
    'ValidTargetCells', ...
    'MeanSourcePixelsPerValidCell', ...
    'Minimum', ...
    'Maximum', ...
    'Mean', ...
    'OutputFile'});

summaryFile = fullfile( ...
    cfg.outputRoot, ...
    'InSAR_1km_Resampling_Summary.csv');

writetable(T, summaryFile);

% 9. 目标格网检查

gridCheckFile = fullfile( ...
    cfg.outputRoot, ...
    'TargetGrid_Check.txt');

fid = fopen(gridCheckFile, 'w');

fprintf(fid, 'Target mask:\n%s\n\n', cfg.maskFile);

fprintf(fid, 'Raster size: %d x %d\n', ...
    Rtarget.RasterSize(1), ...
    Rtarget.RasterSize(2));

fprintf(fid, 'Valid mask cells: %d\n', ...
    nnz(maskValid));

fprintf(fid, 'Longitude limits: %.15f %.15f\n', ...
    Rtarget.LongitudeLimits(1), ...
    Rtarget.LongitudeLimits(2));

fprintf(fid, 'Latitude limits: %.15f %.15f\n', ...
    Rtarget.LatitudeLimits(1), ...
    Rtarget.LatitudeLimits(2));

fprintf(fid, 'ColumnsStartFrom: %s\n', ...
    Rtarget.ColumnsStartFrom);

fprintf(fid, 'RowsStartFrom: %s\n', ...
    Rtarget.RowsStartFrom);

fprintf(fid, '\nAggregation method: %s\n', ...
    cfg.aggregationMethod);

fprintf(fid, 'Minimum source pixels: %d\n', ...
    cfg.minimumSourcePixels);

fclose(fid);

fprintf('\n====================================================================\n');
fprintf('Finished.\n\n');

fprintf('1 km velocity:\n%s\n\n', ...
    cfg.velocityOutputFile);

fprintf('1 km cumulative folder:\n%s\n\n', ...
    cfg.cumulativeOutputFolder);

fprintf('Summary:\n%s\n', ...
    summaryFile);

fprintf('====================================================================\n');
