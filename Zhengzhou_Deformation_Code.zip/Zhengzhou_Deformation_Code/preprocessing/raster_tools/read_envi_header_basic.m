function info = read_envi_header_basic(hdrFile)
% READ_ENVI_HEADER_BASIC
% 读取 ENVI header 的基本信息

if ~isfile(hdrFile)
    error('找不到 HDR 文件：\n%s', hdrFile);
end

textData = fileread(hdrFile);

info.samples = ...
    read_envi_numeric_field(textData, 'samples');

info.lines = ...
    read_envi_numeric_field(textData, 'lines');

info.bands = ...
    read_envi_numeric_field(textData, 'bands');

info.headerOffset = ...
    read_envi_numeric_field(textData, 'header offset');

info.dataType = ...
    read_envi_numeric_field(textData, 'data type');

info.byteOrder = ...
    read_envi_numeric_field(textData, 'byte order');

%% interleave

token = regexp( ...
    textData, ...
    '(?im)^\s*interleave\s*=\s*([^\r\n]+)', ...
    'tokens', ...
    'once');

if isempty(token)

    info.interleave = 'bsq';

else

    info.interleave = ...
        lower(strtrim(token{1}));

end

%% data ignore value

token = regexp( ...
    textData, ...
    '(?im)^\s*data\s+ignore\s+value\s*=\s*([^\r\n]+)', ...
    'tokens', ...
    'once');

if isempty(token)

    info.hasIgnoreValue = false;
    info.ignoreValue = NaN;

else

    valueText = strtrim(token{1});
    valueText = erase(valueText, '{');
    valueText = erase(valueText, '}');

    value = str2double(valueText);

    if isfinite(value)

        info.hasIgnoreValue = true;
        info.ignoreValue = value;

    else

        info.hasIgnoreValue = false;
        info.ignoreValue = NaN;

    end

end

end
