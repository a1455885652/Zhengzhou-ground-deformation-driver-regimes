function insideMask = build_mask_inpolygon_chunked( ...
    R, boundaryLon, boundaryLat, blockRows)
%BUILD_MASK_INPOLYGON_CHUNKED
% 用分块 inpolygon 创建行政区掩膜。
%
% 不使用 polyshape/isinterior，因此不会出现复杂边界导致的
% 巨型临时矩阵。
%
% R           : 裁剪后的 Geographic raster reference
% boundaryLon : shp 经度，NaN 分隔 polygon parts
% boundaryLat : shp 纬度，NaN 分隔 polygon parts
% blockRows   : 每次处理多少行，例如 256

nRows = R.RasterSize(1);
nCols = R.RasterSize(2);

insideMask = false(nRows, nCols);

% 1. 把 NaN 分隔边界拆成有效 polygon parts

separator = isnan(boundaryLon) | isnan(boundaryLat);

idx = [0; find(separator); numel(boundaryLon)+1];

partsLon = {};
partsLat = {};

for p = 1:numel(idx)-1

    a = idx(p) + 1;
    b = idx(p+1) - 1;

    if b < a
        continue;
    end

    lonPart = boundaryLon(a:b);
    latPart = boundaryLat(a:b);

    good = isfinite(lonPart) & isfinite(latPart);

    lonPart = lonPart(good);
    latPart = latPart(good);

    if numel(lonPart) < 3
        continue;
    end

    partsLon{end+1,1} = lonPart; %#ok<AGROW>
    partsLat{end+1,1} = latPart; %#ok<AGROW>
end

if isempty(partsLon)
    error('郑州 shp 中没有找到有效 polygon part。');
end

fprintf('  有效 polygon part 数量：%d\n', numel(partsLon));
fprintf('  分块行数：%d\n', blockRows);

% 2. 分块计算

nBlocks = ceil(nRows / blockRows);

for ib = 1:nBlocks

    r1 = (ib-1)*blockRows + 1;
    r2 = min(ib*blockRows, nRows);

    rows = r1:r2;

    % 只为当前行块生成经纬度坐标，不创建全图 lon/lat 大矩阵。
    [colGrid, rowGrid] = meshgrid(1:nCols, rows);

    [latBlock, lonBlock] = intrinsicToGeographic( ...
        R, colGrid, rowGrid);

    maskBlock = false(size(lonBlock));

    for p = 1:numel(partsLon)

        lonPart = partsLon{p};
        latPart = partsLat{p};

        maskBlock = maskBlock | ...
            inpolygon(lonBlock, latBlock, lonPart, latPart);
    end

    insideMask(rows,:) = maskBlock;

    fprintf('  mask block %d/%d : rows %d-%d\n', ...
        ib, nBlocks, r1, r2);

    clear colGrid rowGrid latBlock lonBlock maskBlock;
end

end
