function exportGeoTiffToXYZTxt(tifFile,txtFile,dataType)

% GeoTIFF -> XYZ TXT
%
% 第1列 Longitude
% 第2列 Latitude
% 第3列 Value
%
% 自动删除 NaN / Inf

%% 1. 读取栅格

[A,R] = readgeoraster(tifFile);

A = double(A);

if ndims(A) > 2
    A = A(:,:,1);
end

[nRows,nCols] = size(A);

fprintf('Raster size : %d rows x %d cols\n', ...
    nRows,nCols);

%% 2. 构建每个像元中心位置

[colGrid,rowGrid] = meshgrid( ...
    1:nCols, ...
    1:nRows);

[latGrid,lonGrid] = intrinsicToGeographic( ...
    R,colGrid,rowGrid);

%% 3. 转成列向量

lon = lonGrid(:);
lat = latGrid(:);
val = A(:);

%% 4. 删除 NaN / Inf

valid = ...
    isfinite(lon) & ...
    isfinite(lat) & ...
    isfinite(val);

lon = lon(valid);
lat = lat(valid);
val = val(valid);

fprintf('Valid points: %d\n',numel(val));

%% 5. 分类数据额外检查

if strcmpi(dataType,'categorical')

    val = round(val);

    bad = ~ismember(val,[1 2 3 4]);

    if any(bad)
        error('机制分类结果中发现 1、2、3、4 之外的值。');
    end

end

%% 6. 写 TXT

fid = fopen(txtFile,'w');

if fid == -1
    error('无法创建TXT：%s',txtFile);
end

cleaner = onCleanup(@() fclose(fid));

%% 分类变量

if strcmpi(dataType,'categorical')

    fprintf(fid, ...
        '%.6f\t%.6f\t%d\n', ...
        [lon,lat,val]');

%% 连续变量

elseif strcmpi(dataType,'continuous')

    fprintf(fid, ...
        '%.6f\t%.6f\t%.8f\n', ...
        [lon,lat,val]');

else

    error('未知 dataType：%s',dataType);

end

fprintf('Saved:\n%s\n',txtFile);

end
