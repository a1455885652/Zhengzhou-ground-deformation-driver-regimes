function [data, info] = read_envi_singleband_geo(inputFile)
% READ_ENVI_SINGLEBAND_GEO
% 读取 SARscape/ENVI 单波段地理编码结果。

hdrFile = [inputFile '.hdr'];

if ~isfile(inputFile)
    error('找不到数据文件：%s', inputFile);
end

if ~isfile(hdrFile)
    error('找不到 HDR 文件：%s', hdrFile);
end

info = read_envi_header_geo(hdrFile);

if info.bands ~= 1
    error('只支持单波段栅格，当前 bands = %d', ...
        info.bands);
end

precision = ...
    envi_data_type_to_matlab(info.dataType);

if info.byteOrder == 0
    machineFormat = 'ieee-le';
elseif info.byteOrder == 1
    machineFormat = 'ieee-be';
else
    error('未知 byte order = %d', ...
        info.byteOrder);
end

fid = fopen(inputFile, 'r', machineFormat);

if fid == -1
    error('无法打开：%s', inputFile);
end

status = fseek( ...
    fid, ...
    info.headerOffset, ...
    'bof');

if status ~= 0
    fclose(fid);
    error('无法跳转到 header offset：%s', inputFile);
end

raw = fread( ...
    fid, ...
    [info.samples, info.lines], ...
    ['*' precision]);

fclose(fid);

expected = ...
    info.samples * info.lines;

if numel(raw) ~= expected
    error('数据数量不正确：预期 %d，读取 %d。', ...
        expected, numel(raw));
end

% ENVI逐行存储 -> MATLAB [lines x samples]
data = double(raw');

end
