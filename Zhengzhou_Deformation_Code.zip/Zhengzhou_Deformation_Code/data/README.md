# Derived inputs and results

These files were supplied with the study and are included to support figure regeneration and analysis checks. The original numeric CSV content, screening workspaces and saved XGBoost model are preserved. JSON fields containing local paths are replaced with portable tokens; the original and release hashes are listed in `../docs/data_files.csv`.

The directory contains screening tables, prepared model inputs, saved predictions and SHAP values, mechanism compositions and assignments, temporal summaries, ALE curves and interaction surfaces. Raster inputs, original GNSS observations and full monthly caches are not included.

Analysis entries write results using the original directory names under `project_root`. Copy this directory to a separate working location before rerunning analyses if the supplied outputs must remain available as a baseline. Plotting entries save under `figure_output` instead.

The source-code MIT licence does not relicense external source datasets. Their original terms and required citations remain applicable. Figures reused from published sources are not part of these data.
