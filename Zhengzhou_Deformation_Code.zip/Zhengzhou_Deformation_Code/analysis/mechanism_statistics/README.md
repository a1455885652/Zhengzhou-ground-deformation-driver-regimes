# 机制统计补充

计算形变状态关联、边界不确定性、典型区多样性与平均有符号 SHAP 特征。

| 项目 | 内容 |
|---|---|
| 输入 | SHAP_Mechanism_K4_K5_Comparison_Output/Python_Output 中的结果表。 |
| 输出 | `project_root/SHAP_Mechanism_K4_K5_Comparison_Output/Discussion_Supplement` |
| 设置 | bootstrap=5000，seed=20260911（统一入口中保留原设置） |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('mechanism_statistics')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。
