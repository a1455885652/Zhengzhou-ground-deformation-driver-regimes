#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Supplementary analyses for K=4 SHAP mechanism zoning.
Inputs are read from <root>/Python_Output.
Outputs are written to <root>/Discussion_Supplement.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import math
import json

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from scipy.stats import chi2_contingency, mannwhitneyu


def nmi_arithmetic(a, b):
    a = np.asarray(a)
    b = np.asarray(b)
    ua, ai = np.unique(a, return_inverse=True)
    ub, bi = np.unique(b, return_inverse=True)
    cont = np.zeros((len(ua), len(ub)), dtype=float)
    np.add.at(cont, (ai, bi), 1)
    n = cont.sum()
    if n == 0:
        return np.nan
    pa = cont.sum(axis=1) / n
    pb = cont.sum(axis=0) / n
    pij = cont / n
    mi = 0.0
    for i in range(cont.shape[0]):
        for j in range(cont.shape[1]):
            if pij[i, j] > 0:
                mi += pij[i, j] * math.log(pij[i, j] / (pa[i] * pb[j]))
    ha = -np.sum(pa[pa > 0] * np.log(pa[pa > 0]))
    hb = -np.sum(pb[pb > 0] * np.log(pb[pb > 0]))
    den = (ha + hb) / 2.0
    return mi / den if den > 0 else 0.0


def cramers_v_from_arrays(a, b):
    ct = pd.crosstab(pd.Series(a, name="A"), pd.Series(b, name="B"))
    if min(ct.shape) < 2:
        return np.nan, np.nan, np.nan, np.nan
    chi2, p, dof, _ = chi2_contingency(ct.values, correction=False)
    n = ct.values.sum()
    v = math.sqrt(chi2 / (n * min(ct.shape[0] - 1, ct.shape[1] - 1)))
    return v, chi2, p, dof


def boundary_flag(df, neighbors):
    lookup = {
        (int(r), int(c)): int(k)
        for r, c, k in zip(df["RasterRow"], df["RasterColumn"], df["MechanismCluster"])
    }
    flags = np.zeros(len(df), dtype=bool)
    neighbor_n = np.zeros(len(df), dtype=int)
    different_n = np.zeros(len(df), dtype=int)
    for ii, (r, c, k) in enumerate(
        zip(df["RasterRow"], df["RasterColumn"], df["MechanismCluster"])
    ):
        labs = []
        r = int(r)
        c = int(c)
        k = int(k)
        for dr, dc in neighbors:
            q = lookup.get((r + dr, c + dc))
            if q is not None:
                labs.append(q)
        neighbor_n[ii] = len(labs)
        different_n[ii] = sum(q != k for q in labs)
        flags[ii] = different_n[ii] > 0
    return flags, neighbor_n, different_n


def shannon_metrics(p):
    p = np.asarray(p, dtype=float)
    p = p[p > 0]
    h = -np.sum(p * np.log(p)) if len(p) else 0.0
    hnorm = h / np.log(4.0)
    eff = np.exp(h)
    simpson = 1.0 - np.sum(p**2)
    return hnorm, eff, simpson


def savefig(fig, outdir, stem):
    fig.savefig(outdir / f"{stem}.png", dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(outdir / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--root", required=True, help="SHAP_Mechanism_K4_K5_Comparison_Output folder"
    )
    ap.add_argument("--bootstrap", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=20260911)
    args = ap.parse_args()

    root = Path(args.root)
    inp = root / "Python_Output"
    out = root / "Discussion_Supplement"
    out.mkdir(parents=True, exist_ok=True)

    required = [
        "K4_Assignment.csv",
        "K4_Mechanism_Profile_Long.csv",
        "ManualZone_SignConsistent_Overlap_K4.csv",
        "K4_K5_Strict_Decision.csv",
    ]
    for fn in required:
        if not (inp / fn).exists():
            raise FileNotFoundError(f"Missing required file: {inp / fn}")

    rng = np.random.default_rng(args.seed)
    B = args.bootstrap

    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 10,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    # Experiment 1: Mechanism class vs deformation polarity
    A = pd.read_csv(inp / "K4_Assignment.csv")
    D = A[A["ResponseState"].isin(["Subsidence", "Uplift"])].copy()
    mech = D["MechanismCluster"].to_numpy()
    resp = D["ResponseState"].to_numpy()

    nmi = nmi_arithmetic(mech, resp)
    v, chi2, chi_p, dof = cramers_v_from_arrays(mech, resp)

    boot_nmi = np.full(B, np.nan)
    boot_v = np.full(B, np.nan)
    n = len(D)
    for b in range(B):
        idx = rng.integers(0, n, n)
        mb = mech[idx]
        rb = resp[idx]
        boot_nmi[b] = nmi_arithmetic(mb, rb)
        boot_v[b] = cramers_v_from_arrays(mb, rb)[0]

    nmi_ci = np.nanquantile(boot_nmi, [0.025, 0.975])
    v_ci = np.nanquantile(boot_v, [0.025, 0.975])

    assoc = pd.DataFrame(
        [
            {
                "N": n,
                "NMI": nmi,
                "NMI_CI025": nmi_ci[0],
                "NMI_CI975": nmi_ci[1],
                "CramersV": v,
                "CramersV_CI025": v_ci[0],
                "CramersV_CI975": v_ci[1],
                "ChiSquare": chi2,
                "ChiSquare_df": dof,
                "ChiSquare_p": chi_p,
                "Bootstrap_B": B,
                "Seed": args.seed,
            }
        ]
    )
    assoc.to_csv(out / "Table_S1_Mechanism_Response_Association.csv", index=False)

    ctab = pd.crosstab(D["MechanismCluster"], D["ResponseState"])
    ctab = ctab.reindex(
        index=[1, 2, 3, 4], columns=["Subsidence", "Uplift"], fill_value=0
    )
    frac = ctab.div(ctab.sum(axis=1), axis=0) * 100
    frac.to_csv(out / "Table_S1b_Mechanism_Response_Percent.csv")

    fig, ax = plt.subplots(figsize=(6.7, 3.9))
    y = np.arange(4)
    sub = frac["Subsidence"].to_numpy()
    upl = frac["Uplift"].to_numpy()
    ax.barh(y, sub, height=0.55, label="Subsidence")
    ax.barh(y, upl, left=sub, height=0.55, label="Uplift")
    for i in range(4):
        if sub[i] >= 8:
            ax.text(
                sub[i] / 2, i, f"{sub[i]:.1f}%", ha="center", va="center", fontsize=9
            )
        if upl[i] >= 8:
            ax.text(
                sub[i] + upl[i] / 2,
                i,
                f"{upl[i]:.1f}%",
                ha="center",
                va="center",
                fontsize=9,
            )
    ax.set_yticks(y, [f"M{i}" for i in range(1, 5)])
    ax.invert_yaxis()
    ax.set_xlim(0, 100)
    ax.set_xlabel("Fraction within mechanism (%)")
    ax.text(
        0.99,
        1.07,
        f"NMI = {nmi:.3f}  |  Cramér's V = {v:.3f}",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=9.5,
    )
    ax.legend(frameon=False, ncol=2, loc="lower center", bbox_to_anchor=(0.5, 1.01))
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="x", alpha=0.18)
    ax.set_axisbelow(True)
    savefig(fig, out, "Fig_S1_Mechanism_vs_Deformation_State")

    # Experiment 2: Boundary uncertainty + 4/8-neighbor sensitivity
    n4 = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    n8 = [(dr, dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if (dr, dc) != (0, 0)]
    boundary_rows = []
    boundary_cache = {}
    for scheme, neigh in [("4-neighbor", n4), ("8-neighbor", n8)]:
        flag, neighbor_n, diff_n = boundary_flag(A, neigh)
        boundary_cache[scheme] = flag
        for metric in ["NormalizedEntropy", "MaxPosterior", "PosteriorMargin"]:
            xb = A.loc[flag, metric].to_numpy(dtype=float)
            xi = A.loc[~flag, metric].to_numpy(dtype=float)
            U, pval = mannwhitneyu(xb, xi, alternative="two-sided")
            # positive means Boundary > Interior
            rbc = 2.0 * U / (len(xb) * len(xi)) - 1.0
            boundary_rows.append(
                {
                    "BoundaryDefinition": scheme,
                    "Metric": metric,
                    "BoundaryN": len(xb),
                    "InteriorN": len(xi),
                    "BoundaryMedian": np.median(xb),
                    "InteriorMedian": np.median(xi),
                    "BoundaryMean": np.mean(xb),
                    "InteriorMean": np.mean(xi),
                    "MannWhitneyU": U,
                    "pValue": pval,
                    "RankBiserial_BoundaryMinusInterior": rbc,
                }
            )
    btab = pd.DataFrame(boundary_rows)
    btab.to_csv(out / "Table_S2_Boundary_Uncertainty_Sensitivity.csv", index=False)

    # Plot normalized entropy under both definitions
    fig, ax = plt.subplots(figsize=(7.2, 4.3))
    data = []
    pos = []
    labels = []
    p0 = 1
    for scheme in ["4-neighbor", "8-neighbor"]:
        flag = boundary_cache[scheme]
        data.extend(
            [
                A.loc[~flag, "NormalizedEntropy"].to_numpy(),
                A.loc[flag, "NormalizedEntropy"].to_numpy(),
            ]
        )
        pos.extend([p0, p0 + 0.8])
        labels.extend([f"{scheme}\nInterior", f"{scheme}\nBoundary"])
        p0 += 2.2
    vp = ax.violinplot(
        data,
        positions=pos,
        widths=0.65,
        showmeans=False,
        showmedians=True,
        showextrema=False,
    )
    for body in vp["bodies"]:
        body.set_alpha(0.75)
    vp["cmedians"].set_linewidth(1.5)
    ax.set_xticks(pos, labels)
    ax.set_ylabel("Normalized entropy")
    ax.set_ylim(-0.02, 1.0)
    ax.grid(axis="y", alpha=0.18)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    # annotation from 8-neighbor result
    rr = btab[
        (btab.BoundaryDefinition == "8-neighbor") & (btab.Metric == "NormalizedEntropy")
    ].iloc[0]
    ptxt = "< 1e-300" if rr.pValue == 0 else f"{rr.pValue:.1e}"
    ax.text(
        0.99,
        0.98,
        f"8-neighbor: median {rr.InteriorMedian:.3f} → {rr.BoundaryMedian:.3f}\n"
        f"r_rb = {rr.RankBiserial_BoundaryMinusInterior:.3f}, p = {ptxt}",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=9,
    )
    savefig(fig, out, "Fig_S2_Boundary_Uncertainty")

    # Experiment 3: Manual-zone mechanism diversity
    Z = pd.read_csv(inp / "ManualZone_SignConsistent_Overlap_K4.csv")
    zone_order = ["Sub1", "Sub2", "Upl1", "Upl2", "Upl3"]
    zrows = []
    for zone in zone_order:
        g = Z[Z["Zone"] == zone].sort_values("MechanismCluster")
        if len(g) != 4:
            raise ValueError(f"Zone {zone} does not have 4 mechanism rows.")
        counts = g["ClusterNInZone"].to_numpy(dtype=int)
        Nzone = int(g["ZoneN"].iloc[0])
        pvec = counts / counts.sum()
        hnorm, eff, simpson = shannon_metrics(pvec)
        dom_idx = int(np.argmax(pvec))
        dom_mech = int(g["MechanismCluster"].iloc[dom_idx])
        dom_share = pvec[dom_idx]

        boot_h = np.empty(B)
        for b in range(B):
            bc = rng.multinomial(Nzone, pvec)
            bp = bc / max(bc.sum(), 1)
            boot_h[b] = shannon_metrics(bp)[0]
        ci = np.quantile(boot_h, [0.025, 0.975])
        zrows.append(
            {
                "Zone": zone,
                "N": Nzone,
                "NormalizedShannonDiversity": hnorm,
                "Diversity_CI025": ci[0],
                "Diversity_CI975": ci[1],
                "EffectiveNumberOfMechanisms": eff,
                "SimpsonDiversity": simpson,
                "DominantMechanism": f"M{dom_mech}",
                "DominantMechanismFraction": dom_share,
            }
        )
    ztab = pd.DataFrame(zrows)
    ztab.to_csv(out / "Table_S3_ManualZone_Mechanism_Diversity.csv", index=False)

    fig, ax = plt.subplots(figsize=(6.9, 4.3))
    x = np.arange(len(ztab))
    y = ztab["NormalizedShannonDiversity"].to_numpy()
    lo = y - ztab["Diversity_CI025"].to_numpy()
    hi = ztab["Diversity_CI975"].to_numpy() - y
    ax.errorbar(x, y, yerr=[lo, hi], fmt="o", capsize=4, markersize=7, linewidth=1.2)
    ax.vlines(x, 0, y, linewidth=2.0, alpha=0.55)
    ax.set_xticks(x, ztab["Zone"])
    ax.set_ylim(0, 1.0)
    ax.set_ylabel("Normalized mechanism diversity")
    ax.grid(axis="y", alpha=0.18)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for xx, yy, dm, ds in zip(
        x, y, ztab["DominantMechanism"], ztab["DominantMechanismFraction"]
    ):
        ax.text(
            xx,
            min(yy + 0.08, 0.95),
            f"{dm}: {ds * 100:.1f}%",
            ha="center",
            va="bottom",
            fontsize=8.5,
        )
    savefig(fig, out, "Fig_S3_ManualZone_Mechanism_Diversity")

    # Experiment 4: Signed SHAP direction fingerprint heatmap
    P = pd.read_csv(inp / "K4_Mechanism_Profile_Long.csv")
    driver_order = [
        "GWS",
        "SurfaceRunoff",
        "SkinReservoir",
        "SubsurfaceRunoff",
        "TotalPrecipitation",
        "BuiltSurface",
        "NighttimeLight",
        "RoadDensity",
        "Population",
        "DEM",
        "GUM",
        "TotalLooseThickness",
        "Silt",
        "GLHYMPS_Permeability",
        "NDVI",
    ]
    friendly = {
        "GWS": "GWS",
        "SurfaceRunoff": "Surface runoff",
        "SkinReservoir": "Skin reservoir",
        "SubsurfaceRunoff": "Subsurface runoff",
        "TotalPrecipitation": "Precipitation",
        "BuiltSurface": "Built surface",
        "NighttimeLight": "Nighttime light",
        "RoadDensity": "Road density",
        "Population": "Population",
        "DEM": "DEM",
        "GUM": "Geology (GUM)",
        "TotalLooseThickness": "Loose-layer thickness",
        "Silt": "Silt",
        "GLHYMPS_Permeability": "Permeability",
        "NDVI": "NDVI",
    }
    mat = P.pivot(
        index="MechanismCluster", columns="Driver", values="MeanSignedCrossFitSHAP"
    )
    mat = mat.reindex(index=[1, 2, 3, 4], columns=driver_order)
    mat.to_csv(out / "Table_S4_MeanSignedSHAP_MechanismFingerprint.csv")

    arr = mat.to_numpy(dtype=float)
    vmax = np.nanmax(np.abs(arr))
    fig, ax = plt.subplots(figsize=(11.5, 3.9))
    im = ax.imshow(
        arr,
        aspect="auto",
        cmap="RdBu_r",
        norm=TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax),
    )
    ax.set_yticks(np.arange(4), ["M1", "M2", "M3", "M4"])
    ax.set_xticks(
        np.arange(len(driver_order)),
        [friendly[d] for d in driver_order],
        rotation=48,
        ha="right",
    )
    for i in range(arr.shape[0]):
        for j in range(arr.shape[1]):
            val = arr[i, j]
            if np.isfinite(val):
                color = "white" if abs(val) > 0.55 * vmax else "black"
                ax.text(
                    j,
                    i,
                    f"{val:.2f}",
                    ha="center",
                    va="center",
                    fontsize=7.2,
                    color=color,
                )
    cbar = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
    cbar.set_label("Mean signed cross-fit SHAP")
    ax.set_xlabel("Driver")
    ax.set_ylabel("Mechanism")
    for xsep in [4.5, 8.5, 13.5]:
        ax.axvline(xsep, color="white", linewidth=2.0)
    fig.tight_layout()
    savefig(fig, out, "Fig_S4_Signed_SHAP_Direction_Heatmap")

    # Existing K4/K5 stability decision copied into summary table
    K = pd.read_csv(inp / "K4_K5_Strict_Decision.csv")
    K.to_csv(out / "Table_S5_K4_K5_Strict_Decision.csv", index=False)

    # Human-readable summary
    r8 = btab[
        (btab.BoundaryDefinition == "8-neighbor") & (btab.Metric == "NormalizedEntropy")
    ].iloc[0]
    with open(out / "Supplementary_Statistics_Summary.txt", "w", encoding="utf-8") as f:
        f.write("K=4 mechanism discussion supplementary analyses\n")
        f.write("================================================\n\n")
        f.write(f"Mechanism vs deformation state: N={n}\n")
        f.write(f"NMI = {nmi:.6f} (95% bootstrap CI {nmi_ci[0]:.6f}–{nmi_ci[1]:.6f})\n")
        f.write(
            f"Cramer's V = {v:.6f} (95% bootstrap CI {v_ci[0]:.6f}–{v_ci[1]:.6f})\n"
        )
        f.write(f"Chi-square = {chi2:.3f}, df={dof}, p={chi_p:.3e}\n\n")
        f.write("8-neighbor boundary uncertainty:\n")
        f.write(f"Boundary N={int(r8.BoundaryN)}, interior N={int(r8.InteriorN)}\n")
        f.write(
            f"Normalized entropy median: boundary={r8.BoundaryMedian:.6f}, interior={r8.InteriorMedian:.6f}\n"
        )
        f.write(
            f"Rank-biserial (boundary - interior)={r8.RankBiserial_BoundaryMinusInterior:.6f}, p={r8.pValue:.3e}\n\n"
        )
        f.write("Manual-zone normalized mechanism diversity:\n")
        for _, rr in ztab.iterrows():
            f.write(
                f"{rr.Zone}: Hnorm={rr.NormalizedShannonDiversity:.6f}, 95% CI "
                f"[{rr.Diversity_CI025:.6f}, {rr.Diversity_CI975:.6f}], "
                f"dominant={rr.DominantMechanism} ({rr.DominantMechanismFraction * 100:.2f}%)\n"
            )

    manifest = {
        "root": str(root),
        "input_dir": str(inp),
        "output_dir": str(out),
        "bootstrap_B": B,
        "seed": args.seed,
        "boundary_definitions": ["4-neighbor", "8-neighbor"],
        "notes": "No model retraining; analyses use existing K4 assignments and SHAP profiles.",
    }
    with open(out / "Supplementary_Analysis_Manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print("\nFinished successfully.")
    print(f"Output: {out}")
    print(f"NMI = {nmi:.4f}; Cramer V = {v:.4f}")
    print(
        f"8-neighbor entropy median: interior {r8.InteriorMedian:.4f}, boundary {r8.BoundaryMedian:.4f}"
    )
    print("\nZone diversity:")
    print(
        ztab[
            [
                "Zone",
                "NormalizedShannonDiversity",
                "Diversity_CI025",
                "Diversity_CI975",
                "DominantMechanism",
                "DominantMechanismFraction",
            ]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
