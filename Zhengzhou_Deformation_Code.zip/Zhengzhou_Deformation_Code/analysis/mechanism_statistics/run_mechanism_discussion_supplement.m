%% run_mechanism_discussion_supplement.m
% 4.3 Discussion supplementary analyses
% MATLAB launcher -> Python
%
% IMPORTANT:
% Keep this .m file and mechanism_discussion_supplement.py
% in the SAME folder.

clear;
clc;


%% 1. Project root
projectRoot = zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output');

%% 2. Python 3.10 executable
pythonExe = zz_python_executable();

%% 3. Analysis settings
bootstrapB = 5000;
randomSeed = 20260911;

%% 4. Locate Python script beside this MATLAB launcher
thisFile = mfilename('fullpath');
thisDir = fileparts(thisFile);
pythonScript = fullfile(thisDir, 'mechanism_discussion_supplement.py');

%% 5. Pre-flight checks
if ~isfolder(projectRoot)
    error('Project root does not exist:\n%s', projectRoot);
end

inputDir = fullfile(projectRoot, 'Python_Output');
if ~isfolder(inputDir)
    error('Python_Output folder does not exist:\n%s', inputDir);
end

if ~isfile(pythonExe)
    error('Python executable does not exist:\n%s', pythonExe);
end

if ~isfile(pythonScript)
    error(['Python script does not exist:\n%s\n\n' ...
        'Put mechanism_discussion_supplement.py in the same folder as this MATLAB script.'], ...
        pythonScript);
end

requiredFiles = {
    'K4_Assignment.csv'
    'K4_Mechanism_Profile_Long.csv'
    'ManualZone_SignConsistent_Overlap_K4.csv'
    'K4_K5_Strict_Decision.csv'
    };

for i = 1:numel(requiredFiles)
    f = fullfile(inputDir, requiredFiles{i});
    if ~isfile(f)
        error('Missing required input file:\n%s', f);
    end
end

%% 6. Check the configured Python environment
zz_check_python();

%% 7. Run supplementary analyses
fprintf('\n[2/3] Running supplementary analyses...\n');

runCmd = sprintf(['"%s" "%s" --root "%s" ' ...
    '--bootstrap %d --seed %d'], ...
    pythonExe, pythonScript, projectRoot, bootstrapB, randomSeed);

fprintf('Command:\n%s\n\n', runCmd);

[status, cmdout] = system(runCmd, '-echo');

if status ~= 0
    error('Python analysis failed. Exit code = %d', status);
end

%% 8. Output location
outputDir = fullfile(projectRoot, 'Discussion_Supplement');

fprintf('\n[3/3] Finished.\n');
fprintf('Output folder:\n%s\n\n', outputDir);

fprintf('Main outputs:\n');
fprintf('  Table_S1_Mechanism_Response_Association.csv\n');
fprintf('  Table_S2_Boundary_Uncertainty_Sensitivity.csv\n');
fprintf('  Table_S3_ManualZone_Mechanism_Diversity.csv\n');
fprintf('  Table_S4_MeanSignedSHAP_MechanismFingerprint.csv\n');
fprintf('  Fig_S1_Mechanism_vs_Deformation_State.png/pdf\n');
fprintf('  Fig_S2_Boundary_Uncertainty.png/pdf\n');
fprintf('  Fig_S3_ManualZone_Mechanism_Diversity.png/pdf\n');
fprintf('  Fig_S4_Signed_SHAP_Direction_Heatmap.png/pdf\n');
fprintf('  Supplementary_Statistics_Summary.txt\n');
