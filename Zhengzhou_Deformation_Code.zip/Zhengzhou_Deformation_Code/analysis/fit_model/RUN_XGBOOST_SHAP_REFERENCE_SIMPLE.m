clear; clc;
cfg=config_xgb_shap_reference_simple();

fprintf('======================================================================\n');
fprintf(' Zhengzhou latest 1-km InSAR | SIMPLE XGBoost-SHAP\n');
fprintf(' Random 80/20 split + training-only 5-fold tuning + direct TreeSHAP\n');
fprintf('======================================================================\n\n');

fprintf('[1/5] Pre-flight...\n');
pythonExe=run_preflight_simple(cfg);

fprintf('\n[2/5] Preparing latest-target dataset...\n');
ensure_folder_simple(cfg.outputRoot);
ensure_folder_simple(cfg.pythonOutputFolder);
ensure_folder_simple(cfg.figureFolder);
prepared=prepare_latest1km_xgb_dataset_simple(cfg);
writetable(prepared.dataTable,cfg.trainingCsv);
writetable(prepared.featureMetadata,cfg.featureMetadataCsv);
writetable(prepared.targetAudit,cfg.targetAuditCsv);
writetable(prepared.roadFilesTable,fullfile(cfg.outputRoot,'RoadDensity_Files_Used.csv'));

fprintf('Samples = %d\n',height(prepared.dataTable));
fprintf('Target mean = %.4f mm/yr; std = %.4f mm/yr; range = [%.4f, %.4f]\n', ...
    prepared.targetMean,prepared.targetStd,prepared.targetMin,prepared.targetMax);

fprintf('\n[3/5] Writing Python config...\n');
write_python_config_simple(cfg);

fprintf('\n[4/5] Running direct XGBoost-SHAP...\n');
run_python_simple(cfg,pythonExe);

fprintf('\n[5/5] Verifying outputs...\n');
verify_simple_outputs(cfg);

M=readtable(fullfile(cfg.pythonOutputFolder,'Test_Metrics.csv'));
fprintf('\n==================== FINAL TEST METRICS ====================\n');
fprintf('R2   = %.4f\n',M.R2(1));
fprintf('RMSE = %.4f mm/yr\n',M.RMSE(1));
fprintf('MAE  = %.4f mm/yr\n',M.MAE(1));
fprintf('Bias = %.4f mm/yr\n',M.Bias(1));
fprintf('============================================================\n');
fprintf('Output: %s\n',cfg.outputRoot);
