function write_python_config_simple(cfg)
C=struct();
C.training_csv=cfg.trainingCsv;
C.feature_metadata_csv=cfg.featureMetadataCsv;
C.output_folder=cfg.pythonOutputFolder;
C.figure_folder=cfg.figureFolder;
C.test_fraction=cfg.testFraction;
C.random_seed=cfg.randomSeed;
C.inner_cv_folds=cfg.innerCVFolds;
C.n_random_search_candidates=cfg.nRandomSearchCandidates;
C.try_gpu=cfg.tryGPU;
C.subsidence_boxes=cfg.subsidenceBoxes;
C.uplift_boxes=cfg.upliftBoxes;
C.positive_is_subsidence=cfg.positiveIsSubsidence;
C.require_sign_consistency=cfg.requireSignConsistencyWithinBoxes;
C.figure_dpi=cfg.figureDPI;
C.top_dependence_drivers=cfg.topDependenceDrivers;

txt=jsonencode(C,'PrettyPrint',true);
fid=fopen(cfg.pythonConfigJson,'w','n','UTF-8');
if fid<0; error('无法写入JSON：%s',cfg.pythonConfigJson); end
cleanup=onCleanup(@() fclose(fid));
fwrite(fid,txt,'char');
end
