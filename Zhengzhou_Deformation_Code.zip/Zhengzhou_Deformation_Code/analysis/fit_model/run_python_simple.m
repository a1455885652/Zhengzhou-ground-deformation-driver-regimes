function run_python_simple(cfg,pythonExe)
cmd=sprintf('"%s" "%s" "%s"',pythonExe,cfg.pythonScript,cfg.pythonConfigJson);
fprintf('\nPython command:\n%s\n\n',cmd);
[status,out]=system(cmd,'-echo');
if status~=0
    error('Python XGBoost-SHAP运行失败。');
end
end
