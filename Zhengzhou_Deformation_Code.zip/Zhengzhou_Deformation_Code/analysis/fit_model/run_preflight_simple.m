function pythonExe = run_preflight_simple(cfg)
fprintf('Python:\n%s\n',cfg.pythonExe);
pythonExe=resolve_python_executable_simple(cfg);
fprintf('  OK\n\n');

items={ ...
    'Latest velocity',cfg.latestVelocityFile; ...
    'Mask',cfg.maskFile; ...
    'Prepared predictor MAT',cfg.preparedMat; ...
    'Annual FormalRoad folder',cfg.annualRoadFolder};
for k=1:size(items,1)
    fprintf('%s:\n%s\n',items{k,1},items{k,2});
    if isfolder(items{k,2}) || isfile(items{k,2})
        fprintf('  OK\n\n');
    else
        error('路径不存在：%s',items{k,2});
    end
end

S=load(cfg.preparedMat,'dataSet');
if ~isfield(S,'dataSet'); error('prepared MAT中没有dataSet。'); end
fn=string(S.dataSet.featureNames(:));
gn=string(S.dataSet.groupNames(:));
fprintf('Required prepared features:\n');
for k=1:numel(cfg.finalPreparedFeatures)
    if any(fn==cfg.finalPreparedFeatures(k))
        fprintf('  [OK] %s\n',cfg.finalPreparedFeatures(k));
    else
        error('缺少固定特征：%s',cfg.finalPreparedFeatures(k));
    end
end
if any(gn=="GUM"); fprintf('  [OK] GUM dummy group\n'); else; error('缺少GUM。'); end

fprintf('\nManual subsidence boxes:\n'); disp(cfg.subsidenceBoxes);
fprintf('Manual uplift boxes:\n'); disp(cfg.upliftBoxes);
fprintf('Simple workflow: random %.0f/%.0f split + %d-fold training-only CV + final TreeSHAP.\n', ...
    100*(1-cfg.testFraction),100*cfg.testFraction,cfg.innerCVFolds);

fprintf('\nChecking Python packages...\n');
check_python_packages_simple(pythonExe);
end
