clear; clc;
cfg=config_xgb_shap_reference_simple();
fprintf('======================================================================\n');
fprintf(' Zhengzhou latest 1-km InSAR | SIMPLE XGBoost-SHAP preflight\n');
fprintf(' Random train/test split + direct final TreeSHAP\n');
fprintf('======================================================================\n\n');
run_preflight_simple(cfg);
fprintf('\n全部输入检查通过。\n');
