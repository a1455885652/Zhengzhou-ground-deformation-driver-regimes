function ensure_folder_simple(folderPath)
if ~exist(folderPath,'dir')
    mkdir(folderPath);
end
end
