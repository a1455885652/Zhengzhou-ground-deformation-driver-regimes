# XGBoost 与 SHAP

准备模型输入，训练 XGBoost，并计算整体及分区 SHAP 结果。

| 项目 | 内容 |
|---|---|
| 输入 | MATLAB 入口读取原始工程栅格；Python 的 fit_model_tables 入口读取附带的 XGBoost_Model_Data.csv 与 Feature_Metadata.csv。 |
| 输出 | `project_root/XGBoost_SHAP_Latest1km_ReferenceSimple_Output` |
| 设置 | config_xgb_shap_reference_simple.m；../../config/experiments/fit_model.json |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('fit_model')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。

若从准备好的表格开始，可在根目录运行：

```bat
.venv\Scripts\python.exe run.py analysis fit_model_tables
```
