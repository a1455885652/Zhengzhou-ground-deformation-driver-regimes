function [roadMean,roadVectorAll,roadFilesTable] = build_road_density_mean_simple(cfg,D)
% 读取2018-2025 FormalRoad年度1 km栅格并计算多年逐像元算术平均。
ny=numel(cfg.roadYears);
stack=nan([D.rasterSize ny]);
Year=nan(ny,1); File=strings(ny,1);

for k=1:ny
    yr=cfg.roadYears(k);
    candidates=[ ...
        dir(fullfile(cfg.annualRoadFolder,sprintf('*%d*.tif',yr))); ...
        dir(fullfile(cfg.annualRoadFolder,sprintf('*%d*.tiff',yr)))];
    if isempty(candidates)
        error('找不到%d年FormalRoad tif：%s',yr,cfg.annualRoadFolder);
    end
    if numel(candidates)>1
        names=string({candidates.name});
        exact=contains(lower(names),'formalroad');
        candidates=candidates(exact);
    end
    if numel(candidates)~=1
        error('%d年FormalRoad文件数量不是1，请检查文件夹。',yr);
    end
    f=fullfile(candidates(1).folder,candidates(1).name);
    [A,R]=readgeoraster(f,'OutputType','double');
    if ndims(A)>2; A=A(:,:,1); end
    assert_geographic_grid_reference_simple(R,D.R,size(A),D.rasterSize, ...
        sprintf('RoadDensity %d vs prepared grid',yr));
    stack(:,:,k)=A;
    Year(k)=yr; File(k)=string(f);
end

roadMean=mean(stack,3,'omitnan');
roadVectorAll=roadMean(double(D.pixelIndex(:)));
roadFilesTable=table(Year,File);
end
