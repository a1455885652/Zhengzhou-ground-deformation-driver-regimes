function assert_geographic_grid_reference_simple(Ra,Rb,sizeA,sizeB,label)
% 严格检查两个地理栅格的尺寸、经纬度范围、像元大小和行列起始方向。
if nargin < 5
    label = 'Grid comparison';
end
if ~isequal(sizeA(1:2),sizeB(1:2))
    error('%s：栅格尺寸不一致。A=[%d %d], B=[%d %d]。', ...
        label,sizeA(1),sizeA(2),sizeB(1),sizeB(2));
end

tol = 1e-9;
fields = {'LatitudeLimits','LongitudeLimits','CellExtentInLatitude','CellExtentInLongitude'};
for k=1:numel(fields)
    f=fields{k};
    if ~isprop(Ra,f) || ~isprop(Rb,f)
        error('%s：参考对象缺少属性 %s。',label,f);
    end
    a=double(Ra.(f)); b=double(Rb.(f));
    if any(abs(a(:)-b(:))>tol)
        error('%s：%s 不一致。',label,f);
    end
end

if isprop(Ra,'RowsStartFrom') && isprop(Rb,'RowsStartFrom')
    if string(Ra.RowsStartFrom) ~= string(Rb.RowsStartFrom)
        error('%s：RowsStartFrom不一致。',label);
    end
end
if isprop(Ra,'ColumnsStartFrom') && isprop(Rb,'ColumnsStartFrom')
    if string(Ra.ColumnsStartFrom) ~= string(Rb.ColumnsStartFrom)
        error('%s：ColumnsStartFrom不一致。',label);
    end
end
end
