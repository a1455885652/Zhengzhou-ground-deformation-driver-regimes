function prepared = prepare_latest1km_xgb_dataset_simple(cfg)
% 使用最新1 km velocity替换旧Y，构建固定15-driver XGBoost数据表。
S=load(cfg.preparedMat,'dataSet');
if ~isfield(S,'dataSet'); error('prepared MAT中没有dataSet。'); end
D=S.dataSet;

[Ygrid,Ry]=readgeoraster(cfg.latestVelocityFile,'OutputType','double');
if ndims(Ygrid)>2; Ygrid=Ygrid(:,:,1); end
[maskGrid,Rm]=readgeoraster(cfg.maskFile,'OutputType','double');
if ndims(maskGrid)>2; maskGrid=maskGrid(:,:,1); end

assert_geographic_grid_reference_simple(Ry,D.R,size(Ygrid),D.rasterSize,'Latest velocity vs prepared grid');
assert_geographic_grid_reference_simple(Rm,D.R,size(maskGrid),D.rasterSize,'Mask vs prepared grid');

maskValid=isfinite(maskGrid) & maskGrid~=0;
preparedPixelIndex=double(D.pixelIndex(:));
latestOnPrepared=Ygrid(preparedPixelIndex);
maskOnPrepared=maskValid(preparedPixelIndex);

sourceCountAvailable=isfile(cfg.latestVelocitySourceCountFile);
if sourceCountAvailable
    [C,Rc]=readgeoraster(cfg.latestVelocitySourceCountFile,'OutputType','double');
    if ndims(C)>2; C=C(:,:,1); end
    assert_geographic_grid_reference_simple(Rc,D.R,size(C),D.rasterSize,'SourcePixelCount vs prepared grid');
    sourceCount=C(preparedPixelIndex);
    countOK=isfinite(sourceCount) & sourceCount>=cfg.minimumVelocitySourcePixels;
else
    sourceCount=nan(size(preparedPixelIndex));
    countOK=true(size(preparedPixelIndex));
end

use=isfinite(latestOnPrepared) & maskOnPrepared & countOK;
coverage=nnz(use)/numel(use);
if coverage<cfg.minimumLatestTargetCoverageOnPreparedSupport
    error('最新target在predictor support上的覆盖率%.4f低于阈值%.4f。', ...
        coverage,cfg.minimumLatestTargetCoverageOnPreparedSupport);
end

Xall=double(D.X);
featureNames=string(D.featureNames(:));
groupNames=string(D.groupNames(:));

selectedCols=zeros(numel(cfg.finalPreparedFeatures),1);
for k=1:numel(cfg.finalPreparedFeatures)
    idx=find(featureNames==cfg.finalPreparedFeatures(k),1);
    if isempty(idx); error('缺少固定特征：%s',cfg.finalPreparedFeatures(k)); end
    selectedCols(k)=idx;
end
Xselected=Xall(:,selectedCols);
selectedFeatureNames=featureNames(selectedCols);
selectedDriverNames=groupNames(selectedCols);

[roadMean,roadVectorAll,roadFilesTable]=build_road_density_mean_simple(cfg,D);
if any(~isfinite(roadVectorAll(use)))
    error('RoadDensity多年平均在最终建模像元上存在NaN/Inf。');
end
geotiffwrite(cfg.roadMeanRaster,single(roadMean),D.R,'CoordRefSysCode',4326);

GUMcols=find(groupNames=="GUM");
if isempty(GUMcols); error('没有找到GUM dummy列。'); end
Xgum=Xall(:,GUMcols);
gumFeatureNames=featureNames(GUMcols);

XmodelAll=[Xselected,roadVectorAll,Xgum];
modelFeatureNames=[selectedFeatureNames;"RoadDensity_Mean_2018_2025";gumFeatureNames];
modelDriverNames=[selectedDriverNames;"RoadDensity";repmat("GUM",numel(GUMcols),1)];
featureType=repmat("Continuous",numel(modelFeatureNames),1);
featureType(modelDriverNames=="GUM")="CategoricalDummy";

Xmodel=XmodelAll(use,:);
Target=latestOnPrepared(use);
if any(~isfinite(Xmodel(:))) || any(~isfinite(Target))
    error('最终X/Y仍含NaN或Inf。');
end

PixelIndex=preparedPixelIndex(use);
Longitude=double(D.lon(use));
Latitude=double(D.lat(use));
SourcePixelCount=sourceCount(use);
[RasterRow,RasterColumn]=ind2sub(D.rasterSize,PixelIndex);
RasterRow=double(RasterRow); RasterColumn=double(RasterColumn);
SampleID=(1:numel(Target))';

T=table(SampleID,PixelIndex,RasterRow,RasterColumn,Longitude,Latitude,Target,SourcePixelCount, ...
    'VariableNames',{'SampleID','PixelIndex','RasterRow','RasterColumn', ...
    'Longitude','Latitude','Target','SourcePixelCount'});

for k=1:numel(modelFeatureNames)
    vname=matlab.lang.makeValidName(modelFeatureNames(k));
    if ismember(vname,T.Properties.VariableNames); error('重复表变量名：%s',vname); end
    T.(vname)=Xmodel(:,k);
    modelFeatureNames(k)=string(vname);
end

featureMetadata=table(modelFeatureNames,modelDriverNames,featureType, ...
    'VariableNames',{'Feature','Driver','FeatureType'});

expected=["NDVI";"SkinReservoir";"SubsurfaceRunoff";"SurfaceRunoff"; ...
    "TotalPrecipitation";"GWS";"NighttimeLight";"Population";"BuiltSurface"; ...
    "DEM";"GLHYMPS_Permeability";"Silt";"TotalLooseThickness";"RoadDensity";"GUM"];
actual=unique(featureMetadata.Driver,'stable');
missing=setdiff(expected,actual);
if ~isempty(missing); error('最终物理driver缺失：%s',strjoin(missing,', ')); end

AuditItem=["Prepared_support";"Final_modeling_samples";"Coverage";"Physical_driver_count";"Model_feature_count"];
AuditValue=[numel(preparedPixelIndex);numel(Target);coverage;numel(actual);size(Xmodel,2)];
targetAudit=table(AuditItem,AuditValue);

prepared=struct();
prepared.dataTable=T;
prepared.featureMetadata=featureMetadata;
prepared.targetAudit=targetAudit;
prepared.roadFilesTable=roadFilesTable;
prepared.targetCoverage=coverage;
prepared.targetMin=min(Target);
prepared.targetMax=max(Target);
prepared.targetMean=mean(Target);
prepared.targetStd=std(Target);
end
