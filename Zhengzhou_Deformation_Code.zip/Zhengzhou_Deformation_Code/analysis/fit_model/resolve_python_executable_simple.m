function executable = resolve_python_executable_simple(cfg)
% Resolve the interpreter from the shared project configuration.
executable = zz_python_executable();
end
