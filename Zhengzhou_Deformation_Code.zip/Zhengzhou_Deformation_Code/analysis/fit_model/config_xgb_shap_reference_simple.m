function cfg = config_xgb_shap_reference_simple()
% CONFIG_XGB_SHAP_REFERENCE_SIMPLE
% 郑州最新1 km InSAR：参考论文式直接 XGBoost-SHAP 实验。
% MATLAB R2023b；所有函数均为独立 .m 文件。
%
% 设计：
%   1) 最新1 km长期形变速率作为因变量。
%   2) 固定15个物理驱动因素，不重新筛变量。
%   3) 随机80/20训练-测试划分。
%   4) 仅在训练集内进行普通5折随机CV调参。
%   5) 独立测试集评价后，用最佳参数在全样本重训。
%   6) 对全样本最终模型直接计算 TreeSHAP。
%   7) 输出全区、2个沉降区、3个抬升区 SHAP。
%   8) 不做 OOF、不做 spatial CV、不做 repeated CV、不做bootstrap。
%
% 符号约定：正值=沉降，负值=抬升。

projectDir = fileparts(mfilename('fullpath'));

%% Python
cfg.pythonExe = ...
    zz_python_executable();
cfg.pythonScript = fullfile(projectDir,'xgb_shap_reference_simple.py');

%% 最新1 km InSAR target
cfg.latestVelocityFile = ...
    zz_project_path('InSAR_1km_latest_irregular_shape/04_Velocity_1km/InSAR_Velocity_1km.tif');

cfg.latestVelocitySourceCountFile = ...
    zz_project_path('InSAR_1km_latest_irregular_shape/04_Velocity_1km/InSAR_Velocity_1km_SourcePixelCount.tif');

cfg.maskFile = ...
    zz_project_path('yanmo/Zhengzhou_mask_1km.tif');

%% 既有长期驱动变量工程：只复用X/坐标/格网，不复用旧Y
cfg.preparedMat = ...
    zz_project_path('LongTerm_Variable_Screening_Output/Variable_Screening_Results.mat');

%% 道路密度：2018-2025 FormalRoad多年平均
cfg.annualRoadFolder = ...
    zz_project_path('RoadDensity_1km/Annual/FormalRoad');
cfg.roadYears = (2018:2025)';

%% 固定最终特征（道路和GUM在程序内额外加入）
cfg.finalPreparedFeatures = [ ...
    "NDVI_Trend"
    "SkinReservoir_Trend"
    "SubsurfaceRunoff_Trend"
    "SurfaceRunoff_Trend"
    "TotalPrecipitation_Trend"
    "GWS_Trend"
    "NighttimeLight_Trend"
    "Population_Trend"
    "BuiltSurface"
    "DEM"
    "GLHYMPS_Permeability"
    "Silt"
    "TotalLooseThickness"];

%% 2个沉降区 + 3个抬升区 [LonMin LonMax LatMin LatMax]
cfg.subsidenceBoxes = [ ...
    113.460 113.760 34.660 34.840
    113.698 113.871 34.484 34.606];

cfg.upliftBoxes = [ ...
    112.777 113.094 34.709 34.891
    112.702 112.942 34.276 34.512
    113.893 114.182 34.583 34.971];

cfg.positiveIsSubsidence = true;
% 矩形只是空间范围；为避免边缘混入相反符号像元，区域SHAP保留符号一致像元。
cfg.requireSignConsistencyWithinBoxes = true;

%% 简单参考论文式模型参数
cfg.testFraction = 0.20;
cfg.randomSeed = 20260904;
cfg.innerCVFolds = 5;
cfg.nRandomSearchCandidates = 24;
cfg.tryGPU = true;

%% 质量控制
cfg.minimumVelocitySourcePixels = 1;
cfg.minimumLatestTargetCoverageOnPreparedSupport = 0.95;

%% 图件
cfg.figureDPI = 600;
cfg.topDependenceDrivers = 6;

%% 输出
cfg.outputRoot = ...
    zz_project_path('XGBoost_SHAP_Latest1km_ReferenceSimple_Output');

cfg.trainingCsv = fullfile(cfg.outputRoot,'XGBoost_Model_Data.csv');
cfg.featureMetadataCsv = fullfile(cfg.outputRoot,'Feature_Metadata.csv');
cfg.targetAuditCsv = fullfile(cfg.outputRoot,'Target_Audit.csv');
cfg.roadMeanRaster = fullfile(cfg.outputRoot,'RoadDensity_Mean_2018_2025.tif');
cfg.pythonConfigJson = fullfile(cfg.outputRoot,'xgb_reference_simple_config.json');
cfg.pythonOutputFolder = fullfile(cfg.outputRoot,'Python_Output');
cfg.figureFolder = fullfile(cfg.outputRoot,'Paper_Figures');
end
