function check_python_packages_simple(pythonExe)
% Report dependency errors without installing or switching interpreters.
zz_check_python();
end
