# -*- coding: utf-8 -*-
"""Fit XGBoost with training-set tuning and compute regional SHAP summaries."""

from __future__ import annotations
import json, random, sys, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb
import shap
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle
from sklearn.model_selection import train_test_split, RandomizedSearchCV, KFold
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

warnings.filterwarnings("ignore", message=".*mismatched devices.*")


def metric_dict(y, p):
    y = np.asarray(y, float)
    p = np.asarray(p, float)
    return {
        "R2": float(r2_score(y, p)),
        "RMSE": float(np.sqrt(mean_squared_error(y, p))),
        "MAE": float(mean_absolute_error(y, p)),
        "Bias": float(np.mean(p - y)),
        "PearsonR": float(np.corrcoef(y, p)[0, 1]) if len(y) > 1 else np.nan,
    }


def test_device(try_gpu, seed):
    if not try_gpu:
        return "cpu"
    try:
        r = np.random.default_rng(seed)
        X = r.normal(size=(50, 4))
        y = r.normal(size=50)
        m = xgb.XGBRegressor(
            n_estimators=5,
            max_depth=2,
            tree_method="hist",
            device="cuda",
            objective="reg:squarederror",
            random_state=seed,
            verbosity=0,
        )
        m.fit(X, y)
        m.predict(X[:2])
        return "cuda"
    except Exception as e:
        print(f"[GPU] CUDA unavailable; CPU fallback: {e}")
        return "cpu"


def make_model(device, seed):
    kw = dict(
        objective="reg:squarederror",
        eval_metric="rmse",
        tree_method="hist",
        random_state=seed,
        verbosity=0,
        n_jobs=-1 if device == "cpu" else 1,
    )
    if device == "cuda":
        kw["device"] = "cuda"
    return xgb.XGBRegressor(**kw)


def parameter_space():
    return {
        "n_estimators": [300, 450, 600, 800, 1000],
        "max_depth": [2, 3, 4, 5, 6],
        "learning_rate": [0.015, 0.025, 0.04, 0.06, 0.08],
        "min_child_weight": [1, 3, 5, 8, 12],
        "subsample": [0.70, 0.80, 0.90, 1.00],
        "colsample_bytree": [0.65, 0.75, 0.85, 1.00],
        "gamma": [0.0, 0.02, 0.05, 0.10, 0.20],
        "reg_alpha": [0.0, 0.01, 0.05, 0.10, 0.50],
        "reg_lambda": [1.0, 2.0, 5.0, 10.0, 20.0],
    }


def get_shap(model, X):
    ex = shap.TreeExplainer(model)
    try:
        sv = ex.shap_values(X)
    except Exception:
        sv = ex(X).values
    sv = np.asarray(sv)
    if sv.ndim == 3:
        sv = sv[:, :, 0]
    return sv


def aggregate_driver_shap(feature_shap, feature_names, feature_to_driver, drivers):
    out = np.zeros((feature_shap.shape[0], len(drivers)))
    for j, d in enumerate(drivers):
        idx = [i for i, f in enumerate(feature_names) if feature_to_driver[f] == d]
        out[:, j] = feature_shap[:, idx].sum(axis=1)
    return out


def driver_values(X, feature_names, feature_to_driver, drivers):
    out = np.zeros((len(X), len(drivers)))
    for j, d in enumerate(drivers):
        fs = [f for f in feature_names if feature_to_driver[f] == d]
        if len(fs) == 1:
            out[:, j] = X[fs[0]].to_numpy(float)
        else:
            D = X[fs].to_numpy(float)
            active = D > 0.5
            z = np.zeros(len(X))
            use = active.any(axis=1)
            if use.any():
                z[use] = np.argmax(active[use], axis=1) + 1
            out[:, j] = z
    return out


def importance_table(S, drivers):
    mean_abs = np.mean(np.abs(S), axis=0)
    mean_signed = np.mean(S, axis=0)
    total = mean_abs.sum()
    rel = mean_abs / total if total > 0 else np.zeros_like(mean_abs)
    T = pd.DataFrame(
        {
            "Driver": drivers,
            "MeanAbsSHAP": mean_abs,
            "MeanSignedSHAP": mean_signed,
            "RelativeImportance": rel,
        }
    )
    T = T.sort_values("MeanAbsSHAP", ascending=False).reset_index(drop=True)
    T["Rank"] = np.arange(1, len(T) + 1)
    return T


def inside(lon, lat, b):
    x0, x1, y0, y1 = [float(v) for v in b]
    return (
        (lon >= min(x0, x1))
        & (lon <= max(x0, x1))
        & (lat >= min(y0, y1))
        & (lat <= max(y0, y1))
    )


def build_zones(df, y, cfg):
    lon = df.Longitude.to_numpy(float)
    lat = df.Latitude.to_numpy(float)
    subs = np.asarray(cfg["subsidence_boxes"], float).reshape(-1, 4)
    upls = np.asarray(cfg["uplift_boxes"], float).reshape(-1, 4)
    pos_sub = bool(cfg["positive_is_subsidence"])
    sign = bool(cfg["require_sign_consistency"])
    masks = {}
    boxonly = {}
    for i, b in enumerate(subs, 1):
        m = inside(lon, lat, b)
        boxonly[f"Sub{i}"] = m.copy()
        if sign:
            m = m & ((y > 0) if pos_sub else (y < 0))
        masks[f"Sub{i}"] = m
    for i, b in enumerate(upls, 1):
        m = inside(lon, lat, b)
        boxonly[f"Upl{i}"] = m.copy()
        if sign:
            m = m & ((y < 0) if pos_sub else (y > 0))
        masks[f"Upl{i}"] = m
    suball = masks["Sub1"] | masks["Sub2"]
    uplall = masks["Upl1"] | masks["Upl2"] | masks["Upl3"]
    return masks, boxonly, suball, uplall, subs, upls


def pretty(x):
    mp = {
        "SkinReservoir": "Skin reservoir",
        "SubsurfaceRunoff": "Subsurface runoff",
        "SurfaceRunoff": "Surface runoff",
        "TotalPrecipitation": "Total precipitation",
        "NighttimeLight": "Nighttime light",
        "RoadDensity": "Road density",
        "BuiltSurface": "Built surface",
        "GLHYMPS_Permeability": "Permeability",
        "TotalLooseThickness": "Loose-layer thickness",
    }
    return mp.get(x, x)


def savefig(fig, path, dpi):
    fig.savefig(
        str(path.with_suffix(".png")), dpi=dpi, bbox_inches="tight", facecolor="white"
    )
    fig.savefig(
        str(path.with_suffix(".tif")),
        dpi=dpi,
        bbox_inches="tight",
        facecolor="white",
        pil_kwargs={"compression": "tiff_lzw"},
    )


def beeswarm_panel(ax, S, V, order, mask, title, seed):
    rng = np.random.default_rng(seed)
    cmap = plt.get_cmap("turbo")
    for row, d in enumerate(order):
        sv = S[d].to_numpy()[mask]
        xv = V[d].to_numpy()[mask]
        if len(sv) == 0:
            continue
        lo, hi = np.nanpercentile(xv, [2, 98])
        z = (
            np.zeros_like(xv, float)
            if hi <= lo
            else np.clip((xv - lo) / (hi - lo), 0, 1)
        )
        jitter = rng.uniform(-0.26, 0.26, len(sv))
        ax.scatter(
            sv,
            row + jitter,
            c=z,
            cmap=cmap,
            vmin=0,
            vmax=1,
            s=4,
            alpha=0.45,
            edgecolors="none",
            rasterized=True,
        )
    ax.axvline(0, color="k", lw=0.7)
    ax.set_yticks(np.arange(len(order)))
    ax.set_yticklabels([pretty(d) for d in order])
    ax.set_xlabel("SHAP value")
    ax.set_title(title, fontweight="bold")
    ax.grid(alpha=0.08)
    ax.set_ylim(-0.6, len(order) - 0.4)


def plot_test(pred_df, M, figdir, dpi):
    plt.rcParams.update({"font.family": "Times New Roman", "font.size": 9})
    y = pred_df.Target.to_numpy()
    p = pred_df.Prediction.to_numpy()
    lo = min(y.min(), p.min())
    hi = max(y.max(), p.max())
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    ax.scatter(y, p, s=10, alpha=0.3, edgecolors="none")
    ax.plot([lo, hi], [lo, hi], "--", c="k", lw=1)
    ax.set_xlabel("Observed deformation rate (mm yr$^{-1}$)")
    ax.set_ylabel("Predicted deformation rate (mm yr$^{-1}$)")
    ax.set_title("Random test-set performance", fontweight="bold")
    ax.grid(alpha=0.15)
    ax.text(
        0.05,
        0.95,
        f"$R^2$ = {M['R2']:.3f}\nRMSE = {M['RMSE']:.3f}\nMAE = {M['MAE']:.3f}",
        transform=ax.transAxes,
        va="top",
    )
    savefig(fig, Path(figdir) / "Fig_01_Test_Performance", dpi)
    plt.close(fig)


def plot_four(S, V, suball, uplall, imp, figdir, dpi, seed):
    plt.rcParams.update({"font.family": "Times New Roman", "font.size": 7.5})
    order = imp.sort_values("MeanAbsSHAP").Driver.astype(str).tolist()
    allm = np.ones(len(S), bool)
    fig, axes = plt.subplots(2, 2, figsize=(10.2, 8.6), constrained_layout=True)
    beeswarm_panel(axes[0, 0], S, V, order, allm, "(a) Entire study area", seed)
    beeswarm_panel(axes[0, 1], S, V, order, suball, "(b) Subsidence zones", seed + 1)
    beeswarm_panel(axes[1, 0], S, V, order, uplall, "(c) Uplift zones", seed + 2)
    vals = dict(zip(imp.Driver.astype(str), imp.MeanAbsSHAP.astype(float)))
    axes[1, 1].barh(np.arange(len(order)), [vals[d] for d in order])
    axes[1, 1].set_yticks(np.arange(len(order)))
    axes[1, 1].set_yticklabels([pretty(d) for d in order])
    axes[1, 1].set_xlabel("Mean |SHAP value|")
    axes[1, 1].set_title("(d) Global importance", fontweight="bold")
    axes[1, 1].grid(axis="x", alpha=0.12)
    sm = ScalarMappable(norm=Normalize(0, 1), cmap="turbo")
    sm.set_array([])
    cb = fig.colorbar(sm, ax=axes[:, :], fraction=0.018, pad=0.015)
    cb.set_ticks([0, 1])
    cb.set_ticklabels(["Low", "High"])
    cb.set_label("Feature value")
    savefig(fig, Path(figdir) / "Fig_02_SHAP_ReferenceStyle_4Panel", dpi)
    plt.close(fig)


def plot_zone_bars(zone_imps, figdir, dpi):
    plt.rcParams.update({"font.family": "Times New Roman", "font.size": 8})
    names = ["Sub1", "Sub2", "Upl1", "Upl2", "Upl3"]
    fig, axes = plt.subplots(2, 3, figsize=(11, 6.8), constrained_layout=True)
    axes = np.asarray(axes).reshape(-1)
    for k, n in enumerate(names):
        T = zone_imps[n].sort_values("MeanAbsSHAP", ascending=True)
        axes[k].barh(np.arange(len(T)), T.MeanAbsSHAP)
        axes[k].set_yticks(np.arange(len(T)))
        axes[k].set_yticklabels([pretty(x) for x in T.Driver])
        axes[k].set_title(n, fontweight="bold")
        axes[k].set_xlabel("Mean |SHAP|")
        axes[k].grid(axis="x", alpha=0.1)
    axes[-1].axis("off")
    savefig(fig, Path(figdir) / "Fig_03_Five_Zone_SHAP_Importance", dpi)
    plt.close(fig)


def plot_zone_map(df, y, subs, upls, suball, uplall, figdir, dpi):
    lon = df.Longitude.to_numpy(float)
    lat = df.Latitude.to_numpy(float)
    fig, ax = plt.subplots(figsize=(7, 5.5))
    sc = ax.scatter(
        lon, lat, c=y, s=9, cmap="RdBu_r", alpha=0.7, edgecolors="none", rasterized=True
    )
    for i, b in enumerate(subs, 1):
        x0, x1, y0, y1 = b
        ax.add_patch(
            Rectangle(
                (min(x0, x1), min(y0, y1)),
                abs(x1 - x0),
                abs(y1 - y0),
                fill=False,
                lw=1.5,
                color="k",
            )
        )
        ax.text(min(x0, x1), max(y0, y1), f" Sub{i}", va="bottom", fontweight="bold")
    for i, b in enumerate(upls, 1):
        x0, x1, y0, y1 = b
        ax.add_patch(
            Rectangle(
                (min(x0, x1), min(y0, y1)),
                abs(x1 - x0),
                abs(y1 - y0),
                fill=False,
                lw=1.5,
                ls="--",
                color="k",
            )
        )
        ax.text(min(x0, x1), max(y0, y1), f" Upl{i}", va="bottom", fontweight="bold")
    ax.scatter(
        lon[suball],
        lat[suball],
        s=13,
        facecolors="none",
        edgecolors="k",
        linewidths=0.25,
    )
    ax.scatter(
        lon[uplall],
        lat[uplall],
        s=13,
        facecolors="none",
        edgecolors="k",
        linewidths=0.25,
    )
    ax.set_xlabel("Longitude (°E)")
    ax.set_ylabel("Latitude (°N)")
    ax.set_title("Manual deformation zones", fontweight="bold")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=0.1)
    cb = fig.colorbar(sc, ax=ax, fraction=0.035, pad=0.02)
    cb.set_label("Deformation rate (mm yr$^{-1}$)\n(+ subsidence, − uplift)")
    savefig(fig, Path(figdir) / "Fig_04_Manual_Zones", dpi)
    plt.close(fig)


def plot_dependence(S, V, imp, n_top, figdir, dpi):
    top = (
        imp.sort_values("MeanAbsSHAP", ascending=False)
        .Driver.astype(str)
        .head(n_top)
        .tolist()
    )
    ncol = 3
    nrow = int(np.ceil(len(top) / ncol))
    fig, axes = plt.subplots(
        nrow, ncol, figsize=(9.5, 3 * nrow), constrained_layout=True
    )
    axes = np.asarray(axes).reshape(-1)
    for k, d in enumerate(top):
        ax = axes[k]
        x = V[d].to_numpy(float)
        y = S[d].to_numpy(float)
        ax.scatter(x, y, s=5, alpha=0.2, edgecolors="none", rasterized=True)
        ax.axhline(0, c="k", ls="--", lw=0.6)
        ax.set_xlabel(pretty(d))
        ax.set_ylabel("SHAP value")
        ax.set_title(f"({chr(97 + k)}) {pretty(d)}", fontweight="bold")
        ax.grid(alpha=0.1)
    for k in range(len(top), len(axes)):
        axes[k].axis("off")
    savefig(fig, Path(figdir) / "Fig_05_Top_Driver_Dependence", dpi)
    plt.close(fig)


def main(config_file):
    with open(config_file, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    out = Path(cfg["output_folder"])
    figdir = Path(cfg["figure_folder"])
    out.mkdir(parents=True, exist_ok=True)
    figdir.mkdir(parents=True, exist_ok=True)
    seed = int(cfg["random_seed"])
    np.random.seed(seed)
    random.seed(seed)
    df = pd.read_csv(cfg["training_csv"])
    meta = pd.read_csv(cfg["feature_metadata_csv"])
    feature_names = meta.Feature.astype(str).tolist()
    f2d = dict(zip(meta.Feature.astype(str), meta.Driver.astype(str)))
    drivers = meta.Driver.astype(str).drop_duplicates().tolist()
    X = df[feature_names].copy()
    y = df.Target.to_numpy(float)
    if not np.isfinite(X.to_numpy()).all() or not np.isfinite(y).all():
        raise RuntimeError("X or y contains NaN/Inf")
    device = test_device(bool(cfg["try_gpu"]), seed)
    print(f"XGBoost {xgb.__version__} | SHAP {shap.__version__} | device={device}")
    print(
        f"Samples={len(df)}, model features={len(feature_names)}, physical drivers={len(drivers)}"
    )

    idx = np.arange(len(df))
    train_idx, test_idx = train_test_split(
        idx, test_size=float(cfg["test_fraction"]), random_state=seed, shuffle=True
    )
    Xtr = X.iloc[train_idx]
    ytr = y[train_idx]
    Xte = X.iloc[test_idx]
    yte = y[test_idx]
    assignment = np.full(len(df), "Train", dtype=object)
    assignment[test_idx] = "Test"
    pd.DataFrame({"SampleID": df.SampleID, "Set": assignment}).to_csv(
        out / "Train_Test_Assignment.csv", index=False
    )

    print("\nTraining-only hyperparameter search...")
    cv = KFold(n_splits=int(cfg["inner_cv_folds"]), shuffle=True, random_state=seed)
    search = RandomizedSearchCV(
        make_model(device, seed),
        parameter_space(),
        n_iter=int(cfg["n_random_search_candidates"]),
        scoring="neg_root_mean_squared_error",
        cv=cv,
        random_state=seed,
        n_jobs=1 if device == "cuda" else -1,
        verbose=1,
        return_train_score=False,
    )
    search.fit(Xtr, ytr)
    best = search.best_estimator_
    with open(out / "Best_Params.json", "w", encoding="utf-8") as f:
        json.dump(search.best_params_, f, indent=2)
    R = pd.DataFrame(search.cv_results_)
    keep = [
        c
        for c in R.columns
        if c.startswith("param_")
        or c in ["mean_test_score", "std_test_score", "rank_test_score"]
    ]
    R[keep].to_csv(out / "Hyperparameter_Search.csv", index=False)

    pred = best.predict(Xte)
    M = metric_dict(yte, pred)
    pd.DataFrame([M]).to_csv(out / "Test_Metrics.csv", index=False)
    P = df.iloc[test_idx][
        ["SampleID", "PixelIndex", "Longitude", "Latitude", "Target"]
    ].copy()
    P["Prediction"] = pred
    P["Residual"] = pred - yte
    P.to_csv(out / "Test_Predictions.csv", index=False)
    print("\nTest metrics:")
    print(json.dumps(M, indent=2))

    final = make_model(device, seed + 1000)
    final.set_params(**search.best_params_)
    final.fit(X, y)
    fp = final.predict(X)
    pd.DataFrame([metric_dict(y, fp)]).to_csv(
        out / "FinalModel_TrainingFit.csv", index=False
    )
    final.save_model(str(out / "XGBoost_Final_Model.json"))

    fshap = get_shap(final, X)
    dshap = aggregate_driver_shap(fshap, feature_names, f2d, drivers)
    dvals = driver_values(X, feature_names, f2d, drivers)
    S = pd.DataFrame(dshap, columns=drivers)
    V = pd.DataFrame(dvals, columns=drivers)
    Sout = S.copy()
    Sout.insert(0, "SampleID", df.SampleID.values)
    Sout.to_csv(out / "SHAP_All_Driver_Values.csv", index=False)
    Vout = V.copy()
    Vout.insert(0, "SampleID", df.SampleID.values)
    Vout.to_csv(out / "SHAP_All_Driver_DataValues.csv", index=False)

    masks, boxonly, suball, uplall, subs, upls = build_zones(df, y, cfg)
    rows = []
    for n in ["Sub1", "Sub2", "Upl1", "Upl2", "Upl3"]:
        m = masks[n]
        b = boxonly[n]
        rows.append(
            {
                "Zone": n,
                "PixelsInsideRectangle": int(b.sum()),
                "PixelsUsedAfterSignFilter": int(m.sum()),
                "MeanDeformationRate": float(np.mean(y[m])) if m.any() else np.nan,
            }
        )
    pd.DataFrame(rows).to_csv(out / "Manual_Zone_Summary.csv", index=False)
    Z = pd.DataFrame(
        {
            "SampleID": df.SampleID,
            "Longitude": df.Longitude,
            "Latitude": df.Latitude,
            "Target": y,
            "Sub1": masks["Sub1"],
            "Sub2": masks["Sub2"],
            "Upl1": masks["Upl1"],
            "Upl2": masks["Upl2"],
            "Upl3": masks["Upl3"],
            "Subsidence_All": suball,
            "Uplift_All": uplall,
        }
    )
    Z.to_csv(out / "Manual_Zone_Assignment.csv", index=False)

    imp_all = importance_table(dshap, drivers)
    imp_sub = importance_table(dshap[suball], drivers)
    imp_upl = importance_table(dshap[uplall], drivers)
    imp_all.to_csv(out / "SHAP_Importance_All.csv", index=False)
    imp_sub.to_csv(out / "SHAP_Importance_Subsidence.csv", index=False)
    imp_upl.to_csv(out / "SHAP_Importance_Uplift.csv", index=False)
    zone_imps = {}
    for n in ["Sub1", "Sub2", "Upl1", "Upl2", "Upl3"]:
        zone_imps[n] = (
            importance_table(dshap[masks[n]], drivers)
            if masks[n].sum() > 0
            else pd.DataFrame(
                columns=[
                    "Driver",
                    "MeanAbsSHAP",
                    "MeanSignedSHAP",
                    "RelativeImportance",
                    "Rank",
                ]
            )
        )
        zone_imps[n].to_csv(out / f"SHAP_Importance_{n}.csv", index=False)

    plot_test(P, M, figdir, int(cfg["figure_dpi"]))
    plot_four(S, V, suball, uplall, imp_all, figdir, int(cfg["figure_dpi"]), seed)
    plot_zone_bars(zone_imps, figdir, int(cfg["figure_dpi"]))
    plot_zone_map(df, y, subs, upls, suball, uplall, figdir, int(cfg["figure_dpi"]))
    plot_dependence(
        S,
        V,
        imp_all,
        int(cfg["top_dependence_drivers"]),
        figdir,
        int(cfg["figure_dpi"]),
    )

    protocol = {
        "workflow": "Simple reference-paper-style XGBoost-SHAP",
        "validation": "single random 80/20 train-test split",
        "hyperparameter_tuning": "RandomizedSearchCV with ordinary shuffled KFold inside training set only",
        "shap": "TreeSHAP from final all-sample model",
        "regional_shap": "subsets of the same whole-area final model",
        "no_oof": True,
        "no_spatial_cv": True,
        "no_repeated_cv": True,
        "no_bootstrap": True,
        "physical_driver_count": len(drivers),
        "random_seed": seed,
        "xgboost_version": xgb.__version__,
        "shap_version": shap.__version__,
    }
    with open(out / "Run_Protocol.json", "w", encoding="utf-8") as f:
        json.dump(protocol, f, indent=2, ensure_ascii=False)
    print("\nTop drivers:")
    print(imp_all.head(10).to_string(index=False))
    print(f"\nDone. Output: {out}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python xgb_shap_reference_simple.py config.json")
    main(sys.argv[1])
