function T = audit_k4_against_velocity(K4,cfg,Rtarget,targetSize)
[V,Rv]=read_geotiff_singleband(cfg.insar.finalVelocity1km);
assert_same_target_grid(Rtarget,Rv,targetSize,size(V),cfg.insar.finalVelocity1km);
lin=sub2ind(targetSize,K4.RasterRow,K4.RasterColumn);
v=V(lin); t=double(K4.Target);
good=isfinite(v)&isfinite(t);
if nnz(good)~=height(K4), error('最终 velocity 或 K4 Target 在 7081 样本中含 NaN。'); end
d=v-t;
maxAbs=max(abs(d)); rmse=sqrt(mean(d.^2)); mae=mean(abs(d)); [r,~]=pearson_corr_complete(v,t);
if r<cfg.k4.minTargetCorrelation
    error(['K4 Target 与最终 velocity 相关性不足 (r=%.8f)。\n' ...
        '可能拿错 velocity 版本或存在正负号/行列方向问题。'],r);
end
if maxAbs>cfg.k4.maxTargetAbsDifference
    error(['K4 Target 与最终 velocity 最大绝对差 %.8g > 容差 %.8g。\n' ...
        '拒绝继续，先确认数据谱系。'],maxAbs,cfg.k4.maxTargetAbsDifference);
end
T=table(height(K4),maxAbs,rmse,mae,r,mean(d), ...
    'VariableNames',{'N','MaxAbsDifference','RMSE','MAE','PearsonR','MeanDifference'});
end
