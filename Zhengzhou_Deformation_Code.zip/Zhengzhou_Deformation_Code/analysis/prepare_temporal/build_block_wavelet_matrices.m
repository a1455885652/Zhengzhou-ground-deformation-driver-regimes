function S = build_block_wavelet_matrices(cache,rate,B,cfg,driverIndex)
% Each column is one spatial block. Inputs are standardized only after the same
% detrending used by the observed WTC. This is the space in which synchronized MIAAFT operates.
T=numel(cache.months); idx=(1+cfg.response.halfWindowMonths):(T-cfg.response.halfWindowMonths);
nT=numel(idx); nB=numel(B.blockID); X=nan(nT,nB); Y=nan(nT,nB);
for b=1:nB
    pix=B.pixelLists{b};
    for q=1:nT
        t=idx(q);
        xv=double(cache.driverData(t,pix,driverIndex)); yv=double(rate.Vrate(t,pix));
        X(q,b)=median(xv(isfinite(xv)),'omitnan');
        Y(q,b)=median(yv(isfinite(yv)),'omitnan');
    end
end
keep=all(isfinite(X),1) & all(isfinite(Y),1);
X=X(:,keep); Y=Y(:,keep); blockIDs=B.blockID(keep); nPixels=B.nPixels(keep);
if size(X,2)<cfg.hierarchical.tierB.minimumSupportingBlocks
    error('Only %d complete spatial blocks remain.',size(X,2));
end
XZ=nan(size(X)); YZ=nan(size(Y));
for b=1:size(X,2)
    XZ(:,b)=preprocess_wavelet_series(X(:,b),cfg.wavelet.detrendDegree);
    YZ(:,b)=preprocess_wavelet_series(Y(:,b),cfg.wavelet.detrendDegree);
end
S=struct('XRaw',X,'YRaw',Y,'XZ',XZ,'YZ',YZ,'blockIDs',blockIDs,'nPixels',nPixels,'months',cache.months(idx),'timeIndex',idx);
end
