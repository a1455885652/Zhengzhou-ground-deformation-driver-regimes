%% BUILD_DYNAMIC_CACHE_WAVELET.m
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_k4_wavelet_lag();
ensure_folder(cfg.cache.root); ensure_folder(cfg.output.root); ensure_folder(cfg.output.audit);
[mask,Rtarget]=read_geotiff_singleband(cfg.grid.maskFile); targetSize=size(mask);
K4=load_and_validate_k4(cfg,targetSize); audit_k4_against_velocity(K4,cfg,Rtarget,targetSize);
lin=sub2ind(targetSize,K4.RasterRow,K4.RasterColumn); months=make_month_vector(cfg.time.startMonth,cfg.time.endMonth);
Tin=list_monthly_geotiffs_strict(cfg.insar.monthEnd1kmFolder,months);
fprintf('Reading InSAR cumulative: %d months x %d K4 pixels...\n',numel(months),numel(lin));
Dcum=read_monthly_samples(Tin,Rtarget,targetSize,lin);
nD=numel(cfg.driver); nT=numel(months); nN=numel(lin);
driverData=nan(nT,nN,nD,'single'); driverNames=strings(nD,1);
for j=1:nD
    fprintf('Reading driver %d/%d: %s\n',j,nD,cfg.driver(j).name);
    Tj=list_monthly_geotiffs_strict(cfg.driver(j).folder,months);
    driverData(:,:,j)=read_monthly_samples(Tj,Rtarget,targetSize,lin); driverNames(j)=string(cfg.driver(j).name);
end
coverCum=mean(isfinite(Dcum),1)'; coverDriver=nan(nN,nD);
for j=1:nD, coverDriver(:,j)=mean(isfinite(driverData(:,:,j)),1)'; end
Tcov=table((1:nN)',double(K4.RasterRow),double(K4.RasterColumn),double(K4.MechanismCluster),double(K4.MaxPosterior),coverCum, ...
    'VariableNames',{'K4Index','RasterRow','RasterColumn','Mechanism','MaxPosterior','CumulativeCoverage'});
for j=1:nD, Tcov.(sprintf('%s_Coverage',cfg.driver(j).name))=coverDriver(:,j); end
writetable(Tcov,fullfile(cfg.output.audit,'K4_Temporal_Coverage.csv'));
Tslope=audit_cumulative_slope_against_k4(Dcum,months,K4,cfg); writetable(Tslope,fullfile(cfg.output.audit,'CumulativeSlope_vs_K4Target.csv'));
cache=struct('months',months,'Dcum',Dcum,'driverData',driverData,'driverNames',driverNames,'K4',K4,'targetSize',targetSize, ...
    'coverCum',single(coverCum),'coverDriver',single(coverDriver),'created',char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')));
save(cfg.cache.dynamicMat,'cache','-v7.3');
fprintf('Saved dynamic cache: %s\n',cfg.cache.dynamicMat);
