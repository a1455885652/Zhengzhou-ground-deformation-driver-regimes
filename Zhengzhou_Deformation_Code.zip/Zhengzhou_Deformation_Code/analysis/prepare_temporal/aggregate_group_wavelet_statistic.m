function G = aggregate_group_wavelet_statistic(M,cfg)
valid=M.valid & isfinite(M.coherence) & isfinite(M.phaseConcentration) & isfinite(M.phase) & isfinite(M.lag);
support=valid & M.coherence>=cfg.hierarchical.blockCoherenceThreshold & ...
    M.phaseConcentration>=cfg.hierarchical.blockMinimumPhaseConcentration;
nTotal=sum(valid); nSupport=sum(support);
if nTotal==0 || nSupport==0
    G=struct('Valid',false,'NBlocks',nTotal,'NSupport',nSupport,'SupportFraction',0,'MeanCoherence',NaN, ...
        'GroupPhaseConcentration',NaN,'DriverLeadFraction',NaN,'MedianLagMonths',NaN,'CouplingStatistic',0,'LeadStatistic',0);
    return;
end
coh=M.coherence(support); ph=M.phase(support); lag=M.lag(support);
w=max(coh.*M.phaseConcentration(support),eps);
z=sum(w.*exp(1i*ph))/sum(w); phaseConc=abs(z);
supportFrac=nSupport/nTotal; meanC=mean(coh,'omitnan'); leadFrac=mean(lag>0,'omitnan'); medLag=median(lag,'omitnan');
coupling=supportFrac*meanC*phaseConc;
leadScore=coupling*max(0,2*leadFrac-1);
G=struct('Valid',true,'NBlocks',nTotal,'NSupport',nSupport,'SupportFraction',supportFrac,'MeanCoherence',meanC, ...
    'GroupPhaseConcentration',phaseConc,'DriverLeadFraction',leadFrac,'MedianLagMonths',medLag, ...
    'CouplingStatistic',coupling,'LeadStatistic',leadScore);
end
