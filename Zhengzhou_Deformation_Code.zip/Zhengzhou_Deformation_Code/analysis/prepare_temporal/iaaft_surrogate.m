function s = iaaft_surrogate(x,maxIter,relTol)
% Schreiber-Schmitz IAAFT: approximately preserve Fourier amplitudes/autocorrelation and exactly preserve sample distribution.
x=double(x(:)); n=numel(x); if any(~isfinite(x)), error('IAAFT input must be finite.'); end
if std(x)<=eps, error('IAAFT input is constant.'); end
sortedX=sort(x); mu=mean(x); targetAmp=abs(fft(x-mu));
s=x(randperm(n)); prev=Inf;
for it=1:maxIter
    Y=fft(s-mean(s)); ph=angle(Y); z=real(ifft(targetAmp.*exp(1i*ph)))+mu;
    [~,ord]=sort(z,'ascend'); s2=zeros(n,1); s2(ord)=sortedX;
    a=abs(fft(s2-mean(s2))); err=norm(a-targetAmp)/max(norm(targetAmp),eps);
    s=s2;
    if isfinite(prev) && abs(prev-err)<=relTol*max(1,prev), break; end
    prev=err;
end
end
