function M = read_monthly_samples(Tfiles,Rtarget,targetSize,sampleLinear)
nT=height(Tfiles); nS=numel(sampleLinear); M=nan(nT,nS,'single');
for t=1:nT
    [Z,R]=read_geotiff_singleband(char(Tfiles.FilePath(t)));
    assert_same_target_grid(Rtarget,R,targetSize,size(Z),char(Tfiles.FilePath(t)));
    vals=Z(sampleLinear); M(t,:)=single(vals(:)');
end
end
