# 月序列与缓存

生成时间分析所需的动态驱动缓存及中心滑动形变速率缓存。

| 项目 | 内容 |
|---|---|
| 输入 | 月末累计形变、月度驱动因素栅格、K=4 归属表。完整缓存未附带。 |
| 输出 | `project_root/K4_WaveletPhaseLag_Cache` |
| 设置 | config_k4_wavelet_lag.m |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('prepare_monthly_deformation')
run_project('prepare_dynamic_cache')
run_project('prepare_rate_cache')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。

该上游工程还保留了早期机制级与层级小波分析入口（`RUN_PRIMARY_WAVELET_LAG.m`、`RUN_HIERARCHICAL_SPATIAL_WAVELET.m`）。本次论文时间分析的统一入口是 `temporal_m124` 和 `temporal_m3`；缓存准备不自动运行这些早期分析。
