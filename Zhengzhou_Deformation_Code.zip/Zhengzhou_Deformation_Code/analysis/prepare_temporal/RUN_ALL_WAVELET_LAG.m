%% RUN_ALL_WAVELET_LAG.m
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
run(fullfile(projectDir,'CHECK_INPUTS_WAVELET_LAG.m'));
cfg=config_k4_wavelet_lag();
if ~isfile(cfg.cache.dynamicMat), run(fullfile(projectDir,'BUILD_DYNAMIC_CACHE_WAVELET.m')); end
if ~isfile(cfg.cache.rateMat), run(fullfile(projectDir,'BUILD_CENTERED_W6_RATE.m')); end
run(fullfile(projectDir,'RUN_PRIMARY_WAVELET_LAG.m'));
