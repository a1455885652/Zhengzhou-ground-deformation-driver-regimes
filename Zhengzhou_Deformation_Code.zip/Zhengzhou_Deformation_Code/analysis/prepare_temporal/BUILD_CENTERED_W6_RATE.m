%% BUILD_CENTERED_W6_RATE.m
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_k4_wavelet_lag(); cache=load_wavelet_cache(cfg);
[Vrate,R2]=build_centered_rolling_rate_cube(cache.Dcum,cfg.response.halfWindowMonths,cfg.response.annualizeToMmPerYear,cfg.response.minimumFinitePoints);
rate=struct(); rate.Vrate=Vrate; rate.R2=R2; rate.months=cache.months; rate.created=char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
save(cfg.cache.rateMat,'rate','-v7.3');
fprintf('Saved centered W6 rate cube: %s\n',cfg.cache.rateMat);
