function month = parse_month_from_filename(fileName)
% 优先识别 YYYYMMDD，再识别 YYYYMM；返回当月1日；找不到返回 NaT。
month=NaT;
name=char(fileName);
tok=regexp(name,'(?<!\d)(20\d{6})(?!\d)','tokens','once');
if ~isempty(tok)
    try
        d=datetime(tok{1},'InputFormat','yyyyMMdd'); month=dateshift(d,'start','month'); return;
    catch
    end
end
tok=regexp(name,'(?<!\d)(20\d{4})(?!\d)','tokens','once');
if ~isempty(tok)
    try
        month=datetime(tok{1},'InputFormat','yyyyMM'); return;
    catch
    end
end
end
