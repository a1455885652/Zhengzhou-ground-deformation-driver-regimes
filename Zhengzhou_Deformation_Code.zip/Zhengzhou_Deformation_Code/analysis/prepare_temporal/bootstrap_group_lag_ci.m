function CI = bootstrap_group_lag_ci(M,nRep,seed,cfg)
lag=M.lag(:); coh=M.coherence(:); pc=M.phaseConcentration(:); valid=M.valid(:) & isfinite(lag) & isfinite(coh) & isfinite(pc);
lag=lag(valid); coh=coh(valid); pc=pc(valid);
if isempty(lag), CI=struct('Median',NaN,'Low95',NaN,'High95',NaN,'Low90',NaN,'High90',NaN); return; end
rng(seed,'twister'); n=numel(lag); vals=nan(nRep,1);
for r=1:nRep
    idx=randi(n,n,1); use=coh(idx)>=cfg.hierarchical.blockCoherenceThreshold & pc(idx)>=cfg.hierarchical.blockMinimumPhaseConcentration;
    if any(use), vals(r)=median(lag(idx(use)),'omitnan'); end
end
vals=vals(isfinite(vals));
if isempty(vals), CI=struct('Median',median(lag,'omitnan'),'Low95',NaN,'High95',NaN,'Low90',NaN,'High90',NaN); return; end
baseUse=coh>=cfg.hierarchical.blockCoherenceThreshold & pc>=cfg.hierarchical.blockMinimumPhaseConcentration;
CI=struct('Median',median(lag(baseUse),'omitnan'), ...
    'Low95',percentile_simple(vals,2.5),'High95',percentile_simple(vals,97.5), ...
    'Low90',percentile_simple(vals,5),'High90',percentile_simple(vals,95));
end
