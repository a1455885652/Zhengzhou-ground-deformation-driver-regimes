function write_count_geotiff(filePath,Z,R,epsgCode)
[parent,~,~]=fileparts(filePath); if ~isempty(parent)&&~isfolder(parent), mkdir(parent); end
if isfile(filePath), delete(filePath); end
geotiffwrite(filePath,uint32(Z),R,'CoordRefSysCode',epsgCode);
end
