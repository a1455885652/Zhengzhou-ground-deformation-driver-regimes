function R = empty_hierarchical_map_result(mechanism,driverName,isCore,v30p)
mapRow=table(mechanism,string(driverName),logical(isCore),v30p,0,1,1,NaN,NaN, ...
    'VariableNames',{'Mechanism','Driver','IsCoreHypothesis','V30_MapP_FWER','NCandidateClusters','GroupCouplingP','GroupLeadP','GroupCouplingQ','GroupLeadQ'});
R=struct('mapRow',mapRow,'clusterRows',empty_hierarchical_cluster_table(),'nullCouple',[],'nullLead',[],'blockIDs',[],'created',datetime('now'));
end
