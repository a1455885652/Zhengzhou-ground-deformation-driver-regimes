function R = run_one_hierarchical_spatial_map(cache,rate,B,cfg,mechanism,driverIndex)
driverName=string(cfg.driver(driverIndex).name); isCore=is_core_hypothesis(mechanism,driverName,cfg);
sourceFile=fullfile(cfg.hierarchical.sourceMapFolder,sprintf('M%d_%s_WaveletMap.mat',mechanism,driverName));
S0=load(sourceFile,'result'); base=S0.result;
checkpoint=fullfile(cfg.hierarchical.checkpointFolder,sprintf('M%d_%s_Hierarchical.mat',mechanism,driverName));
if isfile(checkpoint)
    S=load(checkpoint,'R'); R=S.R; fprintf('  resume checkpoint\n'); return;
end
if isempty(base.clusterTable)
    R=empty_hierarchical_map_result(mechanism,driverName,isCore,base.mapP_FWER); save(checkpoint,'R','-v7.3'); return;
end
cand=find(base.clusterTable.ClusterP_FWER<cfg.hierarchical.candidateClusterP);
if isempty(cand)
    R=empty_hierarchical_map_result(mechanism,driverName,isCore,base.mapP_FWER); save(checkpoint,'R','-v7.3'); return;
end
masks=cell(numel(cand),1);
for q=1:numel(cand), masks{q}=cluster_mask_for_table_row(base,cand(q),cfg); end
BS=build_block_wavelet_matrices(cache,rate,B,cfg,driverIndex);
obsMetrics=compute_block_metrics_for_masks(BS.XZ,BS.YZ,masks,cfg); nC=numel(cand);
obsG=cell(nC,1); CI=cell(nC,1);
for c=1:nC
    obsG{c}=aggregate_group_wavelet_statistic(obsMetrics{c},cfg);
    CI{c}=bootstrap_group_lag_ci(obsMetrics{c},cfg.hierarchical.bootstrapReplicates, ...
        cfg.inference.randomSeed+mechanism*10000+driverIndex*100+c,cfg);
end
nS=cfg.hierarchical.surrogateReplicates; nullCouple=zeros(nS,nC); nullLead=zeros(nS,nC);
usePar=cfg.hierarchical.useParallelIfAvailable && license('test','Distrib_Computing_Toolbox');
if usePar
    parfor r=1:nS
        rng(cfg.inference.randomSeed+310000+mechanism*10000+driverIndex*1000+r,'twister');
        Xs=synchronized_miaaft_surrogate(BS.XZ,cfg.hierarchical.miaaftMaxIterations,cfg.hierarchical.miaaftRelativeTolerance);
        met=compute_block_metrics_for_masks(Xs,BS.YZ,masks,cfg); a=zeros(1,nC); b=zeros(1,nC);
        for c=1:nC, g=aggregate_group_wavelet_statistic(met{c},cfg); a(c)=g.CouplingStatistic; b(c)=g.LeadStatistic; end
        nullCouple(r,:)=a; nullLead(r,:)=b;
    end
else
    for r=1:nS
        if mod(r,25)==0 || r==1, fprintf('  synchronized surrogate %d/%d\n',r,nS); end
        rng(cfg.inference.randomSeed+310000+mechanism*10000+driverIndex*1000+r,'twister');
        Xs=synchronized_miaaft_surrogate(BS.XZ,cfg.hierarchical.miaaftMaxIterations,cfg.hierarchical.miaaftRelativeTolerance);
        met=compute_block_metrics_for_masks(Xs,BS.YZ,masks,cfg);
        for c=1:nC
            g=aggregate_group_wavelet_statistic(met{c},cfg); nullCouple(r,c)=g.CouplingStatistic; nullLead(r,c)=g.LeadStatistic;
        end
    end
end
rows=empty_hierarchical_cluster_table();
clusterCoupleP=nan(nC,1); clusterLeadP=nan(nC,1);
for c=1:nC
    g=obsG{c}; ci=CI{c}; clusterCoupleP(c)=(1+sum(nullCouple(:,c)>=g.CouplingStatistic))/(nS+1);
    clusterLeadP(c)=(1+sum(nullLead(:,c)>=g.LeadStatistic))/(nS+1); bt=base.clusterTable(cand(c),:);
    row=table(mechanism,driverName,isCore,double(bt.ClusterID),double(bt.ClusterP_FWER),bt.StartMonth,bt.EndMonth,double(bt.PeriodMinMonths),double(bt.PeriodMaxMonths), ...
        g.CouplingStatistic,g.LeadStatistic,clusterCoupleP(c),clusterLeadP(c),NaN,NaN,NaN,NaN,g.NBlocks,g.NSupport,g.SupportFraction,g.MeanCoherence,g.GroupPhaseConcentration,g.DriverLeadFraction,ci.Median, ...
        ci.Low95,ci.High95,ci.Low90,ci.High90,double(bt.PolarityAdjustedLagMonths),"Pending","Pending", ...
        'VariableNames',rows.Properties.VariableNames);
    rows=[rows;row]; %#ok<AGROW>
end
% Protect against selecting multiple candidate clusters within the same map.
mapCoupleP=min(1,min(clusterCoupleP)*nC); mapLeadP=min(1,min(clusterLeadP)*nC);
if ~isempty(rows)
    rows.MapGroupCouplingP(:)=mapCoupleP; rows.MapGroupLeadP(:)=mapLeadP;
end
mapRow=table(mechanism,driverName,isCore,base.mapP_FWER,nC,mapCoupleP,mapLeadP,NaN,NaN, ...
    'VariableNames',{'Mechanism','Driver','IsCoreHypothesis','V30_MapP_FWER','NCandidateClusters','GroupCouplingP','GroupLeadP','GroupCouplingQ','GroupLeadQ'});
R=struct('mapRow',mapRow,'clusterRows',rows,'nullCouple',nullCouple,'nullLead',nullLead,'blockIDs',BS.blockIDs,'created',datetime('now'));
save(checkpoint,'R','-v7.3');
end
