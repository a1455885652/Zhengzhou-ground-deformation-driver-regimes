%% RUN_PRIMARY_WAVELET_LAG.m
% 正式检测：C70, centered W6 rate, 4-24 month WTC, IAAFT + cluster max-mass.
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_k4_wavelet_lag();
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence is required.'); end
cache=load_wavelet_cache(cfg); rate=load_centered_rate_cache(cfg);
ensure_folder(cfg.output.root); ensure_folder(cfg.output.maps); ensure_folder(cfg.output.figures); ensure_folder(cfg.output.spatial);
rng(cfg.inference.randomSeed,'twister');
for m=1:4
    [sel,Tsupport]=select_wavelet_support(cache,cfg,m,cfg.support.primaryConfidence);
    writetable(Tsupport,fullfile(cfg.output.audit,sprintf('M%d_FixedSupport_C70.csv',m)));
    mech=build_mechanism_wavelet_series(cache,rate,cfg,sel,m);
    for j=1:numel(cfg.driver)
        outMat=fullfile(cfg.output.maps,sprintf('M%d_%s_WaveletMap.mat',m,cfg.driver(j).name));
        if cfg.output.resume && isfile(outMat)
            fprintf('Resume: skip existing M%d %s\n',m,cfg.driver(j).name); continue;
        end
        fprintf('\n============================================================\n');
        fprintf(' M%d  %s\n',m,cfg.driver(j).name);
        fprintf('============================================================\n');
        result=run_one_wavelet_map(mech,cfg,j,m);
        save(outMat,'result','-v7.3');
    end
end
finalize_wavelet_map_fdr(cfg);
run_spatial_wavelet_validation(cache,rate,cfg);
write_wavelet_result_summary(cfg);
fprintf('\nPRIMARY WAVELET PHASE-LAG ANALYSIS FINISHED.\nOutput: %s\n',cfg.output.root);
