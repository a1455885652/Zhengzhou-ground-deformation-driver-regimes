function [z,trend] = preprocess_wavelet_series(x,degree)
x=double(x(:)); if any(~isfinite(x)), error('Wavelet input contains NaN/Inf.'); end
n=numel(x); t=(-1:2/(n-1):1)'; p=polyfit(t,x,degree); trend=polyval(p,t); r=x-trend;
s=std(r,0); if ~isfinite(s) || s<=eps, error('Wavelet input has near-zero variance after detrending.'); end
z=(r-mean(r))/s;
end
