function T = summarize_observed_clusters(W,threshold,nullMax,cfg,months)
[masses,comps]=cluster_masses_from_map(W.wcoh,threshold,W.validMask,cfg.inference.minimumClusterCells);
if isempty(masses)
    T=table(); return;
end
rows=[];
for k=1:numel(masses)
    idx=comps{k}; [sr,tc]=ind2sub(size(W.wcoh),idx); span=max(tc)-min(tc)+1;
    if span<cfg.inference.minimumClusterTimeSpanMonths, continue; end
    p=(1+sum(nullMax>=masses(k)))/(1+numel(nullMax)); ps=weighted_phase_stats(W,idx,threshold);
    coh=W.wcoh(idx); per=W.period(sr);
    row=table(k,masses(k),p,numel(idx),months(min(tc)),months(max(tc)),min(per),max(per),mean(per),mean(coh),max(coh), ...
        ps.RawPhaseRad,ps.PhaseConcentration,ps.EffectivePeriodMonths,ps.RawPhaseEquivalentLagMonths,ps.RelationPolarity,ps.AdjustedPhaseRad,ps.PolarityAdjustedLagMonths, ...
        'VariableNames',{'ClusterID','ClusterMass','ClusterP_FWER','NCells','StartMonth','EndMonth','PeriodMinMonths','PeriodMaxMonths','PeriodMeanMonths','MeanCoherence','MaxCoherence', ...
        'RawPhaseRad','PhaseConcentration','EffectivePeriodMonths','RawPhaseEquivalentLagMonths','RelationPolarity','AdjustedPhaseRad','PolarityAdjustedLagMonths'});
    if isempty(rows), rows=row; else, rows=[rows;row]; end %#ok<AGROW>
end
if isempty(rows), T=table(); else, T=rows; end
end
