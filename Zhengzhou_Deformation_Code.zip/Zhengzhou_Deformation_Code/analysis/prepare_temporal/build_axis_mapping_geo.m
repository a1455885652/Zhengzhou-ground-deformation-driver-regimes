function mapping = build_axis_mapping_geo(Rsource,Rtarget,sourceSize,targetSize)
% 以高分辨率源像元中心经纬度映射到目标 1 km cell，不创建完整二维 lon/lat 网格。
nRows=sourceSize(1); nCols=sourceSize(2);
yRows=(1:nRows)'; xDummy=ones(nRows,1);
[latRows,~]=intrinsicToGeographic(Rsource,xDummy,yRows);
xCols=(1:nCols)'; yDummy=ones(nCols,1);
[~,lonCols]=intrinsicToGeographic(Rsource,xCols,yDummy);
lonDummy=repmat(mean(Rtarget.LongitudeLimits),nRows,1);
[~,yT]=geographicToIntrinsic(Rtarget,latRows,lonDummy);
targetRow=round(yT);
rowInside=isfinite(targetRow)&targetRow>=1&targetRow<=targetSize(1);
targetRow(~rowInside)=0;
latDummy=repmat(mean(Rtarget.LatitudeLimits),nCols,1);
[xT,~]=geographicToIntrinsic(Rtarget,latDummy,lonCols);
targetCol=round(xT);
colInside=isfinite(targetCol)&targetCol>=1&targetCol<=targetSize(2);
targetCol(~colInside)=0;
mapping.targetRow=uint32(targetRow);
mapping.targetCol=uint32(targetCol);
mapping.sourceRowsInTargetExtent=find(rowInside);
mapping.sourceColsInTargetExtent=find(colInside);
end
