function [med,lo,hi] = bootstrap_median_ci(x,B,alpha,seed)
x=double(x(:)); x=x(isfinite(x)); if isempty(x), med=NaN; lo=NaN; hi=NaN; return; end
rng(seed,'twister'); med=median(x); boot=nan(B,1); n=numel(x);
for b=1:B, boot(b)=median(x(randi(n,n,1))); end
lo=percentile_simple(boot,100*alpha/2); hi=percentile_simple(boot,100*(1-alpha/2));
end
