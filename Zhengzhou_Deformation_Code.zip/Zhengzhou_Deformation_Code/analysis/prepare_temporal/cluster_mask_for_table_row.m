function mask = cluster_mask_for_table_row(result,row,cfg)
[~,comps]=cluster_masses_from_map(result.W.wcoh,result.threshold,result.W.validMask,cfg.inference.minimumClusterCells);
k=double(result.clusterTable.ClusterID(row));
mask=false(size(result.W.wcoh));
if k>=1 && k<=numel(comps), mask(comps{k})=true; end
end
