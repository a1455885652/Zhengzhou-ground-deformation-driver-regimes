function write_wavelet_result_summary(cfg)
f=fullfile(cfg.output.root,'RESULT_SUMMARY.txt'); fid=fopen(f,'w'); if fid<0, error('Cannot write %s',f); end
cleanup=onCleanup(@() fclose(fid));
fprintf(fid,'Zhengzhou K4 Wavelet Phase-Lag result summary\n'); fprintf(fid,'Generated: %s\n\n',char(datetime('now')));
T=readtable(fullfile(cfg.output.root,'Map_Level_Significance.csv')); role=string(T.Role);
fprintf(fid,'Primary map family (4 mechanisms x 4 primary drivers): %d maps.\n',sum(role=="primary"));
fprintf(fid,'Primary maps passing BH-FDR q<%.3f: %d.\n',cfg.inference.mapFDRAlpha,sum(role=="primary" & T.MapQ_FDR<cfg.inference.mapFDRAlpha));
fprintf(fid,'Secondary maps passing BH-FDR q<%.3f: %d.\n\n',cfg.inference.mapFDRAlpha,sum(role=="secondary" & T.MapQ_FDR<cfg.inference.mapFDRAlpha));
sv=fullfile(cfg.output.spatial,'Spatial_Cluster_Validation.csv');
if isfile(sv)
    S=readtable(sv); if ~isempty(S)
        claim=string(S.ClaimClass); fprintf(fid,'Spatially validated cluster candidates: %d.\n',height(S));
        fprintf(fid,'RobustDriverLeadLag: %d.\n',sum(claim=="RobustDriverLeadLag"));
        fprintf(fid,'SignificantCoherence_LagUnresolved: %d.\n',sum(claim=="SignificantCoherence_LagUnresolved"));
    end
end
fprintf(fid,'\nInterpretation rule: only RobustDriverLeadLag may be described as a statistically supported driver-leading lag.\n');
fprintf(fid,'Significant coherence without a resolved positive lag must not be converted into a causal delay claim.\n');
end
