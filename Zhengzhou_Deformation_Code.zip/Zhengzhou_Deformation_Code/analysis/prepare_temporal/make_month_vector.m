function months = make_month_vector(startMonth,endMonth)
startMonth=dateshift(startMonth,'start','month'); endMonth=dateshift(endMonth,'start','month');
if endMonth<startMonth, error('endMonth 早于 startMonth。'); end
months=(startMonth:calmonths(1):endMonth)';
end
