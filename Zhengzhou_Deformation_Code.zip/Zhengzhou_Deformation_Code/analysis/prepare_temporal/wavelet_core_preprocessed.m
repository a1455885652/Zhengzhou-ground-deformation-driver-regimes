function W = wavelet_core_preprocessed(xz,yz,cfg)
xz=double(xz(:)); yz=double(yz(:));
if numel(xz)~=numel(yz) || any(~isfinite(xz)) || any(~isfinite(yz)), error('Preprocessed wavelet inputs must be finite and equal length.'); end
fLim=[1/cfg.wavelet.maxPeriodMonths, 1/cfg.wavelet.minPeriodMonths];
[wcoh,wcs,f,coi]=wcoherence(xz,yz,1,'FrequencyLimits',fLim, ...
    'VoicesPerOctave',cfg.wavelet.voicesPerOctave,'NumScalesToSmooth',cfg.wavelet.numScalesToSmooth);
f=double(f(:)); period=1./f; coi=double(coi(:)); coiPeriod=1./coi;
valid=period(:)<=coiPeriod(:)';
W=struct('wcoh',double(wcoh),'wcs',wcs,'frequency',f,'period',period,'coiFrequency',coi,'coiPeriod',coiPeriod,'validMask',valid,'phase',angle(wcs));
end
