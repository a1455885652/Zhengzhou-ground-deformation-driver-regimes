function comps = connected_components_8(mask)
mask=logical(mask); [nr,nc]=size(mask); visited=false(nr,nc); comps={};
for r=1:nr
    for c=1:nc
        if ~mask(r,c) || visited(r,c), continue; end
        qr=zeros(nnz(mask),1); qc=zeros(nnz(mask),1); head=1; tail=1; qr(1)=r; qc(1)=c; visited(r,c)=true; idx=[];
        while head<=tail
            rr=qr(head); cc=qc(head); head=head+1; idx(end+1,1)=sub2ind([nr,nc],rr,cc); %#ok<AGROW>
            for dr=-1:1
                for dc=-1:1
                    if dr==0 && dc==0, continue; end
                    r2=rr+dr; c2=cc+dc;
                    if r2>=1 && r2<=nr && c2>=1 && c2<=nc && mask(r2,c2) && ~visited(r2,c2)
                        tail=tail+1; qr(tail)=r2; qc(tail)=c2; visited(r2,c2)=true;
                    end
                end
            end
        end
        comps{end+1,1}=idx; %#ok<AGROW>
    end
end
end
