function write_hierarchical_summary(M,C,cfg)
f=fullfile(cfg.hierarchical.outputRoot,'RESULT_SUMMARY.txt'); fid=fopen(f,'w'); if fid<0,error('Cannot write summary.');end
cl=onCleanup(@() fclose(fid));
fprintf(fid,'Zhengzhou K4 Hierarchical Spatial-Block Wavelet Lag v3.1\n');
fprintf(fid,'Generated: %s\n\n',char(datetime('now')));
fprintf(fid,'Core hypothesis family: %d maps. Screening family: %d maps.\n',sum(M.IsCoreHypothesis),sum(~M.IsCoreHypothesis));
fprintf(fid,'Core GroupLead q<0.05: %d; q<0.10: %d.\n',sum(M.IsCoreHypothesis & M.GroupLeadQ<0.05),sum(M.IsCoreHypothesis & M.GroupLeadQ<0.10));
fprintf(fid,'Screening GroupLead q<0.05: %d; q<0.10: %d.\n\n',sum(~M.IsCoreHypothesis & M.GroupLeadQ<0.05),sum(~M.IsCoreHypothesis & M.GroupLeadQ<0.10));
if isempty(C), fprintf(fid,'No candidate clusters entered hierarchical inference.\n'); return; end
cc=string(C.ClaimClass);
fprintf(fid,'Tier-A ConfirmedDriverLeadLag: %d\n',sum(cc=="ConfirmedDriverLeadLag"));
fprintf(fid,'Tier-B SupportedDriverLeadLag: %d\n',sum(cc=="SupportedDriverLeadLag"));
fprintf(fid,'Tier-B SupportedCoherence_LagUnresolved: %d\n',sum(cc=="SupportedCoherence_LagUnresolved"));
fprintf(fid,'Tier-C DirectionalCandidate_NotFDR: %d\n\n',sum(cc=="DirectionalCandidate_NotFDR"));
fprintf(fid,'Interpretation:\n');
fprintf(fid,'Tier-A may be reported as statistically confirmed driver-leading lag (association, not causation).\n');
fprintf(fid,'Tier-B is supportive/discovery evidence and must be labelled as such; q<0.10 and 90%% lag CI are intentionally less strict.\n');
fprintf(fid,'Tier-C must not be converted into a formal lag claim.\n');
fprintf(fid,'cluster-FWER remains controlled by v3.0 max-cluster inference; v3.1 does not relax it for Tier-A.\n');
end
