function Z = rank_remap_columns(Y,sortedTarget)
[n,p]=size(Y); Z=zeros(n,p);
for j=1:p
    [~,ord]=sort(Y(:,j),'ascend'); z=zeros(n,1); z(ord)=sortedTarget(:,j); Z(:,j)=z;
end
end
