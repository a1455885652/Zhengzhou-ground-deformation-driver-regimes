function tf = to_logical_scalar(x)
% 将 readtable 可能返回的 logical/numeric/string/cellstr 安全转换为单个 logical。
if islogical(x), tf=x(1); return; end
if isnumeric(x), tf=(x(1)~=0); return; end
if iscell(x), x=x{1}; end
s=lower(strtrim(string(x)));
if any(s==["true","1","yes","y"]), tf=true;
elseif any(s==["false","0","no","n"]), tf=false;
else, error('无法解析逻辑值：%s',s); end
end
