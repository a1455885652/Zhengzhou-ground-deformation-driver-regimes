function cfg = config_k4_wavelet_lag()
% CONFIG_K4_WAVELET_LAG
% 郑州 K=4 机制分区：中心W6速率 + 小波相干 + 层级空间块相位滞后
% MATLAB R2023b
%
% 科学目标：
%   不再假设 2018-2025 全期只有一个固定 lag，而是在 time-frequency 平面寻找
%   “何时、在哪个周期尺度上”水文驱动与形变速率发生稳定耦合，再由交叉谱相位
%   反演等效时间滞后，并用空间块验证其空间稳健性。
%
% 统计原则：
% 1) 主检测使用机制级固定支持的稳健空间中位数，提高信噪比；
% 2) 6个月滑动速率采用 7 个累计形变点 OLS slope，并把时间戳放在窗口中心，避免前向窗口人为相移；
% 3) 不移除季节项，只去线性趋势；季节/半年/年尺度正是小波要识别的信号；
% 4) wcoherence 使用 analytic Morlet；
% 5) 显著性不采用简单 AR(1) 红噪声，而使用 IAAFT 代理序列，保留边际分布与功率谱；
% 6) time-frequency 多重比较用“cluster-forming threshold + max cluster mass surrogate null”；
% 7) map-level P 再在 M1-M4 × 主驱动之间做 BH-FDR；
% 8) 只有 COI 内、cluster-FWER 通过、map-FDR 通过、相位集中度足够、空间块支持足够时才允许称为稳健 lag；
% 9) 输出 candidate 与 robust 两级结果，不把未通过严格条件的峰值包装成物理滞后。

%% 时间
cfg.time.startMonth = datetime(2018,8,1);
cfg.time.endMonth   = datetime(2025,12,1);

%% 最终 1 km 格网
cfg.grid.maskFile = zz_project_path('yanmo/Zhengzhou_mask_1km.tif');
cfg.grid.maskZeroIsOutside = true;
cfg.grid.epsg = 4326;

%% InSAR
cfg.insar.monthEndHighResFolder = ...
    zz_external_path('monthly_deformation');
cfg.insar.monthEnd1kmFolder = ...
    zz_project_path('InSAR_1km_latest_irregular_shape/02_MonthEnd_Cumulative_1km');
cfg.insar.auditOutputFolder = ...
    zz_project_path('InSAR_1km_latest_irregular_shape/02_MonthEnd_Cumulative_1km_Audit');
cfg.insar.finalVelocity1km = ...
    zz_project_path('InSAR_1km_latest_irregular_shape/04_Velocity_1km/InSAR_Velocity_1km.tif');
cfg.insar.aggregationMethod = 'mean';
cfg.insar.minimumSourcePixels = 1;
cfg.insar.blockRows = 256;
cfg.insar.writeMonthlySourceCountRaster = false;

%% K4
cfg.k4.assignmentFile = ...
    zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output/Python_Output/K4_Assignment.csv');
cfg.k4.decisionFile = ...
    zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output/Python_Output/K4_K5_Strict_Decision.csv');
cfg.k4.expectedSampleCount = 7081;
cfg.k4.expectedClusterCounts = [2279 1794 1522 1486];
cfg.k4.expectedClusters = 1:4;
cfg.k4.maxTargetAbsDifference = 1e-3;
cfg.k4.minTargetCorrelation = 0.99999;
cfg.k4.minCumulativeSlopeCorrelation = 0.90;
cfg.k4.minCumulativeSignAgreement = 0.90;

%% 动态水文驱动
cfg.driver(1).name = 'GWS';
cfg.driver(1).folder = zz_project_path('GWS_1km');
cfg.driver(1).role = 'primary';

cfg.driver(2).name = 'SurfaceRunoff';
cfg.driver(2).folder = zz_project_path('ERA5_Land_1km_TIF/Surface runoff');
cfg.driver(2).role = 'primary';

cfg.driver(3).name = 'SkinReservoir';
cfg.driver(3).folder = zz_project_path('ERA5_Land_1km_TIF/Skin reservoir content');
cfg.driver(3).role = 'primary';

cfg.driver(4).name = 'SoilWater';
cfg.driver(4).folder = zz_project_path('ERA5_Land_1km_TIF/SoilWater_0_289cm_depth_weighted');
cfg.driver(4).role = 'primary';

cfg.driver(5).name = 'TotalPrecipitation';
cfg.driver(5).folder = zz_project_path('ERA5_Land_1km_TIF/Total precipitation');
cfg.driver(5).role = 'secondary';

cfg.driver(6).name = 'SubsurfaceRunoff';
cfg.driver(6).folder = zz_project_path('ERA5_Land_1km_TIF/Sub-surface runoff');
cfg.driver(6).role = 'secondary';

%% 固定空间支持
cfg.support.primaryConfidence = 0.70;
cfg.support.minimumTemporalCoverage = 0.90;
cfg.support.minimumPixelsPerMechanism = 80;
cfg.support.minimumMonthlyValidFraction = 0.70;

%% 6个月中心滑动形变速率
% 对 t-3:t+3 共7个月累计形变做 OLS slope，时间戳放在 t。
% 这样滤波是时间对称的，不把 response 人工向前或向后平移。
cfg.response.halfWindowMonths = 3;
cfg.response.spanMonths = 6;
cfg.response.annualizeToMmPerYear = true;
cfg.response.minimumFinitePoints = 7;

%% 小波设置
cfg.wavelet.minPeriodMonths = 4;
cfg.wavelet.maxPeriodMonths = 24;
cfg.wavelet.voicesPerOctave = 24;
cfg.wavelet.numScalesToSmooth = 12;
cfg.wavelet.detrendDegree = 1;
cfg.wavelet.minimumSeriesLength = 60;
cfg.wavelet.minimumCoherenceForSpatialSupport = 0.50;
cfg.wavelet.minimumPhaseConcentration = 0.50;

% 描述性尺度带，不单独做显著性搜寻；显著性针对完整 time-frequency map。
cfg.wavelet.bandNames = {'4-8m','8-16m','16-24m'};
cfg.wavelet.bandRanges = [4 8; 8 16; 16 24];

%% IAAFT + cluster-based Monte Carlo inference
% 第一套代理序列只用于估计 scale-specific cluster-forming threshold；
% 第二套独立代理序列用于 max-cluster-mass 零分布，避免同一代理集合反复调阈值。
cfg.inference.thresholdSurrogates = 499;
cfg.inference.clusterNullSurrogates = 1999;
cfg.inference.clusterFormingQuantile = 0.90; % 有意较宽松；最终由 max-cluster FWER=0.05 控制
cfg.inference.clusterAlpha = 0.05;
cfg.inference.mapFDRAlpha = 0.05;
cfg.inference.minimumClusterCells = 8;
cfg.inference.minimumClusterTimeSpanMonths = 4;
cfg.inference.iaaftMaxIterations = 500;
cfg.inference.iaaftRelativeTolerance = 1e-7;
cfg.inference.randomSeed = 20260907;

%% 空间块验证
cfg.spatial.blockPixels = 5;                % 约5 km × 5 km
cfg.spatial.minimumPixelsPerBlock = 12;
cfg.spatial.minimumBlocks = 5;
cfg.spatial.minimumSupportFraction = 0.40;
cfg.spatial.bootstrapReplicates = 2000;
cfg.spatial.driverLeadFraction = 0.60;
cfg.spatial.alpha = 0.05;


%% v3.1 层级空间块统计（正式升级）
% 第一层仍使用 v3.0 已完成的机制级 WTC + cluster-FWER，负责限定候选 time-frequency 区域；
% 第二层不再只做“空间块阈值验证”，而是把空间块作为统计重复：
%   block WTC -> group coupling/driver-leading statistic -> synchronized multivariate IAAFT null -> group p/q。
%
% 重要：以下放宽仅用于 Tier-B 支持性结论。Tier-A 的 cluster-FWER=0.05、FDR=0.05、95%CI 均保留。
cfg.hierarchical.sourceMapFolder = ...
    zz_project_path('K4_WaveletPhaseLag_Output/Map_Results');
cfg.hierarchical.outputRoot = ...
    zz_project_path('K4_WaveletPhaseLag_Hierarchical_Output');
cfg.hierarchical.checkpointFolder = fullfile(cfg.hierarchical.outputRoot,'Checkpoints');
cfg.hierarchical.figureFolder = fullfile(cfg.hierarchical.outputRoot,'Figures');

% 进入第二层检验的候选 cluster：v3.0 已经用 max-cluster null 控制整张 time-frequency map。
cfg.hierarchical.candidateClusterP = 0.10;

% 空间块：沿用约5 km块，但适度放宽单块有效性与支持条件。
cfg.hierarchical.blockPixels = 5;
cfg.hierarchical.minimumPixelsPerBlock = 10;
cfg.hierarchical.blockCoherenceThreshold = 0.45;
cfg.hierarchical.blockMinimumPhaseConcentration = 0.30;

% 同步多变量 IAAFT surrogate：保留同一驱动在各空间块间的相对谱相位/交叉相关结构，
% 同时破坏 driver 与 deformation 的真实相位对应。
cfg.hierarchical.surrogateReplicates = 999;
cfg.hierarchical.miaaftMaxIterations = 300;
cfg.hierarchical.miaaftRelativeTolerance = 1e-6;
cfg.hierarchical.useParallelIfAvailable = true;

% 空间 bootstrap。95%CI 用于 Tier-A；90%CI 仅用于 Tier-B 支持性结论。
cfg.hierarchical.bootstrapReplicates = 4000;
cfg.hierarchical.confirmatoryAlpha = 0.05;
cfg.hierarchical.supportiveAlpha = 0.10;

% Tier-A：严格确认性结果。
cfg.hierarchical.tierA.mapFDR = 0.05;
cfg.hierarchical.tierA.clusterP = 0.05;
cfg.hierarchical.tierA.minimumSupportFraction = 0.40;
cfg.hierarchical.tierA.minimumPhaseConcentration = 0.50;
cfg.hierarchical.tierA.minimumLeadFraction = 0.60;
cfg.hierarchical.tierA.minimumSupportingBlocks = 5;

% Tier-B：支持性/探索性结果。该层不允许写成“confirmed causal lag”。
cfg.hierarchical.tierB.mapFDR = 0.10;
cfg.hierarchical.tierB.clusterP = 0.10;
cfg.hierarchical.tierB.minimumSupportFraction = 0.30;
cfg.hierarchical.tierB.minimumPhaseConcentration = 0.40;
cfg.hierarchical.tierB.minimumLeadFraction = 0.55;
cfg.hierarchical.tierB.minimumSupportingBlocks = 4;

% SHAP 机制分区阶段（早于小波分析）已给出的核心动态驱动，用作先验 Core family。
% 其余 mechanism-driver 组合仍全部计算，但放入 Screening family 单独 BH-FDR。
% M1 top: GWS, DEM, SkinReservoir -> 动态核心 GWS/SkinReservoir
% M2 top: SurfaceRunoff, GWS, DEM -> 动态核心 SurfaceRunoff/GWS
% M3 top: SurfaceRunoff, GWS, SubsurfaceRunoff -> 三者均为动态核心
% M4 top: SkinReservoir, BuiltSurface, DEM -> 动态核心 SkinReservoir
cfg.hierarchical.corePairs = {
    1,'GWS';
    1,'SkinReservoir';
    2,'SurfaceRunoff';
    2,'GWS';
    3,'SurfaceRunoff';
    3,'GWS';
    3,'SubsurfaceRunoff';
    4,'SkinReservoir'};

% 第二层 group statistic：
% coupling = supportFraction * meanCoherence * groupPhaseConcentration
% lead     = coupling * max(0, 2*driverLeadFraction-1)
% p值完全由 synchronized MIAAFT null 给出，不依赖正态近似。

%% Cache / output
cfg.cache.root = zz_project_path('K4_WaveletPhaseLag_Cache');
cfg.cache.dynamicMat = fullfile(cfg.cache.root,'K4_Wavelet_DynamicCube.mat');
cfg.cache.rateMat = fullfile(cfg.cache.root,'K4_CenteredW6_RateCube.mat');

cfg.output.root = zz_project_path('K4_WaveletPhaseLag_Output');
cfg.output.audit = fullfile(cfg.output.root,'Audit');
cfg.output.maps = fullfile(cfg.output.root,'Map_Results');
cfg.output.figures = fullfile(cfg.output.root,'Figures');
cfg.output.spatial = fullfile(cfg.output.root,'Spatial_Validation');
cfg.output.resume = true;
cfg.output.makeFigures = true;
cfg.output.overwrite1kmMonthEnd = false;

end
