function [targetData,targetCount]=aggregate_source_to_target_axis(sourceData,mapping,targetSize,minimumSourcePixels,blockRows,aggregationMethod)
if ~strcmpi(aggregationMethod,'mean'), error('仅支持 mean 聚合。'); end
if minimumSourcePixels<1, error('minimumSourcePixels 必须 >=1。'); end
nTarget=prod(targetSize);
sumVec=zeros(nTarget,1);
countVec=zeros(nTarget,1,'uint32');
rowsAll=mapping.sourceRowsInTargetExtent; colsAll=mapping.sourceColsInTargetExtent;
if isempty(rowsAll)||isempty(colsAll)
    targetData=nan(targetSize); targetCount=zeros(targetSize,'uint32'); return;
end
firstRow=rowsAll(1); lastRow=rowsAll(end); firstCol=colsAll(1); lastCol=colsAll(end);
for r0=firstRow:blockRows:lastRow
    r1=min(r0+blockRows-1,lastRow); rows=r0:r1; cols=firstCol:lastCol;
    block=sourceData(rows,cols); valid=isfinite(block);
    if ~any(valid(:)), continue; end
    [lr,lc]=find(valid);
    sr=rows(lr); sc=cols(lc);
    tr=double(mapping.targetRow(sr)); tc=double(mapping.targetCol(sc));
    inside=tr>0&tc>0;
    if ~any(inside), continue; end
    localLinear=sub2ind(size(block),lr(inside),lc(inside));
    vals=double(block(localLinear));
    targetLinear=sub2ind(targetSize,tr(inside),tc(inside));
    bsum=accumarray(targetLinear,vals,[nTarget 1],@sum,0);
    bcnt=accumarray(targetLinear,1,[nTarget 1],@sum,0);
    sumVec=sumVec+bsum;
    countVec=countVec+uint32(bcnt);
end
out=nan(nTarget,1);
good=double(countVec)>=minimumSourcePixels;
out(good)=sumVec(good)./double(countVec(good));
targetData=reshape(out,targetSize);
targetCount=reshape(countVec,targetSize);
end
