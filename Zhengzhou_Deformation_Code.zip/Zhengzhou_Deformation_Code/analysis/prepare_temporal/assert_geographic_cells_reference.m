function assert_geographic_cells_reference(R, filePath)
if ~isa(R,'map.rasterref.GeographicCellsReference')
    error(['本工程要求 GeographicCellsReference（经纬度 cell raster）。\n' ...
        '文件：%s\n实际 reference class：%s'], filePath, class(R));
end
if any(~isfinite([R.LatitudeLimits R.LongitudeLimits R.CellExtentInLatitude R.CellExtentInLongitude]))
    error('地理参考包含非有限值：%s', filePath);
end
end
