function q = bh_fdr_wavelet(p)
p=double(p(:)); q=nan(size(p)); g=isfinite(p); pg=p(g); m=numel(pg); if m==0, return; end
[ps,ord]=sort(pg); qs=ps.*m./(1:m)'; for i=m-1:-1:1, qs(i)=min(qs(i),qs(i+1)); end; qs=min(qs,1);
idx=find(g); q(idx(ord))=qs;
end
