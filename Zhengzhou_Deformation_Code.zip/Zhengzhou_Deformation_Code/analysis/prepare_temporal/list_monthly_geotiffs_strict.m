function T = list_monthly_geotiffs_strict(folderPath,requiredMonths)
% 分析期内每个月必须恰好一个 tif/tiff；重复或缺月直接报错。
if ~isfolder(folderPath), error('目录不存在：%s',folderPath); end
D=[dir(fullfile(folderPath,'*.tif'));dir(fullfile(folderPath,'*.tiff'))];
month=NaT(numel(D),1); path=strings(numel(D),1); name=strings(numel(D),1); keep=false(numel(D),1);
for k=1:numel(D)
    if D(k).isdir, continue; end
    m=parse_month_from_filename(D(k).name);
    if ~isnat(m)
        keep(k)=true; month(k)=m; name(k)=string(D(k).name); path(k)=string(fullfile(D(k).folder,D(k).name));
    end
end
month=month(keep); path=path(keep); name=name(keep);
T0=table(month,name,path,'VariableNames',{'Month','FileName','FilePath'});
T0=T0(ismember(T0.Month,requiredMonths),:);
T0=sortrows(T0,{'Month','FileName'});

outMonth=requiredMonths(:); outName=strings(numel(outMonth),1); outPath=strings(numel(outMonth),1);
for i=1:numel(outMonth)
    hit=find(T0.Month==outMonth(i));
    if isempty(hit)
        error('缺少月份 %s：\n%s',char(string(outMonth(i),'yyyy-MM')),folderPath);
    elseif numel(hit)>1
        error('月份 %s 存在 %d 个候选 GeoTIFF，拒绝静默选取：\n%s', ...
            char(string(outMonth(i),'yyyy-MM')),numel(hit),folderPath);
    end
    outName(i)=T0.FileName(hit); outPath(i)=T0.FilePath(hit);
end
T=table(outMonth,outName,outPath,'VariableNames',{'Month','FileName','FilePath'});
end
