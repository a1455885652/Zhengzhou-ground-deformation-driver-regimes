function nullMax = estimate_null_max_cluster_iaaft(x,y,Wobs,threshold,cfg,seed)
[x0,~]=preprocess_wavelet_series(x,cfg.wavelet.detrendDegree); [y0,~]=preprocess_wavelet_series(y,cfg.wavelet.detrendDegree);
rng(seed,'twister'); nS=cfg.inference.clusterNullSurrogates; nullMax=zeros(nS,1); valid=Wobs.validMask;
fprintf('  Cluster-null surrogates: %d\n',nS);
for b=1:nS
    xs=iaaft_surrogate(x0,cfg.inference.iaaftMaxIterations,cfg.inference.iaaftRelativeTolerance);
    ys=iaaft_surrogate(y0,cfg.inference.iaaftMaxIterations,cfg.inference.iaaftRelativeTolerance);
    Ws=wavelet_core_preprocessed(xs,ys,cfg);
    masses=cluster_masses_from_map(Ws.wcoh,threshold,valid,cfg.inference.minimumClusterCells);
    if isempty(masses), nullMax(b)=0; else, nullMax(b)=max(masses); end
    if mod(b,100)==0 || b==nS, fprintf('    %d/%d\n',b,nS); end
end
end
