function validate_v30_map_source(cfg)
if ~isfolder(cfg.hierarchical.sourceMapFolder)
    error('v3.0 Map_Results folder not found: %s',cfg.hierarchical.sourceMapFolder);
end
missing={};
for m=1:4
    for j=1:numel(cfg.driver)
        f=fullfile(cfg.hierarchical.sourceMapFolder,sprintf('M%d_%s_WaveletMap.mat',m,cfg.driver(j).name));
        if ~isfile(f), missing{end+1,1}=f; end %#ok<AGROW>
    end
end
if ~isempty(missing)
    error('Missing %d v3.0 wavelet-map files. First missing: %s',numel(missing),missing{1});
end
end
