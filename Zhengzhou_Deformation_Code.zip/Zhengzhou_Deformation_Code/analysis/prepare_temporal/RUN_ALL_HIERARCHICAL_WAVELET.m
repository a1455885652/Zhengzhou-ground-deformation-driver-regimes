%% RUN_ALL_HIERARCHICAL_WAVELET.m
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
fprintf('Step 1/2: hierarchical self test\n'); run(fullfile(projectDir,'SELF_TEST_HIERARCHICAL_WAVELET.m'));
fprintf('Step 2/2: hierarchical spatial wavelet inference\n'); run(fullfile(projectDir,'RUN_HIERARCHICAL_SPATIAL_WAVELET.m'));
