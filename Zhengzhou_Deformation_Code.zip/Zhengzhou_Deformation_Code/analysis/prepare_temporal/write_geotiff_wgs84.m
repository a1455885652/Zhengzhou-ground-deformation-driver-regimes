function write_geotiff_wgs84(filePath,Z,R,epsgCode)
[parent,~,~]=fileparts(filePath); if ~isempty(parent)&&~isfolder(parent), mkdir(parent); end
if isfile(filePath), delete(filePath); end
geotiffwrite(filePath,single(Z),R,'CoordRefSysCode',epsgCode);
end
