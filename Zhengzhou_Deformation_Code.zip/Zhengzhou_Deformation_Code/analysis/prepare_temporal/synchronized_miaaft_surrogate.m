function Z = synchronized_miaaft_surrogate(X,maxIter,relTol)
% Multivariate/synchronized IAAFT-like surrogate.
% X: time x spatial-block matrix, already detrended/standardized.
% Spectral projection preserves each block Fourier amplitude and the relative
% phase between blocks at every frequency by allowing only a common phase
% rotation at each frequency. Rank remapping preserves each block marginal distribution.
X=double(X); [n,p]=size(X);
if n<8 || p<1 || any(~isfinite(X),'all'), error('Invalid synchronized MIAAFT input.'); end
sortedX=sort(X,1); F0=fft(X,[],1); targetAmp=abs(F0);
% Initial common random Fourier phase rotations.
theta=zeros(n,1); nPos=floor((n-1)/2);
theta(2:1+nPos)=2*pi*rand(nPos,1)-pi;
for k=2:1+nPos, theta(n-k+2)=-theta(k); end
if mod(n,2)==0, theta(n/2+1)=0; end
phaseMat=repmat(exp(1i*theta),1,p); Z=real(ifft(F0.*phaseMat,[],1));
Z=rank_remap_columns(Z,sortedX); prev=Inf;
for it=1:maxIter
    Fz=fft(Z,[],1); theta=zeros(n,1);
    for k=2:1+nPos
        c=sum(Fz(k,:).*conj(F0(k,:)));
        if abs(c)<=eps, th=2*pi*rand-pi; else, th=angle(c); end
        theta(k)=th; theta(n-k+2)=-th;
    end
    if mod(n,2)==0, theta(n/2+1)=0; end
    Ft=F0.*repmat(exp(1i*theta),1,p);
    Z2=rank_remap_columns(real(ifft(Ft,[],1)),sortedX);
    A=abs(fft(Z2,[],1)); err=norm(A-targetAmp,'fro')/max(norm(targetAmp,'fro'),eps);
    Z=Z2;
    if isfinite(prev) && abs(prev-err)<=relTol*max(1,prev), break; end
    prev=err;
end
end
