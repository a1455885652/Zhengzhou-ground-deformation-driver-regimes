function [slope,r2] = rolling_ols_slope_minpoints(Dseg,annualize,minFinitePoints)
% Columnwise OLS slope against month index 0:(W-1), allowing configurable finite-point minimum.
[nT,nP]=size(Dseg); slope=nan(1,nP); r2=nan(1,nP); x=(0:nT-1)';
for p=1:nP
    y=double(Dseg(:,p)); g=isfinite(y);
    if nnz(g)<minFinitePoints, continue; end
    xx=x(g); yy=y(g); xm=mean(xx); ym=mean(yy); den=sum((xx-xm).^2);
    if den<=0, continue; end
    b=sum((xx-xm).*(yy-ym))/den; a=ym-b*xm; pred=a+b*xx;
    ssr=sum((yy-pred).^2); sst=sum((yy-ym).^2);
    slope(p)=b; if sst>0, r2(p)=1-ssr/sst; end
end
if annualize, slope=slope*12; end
end
