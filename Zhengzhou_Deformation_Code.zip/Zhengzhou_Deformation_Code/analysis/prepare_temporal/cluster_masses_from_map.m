function [masses,comps] = cluster_masses_from_map(wcoh,threshold,validMask,minCells)
excess=wcoh-threshold(:); mask=validMask & excess>0; comps0=connected_components_8(mask); masses=[]; comps={};
for k=1:numel(comps0)
    idx=comps0{k}; if numel(idx)<minCells, continue; end
    masses(end+1,1)=sum(excess(idx),'omitnan'); %#ok<AGROW>
    comps{end+1,1}=idx; %#ok<AGROW>
end
end
