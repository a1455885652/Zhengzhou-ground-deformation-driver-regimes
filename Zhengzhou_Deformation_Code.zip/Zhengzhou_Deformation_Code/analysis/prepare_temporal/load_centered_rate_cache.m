function rate = load_centered_rate_cache(cfg)
if ~isfile(cfg.cache.rateMat), error('Rate cache missing: %s\nRun BUILD_CENTERED_W6_RATE.m first.',cfg.cache.rateMat); end
S=load(cfg.cache.rateMat,'rate'); rate=S.rate;
end
