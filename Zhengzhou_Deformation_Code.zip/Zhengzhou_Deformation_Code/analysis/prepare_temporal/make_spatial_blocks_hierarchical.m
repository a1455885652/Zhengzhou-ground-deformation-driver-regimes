function B = make_spatial_blocks_hierarchical(cache,sel,cfg)
row=double(cache.K4.RasterRow(sel)); col=double(cache.K4.RasterColumn(sel)); bs=cfg.hierarchical.blockPixels;
br=floor((row-1)/bs)+1; bc=floor((col-1)/bs)+1; key=br*10000+bc; [u,~,g]=unique(key);
blockID=[]; pixelLists={}; nPixels=[]; brOut=[]; bcOut=[];
for k=1:numel(u)
    idx=find(g==k);
    if numel(idx)<cfg.hierarchical.minimumPixelsPerBlock, continue; end
    blockID(end+1,1)=numel(blockID)+1; %#ok<AGROW>
    pixelLists{end+1,1}=sel(idx); %#ok<AGROW>
    nPixels(end+1,1)=numel(idx); brOut(end+1,1)=br(idx(1)); bcOut(end+1,1)=bc(idx(1)); %#ok<AGROW>
end
B=struct('blockID',blockID,'pixelLists',{pixelLists},'nPixels',nPixels,'blockRow',brOut,'blockCol',bcOut);
end
