function assert_file_exists(filePath, label)
if ~isfile(filePath)
    error('%s 不存在：\n%s', label, filePath);
end
end
