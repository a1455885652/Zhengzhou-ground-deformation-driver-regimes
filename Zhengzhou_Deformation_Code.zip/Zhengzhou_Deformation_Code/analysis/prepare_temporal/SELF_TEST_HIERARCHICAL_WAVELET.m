%% SELF_TEST_HIERARCHICAL_WAVELET.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir); cfg=config_k4_wavelet_lag();
fprintf('Running hierarchical wavelet self tests...\n');
% 1) synchronized surrogate preserves every column marginal exactly.
rng(1); X=randn(83,6); X(:,2)=0.7*X(:,1)+0.3*randn(83,1); Z=synchronized_miaaft_surrogate(X,100,1e-6);
for j=1:size(X,2), assert(max(abs(sort(X(:,j))-sort(Z(:,j))))<1e-12,'Marginal distribution not preserved.'); end
fprintf('  [PASS] synchronized MIAAFT marginal preservation\n');
% 2) Relative cross-spectral structure should remain broadly similar.
C0=corrcoef(X); C1=corrcoef(Z); assert(mean(abs(C0(:)-C1(:)))<0.20,'Spatial cross-correlation preservation is too poor.');
fprintf('  [PASS] synchronized spatial dependence preservation\n');
% 3) Group statistic increases under coherent multi-block driver-leading synthetic signal.
t=(1:83)'; B=12; Xz=zeros(83,B); Yz=zeros(83,B);
for b=1:B
    x=sin(2*pi*t/8 + 0.05*b)+0.15*randn(83,1);
    y=[nan; x(1:end-1)]+0.15*randn(83,1); y(1)=y(2);
    Xz(:,b)=preprocess_wavelet_series(x,1); Yz(:,b)=preprocess_wavelet_series(y,1);
end
W0=wavelet_core_preprocessed(Xz(:,1),Yz(:,1),cfg); mask=W0.validMask & W0.period(:)>=6 & W0.period(:)<=10;
met=compute_block_metrics_for_masks(Xz,Yz,{mask},cfg); g=aggregate_group_wavelet_statistic(met{1},cfg);
assert(g.SupportFraction>0.5 && g.DriverLeadFraction>0.5,'Synthetic coherent lead was not recovered.');
fprintf('  [PASS] group spatial lead statistic\n');
% 4) Core pair definition.
assert(is_core_hypothesis(3,'SubsurfaceRunoff',cfg) && ~is_core_hypothesis(4,'GWS',cfg),'Core hypothesis family error.');
fprintf('  [PASS] SHAP-prior core hypothesis family\n');
fprintf('ALL HIERARCHICAL WAVELET SELF TESTS PASSED.\n');
