function [slopeAnnual,r2] = rolling_ols_slope_complete(Dseg,annualize)
% Dseg: [window+1 x nPixel], complete windows only are used.
n=size(Dseg,1); tt=(0:n-1)'; tc=tt-mean(tt); den=sum(tc.^2);
slopeAnnual=nan(1,size(Dseg,2)); r2=nan(1,size(Dseg,2));
ok=all(isfinite(Dseg),1);
if ~any(ok), return; end
Y=double(Dseg(:,ok));
sl=(tc' * Y)/den;
intercept=mean(Y,1)-sl*mean(tt);
fit=intercept + tt*sl;
sse=sum((Y-fit).^2,1); ym=mean(Y,1); sst=sum((Y-ym).^2,1);
r=1-sse./max(sst,eps); r(sst<=eps)=1;
if annualize, sl=sl*12; end
slopeAnnual(ok)=sl; r2(ok)=r;
end
