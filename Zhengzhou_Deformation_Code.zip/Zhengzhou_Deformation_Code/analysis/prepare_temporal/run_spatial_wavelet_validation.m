function run_spatial_wavelet_validation(cache,rate,cfg)
ensure_folder(cfg.output.spatial); allRows=[];
for m=1:4
    [sel,~]=select_wavelet_support(cache,cfg,m,cfg.support.primaryConfidence); B=make_spatial_blocks(cache,sel,cfg);
    if numel(B.blockID)<cfg.spatial.minimumBlocks, warning('M%d has only %d spatial blocks.',m,numel(B.blockID)); end
    for j=1:numel(cfg.driver)
        f=fullfile(cfg.output.maps,sprintf('M%d_%s_WaveletMap.mat',m,cfg.driver(j).name)); S=load(f,'result'); result=S.result;
        if isempty(result.clusterTable), continue; end
        for c=1:height(result.clusterTable)
            if result.clusterTable.ClusterP_FWER(c)>=0.10, continue; end % validate plausible clusters, not only final significant ones
            cmask=cluster_mask_for_table_row(result,c,cfg); lagVals=[]; lead=[]; cohVals=[]; blockIDs=[];
            for b=1:numel(B.blockID)
                pix=B.pixelLists{b};
                tIdx=(1+cfg.response.halfWindowMonths):(numel(cache.months)-cfg.response.halfWindowMonths);
                yy=nan(numel(tIdx),1); xx=nan(numel(tIdx),1);
                for tt=1:numel(tIdx)
                    t=tIdx(tt); v=double(rate.Vrate(t,pix)); z=double(cache.driverData(t,pix,j));
                    yy(tt)=median(v(isfinite(v)),'omitnan'); xx(tt)=median(z(isfinite(z)),'omitnan');
                end
                if any(~isfinite(xx)) || any(~isfinite(yy)), continue; end
                M=extract_block_cluster_metric(xx,yy,cmask,cfg); if ~M.Valid, continue; end
                if M.MeanCoherence>=cfg.wavelet.minimumCoherenceForSpatialSupport && M.PhaseConcentration>=0.35
                    lagVals(end+1,1)=M.AdjustedLagMonths; lead(end+1,1)=M.AdjustedLagMonths>0; cohVals(end+1,1)=M.MeanCoherence; blockIDs(end+1,1)=B.blockID(b); %#ok<AGROW>
                end
            end
            nBlocks=numel(B.blockID); nSupport=numel(lagVals); supportFrac=nSupport/max(nBlocks,1); leadFrac=mean(lead,'omitnan');
            [medLag,lo,hi]=bootstrap_median_ci(lagVals,cfg.spatial.bootstrapReplicates,cfg.spatial.alpha,cfg.inference.randomSeed+m*1000+j*100+c);
            robustMap=result.mapQ_FDR<cfg.inference.mapFDRAlpha && result.clusterTable.ClusterP_FWER(c)<cfg.inference.clusterAlpha;
            phaseOK=result.clusterTable.PhaseConcentration(c)>=cfg.wavelet.minimumPhaseConcentration;
            spatialOK=nSupport>=cfg.spatial.minimumBlocks && supportFrac>=cfg.spatial.minimumSupportFraction;
            if robustMap && phaseOK && spatialOK && isfinite(lo) && lo>0 && leadFrac>=cfg.spatial.driverLeadFraction
                claim="RobustDriverLeadLag";
            elseif robustMap && phaseOK && spatialOK && isfinite(hi) && hi<0
                claim="ResponseLeadsDriver_NotCausalSupport";
            elseif robustMap
                claim="SignificantCoherence_LagUnresolved";
            else
                claim="CandidateOnly";
            end
            row=table(m,string(cfg.driver(j).name),c,result.clusterTable.ClusterP_FWER(c),result.mapQ_FDR,result.clusterTable.StartMonth(c),result.clusterTable.EndMonth(c), ...
                result.clusterTable.PeriodMinMonths(c),result.clusterTable.PeriodMaxMonths(c),result.clusterTable.MeanCoherence(c),result.clusterTable.PhaseConcentration(c), ...
                result.clusterTable.RelationPolarity(c),result.clusterTable.PolarityAdjustedLagMonths(c),nBlocks,nSupport,supportFrac,leadFrac,medLag,lo,hi,string(claim), ...
                'VariableNames',{'Mechanism','Driver','ClusterID','ClusterP_FWER','MapQ_FDR','StartMonth','EndMonth','PeriodMinMonths','PeriodMaxMonths','MechanismMeanCoherence','MechanismPhaseConcentration', ...
                'RelationPolarity','MechanismAdjustedLagMonths','NSpatialBlocks','NSupportingBlocks','SpatialSupportFraction','DriverLeadFraction','SpatialMedianLagMonths','LagCI_Low','LagCI_High','ClaimClass'});
            if isempty(allRows), allRows=row; else, allRows=[allRows;row]; end %#ok<AGROW>
        end
    end
end
outFile=fullfile(cfg.output.spatial,'Spatial_Cluster_Validation.csv');
if isempty(allRows)
    fid=fopen(outFile,'w');
    fprintf(fid,'Mechanism,Driver,ClusterID,ClusterP_FWER,MapQ_FDR,StartMonth,EndMonth,PeriodMinMonths,PeriodMaxMonths,MechanismMeanCoherence,MechanismPhaseConcentration,RelationPolarity,MechanismAdjustedLagMonths,NSpatialBlocks,NSupportingBlocks,SpatialSupportFraction,DriverLeadFraction,SpatialMedianLagMonths,LagCI_Low,LagCI_High,ClaimClass\n');
    fclose(fid);
else
    writetable(allRows,outFile);
end
end
