function W = wavelet_core(x,y,cfg)
% x=driver, y=response. The cross-spectrum phase is interpreted as delay of y with respect to x.
[xz,~]=preprocess_wavelet_series(x,cfg.wavelet.detrendDegree);
[yz,~]=preprocess_wavelet_series(y,cfg.wavelet.detrendDegree);
W=wavelet_core_preprocessed(xz,yz,cfg);
end
