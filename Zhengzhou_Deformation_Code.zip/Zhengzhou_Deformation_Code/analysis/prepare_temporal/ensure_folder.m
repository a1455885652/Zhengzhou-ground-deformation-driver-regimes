function ensure_folder(folderPath)
if ~isfolder(folderPath)
    [ok,msg] = mkdir(folderPath);
    if ~ok, error('无法创建目录：%s\n%s', folderPath, msg); end
end
end
