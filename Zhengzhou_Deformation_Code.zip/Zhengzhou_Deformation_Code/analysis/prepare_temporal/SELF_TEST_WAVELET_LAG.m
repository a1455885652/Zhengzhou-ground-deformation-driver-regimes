%% SELF_TEST_WAVELET_LAG.m
% Synthetic tests; no Zhengzhou files are used.
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_k4_wavelet_lag();
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence required for self test.'); end
fprintf('Running Wavelet Phase-Lag self tests...\n'); rng(20260907,'twister');

% 1) IAAFT preserves exact amplitude distribution and approximately preserves Fourier amplitude.
x=randn(96,1)+0.7*sin(2*pi*(1:96)'/12); s=iaaft_surrogate(x,500,1e-8);
assert(max(abs(sort(x)-sort(s)))<1e-12,'IAAFT did not preserve value distribution.');
a=abs(fft(x-mean(x))); b=abs(fft(s-mean(s))); rel=norm(a-b)/norm(a); assert(rel<0.08,'IAAFT spectrum preservation is too poor.');

% 2) Phase convention / polarity-adjustment: inverse relation with +2 month response lag at 12-month period.
phiRaw=pi + 2*pi*2/12; phiRaw=wrap_to_pi_custom(phiRaw); pol=sign(cos(phiRaw)); adj=phiRaw; if pol<0, adj=wrap_to_pi_custom(phiRaw-pi); end
lag=adj/(2*pi)*12; assert(abs(lag-2)<1e-10,'Polarity-adjusted phase lag convention failed.');

% 3) Synthetic nonstationary annual coupling. Use reduced surrogate counts for self-test speed only.
t=(1:96)'; drv=sin(2*pi*t/12)+0.20*randn(size(t)); resp=0.35*randn(size(t));
lagTrue=2; active=20:80; for ii=active, if ii-lagTrue>=1, resp(ii)=resp(ii)-1.4*drv(ii-lagTrue); end, end
cfg2=cfg; cfg2.inference.thresholdSurrogates=79; cfg2.inference.clusterNullSurrogates=199; cfg2.inference.minimumClusterCells=5; cfg2.inference.minimumClusterTimeSpanMonths=3;
W=wavelet_core(drv,resp,cfg2); th=estimate_scale_thresholds_iaaft(drv,resp,W,cfg2,123); nul=estimate_null_max_cluster_iaaft(drv,resp,W,th,cfg2,456);
months=datetime(2000,1,1)+calmonths(0:95); T=summarize_observed_clusters(W,th,nul,cfg2,months(:));
assert(~isempty(T),'Synthetic wavelet test found no cluster.'); [~,k]=min(T.ClusterP_FWER); assert(T.ClusterP_FWER(k)<0.10,'Synthetic cluster did not beat surrogate null.');
assert(T.PhaseConcentration(k)>0.45,'Synthetic phase is not concentrated.');
assert(abs(T.PolarityAdjustedLagMonths(k)-lagTrue)<1.5,'Synthetic lag recovery is outside tolerance.');

% 4) Cluster engine.
M=false(5,6); M(2:3,3:5)=true; C=connected_components_8(M); assert(numel(C)==1 && numel(C{1})==6,'8-connected cluster engine failed.');

fprintf('ALL WAVELET PHASE-LAG SELF TESTS PASSED.\n');
