function tf = is_core_hypothesis(mechanism,driverName,cfg)
tf=false; P=cfg.hierarchical.corePairs;
for k=1:size(P,1)
    if mechanism==P{k,1} && strcmpi(char(driverName),P{k,2}), tf=true; return; end
end
end
