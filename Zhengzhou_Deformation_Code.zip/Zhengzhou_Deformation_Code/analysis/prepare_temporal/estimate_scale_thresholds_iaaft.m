function threshold = estimate_scale_thresholds_iaaft(x,y,Wobs,cfg,seed)
% Generate surrogates from the exact detrended/standardized signals entering WTC.
[x0,~]=preprocess_wavelet_series(x,cfg.wavelet.detrendDegree); [y0,~]=preprocess_wavelet_series(y,cfg.wavelet.detrendDegree);
rng(seed,'twister'); nS=cfg.inference.thresholdSurrogates; nScale=numel(Wobs.period); nTime=numel(x0);
vals=nan(nScale,nS*nTime,'single'); valid=Wobs.validMask;
fprintf('  Threshold surrogates: %d\n',nS);
for b=1:nS
    xs=iaaft_surrogate(x0,cfg.inference.iaaftMaxIterations,cfg.inference.iaaftRelativeTolerance);
    ys=iaaft_surrogate(y0,cfg.inference.iaaftMaxIterations,cfg.inference.iaaftRelativeTolerance);
    Ws=wavelet_core_preprocessed(xs,ys,cfg); A=single(Ws.wcoh); A(~valid)=NaN;
    cols=(b-1)*nTime+(1:nTime); vals(:,cols)=A;
    if mod(b,50)==0 || b==nS, fprintf('    %d/%d\n',b,nS); end
end
threshold=nan(nScale,1); q=100*cfg.inference.clusterFormingQuantile;
for s=1:nScale, v=double(vals(s,:)); v=v(isfinite(v)); threshold(s)=percentile_simple(v,q); end
end
