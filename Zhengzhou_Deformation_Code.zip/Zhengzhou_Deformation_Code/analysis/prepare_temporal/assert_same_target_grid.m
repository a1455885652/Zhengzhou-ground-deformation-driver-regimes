function assert_same_target_grid(Rref,Rcur,sizeRef,sizeCur,filePath)
if ~isequal(sizeRef,sizeCur), error('1 km 栅格尺寸不一致：%s',filePath); end
assert_geographic_cells_reference(Rcur,filePath);
tol=1e-10;
a=[Rref.LatitudeLimits(:);Rref.LongitudeLimits(:);Rref.CellExtentInLatitude;Rref.CellExtentInLongitude];
b=[Rcur.LatitudeLimits(:);Rcur.LongitudeLimits(:);Rcur.CellExtentInLatitude;Rcur.CellExtentInLongitude];
if any(abs(a-b)>tol), error('1 km 栅格地理参考不一致：%s',filePath); end
if ~strcmp(Rref.RowsStartFrom,Rcur.RowsStartFrom) || ~strcmp(Rref.ColumnsStartFrom,Rcur.ColumnsStartFrom)
    error('1 km 栅格行列方向不一致：%s',filePath);
end
end
