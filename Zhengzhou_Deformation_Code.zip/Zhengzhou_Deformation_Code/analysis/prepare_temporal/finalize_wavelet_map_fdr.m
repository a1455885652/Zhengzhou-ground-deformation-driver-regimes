function finalize_wavelet_map_fdr(cfg)
rows=[]; refs={};
for m=1:4
    for j=1:numel(cfg.driver)
        f=fullfile(cfg.output.maps,sprintf('M%d_%s_WaveletMap.mat',m,cfg.driver(j).name));
        if ~isfile(f), error('Missing map result: %s',f); end
        S=load(f,'result'); r=S.result; row=table(m,string(cfg.driver(j).name),string(cfg.driver(j).role),r.mapP_FWER,NaN, ...
            'VariableNames',{'Mechanism','Driver','Role','MapP_FWER','MapQ_FDR'});
        if isempty(rows), rows=row; else, rows=[rows;row]; end %#ok<AGROW>
        refs{end+1,1}=f; %#ok<AGROW>
    end
end
for role=["primary","secondary"]
    idx=find(rows.Role==role); rows.MapQ_FDR(idx)=bh_fdr_wavelet(rows.MapP_FWER(idx));
end
for i=1:height(rows)
    S=load(refs{i},'result'); result=S.result; result.mapQ_FDR=rows.MapQ_FDR(i);
    if ~isempty(result.clusterTable)
        result.clusterTable.MapQ_FDR=repmat(result.mapQ_FDR,height(result.clusterTable),1);
        result.clusterTable.MapPassFDR=result.clusterTable.MapQ_FDR<cfg.inference.mapFDRAlpha;
        result.clusterTable.ClusterPassFWER=result.clusterTable.ClusterP_FWER<cfg.inference.clusterAlpha;
    end
    save(refs{i},'result','-v7.3');
    if cfg.output.makeFigures, plot_wavelet_map_result(result,cfg); end
end
writetable(rows,fullfile(cfg.output.root,'Map_Level_Significance.csv'));
end
