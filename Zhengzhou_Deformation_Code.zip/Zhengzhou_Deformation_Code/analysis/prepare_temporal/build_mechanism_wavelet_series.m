function mech = build_mechanism_wavelet_series(cache,rate,cfg,sel,mechanism)
% Detection series use fixed-support spatial median; block-level validation later checks spatial robustness.
T=numel(cache.months); nD=numel(cfg.driver); y=nan(T,1); x=nan(T,nD);
for t=1:T
    vr=double(rate.Vrate(t,sel)); y(t)=median(vr(isfinite(vr)),'omitnan');
    for j=1:nD
        z=double(cache.driverData(t,sel,j)); x(t,j)=median(z(isfinite(z)),'omitnan');
    end
end
% Centered W6 rate is undefined at first/last halfWindow months; use common interior only.
idx=(1+cfg.response.halfWindowMonths):(T-cfg.response.halfWindowMonths);
y=y(idx); x=x(idx,:); months=cache.months(idx);
if numel(y)<cfg.wavelet.minimumSeriesLength, error('Mechanism series too short.'); end
if any(~isfinite(y)) || any(~isfinite(x),'all'), error('Mechanism-level series contains missing values; inspect fixed support/input coverage.'); end
mech=struct('mechanism',mechanism,'selectedGlobal',sel,'months',months,'timeIndex',idx,'yRaw',y,'xRaw',x,'driverNames',cache.driverNames);
end
