function write_grid_audit_txt(filePath,maskFile,Rtarget,targetSize,nMask,Rsource,sourceSize)
fid=fopen(filePath,'w'); if fid<0, error('无法写入：%s',filePath); end
fprintf(fid,'MONTH-END CUMULATIVE -> 1 KM GRID AUDIT\n=====================================\n\n');
fprintf(fid,'Target mask: %s\n',maskFile);
fprintf(fid,'Target rows/cols: %d %d\n',targetSize(1),targetSize(2));
fprintf(fid,'Valid mask cells: %d\n',nMask);
fprintf(fid,'Target lon limits: %.15f %.15f\n',Rtarget.LongitudeLimits);
fprintf(fid,'Target lat limits: %.15f %.15f\n',Rtarget.LatitudeLimits);
fprintf(fid,'Target cell dLon/dLat: %.15f %.15f\n',Rtarget.CellExtentInLongitude,Rtarget.CellExtentInLatitude);
fprintf(fid,'RowsStartFrom: %s\nColumnsStartFrom: %s\n\n',Rtarget.RowsStartFrom,Rtarget.ColumnsStartFrom);
fprintf(fid,'Source rows/cols: %d %d\n',sourceSize(1),sourceSize(2));
fprintf(fid,'Source lon limits: %.15f %.15f\n',Rsource.LongitudeLimits);
fprintf(fid,'Source lat limits: %.15f %.15f\n',Rsource.LatitudeLimits);
fprintf(fid,'Source cell dLon/dLat: %.15f %.15f\n',Rsource.CellExtentInLongitude,Rsource.CellExtentInLatitude);
fprintf(fid,'Spatial operation: source-cell-center binning + arithmetic mean within each target cell.\n');
fprintf(fid,'No bilinear/cubic/nearest-neighbour interpolation. No transpose/flip.\n');
fclose(fid);
end
