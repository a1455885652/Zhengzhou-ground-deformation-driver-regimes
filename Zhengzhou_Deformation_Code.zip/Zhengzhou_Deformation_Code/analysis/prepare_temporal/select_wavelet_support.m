function [sel,Tout] = select_wavelet_support(cache,cfg,mechanism,confidenceThreshold)
K4=cache.K4; nD=numel(cfg.driver);
keep=double(K4.MechanismCluster)==mechanism & double(K4.MaxPosterior)>=confidenceThreshold & double(cache.coverCum)>=cfg.support.minimumTemporalCoverage;
for j=1:nD, keep=keep & double(cache.coverDriver(:,j))>=cfg.support.minimumTemporalCoverage; end
sel=find(keep);
if numel(sel)<cfg.support.minimumPixelsPerMechanism, error('M%d has only %d eligible pixels.',mechanism,numel(sel)); end
Tout=table(sel,double(K4.RasterRow(sel)),double(K4.RasterColumn(sel)),double(K4.MaxPosterior(sel)), ...
    'VariableNames',{'K4Index','RasterRow','RasterColumn','MaxPosterior'});
end
