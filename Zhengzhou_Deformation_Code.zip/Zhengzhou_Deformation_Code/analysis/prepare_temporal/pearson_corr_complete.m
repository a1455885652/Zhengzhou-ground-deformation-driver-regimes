function [r,n] = pearson_corr_complete(x,y)
x=double(x(:)); y=double(y(:)); good=isfinite(x)&isfinite(y); x=x(good); y=y(good); n=numel(x);
if n<3||std(x)==0||std(y)==0, r=NaN; return; end
C=corrcoef(x,y); r=C(1,2);
end
