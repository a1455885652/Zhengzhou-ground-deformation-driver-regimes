%% CHECK_INPUTS_WAVELET_LAG.m
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_k4_wavelet_lag();
fprintf('============================================================\n');
fprintf(' CHECK INPUTS: K4 Wavelet Phase-Lag project\n');
fprintf('============================================================\n\n');
if exist('wcoherence','file')~=2
    error('wcoherence 未找到。本工程正式分析需要 MATLAB Wavelet Toolbox。');
end
assert_file_exists(cfg.grid.maskFile,'最终1 km mask');
assert_file_exists(cfg.insar.finalVelocity1km,'最终1 km velocity');
assert_file_exists(cfg.k4.assignmentFile,'K4 assignment');
assert_file_exists(cfg.k4.decisionFile,'K4/K5 decision');
if ~isfolder(cfg.insar.monthEnd1kmFolder), error('1 km月末累计目录不存在，请先运行 BUILD_MONTHEND_TO_1KM.m。'); end
[mask,Rtarget]=read_geotiff_singleband(cfg.grid.maskFile); targetSize=size(mask);
K4=load_and_validate_k4(cfg,targetSize); Taudit=audit_k4_against_velocity(K4,cfg,Rtarget,targetSize); disp(Taudit);
months=make_month_vector(cfg.time.startMonth,cfg.time.endMonth);
Tin=list_monthly_geotiffs_strict(cfg.insar.monthEnd1kmFolder,months); fprintf('InSAR: %d/%d months OK.\n',height(Tin),numel(months));
for j=1:numel(cfg.driver)
    if ~isfolder(cfg.driver(j).folder), error('Driver folder missing: %s',cfg.driver(j).folder); end
    Tj=list_monthly_geotiffs_strict(cfg.driver(j).folder,months);
    fprintf('%-20s %d/%d months OK.\n',cfg.driver(j).name,height(Tj),numel(months));
    [Z,R]=read_geotiff_singleband(char(Tj.FilePath(1))); assert_same_target_grid(Rtarget,R,targetSize,size(Z),char(Tj.FilePath(1)));
end
fprintf('Wavelet period range: %.1f-%.1f months; threshold surrogates=%d; cluster-null surrogates=%d.\n', ...
    cfg.wavelet.minPeriodMonths,cfg.wavelet.maxPeriodMonths,cfg.inference.thresholdSurrogates,cfg.inference.clusterNullSurrogates);
fprintf('All strict input checks passed.\n');
