%% RUN_HIERARCHICAL_SPATIAL_WAVELET.m
% v3.1 正式升级：读取 v3.0 已完成的机制级 WTC map，
% 对 cluster-FWER < 0.10 的候选区域执行“空间块 -> 同步MIAAFT -> group-level inference”。
% 不需要重新运行 v3.0 的 499+1999 surrogate map 检验。
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_k4_wavelet_lag();
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence is required.'); end
cache=load_wavelet_cache(cfg); rate=load_centered_rate_cache(cfg);
ensure_folder(cfg.hierarchical.outputRoot);
ensure_folder(cfg.hierarchical.checkpointFolder);
ensure_folder(cfg.hierarchical.figureFolder);
validate_v30_map_source(cfg);
rng(cfg.inference.randomSeed+310,'twister');

mapRows=[]; clusterRows=[];
for m=1:4
    [sel,~]=select_wavelet_support(cache,cfg,m,cfg.support.primaryConfidence);
    B=make_spatial_blocks_hierarchical(cache,sel,cfg);
    fprintf('\n============================================================\n');
    fprintf(' Hierarchical spatial wavelet inference: M%d, %d blocks\n',m,numel(B.blockID));
    fprintf('============================================================\n');
    for j=1:numel(cfg.driver)
        fprintf('\nM%d  %s\n',m,cfg.driver(j).name);
        R=run_one_hierarchical_spatial_map(cache,rate,B,cfg,m,j);
        mr=R.mapRow; cr=R.clusterRows;
        if isempty(mapRows), mapRows=mr; else, mapRows=[mapRows;mr]; end %#ok<AGROW>
        if ~isempty(cr)
            if isempty(clusterRows), clusterRows=cr; else, clusterRows=[clusterRows;cr]; end %#ok<AGROW>
        end
    end
end
[mapRows,clusterRows]=finalize_hierarchical_fdr_and_claims(mapRows,clusterRows,cfg);
writetable(mapRows,fullfile(cfg.hierarchical.outputRoot,'Hierarchical_Map_Inference.csv'));
if isempty(clusterRows)
    writetable(empty_hierarchical_cluster_table(),fullfile(cfg.hierarchical.outputRoot,'Hierarchical_Cluster_Inference.csv'));
else
    writetable(clusterRows,fullfile(cfg.hierarchical.outputRoot,'Hierarchical_Cluster_Inference.csv'));
end
write_hierarchical_summary(mapRows,clusterRows,cfg);
fprintf('\nHIERARCHICAL SPATIAL WAVELET ANALYSIS FINISHED.\nOutput: %s\n',cfg.hierarchical.outputRoot);
