function cache = load_wavelet_cache(cfg)
if ~isfile(cfg.cache.dynamicMat), error('Dynamic cache missing: %s\nRun BUILD_DYNAMIC_CACHE_WAVELET.m first.',cfg.cache.dynamicMat); end
S=load(cfg.cache.dynamicMat,'cache'); cache=S.cache;
end
