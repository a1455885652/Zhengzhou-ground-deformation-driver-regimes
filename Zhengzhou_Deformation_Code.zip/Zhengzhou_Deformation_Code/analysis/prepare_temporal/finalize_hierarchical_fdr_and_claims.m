function [M,C] = finalize_hierarchical_fdr_and_claims(M,C,cfg)
% Separate BH-FDR families: SHAP-prior Core hypotheses vs full Screening hypotheses.
for coreFlag=[true false]
    idx=find(M.IsCoreHypothesis==coreFlag);
    M.GroupCouplingQ(idx)=bh_fdr_wavelet(M.GroupCouplingP(idx));
    M.GroupLeadQ(idx)=bh_fdr_wavelet(M.GroupLeadP(idx));
end
if isempty(C), return; end
for r=1:height(C)
    k=find(M.Mechanism==C.Mechanism(r) & M.Driver==C.Driver(r),1);
    C.MapGroupCouplingQ(r)=M.GroupCouplingQ(k); C.MapGroupLeadQ(r)=M.GroupLeadQ(k);
    a=cfg.hierarchical.tierA; b=cfg.hierarchical.tierB;
    strict=C.CandidateClusterP_FWER(r)<a.clusterP && C.MapGroupLeadQ(r)<a.mapFDR && C.GroupLeadP(r)<a.mapFDR && ...
        C.NSupportingBlocks(r)>=a.minimumSupportingBlocks && C.SpatialSupportFraction(r)>=a.minimumSupportFraction && ...
        C.GroupPhaseConcentration(r)>=a.minimumPhaseConcentration && C.DriverLeadFraction(r)>=a.minimumLeadFraction && ...
        isfinite(C.LagCI95_Low(r)) && C.LagCI95_Low(r)>0;
    support=C.CandidateClusterP_FWER(r)<b.clusterP && C.MapGroupLeadQ(r)<b.mapFDR && C.GroupLeadP(r)<b.mapFDR && ...
        C.NSupportingBlocks(r)>=b.minimumSupportingBlocks && C.SpatialSupportFraction(r)>=b.minimumSupportFraction && ...
        C.GroupPhaseConcentration(r)>=b.minimumPhaseConcentration && C.DriverLeadFraction(r)>=b.minimumLeadFraction && ...
        isfinite(C.LagCI90_Low(r)) && C.LagCI90_Low(r)>0;
    coupling=C.CandidateClusterP_FWER(r)<b.clusterP && C.MapGroupCouplingQ(r)<b.mapFDR && C.GroupCouplingP(r)<b.mapFDR && ...
        C.NSupportingBlocks(r)>=b.minimumSupportingBlocks && C.SpatialSupportFraction(r)>=b.minimumSupportFraction && ...
        C.GroupPhaseConcentration(r)>=b.minimumPhaseConcentration;
    if strict
        C.InferenceTier(r)="TierA"; C.ClaimClass(r)="ConfirmedDriverLeadLag";
    elseif support
        C.InferenceTier(r)="TierB"; C.ClaimClass(r)="SupportedDriverLeadLag";
    elseif coupling
        C.InferenceTier(r)="TierB"; C.ClaimClass(r)="SupportedCoherence_LagUnresolved";
    elseif C.GroupLeadP(r)<0.10 && C.LagCI90_Low(r)>0
        C.InferenceTier(r)="TierC"; C.ClaimClass(r)="DirectionalCandidate_NotFDR";
    else
        C.InferenceTier(r)="TierC"; C.ClaimClass(r)="CandidateOnly";
    end
end
end
