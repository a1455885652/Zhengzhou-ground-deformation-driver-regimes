function T = audit_cumulative_slope_against_k4(Dcum,months,K4,cfg)
% Fit one long OLS slope per K4 pixel from monthly cumulative displacement.
t=(0:numel(months)-1)'; tc=t-mean(t); den=sum(tc.^2);
validAll=all(isfinite(Dcum),1);
slope=nan(size(Dcum,2),1);
if any(validAll)
    slope(validAll)=double(tc' * double(Dcum(:,validAll)))'/den*12;
end
ok=isfinite(slope)&isfinite(double(K4.Target));
if nnz(ok)<0.80*height(K4)
    error('Cumulative lineage audit: too few complete K4 pixel time series (%d/%d).',nnz(ok),height(K4));
end
[r,~]=pearson_corr_complete(slope(ok),double(K4.Target(ok)));
signAgree=mean(sign(slope(ok))==sign(double(K4.Target(ok))) | abs(double(K4.Target(ok)))<1e-8);
medDiff=median(slope(ok)-double(K4.Target(ok)));
if r<cfg.k4.minCumulativeSlopeCorrelation
    error(['Monthly cumulative long slopes correlate poorly with K4 Target (r=%.4f < %.4f).\n' ...
        'Stop: cumulative series may not be the same InSAR lineage/sign convention.'], ...
        r,cfg.k4.minCumulativeSlopeCorrelation);
end
if signAgree<cfg.k4.minCumulativeSignAgreement
    error(['Cumulative/K4 sign agreement %.3f < %.3f. Stop before lag analysis.'], ...
        signAgree,cfg.k4.minCumulativeSignAgreement);
end
T=table(nnz(ok),r,signAgree,medDiff,median(abs(slope(ok)-double(K4.Target(ok)))), ...
    'VariableNames',{'NComplete','PearsonR','SignAgreement','MedianDifference_mmYr','MedianAbsDifference_mmYr'});
end
