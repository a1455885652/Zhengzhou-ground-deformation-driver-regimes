function M = extract_block_cluster_metric(x,y,clusterMask,cfg)
try
    W=wavelet_core(x,y,cfg);
catch
    M=struct('Valid',false); return;
end
mask=clusterMask & W.validMask; if nnz(mask)<3, M=struct('Valid',false); return; end
coh=W.wcoh(mask); meanC=mean(coh,'omitnan'); phi=W.phase(mask); w=max(coh,eps);
Pgrid=repmat(W.period(:),1,size(W.wcoh,2)); pp=Pgrid(mask);
if sum(w.*cos(phi))>=0, pol=1; phiAdj=phi; else, pol=-1; phiAdj=wrap_to_pi_custom(phi-pi); end
z=sum(w.*exp(1i*phiAdj))/sum(w); conc=abs(z); lagCell=phiAdj./(2*pi).*pp; lag=sum(w.*lagCell)/sum(w); pe=sum(w.*pp)/sum(w);
adjPhase=wrap_to_pi_custom(2*pi*lag/max(pe,eps));
M=struct('Valid',true,'MeanCoherence',meanC,'PhaseConcentration',conc,'Polarity',pol,'AdjustedPhaseRad',adjPhase,'AdjustedLagMonths',lag,'EffectivePeriodMonths',pe);
end
