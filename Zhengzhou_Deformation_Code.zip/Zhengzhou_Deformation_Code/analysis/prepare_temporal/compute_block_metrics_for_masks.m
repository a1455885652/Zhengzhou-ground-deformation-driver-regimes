function metrics = compute_block_metrics_for_masks(XZ,YZ,masks,cfg)
nB=size(XZ,2); nC=numel(masks);
metrics=cell(nC,1);
for c=1:nC
    metrics{c}=struct('coherence',nan(nB,1),'phaseConcentration',nan(nB,1),'phase',nan(nB,1), ...
        'lag',nan(nB,1),'period',nan(nB,1),'valid',false(nB,1));
end
for b=1:nB
    W=wavelet_core_preprocessed(XZ(:,b),YZ(:,b),cfg);
    for c=1:nC
        M=extract_block_cluster_metric_precomputed(W,masks{c},cfg);
        if ~M.Valid, continue; end
        metrics{c}.coherence(b)=M.MeanCoherence;
        metrics{c}.phaseConcentration(b)=M.PhaseConcentration;
        metrics{c}.phase(b)=M.AdjustedPhaseRad;
        metrics{c}.lag(b)=M.AdjustedLagMonths;
        metrics{c}.period(b)=M.EffectivePeriodMonths;
        metrics{c}.valid(b)=true;
    end
end
end
