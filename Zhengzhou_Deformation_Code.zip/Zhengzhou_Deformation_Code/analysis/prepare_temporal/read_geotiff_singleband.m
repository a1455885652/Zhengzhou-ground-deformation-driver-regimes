function [Z, R] = read_geotiff_singleband(filePath)
% 单波段 GeoTIFF；NoData/Inf -> NaN；不改变方向。
if ~isfile(filePath), error('GeoTIFF 不存在：%s', filePath); end
[Z,R] = readgeoraster(filePath);
if ndims(Z)>2
    if size(Z,3)~=1, error('只支持单波段：%s', filePath); end
    Z = Z(:,:,1);
end
Z = double(Z);
Z(~isfinite(Z)) = NaN;
try
    info = georasterinfo(filePath);
    mdi = info.MissingDataIndicator;
    if ~isempty(mdi)
        mdi = double(mdi(:));
        for k=1:numel(mdi)
            if isfinite(mdi(k)), Z(Z==mdi(k)) = NaN; end
        end
    end
catch
end
% 常见极端填充值保护
Z(abs(Z) > 1e30) = NaN;
end
