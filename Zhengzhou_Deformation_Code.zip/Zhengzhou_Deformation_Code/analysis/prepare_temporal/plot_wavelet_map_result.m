function plot_wavelet_map_result(result,cfg)
W=result.W; months=result.months; fig=figure('Visible','off','Color','w','Position',[100 100 1100 620]);
imagesc(1:numel(months),log2(W.period),W.wcoh); axis xy; caxis([0 1]); colormap(parula); colorbar; hold on;
plot(1:numel(months),log2(W.coiPeriod),'w--','LineWidth',1.2);
if ~isempty(result.clusterTable)
    sig=false(size(W.wcoh));
    for k=1:height(result.clusterTable)
        if result.clusterTable.ClusterP_FWER(k)<cfg.inference.clusterAlpha && result.mapQ_FDR<cfg.inference.mapFDRAlpha
            sig=sig | cluster_mask_for_table_row(result,k,cfg);
        end
    end
    if any(sig,'all'), contour(1:numel(months),log2(W.period),double(sig),[0.5 0.5],'k','LineWidth',1.8); end
end
xt=round(linspace(1,numel(months),8)); xticks(xt); xticklabels(string(months(xt),'yyyy-MM')); xtickangle(30);
yt=[4 6 8 12 16 24]; yticks(log2(yt)); yticklabels(string(yt)); ylabel('Period (months)'); xlabel('Month');
title(sprintf('M%d  %s  Wavelet coherence  (map q=%.4g)',result.mechanism,result.driverName,result.mapQ_FDR));
ensure_folder(cfg.output.figures); exportgraphics(fig,fullfile(cfg.output.figures,sprintf('M%d_%s_WTC.png',result.mechanism,result.driverName)),'Resolution',300); if ~zz_show_figures(), close(fig); end
end
