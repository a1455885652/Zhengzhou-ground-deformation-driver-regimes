function result = run_one_wavelet_map(mech,cfg,driverIndex,mechanism)
x=mech.xRaw(:,driverIndex); y=mech.yRaw; W=wavelet_core(x,y,cfg);
seed0=cfg.inference.randomSeed + mechanism*10000 + driverIndex*100;
threshold=estimate_scale_thresholds_iaaft(x,y,W,cfg,seed0+1);
nullMax=estimate_null_max_cluster_iaaft(x,y,W,threshold,cfg,seed0+2);
Tcluster=summarize_observed_clusters(W,threshold,nullMax,cfg,mech.months);
if isempty(Tcluster), mapP=1; else, mapP=min(Tcluster.ClusterP_FWER); end
result=struct(); result.mechanism=mechanism; result.driverIndex=driverIndex; result.driverName=char(mech.driverNames(driverIndex));
result.driverRole=cfg.driver(driverIndex).role; result.months=mech.months; result.xRaw=x; result.yRaw=y; result.W=W; result.threshold=threshold; result.nullMax=nullMax;
result.clusterTable=Tcluster; result.mapP_FWER=mapP; result.mapQ_FDR=NaN; result.created=char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
end
