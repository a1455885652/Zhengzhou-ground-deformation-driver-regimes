function [Vrate,R2] = build_centered_rolling_rate_cube(Dcum,halfWindow,annualize,minFinitePoints)
% Centered local OLS derivative. For halfWindow=3, use t-3:t+3 (7 monthly points), span=6 months.
[T,N]=size(Dcum); Vrate=nan(T,N,'single'); R2=nan(T,N,'single');
for t=1+halfWindow:T-halfWindow
    seg=Dcum(t-halfWindow:t+halfWindow,:);
    [s,r2]=rolling_ols_slope_minpoints(seg,annualize,minFinitePoints);
    Vrate(t,:)=single(s); R2(t,:)=single(r2);
end
end
