function K4 = load_and_validate_k4(cfg,targetSize)
K4=readtable(cfg.k4.assignmentFile,'VariableNamingRule','preserve');
required={'RasterRow','RasterColumn','Target','MechanismCluster','MaxPosterior','NormalizedEntropy'};
for k=1:numel(required)
    if ~ismember(required{k},K4.Properties.VariableNames)
        error('K4_Assignment 缺少字段：%s',required{k});
    end
end
if height(K4)~=cfg.k4.expectedSampleCount
    error('K4 样本数错误：实际 %d，预期 %d。',height(K4),cfg.k4.expectedSampleCount);
end
K4.RasterRow=double(K4.RasterRow); K4.RasterColumn=double(K4.RasterColumn);
K4.MechanismCluster=double(K4.MechanismCluster); K4.MaxPosterior=double(K4.MaxPosterior);
if any(K4.RasterRow<1|K4.RasterRow>targetSize(1)|K4.RasterColumn<1|K4.RasterColumn>targetSize(2))
    error('K4 RasterRow/RasterColumn 超出最终 1 km 格网范围。');
end
if any(mod(K4.RasterRow,1)~=0|mod(K4.RasterColumn,1)~=0), error('K4 行列号不是整数。'); end
lin=sub2ind(targetSize,K4.RasterRow,K4.RasterColumn);
if numel(unique(lin))~=height(K4), error('K4 中存在重复 RasterRow/RasterColumn。'); end
for m=1:4
    n=sum(K4.MechanismCluster==m);
    if n~=cfg.k4.expectedClusterCounts(m)
        error('K4 M%d 数量错误：实际 %d，预期 %d。',m,n,cfg.k4.expectedClusterCounts(m));
    end
end
if any(~ismember(K4.MechanismCluster,cfg.k4.expectedClusters)), error('K4 出现 1-4 之外的机制标签。'); end
if any(~isfinite(K4.MaxPosterior)|K4.MaxPosterior<0|K4.MaxPosterior>1), error('MaxPosterior 非法。'); end

D=readtable(cfg.k4.decisionFile,'VariableNamingRule','preserve');
needed={'K','PassStrictQC','Recommended'};
for k=1:numel(needed), if ~ismember(needed{k},D.Properties.VariableNames), error('Decision CSV 缺少 %s',needed{k}); end, end
row4=find(double(D.K)==4,1); row5=find(double(D.K)==5,1);
if isempty(row4)||isempty(row5), error('Decision CSV 缺少 K4/K5 行。'); end
if ~to_logical_scalar(D.PassStrictQC(row4)) || ~to_logical_scalar(D.Recommended(row4))
    error('Decision CSV 未确认 K4 PassStrictQC=true 且 Recommended=true。');
end
if to_logical_scalar(D.Recommended(row5)), error('Decision CSV 意外将 K5 标记为 Recommended。'); end
end
