function S = weighted_phase_stats(W,idx,threshold)
phi=W.phase(idx); coh=W.wcoh(idx); [rr,~]=ind2sub(size(W.wcoh),idx); th=threshold(rr); w=max(coh-th,eps);
Pgrid=repmat(W.period(:),1,size(W.wcoh,2)); pp=Pgrid(idx);
% Raw circular phase for transparent reporting.
zRaw=sum(w.*exp(1i*phi))/sum(w); raw=angle(zRaw); rawConc=abs(zRaw); periodEff=sum(w.*pp)/sum(w);
rawLag=raw/(2*pi)*periodEff;
% Separate relation polarity from temporal offset. Use weighted real direction of the cluster.
if sum(w.*cos(phi))>=0, polarity=1; phiAdj=phi; else, polarity=-1; phiAdj=wrap_to_pi_custom(phi-pi); end
zAdj=sum(w.*exp(1i*phiAdj))/sum(w); adjPhase=angle(zAdj); adjConc=abs(zAdj);
lagCell=phiAdj./(2*pi).*pp; adjLag=sum(w.*lagCell)/sum(w);
S=struct('RawPhaseRad',raw,'RawPhaseConcentration',rawConc,'PhaseConcentration',adjConc, ...
    'EffectivePeriodMonths',periodEff,'RawPhaseEquivalentLagMonths',rawLag,'RelationPolarity',polarity, ...
    'AdjustedPhaseRad',adjPhase,'PolarityAdjustedLagMonths',adjLag);
end
