%% BUILD_MONTHEND_TO_1KM.m
% 已完成月末时间插值的高分辨率累计形变 -> 最终 1 km。
% 不做时间插值，不做双线性/最近邻空间重采样；每个1 km目标格内有效高分辨率像元算术平均。
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_k4_wavelet_lag();

fprintf('============================================================\n');
fprintf(' BUILD: high-resolution month-end cumulative -> final 1 km\n');
fprintf('============================================================\n\n');
assert_file_exists(cfg.grid.maskFile,'最终 1 km mask');
if ~isfolder(cfg.insar.monthEndHighResFolder)
    error('高分辨率月末累计目录不存在：\n%s',cfg.insar.monthEndHighResFolder);
end
ensure_folder(cfg.insar.monthEnd1kmFolder); ensure_folder(cfg.insar.auditOutputFolder);
[maskData,Rtarget]=read_geotiff_singleband(cfg.grid.maskFile);
assert_geographic_cells_reference(Rtarget,cfg.grid.maskFile);
maskValid=isfinite(maskData); if cfg.grid.maskZeroIsOutside, maskValid=maskValid & maskData~=0; end
targetSize=size(maskData);
months=make_month_vector(cfg.time.startMonth,cfg.time.endMonth);
Tin=list_monthly_geotiffs_strict(cfg.insar.monthEndHighResFolder,months);
[firstHigh,Rsource]=read_geotiff_singleband(char(Tin.FilePath(1)));
assert_geographic_cells_reference(Rsource,char(Tin.FilePath(1)));
sourceSize=size(firstHigh); mapping=build_axis_mapping_geo(Rsource,Rtarget,sourceSize,targetSize);

nMonths=numel(months); inputFile=strings(nMonths,1); outputFile=strings(nMonths,1);
validTargetCells=zeros(nMonths,1); meanSourcePixels=nan(nMonths,1); medianSourcePixels=nan(nMonths,1);
minimumSourcePixels=nan(nMonths,1); maximumSourcePixels=nan(nMonths,1);
minimumValue=nan(nMonths,1); maximumValue=nan(nMonths,1); medianValue=nan(nMonths,1); meanValue=nan(nMonths,1);
for t=1:nMonths
    fprintf('[%02d/%02d] %s\n',t,nMonths,char(string(months(t),'yyyy-MM')));
    f=char(Tin.FilePath(t)); [Dhigh,Rcurrent]=read_geotiff_singleband(f);
    assert_same_geographic_grid(Rsource,Rcurrent,sourceSize,size(Dhigh),f);
    [D1km,count1km]=aggregate_source_to_target_axis(Dhigh,mapping,targetSize, ...
        cfg.insar.minimumSourcePixels,cfg.insar.blockRows,cfg.insar.aggregationMethod);
    D1km(~maskValid)=NaN; count1km(~maskValid)=0;
    token=char(string(months(t),'yyyyMM'));
    out=fullfile(cfg.insar.monthEnd1kmFolder,sprintf('InSAR_MonthEnd_Cumulative_1km_%s.tif',token));
    if ~(isfile(out) && ~cfg.output.overwrite1kmMonthEnd), write_geotiff_wgs84(out,D1km,Rtarget,cfg.grid.epsg); end
    if cfg.insar.writeMonthlySourceCountRaster
        write_count_geotiff(fullfile(cfg.insar.auditOutputFolder,sprintf('SourcePixelCount_%s.tif',token)),count1km,Rtarget,cfg.grid.epsg);
    end
    vv=D1km(isfinite(D1km)); cc=double(count1km(isfinite(D1km)));
    inputFile(t)=string(f); outputFile(t)=string(out); validTargetCells(t)=numel(vv);
    if ~isempty(cc), meanSourcePixels(t)=mean(cc); medianSourcePixels(t)=median(cc); minimumSourcePixels(t)=min(cc); maximumSourcePixels(t)=max(cc); end
    if ~isempty(vv), minimumValue(t)=min(vv); maximumValue(t)=max(vv); medianValue(t)=median(vv); meanValue(t)=mean(vv); end
end
Tout=table(months,inputFile,outputFile,validTargetCells,meanSourcePixels,medianSourcePixels,minimumSourcePixels,maximumSourcePixels,minimumValue,maximumValue,medianValue,meanValue, ...
    'VariableNames',{'Month','InputHighResFile','Output1kmFile','ValidTargetCells','MeanSourcePixels','MedianSourcePixels','MinSourcePixels','MaxSourcePixels','Minimum','Maximum','Median','Mean'});
writetable(Tout,fullfile(cfg.insar.auditOutputFolder,'MonthEnd_1km_Aggregation_Audit.csv'));
write_grid_audit_txt(fullfile(cfg.insar.auditOutputFolder,'TargetGrid_Audit.txt'),cfg.grid.maskFile,Rtarget,targetSize,nnz(maskValid),Rsource,sourceSize);
fprintf('\nFinished: %s\n',cfg.insar.monthEnd1kmFolder);
