function result = evaluate_ranked_driver_subsets( ...
    X, Y, groupNames, foldId, rankedDrivers, cfg)
% EVALUATE_RANKED_DRIVER_SUBSETS
%
% 从排名靠前的变量开始逐步增加driver，
% 每个候选集合均采用相同Spatial CV。
%
% 最终使用one-standard-error rule：
% 找到平均RMSE最低的k_best，
% 阈值 = RMSE_best + SE_best，
% 在满足阈值的集合中选择最小k。

nGroups = numel(rankedDrivers);

kValues = (cfg.minSelectedDrivers:nGroups)';

nK = numel(kValues);

meanRMSE = nan(nK,1);
stdRMSE = nan(nK,1);
seRMSE = nan(nK,1);
meanMAE = nan(nK,1);
meanR2 = nan(nK,1);

allFoldRMSE = nan(nK,cfg.nSpatialFolds);

for ii = 1:nK

    k = kValues(ii);

    useGroups = rankedDrivers(1:k);

    cols = ismember(groupNames, useGroups);

    Xk = X(:,cols);

    fprintf('  Testing top-%d drivers (%d descriptors)\n', ...
        k, size(Xk,2));

    foldRMSE = nan(cfg.nSpatialFolds,1);
    foldMAE = nan(cfg.nSpatialFolds,1);
    foldR2 = nan(cfg.nSpatialFolds,1);

    for f = 1:cfg.nSpatialFolds

        train = foldId ~= f;
        test = foldId == f;

        model = TreeBagger( ...
            cfg.nTreesSubset, ...
            Xk(train,:), ...
            Y(train), ...
            'Method','regression', ...
            'MinLeafSize',cfg.minLeafSize, ...
            'NumPredictorsToSample', ...
            max(1,round(sqrt(size(Xk,2)))), ...
            'OOBPrediction','off');

        pred = predict(model, Xk(test,:));

        M = regression_metrics(Y(test),pred);

        foldRMSE(f) = M.RMSE;
        foldMAE(f) = M.MAE;
        foldR2(f) = M.R2;

    end

    allFoldRMSE(ii,:) = foldRMSE;

    meanRMSE(ii) = mean(foldRMSE);
    stdRMSE(ii) = std(foldRMSE);
    seRMSE(ii) = stdRMSE(ii) / sqrt(cfg.nSpatialFolds);
    meanMAE(ii) = mean(foldMAE);
    meanR2(ii) = mean(foldR2);

end

[bestRMSE,bestIdx] = min(meanRMSE);

threshold = ...
    bestRMSE + seRMSE(bestIdx);

eligible = find(meanRMSE <= threshold);

selectedIdx = eligible(1);
selectedK = kValues(selectedIdx);

selectedDrivers = rankedDrivers(1:selectedK);

SelectedBy1SE = false(nK,1);
SelectedBy1SE(selectedIdx) = true;

performanceTable = table( ...
    kValues, ...
    meanRMSE, ...
    stdRMSE, ...
    seRMSE, ...
    meanMAE, ...
    meanR2, ...
    SelectedBy1SE, ...
    'VariableNames', ...
    {'NDrivers','MeanRMSE','StdRMSE','SERMSE', ...
     'MeanMAE','MeanR2','SelectedBy1SE'});

result = struct();
result.performanceTable = performanceTable;
result.selectedK = selectedK;
result.selectedDrivers = selectedDrivers;
result.bestK = kValues(bestIdx);
result.bestRMSE = bestRMSE;
result.oneSEThreshold = threshold;
result.foldRMSE = allFoldRMSE;

end
