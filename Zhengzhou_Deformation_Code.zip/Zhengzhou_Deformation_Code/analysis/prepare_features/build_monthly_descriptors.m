function [F, featureNames, descriptorNames] = ...
    build_monthly_descriptors( ...
    stack, months, supportMask, driverName, includeSeasonality)
% BUILD_MONTHLY_DESCRIPTORS
%
% Mean      多年平均
% Trend     线性趋势/yr
% DStd      去趋势标准差
% SeasonAmp 去趋势后的月气候态最大-最小

A = double(stack);

t = days(months - months(1)) / 365.2425;
t = double(t(:));

tc = t - mean(t);
denom = sum(tc.^2);

meanGrid = mean(A,3);

trendGrid = sum( ...
    A .* reshape(tc,1,1,[]), ...
    3) ./ denom;

fitStack = ...
    meanGrid + ...
    trendGrid .* reshape(tc,1,1,[]);

resid = A - fitStack;

dstdGrid = std(resid,0,3);

idx = find(supportMask);

F = [ ...
    meanGrid(idx), ...
    trendGrid(idx), ...
    dstdGrid(idx)];

featureNames = [ ...
    driverName + "_Mean"; ...
    driverName + "_Trend"; ...
    driverName + "_DStd"];

descriptorNames = [ ...
    "Mean"; ...
    "Trend"; ...
    "DStd"];

if includeSeasonality

    monthNumber = month(months);

    clim = nan([size(meanGrid),12]);

    for m = 1:12
        clim(:,:,m) = mean(resid(:,:,monthNumber==m),3);
    end

    seasonAmp = ...
        max(clim,[],3) - min(clim,[],3);

    F(:,end+1) = seasonAmp(idx);

    featureNames(end+1,1) = ...
        driverName + "_SeasonAmp";

    descriptorNames(end+1,1) = ...
        "SeasonAmp";

end

end
