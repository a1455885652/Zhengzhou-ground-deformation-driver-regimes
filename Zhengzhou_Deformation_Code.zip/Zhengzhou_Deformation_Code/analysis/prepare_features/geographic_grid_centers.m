function [lonGrid, latGrid] = geographic_grid_centers(R)
% GEOGRAPHIC_GRID_CENTERS
% GeographicCellsReference像元中心经纬度。
%
% xIntrinsic -> Column
% yIntrinsic -> Row

nRows = R.RasterSize(1);
nCols = R.RasterSize(2);

[colGrid, rowGrid] = meshgrid(1:nCols, 1:nRows);

[latGrid, lonGrid] = intrinsicToGeographic( ...
    R, ...
    colGrid, ...
    rowGrid);

end
