function A = read_aligned_raster(filePath, Rref, rasterSize)
% READ_ALIGNED_RASTER
% 读取并确认已经严格对齐到最终1 km格网。

if ~isfile(filePath)
    error('文件不存在：%s', filePath);
end

[A, R] = readgeoraster(filePath, 'OutputType','double');

if ndims(A) > 2
    A = A(:,:,1);
end

assert_same_geographic_grid( ...
    Rref, ...
    R, ...
    rasterSize, ...
    size(A), ...
    filePath);

A(~isfinite(A) | abs(A)>1e30) = NaN;

end
