function plot_driver_ranking(ranking, selectedDrivers, outputFile)
% PLOT_DRIVER_RANKING

fig = figure('Visible','off','Position',[100 100 1000 700]);

barh(ranking.CompositeScore);

set(gca, ...
    'YDir','reverse', ...
    'YTick',1:height(ranking), ...
    'YTickLabel',cellstr(ranking.Driver));

xlabel('Composite screening score');
ylabel('Driver');
title('Long-term deformation driver screening');

grid on;

hold on;

for k = 1:height(ranking)
    if ismember(ranking.Driver(k), selectedDrivers)
        text( ...
            ranking.CompositeScore(k), ...
            k, ...
            '  selected', ...
            'VerticalAlignment','middle');
    end
end

exportgraphics(fig,outputFile,'Resolution',300);

if ~zz_show_figures(), close(fig); end

end
