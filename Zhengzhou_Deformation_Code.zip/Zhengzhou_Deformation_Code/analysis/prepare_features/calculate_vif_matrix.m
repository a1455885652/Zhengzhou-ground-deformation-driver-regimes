function vif = calculate_vif_matrix(X)
% CALCULATE_VIF_MATRIX
% 对选中descriptor计算VIF。
%
% 注意：VIF在非线性树模型中不是硬性删除标准，
% 这里只用于诊断潜在解释不稳定性。

X = double(X);

nP = size(X,2);

vif = nan(nP,1);

for j = 1:nP

    y = X(:,j);

    others = setdiff(1:nP,j);

    if isempty(others)
        vif(j) = 1;
        continue;
    end

    Z = X(:,others);

    % 标准化
    y = (y-mean(y))/std(y);

    mu = mean(Z,1);
    sd = std(Z,0,1);
    sd(sd==0) = 1;

    Z = (Z-mu)./sd;

    Z = [ones(size(Z,1),1), Z];

    beta = pinv(Z) * y;

    pred = Z*beta;

    sst = sum((y-mean(y)).^2);
    sse = sum((y-pred).^2);

    if sst <= 0
        vif(j) = Inf;
        continue;
    end

    R2 = 1-sse/sst;

    if R2 >= 1
        vif(j) = Inf;
    else
        vif(j) = 1/(1-R2);
    end

end

end
