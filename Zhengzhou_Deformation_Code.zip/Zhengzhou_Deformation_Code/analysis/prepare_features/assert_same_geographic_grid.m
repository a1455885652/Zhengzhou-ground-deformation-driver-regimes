function assert_same_geographic_grid(R1, R2, size1, size2, label)
% ASSERT_SAME_GEOGRAPHIC_GRID

if ~isequal(size1(1:2), size2(1:2))
    error('格网尺寸不一致 [%s]。', label);
end

tol = 1e-10;

if any(abs(R1.LatitudeLimits - R2.LatitudeLimits) > tol) || ...
   any(abs(R1.LongitudeLimits - R2.LongitudeLimits) > tol)

    error('格网经纬度范围不一致 [%s]。', label);
end

if any(R1.RasterSize ~= R2.RasterSize)
    error('RasterSize不一致 [%s]。', label);
end

end
