function foldId = build_spatial_block_folds( ...
    lon, lat, blockSizeKm, nFolds, randomSeed)
% BUILD_SPATIAL_BLOCK_FOLDS
%
% 先建立固定公里尺度空间block，再将block中心聚为nFolds个连续空间区域。
% 所有同一block中的像元绝不会被拆分到训练/测试两边。

rng(randomSeed);

lat0 = mean(lat);
lon0 = mean(lon);

xKm = ...
    (lon-lon0) .* ...
    (111.320*cosd(lat0));

yKm = ...
    (lat-lat0) .* 110.574;

bx = floor((xKm-min(xKm))/blockSizeKm) + 1;
by = floor((yKm-min(yKm))/blockSizeKm) + 1;

pairs = [bx(:), by(:)];

[uniqueBlocks,~,blockIndex] = unique(pairs,'rows','stable');

nBlocks = size(uniqueBlocks,1);

if nBlocks < nFolds
    error('空间block数量(%d)少于CV折数(%d)。', nBlocks, nFolds);
end

centroids = zeros(nBlocks,2);

for b = 1:nBlocks
    use = blockIndex == b;
    centroids(b,1) = mean(xKm(use));
    centroids(b,2) = mean(yKm(use));
end

% 对block中心做kmeans，使每个fold尽量空间连续
blockFold = kmeans( ...
    centroids, ...
    nFolds, ...
    'Replicates',20, ...
    'MaxIter',1000);

foldId = blockFold(blockIndex);

% 防止空折
for f = 1:nFolds
    if nnz(foldId==f) == 0
        error('Spatial fold %d为空。', f);
    end
end

end
