function result = run_group_screening( ...
    X, Y, featureNames, groupNames, foldId, cfg)
% RUN_GROUP_SCREENING
%
% 组合：
% 1. 单变量Spearman
% 2. Elastic Net选择稳定性
% 3. Spatial-CV grouped permutation importance

groups = unique(groupNames,'stable');
nGroups = numel(groups);
nFeatures = size(X,2);

%% Feature-level Spearman

rho = nan(nFeatures,1);
pval = nan(nFeatures,1);

for j = 1:nFeatures
    [rho(j),pval(j)] = corr( ...
        X(:,j), ...
        Y, ...
        'Type','Spearman', ...
        'Rows','complete');
end

featureStats = table( ...
    featureNames(:), ...
    groupNames(:), ...
    rho, ...
    pval, ...
    abs(rho), ...
    'VariableNames', ...
    {'Feature','Driver','SpearmanRho','PValue','AbsSpearman'});

%% Group univariate relevance

groupUni = zeros(nGroups,1);

for g = 1:nGroups
    cols = groupNames == groups(g);
    groupUni(g) = max(abs(rho(cols)));
end

%% Elastic Net selection frequency across outer spatial folds

elasticSelected = zeros(nGroups, cfg.nSpatialFolds);

for f = 1:cfg.nSpatialFolds

    train = foldId ~= f;

    Xtr = X(train,:);
    ytr = Y(train);

    [B,FitInfo] = lasso( ...
        Xtr, ...
        ytr, ...
        'Alpha',cfg.elasticNetAlpha, ...
        'CV',cfg.elasticNetInnerCV, ...
        'Standardize',true);

    idxLambda = FitInfo.Index1SE;

    beta = B(:,idxLambda);

    for g = 1:nGroups
        cols = groupNames == groups(g);
        elasticSelected(g,f) = any(abs(beta(cols)) > 1e-10);
    end

end

elasticFrequency = mean(elasticSelected,2);

%% Spatial CV grouped permutation

permDelta = nan(nGroups,cfg.nSpatialFolds);
foldRMSE = nan(cfg.nSpatialFolds,1);
foldMAE = nan(cfg.nSpatialFolds,1);
foldR2 = nan(cfg.nSpatialFolds,1);

rng(cfg.randomSeed);

for f = 1:cfg.nSpatialFolds

    fprintf('  Screening spatial fold %d/%d\n', ...
        f, cfg.nSpatialFolds);

    train = foldId ~= f;
    test  = foldId == f;

    model = TreeBagger( ...
        cfg.nTreesScreen, ...
        X(train,:), ...
        Y(train), ...
        'Method','regression', ...
        'MinLeafSize',cfg.minLeafSize, ...
        'NumPredictorsToSample', ...
        max(1,round(sqrt(size(X,2)))), ...
        'OOBPrediction','off');

    pred = predict(model, X(test,:));

    base = regression_metrics(Y(test), pred);

    foldRMSE(f) = base.RMSE;
    foldMAE(f) = base.MAE;
    foldR2(f) = base.R2;

    Xtest = X(test,:);

    for g = 1:nGroups

        cols = find(groupNames == groups(g));

        deltas = nan(cfg.permutationRepeats,1);

        for r = 1:cfg.permutationRepeats

            order = randperm(size(Xtest,1));

            Xperm = Xtest;

            % 同一driver的全部descriptor联合置换
            Xperm(:,cols) = Xtest(order,cols);

            predPerm = predict(model, Xperm);

            permMetric = regression_metrics( ...
                Y(test), predPerm);

            deltas(r) = ...
                permMetric.RMSE - base.RMSE;

        end

        permDelta(g,f) = mean(deltas);

    end

end

groupPermutation = mean(permDelta,2,'omitnan');
groupPermutation(groupPermutation < 0) = 0;

%% 归一化

uniNorm = minmax01(groupUni);
elasticNorm = minmax01(elasticFrequency);
permNorm = minmax01(groupPermutation);

composite = ...
    cfg.weightUnivariate .* uniNorm + ...
    cfg.weightElastic .* elasticNorm + ...
    cfg.weightPermutation .* permNorm;

%% 排名

[~,order] = sort(composite,'descend');

groupsRanked = groups(order);
groupUni = groupUni(order);
elasticFrequency = elasticFrequency(order);
groupPermutation = groupPermutation(order);
uniNorm = uniNorm(order);
elasticNorm = elasticNorm(order);
permNorm = permNorm(order);
composite = composite(order);

Rank = (1:nGroups)';

groupRanking = table( ...
    Rank, ...
    groupsRanked, ...
    groupUni, ...
    elasticFrequency, ...
    groupPermutation, ...
    uniNorm, ...
    elasticNorm, ...
    permNorm, ...
    composite, ...
    'VariableNames', ...
    {'Rank','Driver','MaxAbsSpearman', ...
     'ElasticNetSelectionFrequency', ...
     'GroupedPermutationDeltaRMSE', ...
     'UnivariateNorm','ElasticNorm','PermutationNorm', ...
     'CompositeScore'});

foldMetrics = table( ...
    (1:cfg.nSpatialFolds)', ...
    foldRMSE, ...
    foldMAE, ...
    foldR2, ...
    'VariableNames', ...
    {'Fold','RMSE','MAE','R2'});

result = struct();
result.featureStats = featureStats;
result.groupRanking = groupRanking;
result.foldMetrics = foldMetrics;
result.permutationByFold = permDelta;
result.elasticSelectedByFold = elasticSelected;

end
