function write_screening_protocol( ...
    cfg, dataSet, screenResult, subsetResult, outputFile)
% WRITE_SCREENING_PROTOCOL

fid = fopen(outputFile,'w');

fprintf(fid,'ZHENGZHOU LONG-TERM VARIABLE SCREENING PROTOCOL\n');
fprintf(fid,'================================================\n\n');

fprintf(fid,'Dependent variable:\n%s\n\n',cfg.velocityFile);

fprintf(fid,'Valid samples: %d\n',numel(dataSet.Y));
fprintf(fid,'Descriptor features: %d\n',size(dataSet.X,2));
fprintf(fid,'Physical driver groups: %d\n\n', ...
    numel(unique(dataSet.groupNames)));

fprintf(fid,'Temporal support: %s to %s\n\n', ...
    char(string(cfg.startMonth,'yyyy-MM')), ...
    char(string(cfg.endMonth,'yyyy-MM')));

fprintf(fid,'Dynamic descriptors:\n');
fprintf(fid,'  Mean      = long-term mean state\n');
fprintf(fid,'  Trend     = linear temporal trend per year\n');
fprintf(fid,'  DStd      = standard deviation after removing linear trend\n');
fprintf(fid,'  SeasonAmp = range of detrended monthly climatology\n\n');

fprintf(fid,'Missing-value rule:\n');
fprintf(fid,'  InSAR valid support defines the sample domain.\n');
fprintf(fid,'  Predictors must be finite wherever the velocity raster is finite.\n');
fprintf(fid,'  Dynamic: temporal linear interpolation/end-nearest, then spatial interpolation.\n');
fprintf(fid,'  Static continuous: spatial interpolation.\n');
fprintf(fid,'  Categorical GUM: nearest-neighbour only.\n\n');

fprintf(fid,'Spatial validation:\n');
fprintf(fid,'  Block size: %.2f km\n',cfg.spatialBlockSizeKm);
fprintf(fid,'  Spatial folds: %d\n\n',cfg.nSpatialFolds);

fprintf(fid,'Screening score:\n');
fprintf(fid,'  %.2f * univariate Spearman relevance\n',cfg.weightUnivariate);
fprintf(fid,'  %.2f * Elastic Net spatial-fold selection frequency\n',cfg.weightElastic);
fprintf(fid,'  %.2f * grouped permutation importance under spatial CV\n\n',cfg.weightPermutation);

fprintf(fid,'Final subset rule:\n');
fprintf(fid,'  Drivers are added according to composite ranking.\n');
fprintf(fid,'  Each top-k subset is re-evaluated with spatial CV.\n');
fprintf(fid,'  The smallest k whose mean RMSE is within one standard error of\n');
fprintf(fid,'  the best subset is selected.\n\n');

fprintf(fid,'Best-RMSE driver count: %d\n',subsetResult.bestK);
fprintf(fid,'Selected driver count: %d\n',subsetResult.selectedK);
fprintf(fid,'Best RMSE: %.8f\n',subsetResult.bestRMSE);
fprintf(fid,'1-SE threshold: %.8f\n\n',subsetResult.oneSEThreshold);

fprintf(fid,'Selected drivers:\n');

for k = 1:numel(subsetResult.selectedDrivers)
    fprintf(fid,'  %02d  %s\n',k,subsetResult.selectedDrivers(k));
end

fprintf(fid,'\nImportant interpretation note:\n');
fprintf(fid,'VIF and pairwise correlation are diagnostic, not automatic deletion rules.\n');
fprintf(fid,'The final XGBoost-SHAP stage should re-check correlated-driver attribution stability.\n');

fclose(fid);

end
