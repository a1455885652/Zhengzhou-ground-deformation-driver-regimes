function plot_subset_performance(T, selectedK, outputFile)
% PLOT_SUBSET_PERFORMANCE

fig = figure('Visible','off','Position',[100 100 900 600]);

errorbar( ...
    T.NDrivers, ...
    T.MeanRMSE, ...
    T.SERMSE, ...
    '-o', ...
    'LineWidth',1.2);

hold on;

xline(selectedK,'--');

xlabel('Number of ranked drivers');
ylabel('Spatial-CV RMSE');
title('Ranked subset selection using one-standard-error rule');

grid on;

exportgraphics(fig,outputFile,'Resolution',300);

if ~zz_show_figures(), close(fig); end

end
