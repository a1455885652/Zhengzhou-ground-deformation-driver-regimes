function [dataSet, auditTable, featureInventory] = ...
    prepare_longterm_screening_dataset(cfg)
% PREPARE_LONGTERM_SCREENING_DATASET
%
% 以长期形变速率有效像元作为唯一空间支持。
% 所有自变量在这些像元必须有值；缺失值按变量类型填补。

%% 目标与掩膜

[Ygrid, Rmask] = readgeoraster(cfg.velocityFile, 'OutputType','double');

if ndims(Ygrid) > 2
    Ygrid = Ygrid(:,:,1);
end

[maskData, Rmask2] = readgeoraster(cfg.maskFile, 'OutputType','double');

if ndims(maskData) > 2
    maskData = maskData(:,:,1);
end

assert_same_geographic_grid(Rmask, Rmask2, size(Ygrid), size(maskData), ...
    'Velocity vs mask');

maskValid = isfinite(maskData) & maskData ~= 0;

supportMask = ...
    maskValid & ...
    isfinite(Ygrid) & ...
    abs(Ygrid) < 1e20;

if nnz(supportMask) < 100
    error('长期形变速率有效像元过少：%d', nnz(supportMask));
end

fprintf('Velocity valid support pixels = %d\n', nnz(supportMask));

%% 像元中心经纬度

[lonGrid, latGrid] = geographic_grid_centers(Rmask);

pixelIndex = find(supportMask);
Y = Ygrid(pixelIndex);
lon = lonGrid(pixelIndex);
lat = latGrid(pixelIndex);

%% 特征容器

X = zeros(numel(pixelIndex),0);
featureNames = strings(0,1);
groupNames = strings(0,1);
descriptorNames = strings(0,1);

auditRows = {};
inventoryRows = {};

%% 月变量

for v = 1:numel(cfg.monthlyVariables)

    V = cfg.monthlyVariables(v);

    fprintf('Monthly driver: %s\n', V.name);

    stack = load_monthly_stack( ...
        V.folder, ...
        cfg.months, ...
        Rmask, ...
        size(Ygrid));

    beforeMissing = nnz( ...
        ~isfinite(stack(repmat(supportMask,1,1,size(stack,3)))));

    stack = fill_dynamic_stack( ...
        stack, ...
        supportMask, ...
        lonGrid, ...
        latGrid, ...
        cfg.spatialInterpolationMethod);

    afterMissing = nnz( ...
        ~isfinite(stack(repmat(supportMask,1,1,size(stack,3)))));

    if afterMissing > 0
        error('%s 在形变有效区仍有 %d 个缺失值。', ...
            V.name, afterMissing);
    end

    [F, fNames, dNames] = build_monthly_descriptors( ...
        stack, ...
        cfg.months, ...
        supportMask, ...
        V.name, ...
        V.seasonality);

    startCol = size(X,2) + 1;
    X = [X, F]; %#ok<AGROW>

    featureNames = [featureNames; fNames(:)]; %#ok<AGROW>
    groupNames = [groupNames; repmat(V.name,numel(fNames),1)]; %#ok<AGROW>
    descriptorNames = [descriptorNames; dNames(:)]; %#ok<AGROW>

    for q = 1:numel(fNames)
        inventoryRows(end+1,:) = { ...
            char(fNames(q)), char(V.name), char(dNames(q)), ...
            'Monthly', V.folder}; %#ok<AGROW>
    end

    auditRows(end+1,:) = { ...
        char(V.name), 'Monthly', beforeMissing, afterMissing, ...
        'Temporal linear/end-nearest + spatial natural/nearest'}; %#ok<AGROW>

end

%% 年变量

for v = 1:numel(cfg.annualVariables)

    V = cfg.annualVariables(v);

    fprintf('Annual driver: %s\n', V.name);

    annualStack = load_annual_stack( ...
        V.folder, ...
        cfg.years, ...
        Rmask, ...
        size(Ygrid));

    beforeMissing = nnz( ...
        ~isfinite(annualStack(repmat(supportMask,1,1,size(annualStack,3)))));

    annualStack = fill_dynamic_stack( ...
        annualStack, ...
        supportMask, ...
        lonGrid, ...
        latGrid, ...
        cfg.spatialInterpolationMethod);

    afterMissing = nnz( ...
        ~isfinite(annualStack(repmat(supportMask,1,1,size(annualStack,3)))));

    if afterMissing > 0
        error('%s 在形变有效区仍有 %d 个缺失值。', ...
            V.name, afterMissing);
    end

    [F, fNames, dNames] = build_annual_descriptors( ...
        annualStack, ...
        cfg.years, ...
        supportMask, ...
        V.name);

    X = [X, F]; %#ok<AGROW>
    featureNames = [featureNames; fNames(:)]; %#ok<AGROW>
    groupNames = [groupNames; repmat(V.name,numel(fNames),1)]; %#ok<AGROW>
    descriptorNames = [descriptorNames; dNames(:)]; %#ok<AGROW>

    for q = 1:numel(fNames)
        inventoryRows(end+1,:) = { ...
            char(fNames(q)), char(V.name), char(dNames(q)), ...
            'Annual', V.folder}; %#ok<AGROW>
    end

    auditRows(end+1,:) = { ...
        char(V.name), 'Annual', beforeMissing, afterMissing, ...
        'Temporal linear/end-nearest + spatial natural/nearest'}; %#ok<AGROW>

end

%% 静态连续变量

for v = 1:numel(cfg.staticContinuous)

    V = cfg.staticContinuous(v);

    fprintf('Static continuous driver: %s\n', V.name);

    A = read_aligned_raster(V.file, Rmask, size(Ygrid));

    beforeMissing = nnz(~isfinite(A(supportMask)));

    A = fill_static_continuous( ...
        A, ...
        supportMask, ...
        lonGrid, ...
        latGrid, ...
        cfg.spatialInterpolationMethod);

    afterMissing = nnz(~isfinite(A(supportMask)));

    if afterMissing > 0
        error('%s 在形变有效区仍有 %d 个缺失值。', ...
            V.name, afterMissing);
    end

    X(:,end+1) = A(pixelIndex); %#ok<AGROW>

    featureNames(end+1,1) = V.name;
    groupNames(end+1,1) = V.name;
    descriptorNames(end+1,1) = "Static";

    inventoryRows(end+1,:) = { ...
        char(V.name), char(V.name), 'Static', 'StaticContinuous', V.file}; %#ok<AGROW>

    auditRows(end+1,:) = { ...
        char(V.name), 'StaticContinuous', beforeMissing, afterMissing, ...
        'Spatial natural/nearest'}; %#ok<AGROW>

end

%% GUM类别变量：nearest填补 + one-hot（去掉第一类参考类别）

fprintf('Static categorical driver: %s\n', cfg.gumName);

G = read_aligned_raster(cfg.gumFile, Rmask, size(Ygrid));

beforeMissing = nnz(~isfinite(G(supportMask)));

G = fill_static_categorical_nearest( ...
    G, ...
    supportMask, ...
    lonGrid, ...
    latGrid);

afterMissing = nnz(~isfinite(G(supportMask)));

if afterMissing > 0
    error('GUM 在形变有效区仍有 %d 个缺失值。', afterMissing);
end

g = G(pixelIndex);
cats = unique(g(isfinite(g)));
cats = sort(cats(:));

if numel(cats) < 2
    warning('GUM只有一个有效类别，将作为单一静态数值特征。');

    X(:,end+1) = g;
    featureNames(end+1,1) = "GUM";
    groupNames(end+1,1) = "GUM";
    descriptorNames(end+1,1) = "Category";

    inventoryRows(end+1,:) = { ...
        'GUM','GUM','Category','StaticCategorical',cfg.gumFile};
else

    % 第一类作为reference，避免完全dummy共线性
    referenceCategory = cats(1);

    for c = 2:numel(cats)

        feat = double(g == cats(c));

        fname = "GUM_Cat_" + string(cats(c));

        X(:,end+1) = feat; %#ok<AGROW>
        featureNames(end+1,1) = fname;
        groupNames(end+1,1) = "GUM";
        descriptorNames(end+1,1) = "CategoryDummy";

        inventoryRows(end+1,:) = { ...
            char(fname), 'GUM', ...
            ['CategoryDummy_ref_' num2str(referenceCategory)], ...
            'StaticCategorical', cfg.gumFile}; %#ok<AGROW>

    end

end

auditRows(end+1,:) = { ...
    'GUM', 'StaticCategorical', beforeMissing, afterMissing, ...
    'Spatial nearest category'}; %#ok<AGROW>

%% 最终检查

if any(~isfinite(X(:)))
    error('最终自变量矩阵仍存在NaN/Inf。');
end

if any(~isfinite(Y))
    error('最终因变量仍存在NaN/Inf。');
end

% 删除近零方差特征
sdX = std(X,0,1);

keep = ...
    isfinite(sdX) & ...
    sdX > 1e-12;

if any(~keep)
    fprintf('Removing %d near-zero-variance descriptor(s).\n', nnz(~keep));
end

X = X(:,keep);
featureNames = featureNames(keep);
groupNames = groupNames(keep);
descriptorNames = descriptorNames(keep);

%% 数据集

dataSet = struct();

dataSet.X = X;
dataSet.Y = Y;
dataSet.featureNames = featureNames;
dataSet.groupNames = groupNames;
dataSet.descriptorNames = descriptorNames;
dataSet.pixelIndex = pixelIndex;
dataSet.lon = lon;
dataSet.lat = lat;
dataSet.supportMask = supportMask;
dataSet.R = Rmask;
dataSet.rasterSize = size(Ygrid);

%% 表

auditTable = cell2table( ...
    auditRows, ...
    'VariableNames', ...
    {'Driver','Type','MissingBefore','MissingAfter','FillMethod'});

featureInventory = cell2table( ...
    inventoryRows, ...
    'VariableNames', ...
    {'Feature','Driver','Descriptor','SourceType','Source'});

% 与实际保留特征同步
featureInventory = featureInventory( ...
    ismember(string(featureInventory.Feature), featureNames), :);

end
