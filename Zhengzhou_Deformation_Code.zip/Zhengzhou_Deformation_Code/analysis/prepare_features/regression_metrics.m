function M = regression_metrics(y, pred)
% REGRESSION_METRICS

y = double(y(:));
pred = double(pred(:));

valid = isfinite(y) & isfinite(pred);

y = y(valid);
pred = pred(valid);

err = pred-y;

M.RMSE = sqrt(mean(err.^2));
M.MAE = mean(abs(err));

sst = sum((y-mean(y)).^2);
sse = sum((y-pred).^2);

if sst > 0
    M.R2 = 1 - sse/sst;
else
    M.R2 = NaN;
end

end
