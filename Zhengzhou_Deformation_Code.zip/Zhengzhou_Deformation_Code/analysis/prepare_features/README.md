# 长期特征准备

从驱动因素栅格构建多年均值、趋势及其他描述量，生成初始筛选工作空间。

| 项目 | 内容 |
|---|---|
| 输入 | 原工程掩膜、长期形变速率与配置中列出的驱动因素栅格。 |
| 输出 | `project_root/LongTerm_Variable_Screening_Output` |
| 设置 | config_longterm_variable_screening.m |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('prepare_features')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。
