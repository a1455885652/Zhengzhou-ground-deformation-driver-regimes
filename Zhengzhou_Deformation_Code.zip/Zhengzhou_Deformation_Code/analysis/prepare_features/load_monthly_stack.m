function stack = load_monthly_stack(folderPath, months, Rref, rasterSize)
% LOAD_MONTHLY_STACK
% 按 YYYYMM 从月尺度文件夹读取全部GeoTIFF。

if ~isfolder(folderPath)
    error('月变量目录不存在：%s', folderPath);
end

D = dir(fullfile(folderPath, '*.tif'));

if isempty(D)
    error('目录没有tif：%s', folderPath);
end

n = numel(months);
stack = nan([rasterSize(1:2), n], 'single');

for k = 1:n

    code = char(string(months(k),'yyyyMM'));

    matches = false(numel(D),1);

    for j = 1:numel(D)
        matches(j) = contains(D(j).name, code);
    end

    idx = find(matches);

    if isempty(idx)
        error('缺少 %s 月数据：%s', code, folderPath);
    end

    if numel(idx) > 1
        names = string({D(idx).name});
        error('月份 %s 匹配到多个文件：\n%s', ...
            code, strjoin(names,newline));
    end

    filePath = fullfile(D(idx).folder, D(idx).name);

    A = read_aligned_raster(filePath, Rref, rasterSize);

    stack(:,:,k) = single(A);

end

end
