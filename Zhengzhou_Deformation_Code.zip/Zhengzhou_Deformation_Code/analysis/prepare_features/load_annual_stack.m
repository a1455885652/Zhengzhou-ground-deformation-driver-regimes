function stack = load_annual_stack(folderPath, years, Rref, rasterSize)
% LOAD_ANNUAL_STACK
% 按YYYY读取年度GeoTIFF。

if ~isfolder(folderPath)
    error('年变量目录不存在：%s', folderPath);
end

D = dir(fullfile(folderPath, '*.tif'));

if isempty(D)
    error('目录没有tif：%s', folderPath);
end

n = numel(years);
stack = nan([rasterSize(1:2), n], 'single');

for k = 1:n

    code = num2str(years(k));

    matches = false(numel(D),1);

    for j = 1:numel(D)
        matches(j) = contains(D(j).name, code);
    end

    idx = find(matches);

    if isempty(idx)
        error('缺少 %s 年数据：%s', code, folderPath);
    end

    if numel(idx) > 1
        names = string({D(idx).name});
        error('年份 %s 匹配到多个文件：\n%s', ...
            code, strjoin(names,newline));
    end

    filePath = fullfile(D(idx).folder, D(idx).name);

    A = read_aligned_raster(filePath, Rref, rasterSize);

    stack(:,:,k) = single(A);

end

end
