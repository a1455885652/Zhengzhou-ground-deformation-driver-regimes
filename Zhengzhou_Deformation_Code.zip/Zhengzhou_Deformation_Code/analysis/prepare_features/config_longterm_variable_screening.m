function cfg = config_longterm_variable_screening()
% CONFIG_LONGTERM_VARIABLE_SCREENING
% 郑州市长期形变速率变量筛选配置。

%% 基础路径

cfg.maskFile = ...
    zz_project_path('yanmo/Zhengzhou_mask_1km.tif');

cfg.velocityFile = ...
    zz_project_path('InSAR_1km_latest/04_Velocity_1km/InSAR_Velocity_vertical_reference_1km.tif');

cfg.outputRoot = ...
    zz_project_path('LongTerm_Variable_Screening_Output');

%% 时间范围

cfg.startMonth = datetime(2018,8,1);
cfg.endMonth   = datetime(2025,12,1);

cfg.months = ...
    (cfg.startMonth:calmonths(1):cfg.endMonth)';

cfg.years = (2018:2025)';

%% 动态（月尺度）变量
% seasonality=true：计算SeasonAmp
% seasonality=false：只计算Mean/Trend/DStd

m = 0;
monthly = struct([]);

m=m+1;
monthly(m).name = "NDVI";
monthly(m).folder = ...
    zz_project_path('NDVI_ST_Interpolated/NDVI_Filled');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "Dewpoint";
monthly(m).folder = ...
    zz_project_path('ERA5_Land_1km_TIF/2m dewpoint temperature');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "SkinReservoir";
monthly(m).folder = ...
    zz_project_path('ERA5_Land_1km_TIF/Skin reservoir content');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "SoilWater_0_289cm";
monthly(m).folder = ...
    zz_project_path('ERA5_Land_1km_TIF/SoilWater_0_289cm_depth_weighted');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "SubsurfaceRunoff";
monthly(m).folder = ...
    zz_project_path('ERA5_Land_1km_TIF/Sub-surface runoff');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "SurfaceRunoff";
monthly(m).folder = ...
    zz_project_path('ERA5_Land_1km_TIF/Surface runoff');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "TotalEvaporation";
monthly(m).folder = ...
    zz_project_path('ERA5_Land_1km_TIF/Total evaporation');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "TotalPrecipitation";
monthly(m).folder = ...
    zz_project_path('ERA5_Land_1km_TIF/Total precipitation');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "GWS";
monthly(m).folder = ...
    zz_project_path('GWS_1km');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "TWS";
monthly(m).folder = ...
    zz_project_path('TWS_1km');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "NighttimeLight";
monthly(m).folder = ...
    zz_project_path('Nighttime_light_1km');
monthly(m).seasonality = true;

m=m+1;
monthly(m).name = "RoadDensity";
monthly(m).folder = ...
    zz_project_path('RoadDensity_1km/Monthly/FormalRoad');
monthly(m).seasonality = false;

cfg.monthlyVariables = monthly;

%% 年尺度变量

a = 0;
annual = struct([]);

a=a+1;
annual(a).name = "Population";
annual(a).folder = ...
    zz_project_path('Population_1km');

cfg.annualVariables = annual;

%% 静态连续变量

s = 0;
staticContinuous = struct([]);

s=s+1;
staticContinuous(s).name = "BuiltSurface";
staticContinuous(s).file = ...
    zz_project_path('Built_surface_1km/Built_surface_area_1km.tif');

s=s+1;
staticContinuous(s).name = "DEM";
staticContinuous(s).file = ...
    zz_project_path('Terrain_1km/DEM_1km.tif');

s=s+1;
staticContinuous(s).name = "Slope";
staticContinuous(s).file = ...
    zz_project_path('Terrain_1km/Slope_mean_1km.tif');

s=s+1;
staticContinuous(s).name = "Relief";
staticContinuous(s).file = ...
    zz_project_path('Terrain_1km/Terrain_relief_1km.tif');

s=s+1;
staticContinuous(s).name = "GLHYMPS_Permeability";
staticContinuous(s).file = ...
    zz_project_path('GLHYMPS_Zhengzhou_1km/GLHYMPS_log10_permeability_1km.tif');

s=s+1;
staticContinuous(s).name = "GLHYMPS_Porosity";
staticContinuous(s).file = ...
    zz_project_path('GLHYMPS_Zhengzhou_1km/GLHYMPS_porosity_1km.tif');

s=s+1;
staticContinuous(s).name = "DepthToBedrock";
staticContinuous(s).file = ...
    zz_project_path('GLHYMPS_Zhengzhou_1km/GLHYMPS_depth_to_bedrock_mean_m_1km.tif');

s=s+1;
staticContinuous(s).name = "BDOD";
staticContinuous(s).file = ...
    zz_project_path('SoilGrids_1km/bdod/bdod_0-200cm_weighted_g_cm3_1km.tif');

s=s+1;
staticContinuous(s).name = "Clay";
staticContinuous(s).file = ...
    zz_project_path('SoilGrids_1km/clay/clay_0-200cm_weighted_percent_1km.tif');

s=s+1;
staticContinuous(s).name = "Silt";
staticContinuous(s).file = ...
    zz_project_path('SoilGrids_1km/silt/silt_0-200cm_weighted_percent_1km.tif');

s=s+1;
staticContinuous(s).name = "TotalLooseThickness";
staticContinuous(s).file = ...
    zz_project_path('Thickness_1km/total_soil_regolith_sediment_thickness_1km.tif');

cfg.staticContinuous = staticContinuous;

%% 静态类别变量

cfg.gumName = "GUM";
cfg.gumFile = ...
    zz_project_path('GUM_Zhengzhou_1km/GUM_XX_class_1km.tif');

%% 缺失填补
cfg.imputeTemporalFirst = true;
cfg.spatialInterpolationMethod = 'natural';

%% 空间CV
cfg.randomSeed = 20260829;
cfg.spatialBlockSizeKm = 12;
cfg.nSpatialFolds = 5;

%% 模型参数
cfg.nTreesScreen = 200;
cfg.nTreesSubset = 120;
cfg.minLeafSize = 8;
cfg.permutationRepeats = 2;

%% Elastic Net
cfg.elasticNetAlpha = 0.5;
cfg.elasticNetInnerCV = 5;

%% 组合权重
cfg.weightUnivariate = 0.20;
cfg.weightElastic = 0.30;
cfg.weightPermutation = 0.50;

%% 最终变量数
cfg.minSelectedDrivers = 5;

%% 仅用于数值稳定性诊断
cfg.nearDuplicateSpearman = 0.98;
cfg.highVIF = 10;

end
