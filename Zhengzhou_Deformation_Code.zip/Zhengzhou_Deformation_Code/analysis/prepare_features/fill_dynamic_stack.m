function stack = fill_dynamic_stack( ...
    stack, supportMask, lonGrid, latGrid, spatialMethod)
% FILL_DYNAMIC_STACK
%
% 只要求InSAR形变有效区必须完整。
%
% 第一步：每个像元沿时间线性插值，端点nearest。
% 第二步：仍缺失的值按每个月进行空间插值。
%
% 形变NaN区域不参与筛选，也不要求填补。
%
% 实现上先reshape为 [pixel x time]，避免逐像元时反复复制整幅栅格。

[nRows,nCols,nT] = size(stack);

supportIdx = find(supportMask);

%% 时间填补

M = reshape(double(stack), nRows*nCols, nT);

x = (1:nT)';

for p = 1:numel(supportIdx)

    idx = supportIdx(p);

    y = M(idx,:)';

    valid = isfinite(y);

    if nnz(valid) >= 2

        firstValid = find(valid,1,'first');
        lastValid  = find(valid,1,'last');

        yFilled = interp1( ...
            x(valid), ...
            y(valid), ...
            x, ...
            'linear', ...
            'extrap');

        % 不做端点趋势外推，端点直接使用最近有效观测
        yFilled(1:firstValid-1) = y(firstValid);
        yFilled(lastValid+1:end) = y(lastValid);

        y = yFilled;

    elseif nnz(valid) == 1

        oneValue = y(valid);
        y(:) = oneValue;

    end

    M(idx,:) = y';

end

stack = reshape(single(M), nRows, nCols, nT);

clear M;

%% 空间填补

for t = 1:nT

    A = double(stack(:,:,t));

    missing = supportMask & ~isfinite(A);

    if ~any(missing(:))
        continue;
    end

    known = supportMask & isfinite(A);

    if nnz(known) < 3
        error('第%d期空间有效值不足，无法插值。', t);
    end

    F = scatteredInterpolant( ...
        lonGrid(known), ...
        latGrid(known), ...
        A(known), ...
        spatialMethod, ...
        'nearest');

    A(missing) = F( ...
        lonGrid(missing), ...
        latGrid(missing));

    stillMissing = supportMask & ~isfinite(A);

    if any(stillMissing(:))

        F2 = scatteredInterpolant( ...
            lonGrid(known), ...
            latGrid(known), ...
            A(known), ...
            'nearest', ...
            'nearest');

        A(stillMissing) = F2( ...
            lonGrid(stillMissing), ...
            latGrid(stillMissing));
    end

    stack(:,:,t) = single(A);

end

end
