function RAS = read_envi_sarscape(dataPath, cfg)
%READ_ENVI_SARSCAPE Minimal ENVI reader for single-band SARscape rasters.

hdrPath = [dataPath, '.hdr'];
if ~exist(hdrPath, 'file')
    [folder, base, ~] = fileparts(dataPath);
    hdrPath2 = fullfile(folder, [base, '.hdr']);
    if exist(hdrPath2, 'file')
        hdrPath = hdrPath2;
    else
        error('ENVI header not found for: %s', dataPath);
    end
end

H = parse_envi_header_giv(hdrPath);

precision = envi_precision_giv(H.dataType);
if H.byteOrder == 0
    machineFmt = 'ieee-le';
else
    machineFmt = 'ieee-be';
end

fid = fopen(dataPath, 'r', machineFmt);
if fid < 0
    error('Cannot open ENVI data file: %s', dataPath);
end
cleanup = onCleanup(@() fclose(fid));
fseek(fid, H.headerOffset, 'bof');

nPix = H.samples * H.lines;
raw = fread(fid, nPix, ['*', precision]);
if numel(raw) < nPix
    error('Unexpected ENVI file size for: %s', dataPath);
end
A = reshape(double(raw(1:nPix)), [H.samples, H.lines]).';

if isfinite(H.ignoreValue)
    A(A == H.ignoreValue) = NaN;
end
A(abs(A) > cfg.insar.invalidAbsThreshold) = NaN;

RAS = struct();
RAS.Data = A;
RAS.Type = 'ENVI';
RAS.Reference = [];
RAS.Info = [];
RAS.MapInfo = H.mapInfo;
end
