function [matched, method] = match_gnss_to_sar(station, sarTimes, cfg)
%MATCH_GNSS_TO_SAR Match cleaned GNSS vertical series to SAR epochs.

matched = NaN(numel(sarTimes),1);
method = strings(numel(sarTimes),1);

t = station.Time(:);
v = station.VerticalMM(:);

if isempty(t)
    return;
end

if strcmp(station.SourceType, 'ZHNZ_DAILY')
    gDay = dateshift(t, 'start', 'day');
    sDay = dateshift(sarTimes(:), 'start', 'day');
    [tf, loc] = ismember(sDay, gDay);
    matched(tf) = v(loc(tf));
    method(tf) = "exact-day";
    return;
end

% Local sub-daily GNSS: bracketed linear interpolation to 10:30.
for i = 1:numel(sarTimes)
    ts = sarTimes(i);
    iBefore = find(t <= ts, 1, 'last');
    iAfter  = find(t >= ts, 1, 'first');

    used = false;
    if ~isempty(iBefore) && ~isempty(iAfter) && iBefore ~= iAfter
        h1 = hours(ts - t(iBefore));
        h2 = hours(t(iAfter) - ts);
        if h1 <= cfg.match.localMaxBracketHours && h2 <= cfg.match.localMaxBracketHours
            xx = [seconds(t(iBefore)-ts), seconds(t(iAfter)-ts)];
            yy = [v(iBefore), v(iAfter)];
            matched(i) = interp1(xx, yy, 0, 'linear');
            method(i) = "linear-bracket";
            used = true;
        end
    elseif ~isempty(iBefore) && iBefore == iAfter
        matched(i) = v(iBefore);
        method(i) = "exact";
        used = true;
    end

    if ~used
        [dmin, idx] = min(abs(seconds(t - ts)));
        if ~isempty(idx) && dmin <= cfg.match.localNearestFallbackHours*3600
            matched(i) = v(idx);
            method(i) = "nearest";
        end
    end
end
end
