function T = compute_overall_metrics_giv(results, wins)
rows = cell(numel(wins),11);
for iw = 1:numel(wins)
    w = wins(iw);
    gAll = zeros(0,1);
    iAll = zeros(0,1);
    stationCount = 0;
    for s = 1:numel(results)
        TT = results(s).Table;
        if isempty(TT) || ~ismember(sprintf('InSAR_%dx%d_mm',w,w), TT.Properties.VariableNames)
            continue;
        end
        g = TT.GNSS_mm;
        i = TT.(sprintf('InSAR_%dx%d_mm',w,w));
        mask = isfinite(g) & isfinite(i);
        if any(mask)
            stationCount = stationCount + 1;
            gAll = [gAll; g(mask)]; %#ok<AGROW>
            iAll = [iAll; i(mask)]; %#ok<AGROW>
        end
    end
    M = compute_validation_metrics(gAll, iAll);
    rows(iw,:) = {w, stationCount, M.N, M.PearsonR, M.R2Regression, ...
        M.R2OneToOne, M.RMSE, M.MAE, M.BiasInSARMinusGNSS, M.Slope, M.Intercept};
end
T = cell2table(rows, 'VariableNames', ...
    {'WindowSize','NStations','NPoints','PearsonR','R2_Regression','R2_OneToOne', ...
     'RMSE_mm','MAE_mm','Bias_InSAR_minus_GNSS_mm','RegressionSlope','RegressionIntercept_mm'});
end
