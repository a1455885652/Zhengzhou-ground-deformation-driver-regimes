function [timeOut, vOut, logTable, keepMask] = remove_insar_temporal_gross_errors(timeIn, vIn, cfg)
%REMOVE_INSAR_TEMPORAL_GROSS_ERRORS Conservative InSAR-only temporal QC.
% The GNSS series is never consulted, so validation independence is preserved.

timeIn = timeIn(:);
vIn = vIn(:);
n = numel(vIn);
flag = false(n,1);
localMedian = NaN(n,1);
localSigma = NaN(n,1);

if cfg.insar.temporalOutlier.enabled && n >= cfg.insar.temporalOutlier.minLocalCount
    h = cfg.insar.temporalOutlier.windowHalfWidthEpochs;
    localMedian = movmedian(vIn,[h h],'omitnan');
    absDev = abs(vIn-localMedian);
    localMAD = movmedian(absDev,[h h],'omitnan');
    localSigma = 1.4826 .* localMAD;
    localSigma = max(localSigma,cfg.insar.temporalOutlier.minLocalSigmaMM);
    localCount = movsum(double(isfinite(vIn)),[h h]);

    flag = isfinite(vIn) & isfinite(localMedian) & ...
        localCount >= cfg.insar.temporalOutlier.minLocalCount & ...
        absDev > cfg.insar.temporalOutlier.nSigma .* localSigma;
end

logTable = table(timeIn(flag),vIn(flag),localMedian(flag),localSigma(flag), ...
    abs(vIn(flag)-localMedian(flag)), ...
    'VariableNames',{'DateTime','InSARRaw_mm','LocalMedian_mm', ...
    'LocalRobustSigma_mm','AbsoluteDeviation_mm'});

keepMask = ~flag & ~isnat(timeIn) & isfinite(vIn);
timeOut = timeIn(keepMask);
vOut = vIn(keepMask);
end
