function plot_station_window_comparison(results, cfg)
%PLOT_STATION_WINDOW_COMPARISON Per-station figure with GNSS, 3x3 and 5x5.

outDir = fullfile(cfg.outputDir, 'Station_Figures');
ensure_folder_giv(outDir);

for s = 1:numel(results)
    TT = results(s).Table;
    if isempty(TT)
        continue;
    end
    if ~all(ismember({'InSAR_3x3_mm','InSAR_5x5_mm'}, TT.Properties.VariableNames))
        continue;
    end

    fig = figure('Color','w','Position',[100 100 1050 520]);
    ax = axes(fig); hold(ax,'on');
    plot(ax,TT.DateTime,TT.GNSS_mm,'--o','Color',[0.10 0.10 0.10], ...
        'LineWidth',1.2,'MarkerSize',3.5,'MarkerFaceColor','w');
    plot(ax,TT.DateTime,TT.InSAR_3x3_mm,'-','Color',[0.82 0.15 0.12], ...
        'LineWidth',1.6);
    plot(ax,TT.DateTime,TT.InSAR_5x5_mm,'-','Color',[0.12 0.35 0.70], ...
        'LineWidth',1.6);
    yline(ax,0,':','Color',[0.65 0.65 0.65]);
    grid(ax,'on'); ax.GridAlpha=0.15; box(ax,'on');
    ax.FontName=cfg.plot.fontName; ax.FontSize=cfg.plot.fontSize;
    xlabel(ax,'Time');
    ylabel(ax,'Relative vertical deformation (mm)');
    title(ax,[results(s).Station,'  (positive = subsidence)'],'FontWeight','bold');
    legend(ax,{'GNSS','InSAR 3x3','InSAR 5x5'},'Location','best','Box','off');

    base = fullfile(outDir, [safe_filename_giv(results(s).Station), '_3x3_vs_5x5']);
    exportgraphics(fig,[base,'.png'],'Resolution',cfg.plot.dpi);
    exportgraphics(fig,[base,'.pdf'],'ContentType','vector');
    if ~zz_show_figures(), close(fig); end
end
end
