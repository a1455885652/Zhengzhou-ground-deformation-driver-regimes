function F = discover_insar_displacement_files(cfg)
%DISCOVER_INSAR_DISPLACEMENT_FILES Discover acquisition-date displacement rasters.

chosenDir = '';
raw = [];
for d = 1:numel(cfg.insar.candidateDirs)
    p = cfg.insar.candidateDirs{d};
    if ~exist(p, 'dir')
        continue;
    end
    if cfg.insar.recursive
        r = dir(fullfile(p, '**', '*'));
    else
        r = dir(fullfile(p, '*'));
    end
    r = r(~[r.isdir]);
    if isempty(r)
        continue;
    end

    keep = false(numel(r),1);
    for i = 1:numel(r)
        nm = r(i).name;
        [~,~,ext] = fileparts(nm);
        if any(strcmpi(ext, {'.hdr','.xml','.prj','.aux','.ovr','.csv','.txt','.mat'}))
            continue;
        end
        if isempty(regexp(nm, cfg.insar.includeRegex, 'once'))
            continue;
        end
        if ~isempty(regexp(nm, cfg.insar.excludeRegex, 'once'))
            continue;
        end
        if isempty(regexp(nm, cfg.insar.dateRegex, 'once'))
            continue;
        end
        keep(i) = true;
    end
    r = r(keep);
    if numel(r) >= 3
        raw = r;
        chosenDir = p;
        break;
    end
end

if isempty(raw)
    error(['No acquisition-date InSAR displacement rasters found. Edit ', ...
        'cfg.insar.candidateDirs in config_gnss_insar_validation.m.']);
end

fprintf('      InSAR directory: %s\n', chosenDir);

n = numel(raw);
filePath = strings(n,1);
dateToken = strings(n,1);
dt = NaT(n,1);
priority = zeros(n,1);
for i = 1:n
    filePath(i) = string(fullfile(raw(i).folder, raw(i).name));
    tok = regexp(raw(i).name, cfg.insar.dateRegex, 'tokens', 'once');
    dateToken(i) = string(tok{1});
    dt(i) = datetime(tok{1}, 'InputFormat', 'yyyyMMdd') + cfg.insar.acquisitionTime;

    [~,~,ext] = fileparts(raw(i).name);
    p = 0;
    if any(strcmpi(ext, {'.tif','.tiff'})), p = p + 20; end
    if contains(lower(raw(i).name), 'vertical'), p = p + 10; end
    if contains(lower(raw(i).name), 'disp_geo'), p = p + 5; end
    if isempty(ext) && exist([char(filePath(i)), '.hdr'], 'file'), p = p + 4; end
    priority(i) = p;
end

T = table(filePath, dateToken, dt, priority, ...
    'VariableNames', {'FilePath','DateToken','DateTime','Priority'});
T = sortrows(T, {'DateTime','Priority'}, {'ascend','descend'});

% One raster per acquisition date: keep highest-priority candidate.
[~, ia] = unique(T.DateToken, 'stable');
F = T(ia,:);
F = sortrows(F, 'DateTime');

mask = F.DateTime >= cfg.study.startTime & F.DateTime <= cfg.study.endTime;
F = F(mask,:);

if height(F) < 3
    error('Too few InSAR epochs remained after study-period filtering.');
end
end
