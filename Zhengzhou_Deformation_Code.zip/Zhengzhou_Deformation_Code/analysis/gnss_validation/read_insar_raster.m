function RAS = read_insar_raster(filePath, cfg)
%READ_INSAR_RASTER Read GeoTIFF or SARscape/ENVI raster.

[~,~,ext] = fileparts(filePath);
if any(strcmpi(ext, {'.tif','.tiff'}))
    [A, R] = readgeoraster(filePath);
    A = double(A);
    if ndims(A) > 2
        A = A(:,:,1);
    end
    info = georasterinfo(filePath);
    try
        mdi = info.MissingDataIndicator;
        if ~isempty(mdi)
            for k = 1:numel(mdi)
                A(A == double(mdi(k))) = NaN;
            end
        end
    catch
    end
    A(abs(A) > cfg.insar.invalidAbsThreshold) = NaN;

    RAS = struct();
    RAS.Data = A;
    RAS.Type = 'GEOTIFF';
    RAS.Reference = R;
    RAS.Info = info;
    RAS.MapInfo = [];
else
    RAS = read_envi_sarscape(filePath, cfg);
end
end
