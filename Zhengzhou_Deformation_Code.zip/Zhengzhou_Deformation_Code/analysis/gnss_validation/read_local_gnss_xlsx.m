function S = read_local_gnss_xlsx(filePath, cfg)
%READ_LOCAL_GNSS_XLSX Read one local GNSS Excel file.
% Verified sample columns:
% 3 Device name, 5 Time, 6 dX(mm), 7 dY(mm), 8 dH(mm).

T = readtable(filePath, 'VariableNamingRule', 'preserve', 'TextType', 'string');

if width(T) < cfg.gnss.local.verticalColumn
    error('GNSS file has fewer than %d columns: %s', ...
        cfg.gnss.local.verticalColumn, filePath);
end

rawName = string(T{:, cfg.gnss.local.stationNameColumn});
rawName = strip(rawName);
rawName(rawName == "") = missing;
validName = rawName(~ismissing(rawName));
if isempty(validName)
    error('No station name found in column %d: %s', ...
        cfg.gnss.local.stationNameColumn, filePath);
end

uNames = unique(validName);
if numel(uNames) > 1
    warning('Multiple station names found in %s. Using the most frequent one.', filePath);
    counts = zeros(numel(uNames),1);
    for k = 1:numel(uNames)
        counts(k) = sum(validName == uNames(k));
    end
    [~, kmax] = max(counts);
    stationName = uNames(kmax);
else
    stationName = uNames(1);
end

rawTime = T{:, cfg.gnss.local.timeColumn};
time = parse_local_gnss_time(rawTime);

xmm = column_to_double_giv(T{:, cfg.gnss.local.xColumn});
ymm = column_to_double_giv(T{:, cfg.gnss.local.yColumn});
verticalRaw = column_to_double_giv(T{:, cfg.gnss.local.verticalColumn});
verticalMM = cfg.gnss.localVerticalToPaperSign .* verticalRaw;

mask = ~isnat(time) & isfinite(verticalMM) & rawName == stationName;
time = time(mask);
xmm = xmm(mask);
ymm = ymm(mask);
verticalMM = verticalMM(mask);

% Crop to study period before merging duplicates.
mask2 = time >= cfg.study.startTime & time <= cfg.study.endTime;
time = time(mask2);
xmm = xmm(mask2);
ymm = ymm(mask2);
verticalMM = verticalMM(mask2);

[time, verticalMM, xmm, ymm] = aggregate_duplicate_gnss_times(time, verticalMM, xmm, ymm);

S = struct();
S.Name = char(stationName);
S.SourceType = 'LOCAL_XLSX';
S.FilePath = filePath;
S.Time = time;
S.VerticalMM = verticalMM;
S.XMM = xmm;
S.YMM = ymm;
end
