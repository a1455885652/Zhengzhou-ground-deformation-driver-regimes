function H = parse_envi_header_giv(hdrPath)
%PARSE_ENVI_HEADER_GIV Parse essential ENVI/SARscape header fields.

txt = fileread(hdrPath);

H.samples = get_num_field_giv(txt, 'samples');
H.lines = get_num_field_giv(txt, 'lines');
H.bands = get_num_field_giv(txt, 'bands');
H.headerOffset = get_num_field_giv(txt, 'header offset');
H.dataType = get_num_field_giv(txt, 'data type');
H.byteOrder = get_num_field_giv(txt, 'byte order');
H.ignoreValue = get_optional_num_field_giv(txt, 'data ignore value', NaN);

mapTok = regexp(txt, '(?is)map\s+info\s*=\s*\{([^}]*)\}', 'tokens', 'once');
if isempty(mapTok)
    error('No ENVI map info found in header: %s', hdrPath);
end
parts = strtrim(string(strsplit(mapTok{1}, ',')));
if numel(parts) < 7
    error('Malformed ENVI map info in header: %s', hdrPath);
end

M = struct();
M.ProjectionName = char(parts(1));
M.RefPixelX = str2double(parts(2));
M.RefPixelY = str2double(parts(3));
M.MapX = str2double(parts(4));
M.MapY = str2double(parts(5));
M.PixelSizeX = abs(str2double(parts(6)));
M.PixelSizeY = abs(str2double(parts(7)));
M.IsGeographic = contains(lower(M.ProjectionName), 'geographic') || ...
                 contains(lower(M.ProjectionName), 'lat/lon');
H.mapInfo = M;
end
