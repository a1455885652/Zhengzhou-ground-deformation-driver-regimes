function x = column_to_double_giv(raw)
if isnumeric(raw)
    x = double(raw);
elseif islogical(raw)
    x = double(raw);
else
    x = str2double(string(raw));
end
x = x(:);
end
