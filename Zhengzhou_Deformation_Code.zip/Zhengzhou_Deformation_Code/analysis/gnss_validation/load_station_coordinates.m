function C = load_station_coordinates(coordTxt, excludeStations)
%LOAD_STATION_COORDINATES Read Chinese station-name + DMS coordinates.

lines = readlines(coordTxt, 'EmptyLineRule', 'skip');
name = strings(0,1);
lon = zeros(0,1);
lat = zeros(0,1);

pat = '^(.*?)\s+(\d+)°(\d+)[′''](\d+(?:\.\d+)?)[″"]\s+(\d+)°(\d+)[′''](\d+(?:\.\d+)?)[″"]\s*$';

for i = 1:numel(lines)
    s = strtrim(lines(i));
    tok = regexp(char(s), pat, 'tokens', 'once');
    if isempty(tok)
        warning('Coordinate line could not be parsed: %s', s);
        continue;
    end

    stationName = string(strtrim(tok{1}));
    if any(strcmp(stationName, string(excludeStations)))
        continue;
    end

    lonDD = str2double(tok{2}) + str2double(tok{3})/60 + str2double(tok{4})/3600;
    latDD = str2double(tok{5}) + str2double(tok{6})/60 + str2double(tok{7})/3600;

    name(end+1,1) = stationName; %#ok<AGROW>
    lon(end+1,1) = lonDD; %#ok<AGROW>
    lat(end+1,1) = latDD; %#ok<AGROW>
end

C = table(name, lon, lat, 'VariableNames', {'Station','Longitude','Latitude'});
end
