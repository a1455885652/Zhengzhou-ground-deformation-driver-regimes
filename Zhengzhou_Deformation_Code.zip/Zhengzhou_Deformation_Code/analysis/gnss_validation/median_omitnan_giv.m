function y = median_omitnan_giv(x)
y = median(x, 'omitnan');
end
