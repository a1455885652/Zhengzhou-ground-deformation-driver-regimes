function [valsClean, keepMask, nRejected] = reject_spatial_outliers_giv(vals, cfg)
%REJECT_SPATIAL_OUTLIERS_GIV Robust MAD rejection for local InSAR pixels.

vals = vals(:);
finiteMask = isfinite(vals);
keepMask = finiteMask;
nRejected = 0;

if ~cfg.insar.spatialOutlier.enabled || sum(finiteMask) < cfg.insar.spatialOutlier.minPoints
    valsClean = vals(finiteMask);
    return;
end

v = vals(finiteMask);
medv = median(v);
madv = median(abs(v-medv));
robustSigma = 1.4826 * madv;

if ~isfinite(robustSigma) || robustSigma <= eps(max(abs(v))+1)
    valsClean = v;
    return;
end

badFinite = abs(v-medv) > cfg.insar.spatialOutlier.nSigma * robustSigma;
idxFinite = find(finiteMask);
keepMask(idxFinite(badFinite)) = false;
nRejected = sum(badFinite);
valsClean = vals(keepMask);
end
