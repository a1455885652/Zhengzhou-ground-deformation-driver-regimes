# GNSS 对照

按共同时间基准匹配 GNSS 与 InSAR，并保留各自独立的质量控制。

| 项目 | 内容 |
|---|---|
| 输入 | project_root/GNSS 中的原始站点记录及 external_paths.gnss_insar_raster 指定的影像目录。 |
| 输出 | `project_root/GNSS_InSAR_Validation_Output_v3` |
| 设置 | config_gnss_insar_validation.m |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('gnss_validation')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。

本入口不根据 GNSS 拟合或校准 InSAR 曲线。`legacy/Fig03_GNSS_v4` 是另一个较早的展示原型，不由本入口调用。原始 GNSS 和位移栅格未附带，无法据此确认整幅论文图 3 的最终拼版。
