function stations = build_gnss_station_database(cfg)
%BUILD_GNSS_STATION_DATABASE Build the seven local GNSS stations.
% ZHNZ is optional in the code but disabled in the current v2 configuration.

C = load_station_coordinates(cfg.gnss.coordTxt, cfg.gnss.excludeStations);

files = dir(fullfile(cfg.gnss.rootDir, '*.xlsx'));
parts = struct('Name', {}, 'SourceType', {}, 'FilePath', {}, 'Time', {}, ...
    'VerticalMM', {}, 'XMM', {}, 'YMM', {});

for i = 1:numel(files)
    fp = fullfile(files(i).folder, files(i).name);
    try
        p = read_local_gnss_xlsx(fp, cfg);
        parts(end+1) = p; %#ok<AGROW>
    catch ME
        warning('Skipped %s: %s', files(i).name, ME.message);
    end
end

stations = struct('Name', {}, 'SourceType', {}, 'FilePath', {}, ...
    'Longitude', {}, 'Latitude', {}, 'Time', {}, 'VerticalMM', {}, ...
    'XMM', {}, 'YMM', {}, 'NBeforeOutlierQC', {}, 'NOutliersRemoved', {}, ...
    'OutlierLog', {});

for i = 1:height(C)
    stationName = char(C.Station(i));
    idx = find(strcmp({parts.Name}, stationName));
    if isempty(idx)
        warning('No local GNSS Excel found for station: %s', stationName);
        continue;
    end

    t = NaT(0,1); v = zeros(0,1); x = zeros(0,1); y = zeros(0,1);
    fileList = strings(0,1);
    for j = idx
        t = [t; parts(j).Time]; %#ok<AGROW>
        v = [v; parts(j).VerticalMM]; %#ok<AGROW>
        x = [x; parts(j).XMM]; %#ok<AGROW>
        y = [y; parts(j).YMM]; %#ok<AGROW>
        fileList(end+1,1) = string(parts(j).FilePath); %#ok<AGROW>
    end
    [t, v, x, y] = aggregate_duplicate_gnss_times(t, v, x, y);

    nBefore = numel(v);
    [t, v, x, y, outLog] = remove_gnss_gross_errors(t, v, x, y, cfg);

    s = struct();
    s.Name = stationName;
    s.SourceType = 'LOCAL_XLSX';
    s.FilePath = char(strjoin(fileList, '; '));
    s.Longitude = C.Longitude(i);
    s.Latitude = C.Latitude(i);
    s.Time = t;
    s.VerticalMM = v;
    s.XMM = x;
    s.YMM = y;
    s.NBeforeOutlierQC = nBefore;
    s.NOutliersRemoved = height(outLog);
    s.OutlierLog = outLog;
    stations(end+1) = s; %#ok<AGROW>
end

if cfg.gnss.useZHNZ
    if exist(cfg.gnss.zhnzTxt, 'file')
        z = read_zhnz_gnss_txt(cfg.gnss.zhnzTxt, cfg);
        nBefore = numel(z.VerticalMM);
        [tt,vv,xx,yy,outLog] = remove_gnss_gross_errors(z.Time,z.VerticalMM,z.XMM,z.YMM,cfg);
        s = struct();
        s.Name = z.Name;
        s.SourceType = z.SourceType;
        s.FilePath = z.FilePath;
        s.Longitude = cfg.gnss.zhnz.lon;
        s.Latitude = cfg.gnss.zhnz.lat;
        s.Time = tt;
        s.VerticalMM = vv;
        s.XMM = xx;
        s.YMM = yy;
        s.NBeforeOutlierQC = nBefore;
        s.NOutliersRemoved = height(outLog);
        s.OutlierLog = outLog;
        stations(end+1) = s; %#ok<AGROW>
    else
        warning('ZHNZ file not found: %s', cfg.gnss.zhnzTxt);
    end
end

for i = 1:numel(stations)
    fprintf('      %-20s  %9.5f E  %8.5f N  %6d records  removed=%d\n', ...
        stations(i).Name, stations(i).Longitude, stations(i).Latitude, ...
        numel(stations(i).Time), stations(i).NOutliersRemoved);
end
end
