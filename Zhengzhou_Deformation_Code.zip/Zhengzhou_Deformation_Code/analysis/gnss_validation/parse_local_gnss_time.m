function t = parse_local_gnss_time(raw)
%PARSE_LOCAL_GNSS_TIME Parse values such as "2026-06-24 06".

if isdatetime(raw)
    t = raw;
    return;
end

s = string(raw);
s = strip(s);
t = NaT(size(s));

formats = {'yyyy-MM-dd HH', 'yyyy-MM-dd HH:mm', 'yyyy-MM-dd HH:mm:ss', ...
           'yyyy/MM/dd HH', 'yyyy/MM/dd HH:mm', 'yyyy/MM/dd HH:mm:ss'};

remaining = s ~= "" & ~ismissing(s);
for k = 1:numel(formats)
    if ~any(remaining)
        break;
    end
    idx = find(remaining);
    try
        tmp = datetime(s(idx), 'InputFormat', formats{k});
        good = ~isnat(tmp);
        t(idx(good)) = tmp(good);
        remaining(idx(good)) = false;
    catch
        % Try next format.
    end
end

% Last-resort automatic parser.
if any(remaining)
    idx = find(remaining);
    for k = 1:numel(idx)
        try
            t(idx(k)) = datetime(s(idx(k)));
        catch
        end
    end
end
end
