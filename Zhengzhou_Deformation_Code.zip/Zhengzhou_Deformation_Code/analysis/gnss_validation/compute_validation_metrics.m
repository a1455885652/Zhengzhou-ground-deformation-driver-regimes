function M = compute_validation_metrics(gnss, insar)
mask = isfinite(gnss) & isfinite(insar);
g = gnss(mask);
i = insar(mask);

M = struct('N',numel(g),'PearsonR',NaN,'R2Regression',NaN,'R2OneToOne',NaN, ...
    'RMSE',NaN,'MAE',NaN,'BiasInSARMinusGNSS',NaN,'Slope',NaN,'Intercept',NaN);
if numel(g) < 2
    return;
end

C = corrcoef(g,i);
if size(C,1) >= 2
    M.PearsonR = C(1,2);
end

p = polyfit(g,i,1);
pred = polyval(p,g);
ssResReg = sum((i-pred).^2);
ssTot = sum((i-mean(i)).^2);
if ssTot > 0
    M.R2Regression = 1 - ssResReg/ssTot;
end

ssRes1 = sum((i-g).^2);
ssTotG = sum((g-mean(g)).^2);
if ssTotG > 0
    M.R2OneToOne = 1 - ssRes1/ssTotG;
end

r = i-g;
M.RMSE = sqrt(mean(r.^2));
M.MAE = mean(abs(r));
M.BiasInSARMinusGNSS = mean(r);
M.Slope = p(1);
M.Intercept = p(2);
end
