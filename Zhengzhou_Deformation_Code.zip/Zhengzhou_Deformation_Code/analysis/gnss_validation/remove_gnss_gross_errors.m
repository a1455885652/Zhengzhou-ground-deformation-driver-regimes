function [timeOut, vOut, xOut, yOut, logTable] = remove_gnss_gross_errors(timeIn, vIn, xIn, yIn, cfg)
%REMOVE_GNSS_GROSS_ERRORS Conservative moving-median/MAD gross-error removal.
% Detection uses GNSS vertical displacement only and is independent of InSAR.

n = numel(vIn);
flag = false(n,1);
localMedian = NaN(n,1);
localSigma = NaN(n,1);

if cfg.gnss.outlier.enabled && n >= cfg.gnss.outlier.minLocalCount
    h = cfg.gnss.outlier.windowHalfWidthSamples;
    localMedian = movmedian(vIn, [h h], 'omitnan');
    absDev = abs(vIn - localMedian);
    localMAD = movmedian(absDev, [h h], 'omitnan');
    localSigma = 1.4826 .* localMAD;
    localSigma = max(localSigma, cfg.gnss.outlier.minLocalSigmaMM);

    localCount = movsum(double(isfinite(vIn)), [h h]);
    flag = isfinite(vIn) & isfinite(localMedian) & ...
        localCount >= cfg.gnss.outlier.minLocalCount & ...
        absDev > cfg.gnss.outlier.nSigma .* localSigma;
end

logTable = table(timeIn(flag), vIn(flag), localMedian(flag), localSigma(flag), ...
    abs(vIn(flag)-localMedian(flag)), ...
    'VariableNames', {'DateTime','VerticalRaw_mm','LocalMedian_mm', ...
    'LocalRobustSigma_mm','AbsoluteDeviation_mm'});

keep = ~flag & ~isnat(timeIn) & isfinite(vIn);
timeOut = timeIn(keep);
vOut = vIn(keep);
xOut = xIn(keep);
yOut = yIn(keep);
end
