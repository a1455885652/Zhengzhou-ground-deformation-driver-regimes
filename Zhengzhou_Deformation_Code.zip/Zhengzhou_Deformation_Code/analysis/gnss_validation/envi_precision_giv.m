function p = envi_precision_giv(dataType)
switch dataType
    case 1,  p = 'uint8';
    case 2,  p = 'int16';
    case 3,  p = 'int32';
    case 4,  p = 'single';
    case 5,  p = 'double';
    case 12, p = 'uint16';
    case 13, p = 'uint32';
    case 14, p = 'int64';
    case 15, p = 'uint64';
    otherwise
        error('Unsupported ENVI data type: %d', dataType);
end
end
