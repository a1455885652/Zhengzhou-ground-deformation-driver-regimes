function cfg = config_gnss_insar_validation()
%CONFIG_GNSS_INSAR_VALIDATION Configuration for GNSS-InSAR validation v3.
%
% v3 main choices:
% 1) Final InSAR station extraction uses 3x3 only.
% 2) Missing pixels around a station are still filled inside a station-centred
%    5x5 target block by local IDW before the 3x3 statistic is calculated.
% 3) ZHNZ is excluded. 大马站 remains excluded.
% 4) GNSS and InSAR gross errors are rejected independently.
% 5) Paper time-series figures show ALL cleaned GNSS samples and ALL cleaned
%    InSAR epochs within their overlap period; plotting does not require the
%    two sensors to share identical dates.
% 6) InSAR is NOT fitted to GNSS. Only sign, common reference epoch and
%    independent QC are applied, preserving independent validation.
%
% Paper sign convention:
%   positive = subsidence/downward
%   negative = uplift/upward

cfg = struct();

%% Paths
cfg.gnss.rootDir  = zz_project_path('GNSS');
cfg.gnss.coordTxt = fullfile(cfg.gnss.rootDir, '坐标.txt');
cfg.gnss.zhnzTxt  = fullfile(cfg.gnss.rootDir, 'ZHNZ.txt');

cfg.insar.candidateDirs = {zz_external_path('gnss_insar_raster')};

cfg.outputDir = zz_project_path('GNSS_InSAR_Validation_Output_v3');

%% Study period and SAR acquisition time
cfg.study.startTime = datetime(2018,6,1,0,0,0);
cfg.study.endTime   = datetime(2025,12,31,23,59,59);
cfg.insar.acquisitionTime = hours(10) + minutes(30);

%% Local GNSS Excel structure
cfg.gnss.local.stationNameColumn = 3;
cfg.gnss.local.timeColumn        = 5;
cfg.gnss.local.xColumn           = 6;
cfg.gnss.local.yColumn           = 7;
cfg.gnss.local.verticalColumn    = 8;

% Verified sign: use the local GNSS vertical sign directly.
cfg.gnss.localVerticalToPaperSign = +1;

% Two stations not used in final validation.
cfg.gnss.excludeStations = {'大马站'};
cfg.gnss.useZHNZ = false;

%% GNSS gross-error rejection
% Independent from InSAR. No InSAR-GNSS residual is used for deleting data.
cfg.gnss.outlier.enabled = true;
cfg.gnss.outlier.windowHalfWidthSamples = 6; % 13-sample local window
cfg.gnss.outlier.nSigma = 5.0;
cfg.gnss.outlier.minLocalSigmaMM = 1.0;
cfg.gnss.outlier.minLocalCount = 5;

%% GNSS temporal matching -- only for quantitative metrics
cfg.match.localMaxBracketHours = 6;
cfg.match.localNearestFallbackHours = 2;

%% InSAR discovery
cfg.insar.includeRegex = '(?i)disp';
cfg.insar.excludeRegex = '(?i)(velocity|monthly|monthend|increment|1km)';
cfg.insar.dateRegex = '(20\d{6})';
cfg.insar.recursive = true;

%% InSAR units/sign
cfg.insar.scaleToMM = 1.0;   % set to 1000 only when source raster unit is metre
cfg.insar.signToPaper = 1.0;

%% Spatial extraction -- final choice: 3x3 only
cfg.insar.windowSizes = 3;
cfg.insar.primaryStatistic = 'mean';
cfg.insar.minValidFraction = 0.50;
cfg.insar.invalidAbsThreshold = 1e6;

%% Local missing-pixel interpolation
% The target 5x5 block is repaired in memory only; source rasters are unchanged.
cfg.insar.interp.enabled = true;
cfg.insar.interp.targetWindowSize = 5;
cfg.insar.interp.searchHalfSizesPixels = [3 5 8 12 18 25 35 50];
cfg.insar.interp.minSourcePoints = 8;
cfg.insar.interp.kNearest = 12;
cfg.insar.interp.idwPower = 2.0;

%% Spatial gross-error rejection within each InSAR window
cfg.insar.spatialOutlier.enabled = true;
cfg.insar.spatialOutlier.nSigma = 6.0;
cfg.insar.spatialOutlier.minPoints = 7;

%% InSAR temporal gross-error rejection for time-series plotting
% Independent from GNSS. Very conservative to avoid deleting real deformation.
cfg.insar.temporalOutlier.enabled = true;
cfg.insar.temporalOutlier.windowHalfWidthEpochs = 3; % 7 SAR epochs
cfg.insar.temporalOutlier.nSigma = 6.0;
cfg.insar.temporalOutlier.minLocalSigmaMM = 2.0;
cfg.insar.temporalOutlier.minLocalCount = 5;

%% Comparison metrics
cfg.compare.requireSameEpochsAcrossWindows = true;
cfg.compare.minCommonEpochs = 6;
cfg.compare.rejectByPairResidual = false;

%% Full-series figure/reference settings
% Plot every cleaned GNSS observation and every cleaned InSAR acquisition in
% the temporal overlap. No date matching is required for the lines themselves.
cfg.fullSeries.referenceGNSSMaxBracketHours = 24;
cfg.fullSeries.referenceGNSSNearestHours = 24;
cfg.fullSeries.plotOnlyTemporalOverlap = true;

% IMPORTANT: do not fit scale/trend of InSAR to GNSS in a validation figure.
% Only a common datum/reference epoch is used.
cfg.fullSeries.allowGNSSDrivenInSARFitting = false;

%% Plotting
cfg.plot.fontName = 'Times New Roman';
cfg.plot.fontSize = 12;
cfg.plot.lineWidthInSAR = 1.8;
cfg.plot.lineWidthGNSS = 1.15;
cfg.plot.markerSize = 4.2;
cfg.plot.dpi = 600;
cfg.plot.annotateMatchedMetrics = true;
cfg.plot.insarColor = [0.86 0.12 0.10];
cfg.plot.gnssColor = [0.08 0.08 0.08];

end
