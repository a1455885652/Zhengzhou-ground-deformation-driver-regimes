function E = extract_insar_at_stations(insarFiles, stations, cfg)
%EXTRACT_INSAR_AT_STATIONS Read each raster once and extract all stations.
% v2: fill NaNs inside each station-centred 5x5 block by adaptive IDW.

nT = height(insarFiles);
nS = numel(stations);
wins = cfg.insar.windowSizes(:).';
nW = numel(wins);

Mean = NaN(nT,nS,nW);
Median = NaN(nT,nS,nW);
Std = NaN(nT,nS,nW);
ValidFraction = zeros(nT,nS,nW);
RawValidFraction = zeros(nT,nS,nW);
NValid = zeros(nT,nS,nW);
NSpatialOutliersRemoved = zeros(nT,nS,nW);
CenterRow = NaN(nT,nS);
CenterCol = NaN(nT,nS);

RawNValid5x5 = zeros(nT,nS);
FilledNValid5x5 = zeros(nT,nS);
NInterpolated5x5 = zeros(nT,nS);
InterpAttempted = false(nT,nS);
InterpSucceeded = false(nT,nS);
InterpSearchHalfSizePixels = NaN(nT,nS);
InterpNSource = zeros(nT,nS);
InterpNSourceRejected = zeros(nT,nS);
InterpMaxNearestSourceDistancePixels = NaN(nT,nS);

for it = 1:nT
    fp = char(insarFiles.FilePath(it));
    fprintf('      [%3d/%3d] %s\n', it, nT, char(insarFiles.DateToken(it)));
    RAS = read_insar_raster(fp, cfg);

    for is = 1:nS
        [r, c, inside] = station_to_raster_index(RAS, ...
            stations(is).Longitude, stations(is).Latitude);
        if ~inside
            continue;
        end
        CenterRow(it,is) = r;
        CenterCol(it,is) = c;

        [block5, D] = interpolate_station_5x5_idw(RAS.Data, r, c, cfg);
        rr5 = D.TargetRows;
        cc5 = D.TargetCols;

        RawNValid5x5(it,is) = D.RawNValid;
        FilledNValid5x5(it,is) = D.FilledNValid;
        NInterpolated5x5(it,is) = D.NInterpolated;
        InterpAttempted(it,is) = D.InterpolationAttempted;
        InterpSucceeded(it,is) = D.InterpolationSucceeded;
        InterpSearchHalfSizePixels(it,is) = D.SearchHalfSizePixels;
        InterpNSource(it,is) = D.NSource;
        InterpNSourceRejected(it,is) = D.NSourceRejected;
        InterpMaxNearestSourceDistancePixels(it,is) = D.MaxNearestSourceDistancePixels;

        for iw = 1:nW
            w = wins(iw);
            h = floor(w/2);
            rr = max(1,r-h):min(size(RAS.Data,1),r+h);
            cc = max(1,c-h):min(size(RAS.Data,2),c+h);

            % Raw window, before interpolation.
            rawBlock = RAS.Data(rr,cc);
            rawValid = isfinite(rawBlock);
            RawValidFraction(it,is,iw) = sum(rawValid(:)) / (w*w);

            % Extract the same coordinates from the interpolated 5x5 target.
            [okR, locR] = ismember(rr, rr5);
            [okC, locC] = ismember(cc, cc5);
            if ~all(okR) || ~all(okC)
                % This should only occur at raster edges; fall back to raw block.
                block = rawBlock;
            else
                block = block5(locR,locC);
            end

            valsAll = block(:);
            [vals, ~, nRej] = reject_spatial_outliers_giv(valsAll, cfg);
            NSpatialOutliersRemoved(it,is,iw) = nRej;

            frac = numel(vals) / (w*w);
            ValidFraction(it,is,iw) = frac;
            NValid(it,is,iw) = numel(vals);

            if frac < cfg.insar.minValidFraction || isempty(vals)
                continue;
            end

            Mean(it,is,iw) = mean(vals);
            Median(it,is,iw) = median(vals);
            if numel(vals) >= 2
                Std(it,is,iw) = std(vals,0);
            else
                Std(it,is,iw) = 0;
            end
        end
    end
end

% Convert source units/sign once here.
Mean = Mean * cfg.insar.scaleToMM * cfg.insar.signToPaper;
Median = Median * cfg.insar.scaleToMM * cfg.insar.signToPaper;
Std = Std * abs(cfg.insar.scaleToMM);

E = struct();
E.DateTime = insarFiles.DateTime;
E.DateToken = insarFiles.DateToken;
E.FilePath = insarFiles.FilePath;
E.WindowSizes = wins;
E.Mean = Mean;
E.Median = Median;
E.Std = Std;
E.ValidFraction = ValidFraction;
E.RawValidFraction = RawValidFraction;
E.NValid = NValid;
E.NSpatialOutliersRemoved = NSpatialOutliersRemoved;
E.CenterRow = CenterRow;
E.CenterCol = CenterCol;
E.RawNValid5x5 = RawNValid5x5;
E.FilledNValid5x5 = FilledNValid5x5;
E.NInterpolated5x5 = NInterpolated5x5;
E.InterpAttempted = InterpAttempted;
E.InterpSucceeded = InterpSucceeded;
E.InterpSearchHalfSizePixels = InterpSearchHalfSizePixels;
E.InterpNSource = InterpNSource;
E.InterpNSourceRejected = InterpNSourceRejected;
E.InterpMaxNearestSourceDistancePixels = InterpMaxNearestSourceDistancePixels;
end
