function v = get_optional_num_field_giv(txt, key, defaultValue)
pat = ['(?im)^\s*', regexptranslate('escape', key), '\s*=\s*([-+0-9.eE]+)'];
tok = regexp(txt, pat, 'tokens', 'once');
if isempty(tok)
    v = defaultValue;
else
    v = str2double(tok{1});
end
end
