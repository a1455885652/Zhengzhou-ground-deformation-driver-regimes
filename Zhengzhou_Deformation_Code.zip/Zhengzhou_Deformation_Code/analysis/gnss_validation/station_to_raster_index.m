function [row, col, inside] = station_to_raster_index(RAS, lon, lat)
%STATION_TO_RASTER_INDEX Convert WGS84 station coordinate to raster index.

nRows = size(RAS.Data,1);
nCols = size(RAS.Data,2);
row = NaN; col = NaN; inside = false;

if strcmp(RAS.Type, 'GEOTIFF')
    R = RAS.Reference;
    className = class(R);

    if contains(className, 'Geographic')
        [xIntrinsic, yIntrinsic] = geographicToIntrinsic(R, lat, lon);
    else
        crs = [];
        try
            crs = RAS.Info.ProjectedCRS;
        catch
        end
        if isempty(crs)
            error('Projected GeoTIFF has no ProjectedCRS metadata.');
        end
        [xWorld, yWorld] = projfwd(crs, lat, lon);
        [xIntrinsic, yIntrinsic] = worldToIntrinsic(R, xWorld, yWorld);
    end

    col = round(xIntrinsic);
    row = round(yIntrinsic);
else
    M = RAS.MapInfo;
    if ~M.IsGeographic
        error(['Custom ENVI reader currently expects Geographic Lat/Lon map info. ', ...
               'Convert this raster to GeoTIFF or use geographic SARscape output.']);
    end
    col = round(M.RefPixelX + (lon - M.MapX) / M.PixelSizeX);
    row = round(M.RefPixelY + (M.MapY - lat) / M.PixelSizeY);
end

inside = row >= 1 && row <= nRows && col >= 1 && col <= nCols;
end
