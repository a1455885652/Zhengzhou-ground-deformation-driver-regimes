clear; clc;

projectDir = fileparts(mfilename('fullpath'));
addpath(projectDir);

cfg = config_gnss_insar_validation();
ensure_folder_giv(cfg.outputDir);

fprintf('============================================================\n');
fprintf(' GNSS-InSAR vertical deformation validation v3\n');
fprintf(' final 3x3 + full-series plotting + independent gross-error QC\n');
fprintf('============================================================\n');

fprintf('[1/8] Loading and QC-filtering the 7 local GNSS stations...\n');
stations = build_gnss_station_database(cfg);
fprintf('      Loaded %d GNSS stations. ZHNZ used = %d\n',numel(stations),cfg.gnss.useZHNZ);

fprintf('[2/8] Discovering InSAR displacement rasters...\n');
insarFiles = discover_insar_displacement_files(cfg);
fprintf('      Found %d InSAR acquisition epochs.\n',height(insarFiles));
writetable(insarFiles,fullfile(cfg.outputDir,'InSAR_Discovery_Log.csv'));

fprintf('[3/8] Extracting final 3x3 InSAR windows with local spatial interpolation...\n');
E = extract_insar_at_stations(insarFiles,stations,cfg);
save(fullfile(cfg.outputDir,'InSAR_Window_Extraction.mat'),'E','stations','cfg','-v7.3');

fprintf('[4/8] Computing quantitative metrics on matched SAR epochs...\n');
[results,metricsByStation,metricsOverall] = build_validation_results(E,stations,cfg);

fprintf('[5/8] Building full cleaned time series without forcing common dates...\n');
fullSeries = build_full_timeseries_results(E,stations,cfg);

fprintf('[6/8] Writing tables and QC/interpolation logs...\n');
write_validation_outputs(results,metricsByStation,metricsOverall,stations,E,cfg);
write_full_series_outputs(fullSeries,cfg);

fprintf('[7/8] Drawing paper-style full time-series figure...\n');
plot_full_station_timeseries_3x3(fullSeries,metricsByStation,cfg);

fprintf('[8/8] Drawing pooled 3x3 validation scatter...\n');
plot_pooled_scatter(results,metricsOverall,3,cfg);

save(fullfile(cfg.outputDir,'GNSS_InSAR_Validation_Workspace.mat'), ...
    'results','fullSeries','metricsByStation','metricsOverall', ...
    'stations','insarFiles','E','cfg','-v7.3');

fprintf('\nFinished.\n');
fprintf('Output: %s\n',cfg.outputDir);
fprintf('Main figure: Fig_Full_TimeSeries_3x3_PaperStyle.png\n');
fprintf('Check: Full_TimeSeries_3x3_Summary.csv and Metrics_By_Station.csv\n');
