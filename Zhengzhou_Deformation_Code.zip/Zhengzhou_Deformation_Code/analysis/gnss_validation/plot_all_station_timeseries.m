function plot_all_station_timeseries(results, metricsByStation, windowSize, cfg)
%PLOT_ALL_STATION_TIMESERIES 4x2 panel for eight stations.

fig = figure('Color','w','Position',[60 40 1500 1050]);
tl = tiledlayout(4,2,'TileSpacing','compact','Padding','compact');

for s = 1:numel(results)
    ax = nexttile(tl);
    TT = results(s).Table;
    if isempty(TT)
        axis(ax,'off');
        text(ax,0.5,0.5,[results(s).Station,' - no common epochs'], ...
            'HorizontalAlignment','center');
        continue;
    end

    vName = sprintf('InSAR_%dx%d_mm',windowSize,windowSize);
    if ~ismember(vName, TT.Properties.VariableNames)
        axis(ax,'off');
        continue;
    end

    plot(ax, TT.DateTime, TT.(vName), '-', 'LineWidth', cfg.plot.lineWidth, ...
        'Color', [0.82 0.15 0.12]);
    hold(ax,'on');
    plot(ax, TT.DateTime, TT.GNSS_mm, '--o', 'LineWidth', 1.1, ...
        'MarkerSize', 3.2, 'Color', [0.10 0.10 0.10], ...
        'MarkerFaceColor', 'w');
    yline(ax,0,':','Color',[0.65 0.65 0.65]);

    m = metricsByStation(strcmp(metricsByStation.Station,results(s).Station) & ...
        metricsByStation.WindowSize==windowSize,:);
    if ~isempty(m)
        txt = sprintf('R = %.3f   RMSE = %.2f mm', m.PearsonR(1), m.RMSE_mm(1));
        text(ax,0.02,0.06,txt,'Units','normalized','FontName',cfg.plot.fontName, ...
            'FontSize',9,'VerticalAlignment','bottom');
    end

    title(ax, results(s).Station, 'FontName',cfg.plot.fontName,'FontWeight','bold');
    grid(ax,'on');
    ax.GridAlpha = 0.15;
    ax.FontName = cfg.plot.fontName;
    ax.FontSize = cfg.plot.fontSize;
    box(ax,'on');
    ylabel(ax,'Relative vertical deformation (mm)');
end

xlabel(tl,'Time','FontName',cfg.plot.fontName,'FontSize',13);
ylabel(tl,'Positive = subsidence; negative = uplift','FontName',cfg.plot.fontName,'FontSize',13);
title(tl,sprintf('GNSS-InSAR validation (%dx%d InSAR window)',windowSize,windowSize), ...
    'FontName',cfg.plot.fontName,'FontSize',15,'FontWeight','bold');

lg = legend({'InSAR','GNSS'},'Orientation','horizontal','Box','off');
lg.Layout.Tile = 'south';
lg.FontName = cfg.plot.fontName;

base = fullfile(cfg.outputDir, sprintf('Fig_TimeSeries_%dx%d',windowSize,windowSize));
exportgraphics(fig,[base,'.png'],'Resolution',cfg.plot.dpi);
exportgraphics(fig,[base,'.tif'],'Resolution',cfg.plot.dpi);
exportgraphics(fig,[base,'.pdf'],'ContentType','vector');
if ~zz_show_figures(), close(fig); end
end
