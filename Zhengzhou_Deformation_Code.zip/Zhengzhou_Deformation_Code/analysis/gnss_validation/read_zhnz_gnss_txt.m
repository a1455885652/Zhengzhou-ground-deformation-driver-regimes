function S = read_zhnz_gnss_txt(filePath, cfg)
%READ_ZHNZ_GNSS_TXT Read CEA ZHNZ daily NEU series.
% Columns: YYYY.DECM YYYY DOY N(m) E(m) U(m) sig_n sig_e sig_u.

lines = readlines(filePath, 'EmptyLineRule', 'skip');
rows = zeros(numel(lines), 9);
n = 0;
for i = 1:numel(lines)
    s = strtrim(lines(i));
    if s == "" || startsWith(s, '#') || startsWith(s, '\#')
        continue;
    end
    vals = sscanf(char(s), '%f');
    if numel(vals) < 9
        continue;
    end
    n = n + 1;
    rows(n,:) = vals(1:9).';
end
rows = rows(1:n,:);

if isempty(rows)
    error('No numeric ZHNZ data parsed from %s', filePath);
end

yearNum = rows(:,2);
doy = rows(:,3);
time = datetime(yearNum,1,1) + days(doy - 1);
Nmm = rows(:,4) * 1000;
Emm = rows(:,5) * 1000;
Umm = rows(:,6) * 1000;
sigUmm = rows(:,9) * 1000;

verticalMM = cfg.gnss.zhnzVerticalToPaperSign .* Umm;

mask = time >= cfg.study.startTime & time <= cfg.study.endTime & isfinite(verticalMM);
time = time(mask);
Nmm = Nmm(mask);
Emm = Emm(mask);
verticalMM = verticalMM(mask);
sigUmm = sigUmm(mask);

[time, verticalMM, Nmm, Emm] = aggregate_duplicate_gnss_times(time, verticalMM, Nmm, Emm);

S = struct();
S.Name = cfg.gnss.zhnz.name;
S.SourceType = 'ZHNZ_DAILY';
S.FilePath = filePath;
S.Time = time;
S.VerticalMM = verticalMM;
S.XMM = Nmm;
S.YMM = Emm;
end
