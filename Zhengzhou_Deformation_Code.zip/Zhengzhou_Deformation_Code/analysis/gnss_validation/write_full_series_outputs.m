function write_full_series_outputs(fullSeries, cfg)
%WRITE_FULL_SERIES_OUTPUTS Save cleaned full GNSS/InSAR series and InSAR QC logs.

outDir = fullfile(cfg.outputDir,'Full_TimeSeries_3x3');
ensure_folder_giv(outDir);
qcDir = fullfile(cfg.outputDir,'InSAR_Temporal_Gross_Error_Logs');
ensure_folder_giv(qcDir);

summaryRows = cell(numel(fullSeries),8);
for s = 1:numel(fullSeries)
    F = fullSeries(s);

    % Save as two tables in one wide CSV using separate columns. Because the
    % sensors have different timestamps, pad the shorter vector with missing.
    n = max(numel(F.GNSSTime),numel(F.InSARTime));
    gT = NaT(n,1); gV = NaN(n,1); iT = NaT(n,1); iV = NaN(n,1);
    if ~isempty(F.GNSSTime)
        gT(1:numel(F.GNSSTime)) = F.GNSSTime;
        gV(1:numel(F.GNSS_mm)) = F.GNSS_mm;
    end
    if ~isempty(F.InSARTime)
        iT(1:numel(F.InSARTime)) = F.InSARTime;
        iV(1:numel(F.InSAR_mm)) = F.InSAR_mm;
    end
    T = table(gT,gV,iT,iV,'VariableNames', ...
        {'GNSS_DateTime','GNSS_mm','InSAR_DateTime','InSAR_3x3_mm'});
    writetable(T,fullfile(outDir,[safe_filename_giv(F.Station),'_FullSeries.csv']));

    L = F.InSARTemporalOutlierLog;
    if ~isempty(L) && height(L)>0
        L.Station = repmat(string(F.Station),height(L),1);
        L = movevars(L,'Station','Before',1);
        writetable(L,fullfile(qcDir,[safe_filename_giv(F.Station), ...
            '_InSAR_Temporal_GrossErrors.csv']));
    end

    if isnat(F.ReferenceEpoch)
        refText = "";
    else
        tmpRef = F.ReferenceEpoch;
        tmpRef.Format = 'yyyy-MM-dd HH:mm';
        refText = string(tmpRef);
    end
    summaryRows(s,:) = {F.Station,F.Longitude,F.Latitude,refText, ...
        F.ReferenceMethod,numel(F.GNSSTime),numel(F.InSARTime),height(L)};
end

S = cell2table(summaryRows,'VariableNames', ...
    {'Station','Longitude','Latitude','ReferenceEpoch','ReferenceMethod', ...
    'GNSS_N_Plotted','InSAR_N_Plotted','InSAR_TemporalGrossErrorsRemoved'});
writetable(S,fullfile(cfg.outputDir,'Full_TimeSeries_3x3_Summary.csv'));
end
