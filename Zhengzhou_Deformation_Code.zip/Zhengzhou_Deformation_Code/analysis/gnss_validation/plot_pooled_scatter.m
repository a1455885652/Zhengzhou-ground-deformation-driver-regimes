function plot_pooled_scatter(results, metricsOverall, windowSize, cfg)
%PLOT_POOLED_SCATTER Pooled station-epoch GNSS vs InSAR comparison.

g = zeros(0,1); i = zeros(0,1);
for s = 1:numel(results)
    TT = results(s).Table;
    vName = sprintf('InSAR_%dx%d_mm',windowSize,windowSize);
    if isempty(TT) || ~ismember(vName,TT.Properties.VariableNames)
        continue;
    end
    gg = TT.GNSS_mm;
    ii = TT.(vName);
    m = isfinite(gg) & isfinite(ii);
    g = [g;gg(m)]; %#ok<AGROW>
    i = [i;ii(m)]; %#ok<AGROW>
end
if numel(g)<2
    return;
end

fig = figure('Color','w','Position',[100 100 650 600]);
ax = axes(fig); hold(ax,'on');
scatter(ax,g,i,22,'filled','MarkerFaceAlpha',0.55);
lims = [min([g;i]), max([g;i])];
pad = max(diff(lims)*0.05,1);
lims = lims + [-pad pad];
plot(ax,lims,lims,'k--','LineWidth',1.1);
p = polyfit(g,i,1);
xx = linspace(lims(1),lims(2),200);
plot(ax,xx,polyval(p,xx),'-','LineWidth',1.5,'Color',[0.82 0.15 0.12]);
xlim(ax,lims); ylim(ax,lims); axis(ax,'square');
grid(ax,'on'); ax.GridAlpha=0.15; box(ax,'on');
ax.FontName=cfg.plot.fontName; ax.FontSize=cfg.plot.fontSize;
xlabel(ax,'GNSS relative vertical deformation (mm)');
ylabel(ax,'InSAR relative vertical deformation (mm)');
title(ax,sprintf('Pooled validation (%dx%d window)',windowSize,windowSize),'FontWeight','bold');

m = metricsOverall(metricsOverall.WindowSize==windowSize,:);
if ~isempty(m)
    txt = sprintf('N = %d\nR = %.3f\nR^2 = %.3f\nRMSE = %.2f mm\nMAE = %.2f mm\nBias = %.2f mm', ...
        m.NPoints(1),m.PearsonR(1),m.R2_Regression(1),m.RMSE_mm(1),m.MAE_mm(1), ...
        m.Bias_InSAR_minus_GNSS_mm(1));
    text(ax,0.04,0.96,txt,'Units','normalized','VerticalAlignment','top', ...
        'FontName',cfg.plot.fontName,'FontSize',10,'BackgroundColor','w','Margin',5);
end
legend(ax,{'Matched epochs','1:1 line','Linear fit'},'Location','southeast','Box','off');

base = fullfile(cfg.outputDir,sprintf('Fig_PooledScatter_%dx%d',windowSize,windowSize));
exportgraphics(fig,[base,'.png'],'Resolution',cfg.plot.dpi);
exportgraphics(fig,[base,'.tif'],'Resolution',cfg.plot.dpi);
exportgraphics(fig,[base,'.pdf'],'ContentType','vector');
if ~zz_show_figures(), close(fig); end
end
