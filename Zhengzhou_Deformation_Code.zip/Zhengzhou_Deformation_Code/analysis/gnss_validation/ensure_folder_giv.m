function ensure_folder_giv(folderPath)
if ~exist(folderPath, 'dir')
    mkdir(folderPath);
end
end
