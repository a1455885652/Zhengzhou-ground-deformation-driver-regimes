function s = safe_filename_giv(name)
s = regexprep(char(name), '[\\/:*?"<>|]', '_');
s = strtrim(s);
end
