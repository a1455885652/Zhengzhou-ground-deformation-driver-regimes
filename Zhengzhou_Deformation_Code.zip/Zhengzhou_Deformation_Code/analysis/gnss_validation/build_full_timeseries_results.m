function fullSeries = build_full_timeseries_results(E, stations, cfg)
%BUILD_FULL_TIMESERIES_RESULTS Prepare all cleaned GNSS/InSAR points for plotting.
%
% No epoch matching is imposed on the plotted lines. Each station uses all
% cleaned observations within the temporal overlap of the two sensors.
% Both sensors are placed on a common displacement datum at the first InSAR
% epoch for which a nearby/bracketed GNSS value is available. No scale/trend
% fitting to GNSS is allowed.

if cfg.fullSeries.allowGNSSDrivenInSARFitting
    error(['GNSS-driven fitting of the InSAR time series is disabled for ', ...
        'independent validation. Use a separate calibration/holdout design ', ...
        'if calibration is scientifically required.']);
end

if numel(E.WindowSizes) ~= 1 || E.WindowSizes(1) ~= 3
    error('v3 full-series plotting expects the final 3x3 extraction only.');
end

nS = numel(stations);
fullSeries = struct('Station',{},'Longitude',{},'Latitude',{}, ...
    'ReferenceEpoch',{},'ReferenceMethod',{}, ...
    'GNSSTime',{},'GNSS_mm',{},'InSARTime',{},'InSAR_mm',{}, ...
    'InSARTemporalOutlierLog',{});

for s = 1:nS
    tG = stations(s).Time(:);
    g = stations(s).VerticalMM(:);

    if strcmpi(cfg.insar.primaryStatistic,'median')
        x = squeeze(E.Median(:,s,1));
    else
        x = squeeze(E.Mean(:,s,1));
    end
    tI = E.DateTime(:);

    % Independent InSAR temporal gross-error QC.
    [tIc,xClean,insarLog] = remove_insar_temporal_gross_errors(tI,x,cfg);

    gMask = ~isnat(tG) & isfinite(g) & ...
        tG >= cfg.study.startTime & tG <= cfg.study.endTime;
    tG = tG(gMask);
    g = g(gMask);

    iMask = ~isnat(tIc) & isfinite(xClean) & ...
        tIc >= cfg.study.startTime & tIc <= cfg.study.endTime;
    tIc = tIc(iMask);
    xClean = xClean(iMask);

    if isempty(tG) || isempty(tIc)
        fullSeries(end+1) = empty_full_series_record_giv(stations(s),insarLog); %#ok<AGROW>
        continue;
    end

    ovStart = max(min(tG),min(tIc));
    ovEnd = min(max(tG),max(tIc));
    if ovStart >= ovEnd
        fullSeries(end+1) = empty_full_series_record_giv(stations(s),insarLog); %#ok<AGROW>
        continue;
    end

    mg = tG >= ovStart & tG <= ovEnd;
    mi = tIc >= ovStart & tIc <= ovEnd;
    tGp = tG(mg); gp = g(mg);
    tIp = tIc(mi); xp = xClean(mi);

    if isempty(tGp) || isempty(tIp)
        fullSeries(end+1) = empty_full_series_record_giv(stations(s),insarLog); %#ok<AGROW>
        continue;
    end

    % Find the first InSAR epoch at which GNSS can independently define the
    % same displacement datum without long-range temporal extrapolation.
    tRef = NaT;
    xRef = NaN;
    gRef = NaN;
    refMethod = "none";
    for ir = 1:numel(tIp)
        [gCandidate,mCandidate] = interpolate_gnss_reference_value(tGp,gp,tIp(ir),cfg);
        if isfinite(gCandidate)
            tRef = tIp(ir);
            xRef = xp(ir);
            gRef = gCandidate;
            refMethod = mCandidate;
            break;
        end
    end

    if isnat(tRef)
        warning('%s: no reliable common reference epoch found.',stations(s).Name);
        fullSeries(end+1) = empty_full_series_record_giv(stations(s),insarLog); %#ok<AGROW>
        continue;
    end

    gp0 = gp - gRef;
    xp0 = xp - xRef;

    q = struct();
    q.Station = stations(s).Name;
    q.Longitude = stations(s).Longitude;
    q.Latitude = stations(s).Latitude;
    q.ReferenceEpoch = tRef;
    q.ReferenceMethod = char(refMethod);
    q.GNSSTime = tGp;
    q.GNSS_mm = gp0;
    q.InSARTime = tIp;
    q.InSAR_mm = xp0;
    q.InSARTemporalOutlierLog = insarLog;
    fullSeries(end+1) = q; %#ok<AGROW>
end
end
