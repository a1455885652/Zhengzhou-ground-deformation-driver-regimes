function [filledBlock, D] = interpolate_station_5x5_idw(data, r, c, cfg)
%INTERPOLATE_STATION_5X5_IDW Fill NaNs in station-centred 5x5 block by IDW.
% Surrounding valid pixels are searched adaptively. Existing valid target
% pixels are never altered. Interpolation occurs only in memory.

w = cfg.insar.interp.targetWindowSize;
h = floor(w/2);
nRows = size(data,1);
nCols = size(data,2);

rr = max(1,r-h):min(nRows,r+h);
cc = max(1,c-h):min(nCols,c+h);
rawBlock = data(rr,cc);
filledBlock = rawBlock;

D = struct();
D.TargetRows = rr;
D.TargetCols = cc;
D.TargetN = numel(rawBlock);
D.RawNValid = sum(isfinite(rawBlock(:)));
D.FilledNValid = D.RawNValid;
D.NInterpolated = 0;
D.InterpolationAttempted = any(~isfinite(rawBlock(:)));
D.InterpolationSucceeded = ~D.InterpolationAttempted;
D.SearchHalfSizePixels = 0;
D.NSource = 0;
D.NSourceRejected = 0;
D.MaxNearestSourceDistancePixels = NaN;

if ~cfg.insar.interp.enabled || ~D.InterpolationAttempted
    return;
end

srcR = [];
srcC = [];
srcV = [];
chosenH = NaN;
sourceRejected = 0;

for hs = cfg.insar.interp.searchHalfSizesPixels(:).'
    rrs = max(1,r-hs):min(nRows,r+hs);
    ccs = max(1,c-hs):min(nCols,c+hs);
    B = data(rrs,ccs);
    [BR, BC] = ndgrid(rrs,ccs);
    m = isfinite(B);
    if ~any(m(:))
        continue;
    end

    candV = B(m);
    candR = BR(m);
    candC = BC(m);

    [~, keepLocal, nRej] = reject_spatial_outliers_giv(candV, cfg);
    candV = candV(keepLocal);
    candR = candR(keepLocal);
    candC = candC(keepLocal);

    if numel(candV) >= cfg.insar.interp.minSourcePoints
        srcR = candR;
        srcC = candC;
        srcV = candV;
        chosenH = hs;
        sourceRejected = nRej;
        break;
    end
end

if isempty(srcV)
    D.InterpolationSucceeded = false;
    return;
end

D.SearchHalfSizePixels = chosenH;
D.NSource = numel(srcV);
D.NSourceRejected = sourceRejected;

[TR, TC] = ndgrid(rr,cc);
missing = ~isfinite(filledBlock);
missIdx = find(missing);
nearestD = NaN(numel(missIdx),1);

for q = 1:numel(missIdx)
    rt = TR(missIdx(q));
    ct = TC(missIdx(q));
    d = hypot(double(srcR)-double(rt), double(srcC)-double(ct));

    % A missing target cell cannot itself be a valid source, but guard zero.
    positive = d > 0 & isfinite(d) & isfinite(srcV);
    d = d(positive);
    vv = srcV(positive);
    if isempty(d)
        continue;
    end

    [d, ord] = sort(d, 'ascend');
    vv = vv(ord);
    k = min(cfg.insar.interp.kNearest, numel(d));
    d = d(1:k);
    vv = vv(1:k);

    nearestD(q) = d(1);
    weights = 1 ./ (d .^ cfg.insar.interp.idwPower);
    filledBlock(missIdx(q)) = sum(weights .* vv) / sum(weights);
end

D.FilledNValid = sum(isfinite(filledBlock(:)));
D.NInterpolated = D.FilledNValid - D.RawNValid;
D.InterpolationSucceeded = D.FilledNValid == D.TargetN;
if any(isfinite(nearestD))
    D.MaxNearestSourceDistancePixels = max(nearestD,[],'omitnan');
end
end
