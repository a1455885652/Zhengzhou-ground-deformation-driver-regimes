function [results, metricsByStation, metricsOverall] = build_validation_results(E, stations, cfg)
%BUILD_VALIDATION_RESULTS Re-reference and compute 3x3/5x5 validation.

nS = numel(stations);
wins = E.WindowSizes;
nW = numel(wins);
results = struct('Station', {}, 'Longitude', {}, 'Latitude', {}, 'Table', {});
metricRows = cell(0,12);

for is = 1:nS
    [g, matchMethod] = match_gnss_to_sar(stations(is), E.DateTime, cfg);

    if strcmpi(cfg.insar.primaryStatistic, 'median')
        ins = squeeze(E.Median(:,is,:));
    else
        ins = squeeze(E.Mean(:,is,:));
    end
    if nW == 1
        ins = ins(:);
    end

    % Fair window comparison: same epochs for all windows.
    if cfg.compare.requireSameEpochsAcrossWindows
        common = isfinite(g);
        for iw = 1:nW
            common = common & isfinite(ins(:,iw));
        end
    else
        common = isfinite(g);
    end

    if sum(common) < cfg.compare.minCommonEpochs
        warning('%s has only %d common epochs.', stations(is).Name, sum(common));
    end

    tUse = E.DateTime(common);
    gUse = g(common);
    methodUse = matchMethod(common);

    if isempty(tUse)
        Tout = table();
        results(end+1) = struct('Station', stations(is).Name, ...
            'Longitude', stations(is).Longitude, 'Latitude', stations(is).Latitude, ...
            'Table', Tout); %#ok<AGROW>
        continue;
    end

    % Re-reference GNSS and all windows to the identical first common epoch.
    g0 = gUse - gUse(1);

    Tout = table(tUse, repmat(string(stations(is).Name),numel(tUse),1), ...
        repmat(stations(is).Longitude,numel(tUse),1), ...
        repmat(stations(is).Latitude,numel(tUse),1), ...
        g0, methodUse, ...
        'VariableNames', {'DateTime','Station','Longitude','Latitude','GNSS_mm','GNSS_MatchMethod'});

    for iw = 1:nW
        w = wins(iw);
        x = ins(common,iw);
        vf = squeeze(E.ValidFraction(common,is,iw));
        rvf = squeeze(E.RawValidFraction(common,is,iw));
        nv = squeeze(E.NValid(common,is,iw));
        ss = squeeze(E.Std(common,is,iw));
        nso = squeeze(E.NSpatialOutliersRemoved(common,is,iw));

        x0 = x - x(1);
        residual = x0 - g0;

        Tout.(sprintf('InSAR_%dx%d_mm',w,w)) = x0;
        Tout.(sprintf('Residual_%dx%d_mm',w,w)) = residual;
        Tout.(sprintf('RawValidFraction_%dx%d',w,w)) = rvf;
        Tout.(sprintf('ValidFraction_%dx%d',w,w)) = vf;
        Tout.(sprintf('NValid_%dx%d',w,w)) = nv;
        Tout.(sprintf('WindowStd_%dx%d_mm',w,w)) = ss;
        Tout.(sprintf('SpatialOutliersRemoved_%dx%d',w,w)) = nso;

        M = compute_validation_metrics(g0, x0);
        metricRows(end+1,:) = {stations(is).Name, w, M.N, M.PearsonR, ...
            M.R2Regression, M.R2OneToOne, M.RMSE, M.MAE, M.BiasInSARMinusGNSS, ...
            M.Slope, M.Intercept, char(tUse(1))}; %#ok<AGROW>
    end

    % Interpolation diagnostics shared by 3x3/5x5 because both come from
    % the same station-centred 5x5 target block.
    Tout.RawNValid_5x5 = E.RawNValid5x5(common,is);
    Tout.FilledNValid_5x5 = E.FilledNValid5x5(common,is);
    Tout.NInterpolated_5x5 = E.NInterpolated5x5(common,is);
    Tout.InterpSearchHalfSizePixels = E.InterpSearchHalfSizePixels(common,is);
    Tout.InterpNSource = E.InterpNSource(common,is);
    Tout.InterpMaxNearestSourceDistancePixels = E.InterpMaxNearestSourceDistancePixels(common,is);

    results(end+1) = struct('Station', stations(is).Name, ...
        'Longitude', stations(is).Longitude, 'Latitude', stations(is).Latitude, ...
        'Table', Tout); %#ok<AGROW>
end

metricsByStation = cell2table(metricRows, 'VariableNames', ...
    {'Station','WindowSize','N','PearsonR','R2_Regression','R2_OneToOne', ...
     'RMSE_mm','MAE_mm','Bias_InSAR_minus_GNSS_mm','RegressionSlope', ...
     'RegressionIntercept_mm','ReferenceEpoch'});

metricsOverall = compute_overall_metrics_giv(results, wins);
end
