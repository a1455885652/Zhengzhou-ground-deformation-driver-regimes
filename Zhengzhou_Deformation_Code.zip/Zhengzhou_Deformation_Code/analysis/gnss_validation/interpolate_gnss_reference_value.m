function [vRef, method] = interpolate_gnss_reference_value(t, v, tRef, cfg)
%INTERPOLATE_GNSS_REFERENCE_VALUE Estimate GNSS value at one InSAR reference epoch.
% Used only to put both displacement series on a common datum.

vRef = NaN;
method = "none";
if isempty(t) || isempty(v)
    return;
end

t = t(:); v = v(:);
mask = ~isnat(t) & isfinite(v);
t = t(mask); v = v(mask);
if isempty(t)
    return;
end

ib = find(t <= tRef,1,'last');
ia = find(t >= tRef,1,'first');
maxBracketSec = cfg.fullSeries.referenceGNSSMaxBracketHours * 3600;

if ~isempty(ib) && ~isempty(ia)
    if ib == ia
        vRef = v(ib);
        method = "exact";
        return;
    end
    d1 = seconds(tRef-t(ib));
    d2 = seconds(t(ia)-tRef);
    if d1 <= maxBracketSec && d2 <= maxBracketSec
        xx = [seconds(t(ib)-tRef), seconds(t(ia)-tRef)];
        yy = [v(ib), v(ia)];
        vRef = interp1(xx,yy,0,'linear');
        method = "linear-bracket";
        return;
    end
end

[dmin,idx] = min(abs(seconds(t-tRef)));
if ~isempty(idx) && dmin <= cfg.fullSeries.referenceGNSSNearestHours*3600
    vRef = v(idx);
    method = "nearest";
end
end
