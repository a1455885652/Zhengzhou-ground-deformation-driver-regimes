function write_validation_outputs(results, metricsByStation, metricsOverall, stations, E, cfg)
writetable(metricsByStation, fullfile(cfg.outputDir, 'Metrics_By_Station.csv'));
writetable(metricsOverall, fullfile(cfg.outputDir, 'Metrics_Overall.csv'));

outTs = fullfile(cfg.outputDir, 'Matched_TimeSeries');
ensure_folder_giv(outTs);
for s = 1:numel(results)
    if isempty(results(s).Table)
        continue;
    end
    fn = [safe_filename_giv(results(s).Station), '_Matched_TimeSeries.csv'];
    writetable(results(s).Table, fullfile(outTs, fn));
end

%% Station metadata + GNSS QC summary
name = string({stations.Name}).';
lon = [stations.Longitude].';
lat = [stations.Latitude].';
nBefore = [stations.NBeforeOutlierQC].';
nRemoved = [stations.NOutliersRemoved].';
nAfter = arrayfun(@(s) numel(s.Time), stations).';
Tmeta = table(name, lon, lat, nBefore, nRemoved, nAfter, ...
    'VariableNames', {'Station','Longitude','Latitude','GNSS_N_BeforeQC', ...
    'GNSS_GrossErrorsRemoved','GNSS_N_AfterQC'});
writetable(Tmeta, fullfile(cfg.outputDir, 'Station_Metadata_and_GNSS_QC.csv'));

outQC = fullfile(cfg.outputDir, 'GNSS_Gross_Error_Logs');
ensure_folder_giv(outQC);
for s = 1:numel(stations)
    if isempty(stations(s).OutlierLog) || height(stations(s).OutlierLog)==0
        continue;
    end
    L = stations(s).OutlierLog;
    L.Station = repmat(string(stations(s).Name),height(L),1);
    L = movevars(L,'Station','Before',1);
    fn = [safe_filename_giv(stations(s).Name), '_GNSS_GrossErrors.csv'];
    writetable(L,fullfile(outQC,fn));
end

%% InSAR interpolation epoch log and station summary
nT = numel(E.DateTime);
nS = numel(stations);
rows = cell(nT*nS,11);
k = 0;
for s = 1:nS
    for it = 1:nT
        k = k + 1;
        rows(k,:) = {stations(s).Name, E.DateTime(it), E.RawNValid5x5(it,s), ...
            E.FilledNValid5x5(it,s), E.NInterpolated5x5(it,s), ...
            E.InterpAttempted(it,s), E.InterpSucceeded(it,s), ...
            E.InterpSearchHalfSizePixels(it,s), E.InterpNSource(it,s), ...
            E.InterpNSourceRejected(it,s), E.InterpMaxNearestSourceDistancePixels(it,s)};
    end
end
Tlog = cell2table(rows(1:k,:), 'VariableNames', ...
    {'Station','DateTime','RawNValid5x5','FilledNValid5x5','NInterpolated5x5', ...
    'InterpolationAttempted','InterpolationSucceeded','SearchHalfSizePixels', ...
    'NSource','NSourceRejected','MaxNearestSourceDistancePixels'});
writetable(Tlog, fullfile(cfg.outputDir, 'InSAR_Interpolation_Epoch_Log.csv'));

sumRows = cell(nS,10);
for s = 1:nS
    inside = isfinite(E.CenterRow(:,s));
    rawZero = inside & E.RawNValid5x5(:,s)==0;
    attempted = inside & E.InterpAttempted(:,s);
    recovered = rawZero & E.FilledNValid5x5(:,s)>0;
    full25 = inside & E.FilledNValid5x5(:,s)>=25;
    sh = E.InterpSearchHalfSizePixels(:,s);
    src = E.InterpNSource(:,s);
    ni = E.NInterpolated5x5(:,s);
    nd = E.InterpMaxNearestSourceDistancePixels(:,s);
    sumRows(s,:) = {stations(s).Name, sum(inside), sum(rawZero), sum(attempted), ...
        sum(recovered), sum(full25), median(ni(inside),'omitnan'), ...
        max(sh,[],'omitnan'), median(src(inside),'omitnan'), median(nd(inside),'omitnan')};
end
Tsum = cell2table(sumRows, 'VariableNames', ...
    {'Station','EpochsInsideRaster','EpochsRaw5x5ZeroValid','EpochsInterpolationAttempted', ...
    'EpochsRecoveredFromZero','EpochsFull5x5AfterInterpolation','MedianInterpolatedPixels', ...
    'MaxSearchHalfSizePixels','MedianSourceCount','MedianNearestSourceDistancePixels'});
writetable(Tsum, fullfile(cfg.outputDir, 'InSAR_Interpolation_Summary.csv'));
end
