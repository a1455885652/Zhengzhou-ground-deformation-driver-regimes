function plot_full_station_timeseries_3x3(fullSeries, metricsByStation, cfg)
%PLOT_FULL_STATION_TIMESERIES_3X3 Paper-style 7-station full time-series plot.
% All cleaned GNSS samples and all cleaned InSAR epochs are plotted.
% Matched-date metrics, when annotated, are calculated separately and do not
% determine which points are displayed.

nS = numel(fullSeries);
fig = figure('Color','w','Position',[40 30 1500 1180]);
tl = tiledlayout(4,2,'TileSpacing','compact','Padding','compact');
letters = 'abcdefghijklmnopqrstuvwxyz';

for s = 1:nS
    ax = nexttile(tl);
    F = fullSeries(s);

    if isempty(F.GNSSTime) || isempty(F.InSARTime)
        axis(ax,'off');
        text(ax,0.5,0.5,sprintf('(%c) %s\nNo temporal overlap',letters(s),F.Station), ...
            'HorizontalAlignment','center','FontName',cfg.plot.fontName, ...
            'FontSize',cfg.plot.fontSize);
        continue;
    end

    % GNSS first so the InSAR line remains visually clear on top.
    pG = plot(ax,F.GNSSTime,F.GNSS_mm,'--', ...
        'Color',cfg.plot.gnssColor,'LineWidth',cfg.plot.lineWidthGNSS);
    hold(ax,'on');
    pI = plot(ax,F.InSARTime,F.InSAR_mm,'-o', ...
        'Color',cfg.plot.insarColor,'LineWidth',cfg.plot.lineWidthInSAR, ...
        'MarkerSize',cfg.plot.markerSize,'MarkerFaceColor','w');
    yline(ax,0,':','Color',[0.70 0.70 0.70],'LineWidth',0.8);

    title(ax,sprintf('(%c) %s',letters(s),F.Station), ...
        'FontName',cfg.plot.fontName,'FontSize',cfg.plot.fontSize+1, ...
        'FontWeight','bold','Interpreter','none');
    ylabel(ax,'Relative vertical deformation (mm)', ...
        'FontName',cfg.plot.fontName);
    grid(ax,'on');
    ax.GridAlpha = 0.13;
    ax.FontName = cfg.plot.fontName;
    ax.FontSize = cfg.plot.fontSize;
    ax.LineWidth = 1.0;
    box(ax,'on');

    if cfg.plot.annotateMatchedMetrics
        m = metricsByStation(strcmp(metricsByStation.Station,F.Station) & ...
            metricsByStation.WindowSize==3,:);
        if ~isempty(m) && isfinite(m.PearsonR(1))
            txt = sprintf('R = %.2f\nRMSE = %.1f mm\nN = %d', ...
                m.PearsonR(1),m.RMSE_mm(1),m.N(1));
            text(ax,0.03,0.08,txt,'Units','normalized', ...
                'FontName',cfg.plot.fontName,'FontSize',cfg.plot.fontSize-1, ...
                'VerticalAlignment','bottom','BackgroundColor','w', ...
                'Margin',2);
        end
    end

    if s == 1
        legend(ax,[pI pG],{'InSAR (3×3)','GNSS'}, ...
            'Location','best','Box','off','FontName',cfg.plot.fontName, ...
            'FontSize',cfg.plot.fontSize-1);
    end
end

% Eighth tile is intentionally used as a clean explanatory panel.
if nS < 8
    ax = nexttile(tl);
    axis(ax,'off');
    text(ax,0.05,0.75,'Time-series comparison', ...
        'FontName',cfg.plot.fontName,'FontSize',cfg.plot.fontSize+2, ...
        'FontWeight','bold');
    text(ax,0.05,0.58,{'All cleaned observations are shown.', ...
        'Lines are referenced to a common datum.', ...
        'R and RMSE use matched SAR epochs only.'}, ...
        'FontName',cfg.plot.fontName,'FontSize',cfg.plot.fontSize, ...
        'VerticalAlignment','top');
end

xlabel(tl,'Time','FontName',cfg.plot.fontName,'FontSize',14);
title(tl,'GNSS–InSAR vertical deformation time series (3×3 InSAR window)', ...
    'FontName',cfg.plot.fontName,'FontSize',16,'FontWeight','bold');

base = fullfile(cfg.outputDir,'Fig_Full_TimeSeries_3x3_PaperStyle');
exportgraphics(fig,[base,'.png'],'Resolution',cfg.plot.dpi);
exportgraphics(fig,[base,'.tif'],'Resolution',cfg.plot.dpi);
exportgraphics(fig,[base,'.pdf'],'ContentType','vector');
if ~zz_show_figures(), close(fig); end
end
