function [tOut, vOut, xOut, yOut] = aggregate_duplicate_gnss_times(t, v, x, y)
%AGGREGATE_DUPLICATE_GNSS_TIMES Median-aggregate duplicate timestamps.

[t, order] = sort(t);
v = v(order);
x = x(order);
y = y(order);

[G, tOut] = findgroups(t);
vOut = splitapply(@median_omitnan_giv, v, G);
xOut = splitapply(@median_omitnan_giv, x, G);
yOut = splitapply(@median_omitnan_giv, y, G);

vOut = vOut(:);
xOut = xOut(:);
yOut = yOut(:);
tOut = tOut(:);
end
