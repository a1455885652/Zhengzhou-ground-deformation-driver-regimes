function q = empty_full_series_record_giv(station, insarLog)
%EMPTY_FULL_SERIES_RECORD_GIV Create an empty full-series result record.
q = struct();
q.Station = station.Name;
q.Longitude = station.Longitude;
q.Latitude = station.Latitude;
q.ReferenceEpoch = NaT;
q.ReferenceMethod = 'none';
q.GNSSTime = NaT(0,1);
q.GNSS_mm = zeros(0,1);
q.InSARTime = NaT(0,1);
q.InSAR_mm = zeros(0,1);
q.InSARTemporalOutlierLog = insarLog;
end
