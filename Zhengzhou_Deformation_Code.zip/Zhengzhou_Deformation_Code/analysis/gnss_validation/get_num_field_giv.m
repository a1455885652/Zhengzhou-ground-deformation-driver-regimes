function v = get_num_field_giv(txt, key)
pat = ['(?im)^\s*', regexptranslate('escape', key), '\s*=\s*([-+0-9.eE]+)'];
tok = regexp(txt, pat, 'tokens', 'once');
if isempty(tok)
    error('Required ENVI field not found: %s', key);
end
v = str2double(tok{1});
end
