function M = extract_locked_block_metrics(XZ,YZ,mask,cfg)
nB=size(XZ,2);
M=struct('coherence',nan(nB,1),'phaseConcentration',nan(nB,1),'phase',nan(nB,1),'lag',nan(nB,1),'valid',false(nB,1));
for b=1:nB
    W=wavelet_core_preprocessed(XZ(:,b),YZ(:,b),cfg);
    idx=find(mask & W.validMask);
    if isempty(idx), continue; end
    coh=W.wcoh(idx); phi=W.phase(idx); [rr,~]=ind2sub(size(W.wcoh),idx); per=W.period(rr);
    use=isfinite(coh)&isfinite(phi)&coh>=cfg.block.minimumCoherence;
    if sum(use)<3, continue; end
    coh=coh(use); phi=phi(use); per=per(use);
    phiAdj=phi; neg=cos(phi)<0; phiAdj(neg)=wrap_to_pi_custom(phi(neg)-pi);
    w=max(coh,eps); z=sum(w.*exp(1i*phiAdj))/sum(w);
    lag=phiAdj./(2*pi).*per;
    M.coherence(b)=mean(coh,'omitnan'); M.phaseConcentration(b)=abs(z); M.phase(b)=angle(z);
    M.lag(b)=sum(w.*lag)/sum(w); M.valid(b)=true;
end
end
