function T = summarize_discovery_clusters(G,threshold,nullMax,months,cfg)
[masses,comps]=cluster_masses_group_map(G.stat,threshold,G.validMask,cfg);
vars={'ClusterID','ClusterMass','ClusterP_FWER','StartMonth','EndMonth','PeriodMinMonths','PeriodMaxMonths', ...
    'SupportFraction','MeanCoherence','PhaseConcentration','DriverLeadFraction','MedianLagMonths','NCells'};
T=table('Size',[0 numel(vars)],'VariableTypes',{'double','double','double','datetime','datetime','double','double','double','double','double','double','double','double'},'VariableNames',vars);
for k=1:numel(comps)
    idx=comps{k}; [rr,cc]=ind2sub(size(G.stat),idx);
    p=(1+sum(nullMax>=masses(k)))/(numel(nullMax)+1);
    row=table(k,masses(k),p,min(months(cc)),max(months(cc)),min(G.period(rr)),max(G.period(rr)), ...
        median(G.supportFraction(idx),'omitnan'),median(G.meanCoherence(idx),'omitnan'),median(G.phaseConcentration(idx),'omitnan'), ...
        median(G.driverLeadFraction(idx),'omitnan'),median(G.medianLagMonths(idx),'omitnan'),numel(idx),'VariableNames',vars);
    T=[T;row]; %#ok<AGROW>
end
end
