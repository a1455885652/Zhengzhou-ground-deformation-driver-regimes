function B2 = subset_blocks(B,idx)
B2=struct();
B2.blockID=B.blockID(idx);
B2.pixelLists=B.pixelLists(idx);
B2.nPixels=B.nPixels(idx);
B2.blockRow=B.blockRow(idx);
B2.blockCol=B.blockCol(idx);
end
