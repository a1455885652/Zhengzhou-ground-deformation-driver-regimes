function sel = select_mechanism_confident_pixels(cache,cfg,mechanism)
K4=cache.K4;
sel=find(double(K4.MechanismCluster)==mechanism & double(K4.MaxPosterior)>=cfg.minimumPosterior);
if isempty(sel), error('No M%d pixels pass MaxPosterior >= %.2f.',mechanism,cfg.minimumPosterior); end
if isfield(cache,'coverCum')
    good=double(cache.coverCum(sel))>=cfg.minimumTemporalCoverage;
    if isfield(cache,'coverDriver')
        for j=1:size(cache.coverDriver,2)
            good=good & double(cache.coverDriver(sel,j))>=cfg.minimumTemporalCoverage;
        end
    end
    sel=sel(good);
end
if numel(sel)<100, error('Only %d M%d pixels remain after support audit.',numel(sel),mechanism); end
end
