function q = bh_fdr(p)
p=double(p(:)); q=nan(size(p)); good=isfinite(p); idx=find(good); pg=p(good); m=numel(pg);
if m==0, return; end
[ps,ord]=sort(pg); adj=ps.*m./(1:m)';
for i=m-1:-1:1, adj(i)=min(adj(i),adj(i+1)); end
adj=min(adj,1); tmp=nan(m,1); tmp(ord)=adj; q(idx)=tmp;
end
