function T = finalize_mechanism_results(Rs,cfg,mechanism,family)
n=numel(Rs); p=ones(n,1); for i=1:n, p(i)=Rs{i}.ValidationP; end
family=string(family);
if family=="Core", adjusted=holm_adjust(p); else, adjusted=bh_fdr(p); end
vars={'Mechanism','Driver','Family','DiscoveryClusterP','DiscoveryStartMonth','DiscoveryEndMonth','DiscoveryPeriodMinMonths','DiscoveryPeriodMaxMonths', ...
    'DiscoveryLagMonths','ValidationLeadP','WithinMechanismAdjustedP','GlobalCoreHolmP','ValidationNBlocks','ValidationNSupport','ValidationSupportFraction', ...
    'ValidationPhaseConcentration','ValidationLeadFraction','ValidationMedianLagMonths','LagCI95_Low','LagCI95_High','LagCI90_Low','LagCI90_High', ...
    'DiscoveryValidationLagDifference','ClaimClass'};
types={'double','string','string','double','datetime','datetime','double','double','double','double','double','double','double','double','double','double','double','double','double','double','double','double','double','string'};
T=table('Size',[0 numel(vars)],'VariableTypes',types,'VariableNames',vars);
for i=1:n
    R=Rs{i};
    if isempty(R.LockedRow) || isempty(R.ValidationGroup)
        row=table(mechanism,string(R.Driver),family,NaN,NaT,NaT,NaN,NaN,NaN,R.ValidationP,adjusted(i),NaN,0,0,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,"NoDiscoveryCluster",'VariableNames',vars);
        T=[T;row]; continue;
    end
    dLag=double(R.LockedRow.MedianLagMonths); g=R.ValidationGroup; ci=R.LagCI; diff=abs(dLag-ci.Median);
    if family=="Core"
        confirm = adjusted(i)<=cfg.validation.confirm.adjustedAlpha && g.SupportFraction>=cfg.validation.confirm.minimumSupportFraction && ...
            g.PhaseConcentration>=cfg.validation.confirm.minimumPhaseConcentration && g.DriverLeadFraction>=cfg.validation.confirm.minimumLeadFraction && ...
            g.NSupport>=cfg.validation.confirm.minimumSupportingBlocks && ci.Low95>0 && diff<=cfg.validation.confirm.maximumDiscoveryValidationLagDifference;
        support = adjusted(i)<=cfg.validation.support.adjustedAlpha && g.SupportFraction>=cfg.validation.support.minimumSupportFraction && ...
            g.PhaseConcentration>=cfg.validation.support.minimumPhaseConcentration && g.DriverLeadFraction>=cfg.validation.support.minimumLeadFraction && ...
            g.NSupport>=cfg.validation.support.minimumSupportingBlocks && ci.Low90>0 && diff<=cfg.validation.support.maximumDiscoveryValidationLagDifference;
        if confirm
            claim="ConfirmedSpatialHoldoutLag";
        elseif support
            claim="SupportedRelaxedSpatialHoldoutLag";
        elseif ci.Low90>0 && g.DriverLeadFraction>=cfg.validation.support.minimumLeadFraction
            claim="DirectionalReplication_NotAdjustedSignificant";
        else
            claim="NotReplicated";
        end
    else
        explore = adjusted(i)<=cfg.validation.exploratoryFDRAlpha && g.SupportFraction>=cfg.validation.exploratory.minimumSupportFraction && ...
            g.PhaseConcentration>=cfg.validation.exploratory.minimumPhaseConcentration && g.DriverLeadFraction>=cfg.validation.exploratory.minimumLeadFraction && ...
            g.NSupport>=cfg.validation.exploratory.minimumSupportingBlocks && ci.Low90>0 && diff<=cfg.validation.exploratory.maximumDiscoveryValidationLagDifference;
        if explore
            claim="ExploratorySupportedLag";
        elseif ci.Low90>0 && g.DriverLeadFraction>=cfg.validation.exploratory.minimumLeadFraction
            claim="ExploratoryDirectionalCandidate";
        else
            claim="ExploratoryNotReplicated";
        end
    end
    row=table(mechanism,string(R.Driver),family,double(R.LockedRow.ClusterP_FWER),R.LockedRow.StartMonth,R.LockedRow.EndMonth, ...
        double(R.LockedRow.PeriodMinMonths),double(R.LockedRow.PeriodMaxMonths),dLag,R.ValidationP,adjusted(i),NaN,g.NBlocks,g.NSupport,g.SupportFraction, ...
        g.PhaseConcentration,g.DriverLeadFraction,ci.Median,ci.Low95,ci.High95,ci.Low90,ci.High90,diff,claim,'VariableNames',vars);
    T=[T;row];
end
end
