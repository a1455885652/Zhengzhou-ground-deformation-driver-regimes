function S = split_blocks_supergrid_ratio(B,cfg,mechanism)
f=cfg.superBlockFactor;
sr=floor((B.blockRow-1)/f)+1;
sc=floor((B.blockCol-1)/f)+1;
modulo=cfg.split.modulo;
discClasses=cfg.split.discoveryClasses(:)';
best=[]; bestScore=Inf;
% Geometry-only offset selection. No driver or deformation values are used.
for off=0:(modulo-1)
    cls=mod(2*sr+3*sc+cfg.split.baseOffset+mechanism+off,modulo);
    disc=find(ismember(cls,discClasses)); val=find(~ismember(cls,discClasses));
    if numel(disc)<cfg.minimumDiscoveryBlocks || numel(val)<cfg.minimumValidationBlocks, continue; end
    frac=numel(disc)/numel(B.blockID);
    score=abs(frac-cfg.split.targetDiscoveryFraction);
    if score<bestScore
        bestScore=score; best=struct('disc',disc(:),'val',val(:),'cls',cls(:),'offset',off,'frac',frac);
    end
end
if isempty(best)
    error('Could not create a valid geometry-only M%d split. Eligible blocks=%d.',mechanism,numel(B.blockID));
end
% Ensure no ~10-km superblock is split.
key=sr*100000+sc;
for k=unique(key)'
    ii=find(key==k);
    if any(ismember(ii,best.disc)) && any(ismember(ii,best.val))
        error('Internal split error: one superblock was assigned to both sets.');
    end
end
S=struct('discoveryIndex',best.disc,'validationIndex',best.val,'superRow',sr(:),'superCol',sc(:), ...
    'splitClass',best.cls,'chosenOffset',best.offset,'discoveryFraction',best.frac, ...
    'discoveryBlockID',B.blockID(best.disc),'validationBlockID',B.blockID(best.val));
end
