function R = run_one_mechanism_driver_holdout(cache,rate,Bdisc,Bval,cfg,mechanism,driverName,family)
name=string(driverName); family=string(family); j=find_driver_index_cache(cache,name);
checkpoint=fullfile(cfg.output.checkpoints,sprintf('M%d_%s_%s_Holdout.mat',mechanism,name,family));
if cfg.output.resume && isfile(checkpoint)
    S=load(checkpoint,'R'); R=S.R; fprintf('  Resume M%d %s [%s]\n',mechanism,name,family); return;
end
fprintf('\n=== M%d %s [%s] ===\n',mechanism,name,family);
D=build_block_wavelet_matrices_holdout(cache,rate,Bdisc,cfg,j);
V=build_block_wavelet_matrices_holdout(cache,rate,Bval,cfg,j);
fprintf('  Discovery blocks=%d; Validation blocks=%d\n',size(D.XZ,2),size(V.XZ,2));
seedBase=cfg.randomSeed+mechanism*100000+j*5000+(family=="Exploratory")*2000000;
G=compute_group_lead_map(D.XZ,D.YZ,cfg);
th=estimate_discovery_scale_thresholds(D.XZ,D.YZ,cfg,seedBase+1000);
nullMax=estimate_discovery_null_maxmass(D.XZ,D.YZ,th,cfg,seedBase+2000);
T=summarize_discovery_clusters(G,th,nullMax,D.months,cfg);
writetable(T,fullfile(cfg.output.tables,sprintf('M%d_%s_%s_DiscoveryClusters.csv',mechanism,name,family)));
[mask,locked]=choose_locked_cluster(G,T,th,cfg);
if isempty(locked)
    R=struct('Mechanism',mechanism,'Driver',name,'Family',family,'DiscoveryTable',T,'LockedRow',locked,'LockedMask',mask, ...
        'DiscoveryMatrices',D,'ValidationMatrices',V,'ValidationMetric',[],'ValidationGroup',[],'ValidationP',1, ...
        'NullValidation',[],'LagCI',[],'Status',"NoDiscoveryCluster");
    save(checkpoint,'R','-v7.3'); return;
end
fprintf('  Locked discovery cluster p=%.4f, lag=%.3f months, %s to %s, %.2f-%.2f months\n', ...
    locked.ClusterP_FWER,locked.MedianLagMonths,string(locked.StartMonth),string(locked.EndMonth),locked.PeriodMinMonths,locked.PeriodMaxMonths);
M=extract_locked_block_metrics(V.XZ,V.YZ,mask,cfg); GV=aggregate_locked_group_metric(M,cfg);
[p,nullStat]=validation_surrogate_p(V.XZ,V.YZ,mask,GV.LeadStatistic,cfg,seedBase+3000);
CI=bootstrap_validation_lag(M,cfg,seedBase+4000);
Tb=table(V.blockIDs(:),V.blockRow(:),V.blockCol(:),V.nPixels(:),M.valid(:),M.coherence(:),M.phaseConcentration(:),M.phase(:),M.lag(:), ...
    'VariableNames',{'BlockID','BlockRow','BlockCol','Npixels','Valid','MeanCoherence','PhaseConcentration','AdjustedPhaseRad','LagMonths'});
writetable(Tb,fullfile(cfg.output.tables,sprintf('M%d_%s_%s_ValidationBlocks.csv',mechanism,name,family)));
R=struct('Mechanism',mechanism,'Driver',name,'Family',family,'DiscoveryTable',T,'LockedRow',locked,'LockedMask',mask,'DiscoveryGroupMap',G, ...
    'DiscoveryMatrices',D,'ValidationMatrices',V,'ValidationMetric',M,'ValidationGroup',GV,'ValidationP',p, ...
    'NullValidation',nullStat,'LagCI',CI,'Status',"Validated");
save(checkpoint,'R','-v7.3');
if cfg.output.makeFigures
    plot_discovery_locked_cluster(G,mask,D.months,mechanism,name,fullfile(cfg.output.figures,sprintf('M%d_%s_%s_DiscoveryLockedCluster.png',mechanism,name,family)));
    plot_validation_block_lags(M,V,mechanism,name,fullfile(cfg.output.figures,sprintf('M%d_%s_%s_ValidationBlockLag.png',mechanism,name,family)));
end
save_locked_cluster_cells(mask,G,D.months,fullfile(cfg.output.tables,sprintf('M%d_%s_%s_LockedClusterCells.csv',mechanism,name,family)));
end
