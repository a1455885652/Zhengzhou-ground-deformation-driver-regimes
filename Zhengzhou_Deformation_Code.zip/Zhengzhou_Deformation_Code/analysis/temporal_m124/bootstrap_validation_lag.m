function CI = bootstrap_validation_lag(M,cfg,seed)
valid=M.valid & isfinite(M.coherence) & isfinite(M.phaseConcentration) & isfinite(M.lag);
support=valid & M.coherence>=cfg.block.minimumCoherence & M.phaseConcentration>=cfg.block.minimumPhaseConcentration;
lag=M.lag(support); if isempty(lag), CI=struct('Median',NaN,'Low95',NaN,'High95',NaN,'Low90',NaN,'High90',NaN); return; end
n=numel(lag); nR=cfg.validation.bootstrapReplicates; rng(seed,'twister'); vals=nan(nR,1);
for r=1:nR, ii=randi(n,n,1); vals(r)=median(lag(ii),'omitnan'); end
CI=struct('Median',median(lag,'omitnan'),'Low95',percentile_simple(vals,2.5),'High95',percentile_simple(vals,97.5), ...
    'Low90',percentile_simple(vals,5),'High90',percentile_simple(vals,95));
end
