function [p,nullStat] = validation_surrogate_p(XZ,YZ,mask,obsStat,cfg,seed)
nR=cfg.validation.surrogates; nullStat=zeros(nR,1); rng(seed,'twister');
usePar=cfg.useParallelIfAvailable && license('test','Distrib_Computing_Toolbox');
if usePar
    parfor r=1:nR
        rng(seed+r,'twister');
        Xs=synchronized_miaaft_surrogate(XZ,cfg.surrogate.miaaftMaxIterations,cfg.surrogate.miaaftRelativeTolerance);
        M=extract_locked_block_metrics(Xs,YZ,mask,cfg); G=aggregate_locked_group_metric(M,cfg); nullStat(r)=G.LeadStatistic;
    end
else
    for r=1:nR
        if mod(r,50)==0 || r==1, fprintf('    validation surrogate %d/%d\n',r,nR); end
        rng(seed+r,'twister');
        Xs=synchronized_miaaft_surrogate(XZ,cfg.surrogate.miaaftMaxIterations,cfg.surrogate.miaaftRelativeTolerance);
        M=extract_locked_block_metrics(Xs,YZ,mask,cfg); G=aggregate_locked_group_metric(M,cfg); nullStat(r)=G.LeadStatistic;
    end
end
p=(1+sum(nullStat>=obsStat))/(nR+1);
end
