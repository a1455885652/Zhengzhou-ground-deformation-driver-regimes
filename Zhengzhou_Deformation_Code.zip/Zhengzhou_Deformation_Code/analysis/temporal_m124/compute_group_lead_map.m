function G = compute_group_lead_map(XZ,YZ,cfg)
% Group time-frequency map across spatial blocks.
% x = driver, y = deformation rate. Positive adjusted lag means driver leads.
nB=size(XZ,2);
W0=wavelet_core_preprocessed(XZ(:,1),YZ(:,1),cfg);
[nS,nT]=size(W0.wcoh);
coh=nan(nS,nT,nB); ph=nan(nS,nT,nB); valid=false(nS,nT,nB);
coh(:,:,1)=W0.wcoh; ph(:,:,1)=W0.phase; valid(:,:,1)=W0.validMask;
for b=2:nB
    W=wavelet_core_preprocessed(XZ(:,b),YZ(:,b),cfg);
    coh(:,:,b)=W.wcoh; ph(:,:,b)=W.phase; valid(:,:,b)=W.validMask;
end
stat=zeros(nS,nT); supportFrac=zeros(nS,nT); meanC=nan(nS,nT); phaseConc=nan(nS,nT); leadFrac=nan(nS,nT); lagMed=nan(nS,nT);
P=repmat(W0.period(:),1,nT);
for r=1:nS
    for t=1:nT
        vv=squeeze(valid(r,t,:)); cc=squeeze(coh(r,t,:)); pp=squeeze(ph(r,t,:));
        good=vv & isfinite(cc) & isfinite(pp);
        if sum(good)<4, continue; end
        supp=good & cc>=cfg.block.minimumCoherence;
        supportFrac(r,t)=sum(supp)/sum(good);
        if ~any(supp), continue; end
        c=cc(supp); p=pp(supp);
        pAdj=p; neg=cos(p)<0; pAdj(neg)=wrap_to_pi_custom(p(neg)-pi);
        lag=pAdj/(2*pi)*P(r,t);
        w=max(c,eps);
        z=sum(w.*exp(1i*pAdj))/sum(w);
        meanC(r,t)=mean(c,'omitnan'); phaseConc(r,t)=abs(z); leadFrac(r,t)=mean(lag>0); lagMed(r,t)=median(lag,'omitnan');
        stat(r,t)=supportFrac(r,t)*meanC(r,t)*phaseConc(r,t)*max(0,2*leadFrac(r,t)-1);
    end
end
G=struct('stat',stat,'supportFraction',supportFrac,'meanCoherence',meanC,'phaseConcentration',phaseConc, ...
    'driverLeadFraction',leadFrac,'medianLagMonths',lagMed,'period',W0.period,'validMask',W0.validMask,'Wtemplate',W0);
end
