function [masses,comps] = cluster_masses_group_map(stat,threshold,validMask,cfg)
th=repmat(threshold(:),1,size(stat,2)); supra=validMask & isfinite(stat) & stat>th;
allComps=connected_components_8(supra); masses=[]; comps={};
for k=1:numel(allComps)
    idx=allComps{k};
    if numel(idx)<cfg.discovery.minimumClusterCells, continue; end
    [~,c]=ind2sub(size(stat),idx);
    if (max(c)-min(c)+1)<cfg.discovery.minimumClusterTimeSpanMonths, continue; end
    mass=sum(stat(idx)-th(idx),'omitnan');
    if mass<=0, continue; end
    masses(end+1,1)=mass; comps{end+1,1}=idx; %#ok<AGROW>
end
end
