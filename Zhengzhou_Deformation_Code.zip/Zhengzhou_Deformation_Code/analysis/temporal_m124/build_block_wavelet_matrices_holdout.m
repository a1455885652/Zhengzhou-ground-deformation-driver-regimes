function S = build_block_wavelet_matrices_holdout(cache,rate,B,cfg,driverIndex)
T=numel(cache.months); h=cfg.response.halfWindowMonths; idx=(1+h):(T-h);
nT=numel(idx); nB=numel(B.blockID); X=nan(nT,nB); Y=nan(nT,nB);
for b=1:nB
    pix=B.pixelLists{b};
    for q=1:nT
        t=idx(q);
        xv=double(cache.driverData(t,pix,driverIndex));
        yv=double(rate.Vrate(t,pix));
        X(q,b)=median(xv(isfinite(xv)),'omitnan');
        Y(q,b)=median(yv(isfinite(yv)),'omitnan');
    end
end
keep=all(isfinite(X),1) & all(isfinite(Y),1);
X=X(:,keep); Y=Y(:,keep);
if size(X,2)<cfg.minimumBlocksPerSet
    error('Only %d complete blocks remain in this split.',size(X,2));
end
XZ=nan(size(X)); YZ=nan(size(Y));
for b=1:size(X,2)
    XZ(:,b)=preprocess_wavelet_series(X(:,b),cfg.wavelet.detrendDegree);
    YZ(:,b)=preprocess_wavelet_series(Y(:,b),cfg.wavelet.detrendDegree);
end
S=struct('XRaw',X,'YRaw',Y,'XZ',XZ,'YZ',YZ,'blockIDs',B.blockID(keep), ...
    'nPixels',B.nPixels(keep),'blockRow',B.blockRow(keep),'blockCol',B.blockCol(keep), ...
    'months',cache.months(idx),'timeIndex',idx);
end
