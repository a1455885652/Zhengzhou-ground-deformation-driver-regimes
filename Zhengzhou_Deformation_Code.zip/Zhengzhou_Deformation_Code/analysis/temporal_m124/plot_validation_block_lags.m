function plot_validation_block_lags(M,V,mechanism,driverName,file)
f=figure('Visible','off','Color','w','Position',[100 100 780 620]);
valid=M.valid & isfinite(M.lag);
scatter(V.blockCol(valid),V.blockRow(valid),70,M.lag(valid),'filled'); colorbar;
xlabel('5-km block column'); ylabel('5-km block row');
title(sprintf('M%d %s locked-window validation block lag (months)',mechanism,string(driverName)));
axis equal tight; grid on;
exportgraphics(f,file,'Resolution',200); if ~zz_show_figures(), close(f); end
end
