function threshold = estimate_discovery_scale_thresholds(XZ,YZ,cfg,seed)
nR=cfg.discovery.thresholdSurrogates;
rng(seed,'twister'); G0=compute_group_lead_map(XZ,YZ,cfg); [nS,nT]=size(G0.stat);
vals=cell(nS,1);
for r=1:nR
    if mod(r,20)==0 || r==1, fprintf('    threshold surrogate %d/%d\n',r,nR); end
    Xs=synchronized_miaaft_surrogate(XZ,cfg.surrogate.miaaftMaxIterations,cfg.surrogate.miaaftRelativeTolerance);
    G=compute_group_lead_map(Xs,YZ,cfg);
    for s=1:nS
        v=G.stat(s,G.validMask(s,:)); v=v(isfinite(v));
        vals{s}=[vals{s};v(:)]; %#ok<AGROW>
    end
end
threshold=nan(nS,1);
for s=1:nS
    threshold(s)=percentile_simple(vals{s},100*cfg.discovery.clusterFormingQuantile);
    if ~isfinite(threshold(s)), threshold(s)=Inf; end
end
end
