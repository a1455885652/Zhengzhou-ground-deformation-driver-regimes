function plot_discovery_locked_cluster(G,mask,months,mechanism,driverName,file)
f=figure('Visible','off','Color','w','Position',[100 100 1100 560]);
imagesc(months,G.period,G.stat); axis xy; colorbar; hold on;
[rr,cc]=find(mask);
if ~isempty(rr), plot(months(cc),G.period(rr),'k.','MarkerSize',8); end
set(gca,'YScale','log'); ylabel('Period (months)'); xlabel('Time');
title(sprintf('M%d %s discovery group lead statistic; locked cluster marked',mechanism,string(driverName)));
exportgraphics(f,file,'Resolution',200); if ~zz_show_figures(), close(f); end
end
