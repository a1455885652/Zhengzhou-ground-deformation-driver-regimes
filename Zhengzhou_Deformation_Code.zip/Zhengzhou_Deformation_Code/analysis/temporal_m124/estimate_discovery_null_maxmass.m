function nullMax = estimate_discovery_null_maxmass(XZ,YZ,threshold,cfg,seed)
nR=cfg.discovery.clusterNullSurrogates; nullMax=zeros(nR,1); rng(seed,'twister');
for r=1:nR
    if mod(r,25)==0 || r==1, fprintf('    cluster-null surrogate %d/%d\n',r,nR); end
    Xs=synchronized_miaaft_surrogate(XZ,cfg.surrogate.miaaftMaxIterations,cfg.surrogate.miaaftRelativeTolerance);
    G=compute_group_lead_map(Xs,YZ,cfg);
    masses=cluster_masses_group_map(G.stat,threshold,G.validMask,cfg);
    if ~isempty(masses), nullMax(r)=max(masses); end
end
end
