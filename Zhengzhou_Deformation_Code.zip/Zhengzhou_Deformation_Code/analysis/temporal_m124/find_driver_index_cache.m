function j = find_driver_index_cache(cache,name)
names=string(cache.driverNames(:));
j=find(strcmpi(names,string(name)),1);
if isempty(j), error('Driver not found in dynamic cache: %s',string(name)); end
end
