function write_mechanism_summary(T,split,cfg,mechanism,file)
fid=fopen(file,'w'); if fid<0, error('Cannot write %s',file); end; c=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'M%d hydrologic lag spatial discovery-validation summary\n',mechanism);
fprintf(fid,'Created: %s\n\n',char(datetime('now')));
fprintf(fid,'Minimum K4 posterior: %.2f\n',cfg.minimumPosterior);
fprintf(fid,'Discovery 5-km blocks: %d\n',numel(split.discoveryBlockID));
fprintf(fid,'Validation 5-km blocks: %d\n',numel(split.validationBlockID));
fprintf(fid,'Discovery fraction: %.3f; geometry-only split offset: %d\n\n',split.discoveryFraction,split.chosenOffset);
fprintf(fid,'Validation never re-selects time, period, cluster, or lag.\n');
fprintf(fid,'Core hypotheses use within-mechanism Holm adjustment.\n');
fprintf(fid,'Exploratory hypotheses use within-mechanism BH-FDR and are labelled separately.\n\n');
for i=1:height(T)
    fprintf(fid,'%s [%s]\n',T.Driver(i),T.Family(i));
    fprintf(fid,'  Discovery p = %.6f; lag = %.3f months\n',T.DiscoveryClusterP(i),T.DiscoveryLagMonths(i));
    fprintf(fid,'  Validation p = %.6f; within-mechanism adjusted p = %.6f\n',T.ValidationLeadP(i),T.WithinMechanismAdjustedP(i));
    fprintf(fid,'  Support = %.1f%%; driver-leading blocks = %.1f%%; phase concentration = %.3f\n', ...
        100*T.ValidationSupportFraction(i),100*T.ValidationLeadFraction(i),T.ValidationPhaseConcentration(i));
    fprintf(fid,'  Validation lag = %.3f months; 95%% CI [%.3f, %.3f]; 90%% CI [%.3f, %.3f]\n', ...
        T.ValidationMedianLagMonths(i),T.LagCI95_Low(i),T.LagCI95_High(i),T.LagCI90_Low(i),T.LagCI90_High(i));
    fprintf(fid,'  Claim = %s\n\n',T.ClaimClass(i));
end
fprintf(fid,'Interpretation boundary: internal spatial holdout replication; no causal or external-validation claim.\n');
end
