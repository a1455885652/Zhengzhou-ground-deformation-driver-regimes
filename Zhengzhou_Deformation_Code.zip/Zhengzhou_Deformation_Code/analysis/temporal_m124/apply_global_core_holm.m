function T = apply_global_core_holm(T)
T.GlobalCoreHolmP(:)=NaN;
idx=find(T.Family=="Core");
if isempty(idx), return; end
q=holm_adjust(T.ValidationLeadP(idx));
T.GlobalCoreHolmP(idx)=q;
end
