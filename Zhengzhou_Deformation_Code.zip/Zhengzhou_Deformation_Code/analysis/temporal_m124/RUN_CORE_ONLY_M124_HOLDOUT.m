%% RUN_CORE_ONLY_M124_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_m124_hydrologic_holdout(); cfg.runExploratory=false;
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence is required.'); end
ensure_folder(cfg.output.root); ensure_folder(cfg.output.tables); ensure_folder(cfg.output.figures); ensure_folder(cfg.output.checkpoints);
cache=load_wavelet_cache(cfg); rate=load_centered_rate_cache(cfg); Tall=table(); firstTable=true;
for mechanism=cfg.mechanisms
    sel=select_mechanism_confident_pixels(cache,cfg,mechanism); B=make_spatial_blocks_holdout(cache,sel,cfg,mechanism); S=split_blocks_supergrid_ratio(B,cfg,mechanism);
    write_split_table(B,S,fullfile(cfg.output.tables,sprintf('M%d_SpatialHoldout_Split.csv',mechanism)));
    Bdisc=subset_blocks(B,S.discoveryIndex); Bval=subset_blocks(B,S.validationIndex); [coreDrivers,~]=get_mechanism_driver_sets(cfg,mechanism);
    Rs=cell(numel(coreDrivers),1); for d=1:numel(coreDrivers), Rs{d}=run_one_mechanism_driver_holdout(cache,rate,Bdisc,Bval,cfg,mechanism,coreDrivers(d),"Core"); end
    Tm=finalize_mechanism_results(Rs,cfg,mechanism,"Core"); if firstTable, Tall=Tm; firstTable=false; else, Tall=[Tall;Tm]; end %#ok<AGROW>
    writetable(Tm,fullfile(cfg.output.root,sprintf('FINAL_M%d_CORE_HOLDOUT_INFERENCE.csv',mechanism)));
end
Tall=apply_global_core_holm(Tall); writetable(Tall,fullfile(cfg.output.root,'FINAL_M124_CORE_HOLDOUT_INFERENCE.csv'));
fprintf('\nCORE-ONLY RUN DONE.\n');
