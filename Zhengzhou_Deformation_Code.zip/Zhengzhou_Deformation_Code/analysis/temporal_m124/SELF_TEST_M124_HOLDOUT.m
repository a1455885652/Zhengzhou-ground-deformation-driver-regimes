%% SELF_TEST_M124_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_m124_hydrologic_holdout();
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence is required.'); end
fprintf('Running M1/M2/M4 spatial-holdout self tests...\n'); rng(20260907,'twister');

% 1) Geometry-only 40/60 split keeps each superblock entirely in one set.
B=struct(); B.blockID=(1:80)'; B.blockRow=repelem((1:10)',8); B.blockCol=repmat((1:8)',10,1); B.nPixels=20*ones(80,1); B.pixelLists=arrayfun(@(x)x,1:80,'UniformOutput',false)';
cfg2=cfg; cfg2.minimumDiscoveryBlocks=8; cfg2.minimumValidationBlocks=8;
for mechanism=[1 2 4]
    S=split_blocks_supergrid_ratio(B,cfg2,mechanism); key=S.superRow*1000+S.superCol;
    for k=unique(key)'
        ii=find(key==k); inD=ismember(ii,S.discoveryIndex); inV=ismember(ii,S.validationIndex);
        assert(~(any(inD)&&any(inV)),'A superblock was split across discovery/validation.');
    end
    assert(S.discoveryFraction>0.25 && S.discoveryFraction<0.55,'Discovery fraction is unreasonable.');
end

% 2) Phase convention: +1 month driver lead at 8-month period.
phi=2*pi*1/8; lag=phi/(2*pi)*8; assert(abs(lag-1)<1e-12,'Phase-to-lag convention failed.');

% 3) Synthetic block signal recovers a positive ~1-month lag.
n=84; t=(1:n)'; nB=20; X=zeros(n,nB); Y=zeros(n,nB);
for b=1:nB
    x=sin(2*pi*t/8+0.08*randn)+0.25*randn(n,1);
    y=0.30*randn(n,1); y(2:end)=1.2*x(1:end-1)+0.30*randn(n-1,1);
    X(:,b)=preprocess_wavelet_series(x,1); Y(:,b)=preprocess_wavelet_series(y,1);
end
G=compute_group_lead_map(X,Y,cfg2);
periodMask=G.period>=6 & G.period<=10; timeMask=false(1,n); timeMask(15:70)=true; mask=periodMask(:)&timeMask;
M=extract_locked_block_metrics(X,Y,mask,cfg2); A=aggregate_locked_group_metric(M,cfg2);
assert(A.DriverLeadFraction>0.55,'Synthetic driver-leading fraction too small.');
assert(A.MedianLagMonths>0.20 && A.MedianLagMonths<2.0,'Synthetic lag recovery failed.');

% 4) Multiple-testing utilities.
qH=holm_adjust([0.01;0.04]); assert(all(abs(qH-[0.02;0.04])<1e-12),'Holm adjustment failed.');
qB=bh_fdr([0.01;0.04;0.20]); assert(all(isfinite(qB)) && all(qB>=0 & qB<=1),'BH-FDR failed.');

% 5) Mechanism driver definitions are unique within each family.
for mechanism=[1 2 4]
    [c,e]=get_mechanism_driver_sets(cfg,mechanism);
    assert(numel(unique(lower(c)))==numel(c),'Duplicate core driver.');
    assert(numel(intersect(lower(c),lower(e)))==0,'Core/exploratory driver overlap.');
end
fprintf('ALL M1/M2/M4 SPATIAL-HOLDOUT SELF TESTS PASSED.\n');
