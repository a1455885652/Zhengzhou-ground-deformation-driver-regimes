function T = write_split_table(B,S,file)
setName=repmat("",numel(B.blockID),1); setName(S.discoveryIndex)="Discovery"; setName(S.validationIndex)="Validation";
T=table(B.blockID,B.blockRow,B.blockCol,B.nPixels,S.superRow,S.superCol,S.splitClass,setName, ...
    'VariableNames',{'BlockID','BlockRow','BlockCol','Npixels','SuperBlockRow','SuperBlockCol','SplitClass','Set'});
writetable(T,file);
end
