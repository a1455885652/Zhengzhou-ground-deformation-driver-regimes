function [mask,row] = choose_locked_cluster(G,T,threshold,cfg)
mask=false(size(G.stat)); row=T([],:);
if isempty(T), return; end
ok=T.ClusterP_FWER<=cfg.discovery.candidateAlpha & ...
   T.SupportFraction>=cfg.discovery.minimumSupportFraction & ...
   T.DriverLeadFraction>=cfg.discovery.minimumLeadFraction & ...
   T.PhaseConcentration>=cfg.discovery.minimumPhaseConcentration & ...
   T.MedianLagMonths>0;
C=T(ok,:); if isempty(C), return; end
C=sortrows(C,{'ClusterP_FWER','ClusterMass'},{'ascend','descend'}); row=C(1,:);
[masses,comps]=cluster_masses_group_map(G.stat,threshold,G.validMask,cfg); %#ok<ASGLU>
id=double(row.ClusterID); if id<1 || id>numel(comps), error('Locked cluster ID mismatch.'); end
mask(comps{id})=true;
end
