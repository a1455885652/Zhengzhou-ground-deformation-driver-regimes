function write_master_summary(T,cfg,file)
fid=fopen(file,'w'); if fid<0, error('Cannot write %s',file); end; c=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'M1/M2/M4 hydrologic lag spatial holdout master summary\n');
fprintf(fid,'Created: %s\n\n',char(datetime('now')));
fprintf(fid,'Support tier is intentionally more permissive than Tier A and must be reported as supportive evidence.\n');
fprintf(fid,'Core Tier A: within-mechanism Holm <= %.2f + strict spatial/phase/95%%CI criteria.\n',cfg.validation.confirm.adjustedAlpha);
fprintf(fid,'Core Tier B: within-mechanism Holm <= %.2f + relaxed spatial/phase/90%%CI criteria.\n',cfg.validation.support.adjustedAlpha);
fprintf(fid,'Exploratory: within-mechanism BH-FDR <= %.2f + relaxed criteria; never call confirmatory.\n\n',cfg.validation.exploratoryFDRAlpha);
for m=cfg.mechanisms
    fprintf(fid,'===== M%d =====\n',m);
    Q=T(T.Mechanism==m,:);
    for i=1:height(Q)
        fprintf(fid,'%s [%s]: %s; validation lag %.3f months; adjusted p %.4f; support %.1f%%; lead %.1f%%\n', ...
            Q.Driver(i),Q.Family(i),Q.ClaimClass(i),Q.ValidationMedianLagMonths(i),Q.WithinMechanismAdjustedP(i), ...
            100*Q.ValidationSupportFraction(i),100*Q.ValidationLeadFraction(i));
    end
    fprintf(fid,'\n');
end
fprintf(fid,'GlobalCoreHolmP is a stricter sensitivity column across all six core hypotheses and is not used to create a Tier-B claim.\n');
end
