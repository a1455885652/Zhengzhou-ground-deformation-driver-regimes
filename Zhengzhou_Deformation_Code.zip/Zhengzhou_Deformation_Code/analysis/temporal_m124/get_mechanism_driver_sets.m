function [coreDrivers,exploratoryDrivers] = get_mechanism_driver_sets(cfg,mechanism)
key=sprintf('M%d',mechanism);
if ~isfield(cfg.core,key), error('No core-driver definition for %s.',key); end
coreDrivers=string(cfg.core.(key));
if cfg.runExploratory && isfield(cfg.exploratory,key)
    exploratoryDrivers=string(cfg.exploratory.(key));
else
    exploratoryDrivers=strings(1,0);
end
end
