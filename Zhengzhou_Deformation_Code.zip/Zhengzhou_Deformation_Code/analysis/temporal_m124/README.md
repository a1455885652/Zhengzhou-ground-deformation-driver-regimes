# M1、M2、M4 时间分析

按原设置划分空间块并锁定发现窗口，验证水文关系及相位滞后。

| 项目 | 内容 |
|---|---|
| 输入 | K4_Wavelet_DynamicCube.mat、K4_CenteredW6_RateCube.mat、K=4 归属表。 |
| 输出 | `project_root/M124_HydrologicLag_SpatialHoldout_Output` |
| 设置 | config_m124_hydrologic_holdout.m |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('temporal_m124')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。
