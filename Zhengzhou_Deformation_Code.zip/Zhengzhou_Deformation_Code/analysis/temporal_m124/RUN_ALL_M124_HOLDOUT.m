%% RUN_ALL_M124_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
SELF_TEST_M124_HOLDOUT;
CHECK_INPUTS_M124_HOLDOUT;
RUN_M124_HYDROLOGIC_HOLDOUT;
