%% RUN_M124_HYDROLOGIC_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_m124_hydrologic_holdout();
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence is required.'); end
ensure_folder(cfg.output.root); ensure_folder(cfg.output.tables); ensure_folder(cfg.output.figures); ensure_folder(cfg.output.checkpoints);
cache=load_wavelet_cache(cfg); rate=load_centered_rate_cache(cfg);
Tall=table(); AllResults=struct(); SplitInfo=struct(); firstTable=true;
for mechanism=cfg.mechanisms
    fprintf('\n\n################ M%d ################\n',mechanism);
    sel=select_mechanism_confident_pixels(cache,cfg,mechanism);
    B=make_spatial_blocks_holdout(cache,sel,cfg,mechanism);
    S=split_blocks_supergrid_ratio(B,cfg,mechanism); SplitInfo.(sprintf('M%d',mechanism))=S;
    write_split_table(B,S,fullfile(cfg.output.tables,sprintf('M%d_SpatialHoldout_Split.csv',mechanism)));
    Bdisc=subset_blocks(B,S.discoveryIndex); Bval=subset_blocks(B,S.validationIndex);
    [coreDrivers,exploreDrivers]=get_mechanism_driver_sets(cfg,mechanism);

    RsCore=cell(numel(coreDrivers),1);
    for d=1:numel(coreDrivers)
        RsCore{d}=run_one_mechanism_driver_holdout(cache,rate,Bdisc,Bval,cfg,mechanism,coreDrivers(d),"Core");
    end
    Tcore=finalize_mechanism_results(RsCore,cfg,mechanism,"Core");
    AllResults.(sprintf('M%d_Core',mechanism))=RsCore;

    Texp=Tcore([],:); RsExp={};
    if cfg.runExploratory && ~isempty(exploreDrivers)
        RsExp=cell(numel(exploreDrivers),1);
        for d=1:numel(exploreDrivers)
            RsExp{d}=run_one_mechanism_driver_holdout(cache,rate,Bdisc,Bval,cfg,mechanism,exploreDrivers(d),"Exploratory");
        end
        Texp=finalize_mechanism_results(RsExp,cfg,mechanism,"Exploratory");
        AllResults.(sprintf('M%d_Exploratory',mechanism))=RsExp;
    end
    Tm=[Tcore;Texp];
    writetable(Tm,fullfile(cfg.output.root,sprintf('FINAL_M%d_HYDROLOGIC_HOLDOUT_INFERENCE.csv',mechanism)));
    write_mechanism_summary(Tm,S,cfg,mechanism,fullfile(cfg.output.root,sprintf('M%d_RESULT_SUMMARY.txt',mechanism)));
    if firstTable, Tall=Tm; firstTable=false; else, Tall=[Tall;Tm]; end %#ok<AGROW>
end
Tall=apply_global_core_holm(Tall);
writetable(Tall,fullfile(cfg.output.root,'FINAL_M124_HYDROLOGIC_HOLDOUT_INFERENCE.csv'));
write_master_summary(Tall,cfg,fullfile(cfg.output.root,'RESULT_SUMMARY.txt'));
save(fullfile(cfg.output.root,'M124_Hydrologic_Holdout_AllResults.mat'),'AllResults','Tall','SplitInfo','cfg','-v7.3');
fprintf('\nDONE. Master table: %s\n',fullfile(cfg.output.root,'FINAL_M124_HYDROLOGIC_HOLDOUT_INFERENCE.csv'));
