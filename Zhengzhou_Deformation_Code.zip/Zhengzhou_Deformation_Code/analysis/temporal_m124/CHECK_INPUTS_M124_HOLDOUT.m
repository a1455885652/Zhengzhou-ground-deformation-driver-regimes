%% CHECK_INPUTS_M124_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_m124_hydrologic_holdout();
cache=load_wavelet_cache(cfg); rate=load_centered_rate_cache(cfg); %#ok<NASGU>
ensure_folder(cfg.output.root); ensure_folder(cfg.output.tables); ensure_folder(cfg.output.figures); ensure_folder(cfg.output.checkpoints);
fprintf('Dynamic drivers in cache:\n'); disp(string(cache.driverNames(:))');
for mechanism=cfg.mechanisms
    sel=select_mechanism_confident_pixels(cache,cfg,mechanism);
    B=make_spatial_blocks_holdout(cache,sel,cfg,mechanism);
    S=split_blocks_supergrid_ratio(B,cfg,mechanism);
    write_split_table(B,S,fullfile(cfg.output.tables,sprintf('M%d_SpatialHoldout_Split.csv',mechanism)));
    [coreDrivers,exploreDrivers]=get_mechanism_driver_sets(cfg,mechanism);
    fprintf('\nM%d: pixels=%d, eligible 5-km blocks=%d, Discovery=%d, Validation=%d, discovery fraction=%.3f\n', ...
        mechanism,numel(sel),numel(B.blockID),numel(S.discoveryIndex),numel(S.validationIndex),S.discoveryFraction);
    fprintf('  Core: %s\n',strjoin(coreDrivers,', '));
    fprintf('  Exploratory: %s\n',strjoin(exploreDrivers,', '));
end
fprintf('\nINPUT CHECK PASSED.\n');
