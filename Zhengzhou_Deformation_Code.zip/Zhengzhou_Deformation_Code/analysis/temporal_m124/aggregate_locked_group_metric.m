function G = aggregate_locked_group_metric(M,cfg)
valid=M.valid & isfinite(M.coherence) & isfinite(M.phaseConcentration) & isfinite(M.phase) & isfinite(M.lag);
nTotal=sum(valid);
support=valid & M.coherence>=cfg.block.minimumCoherence & M.phaseConcentration>=cfg.block.minimumPhaseConcentration;
nSupport=sum(support);
if nTotal==0 || nSupport==0
    G=struct('NBlocks',nTotal,'NSupport',nSupport,'SupportFraction',0,'MeanCoherence',NaN,'PhaseConcentration',NaN, ...
        'DriverLeadFraction',NaN,'MedianLagMonths',NaN,'LeadStatistic',0); return;
end
coh=M.coherence(support); pc=M.phaseConcentration(support); ph=M.phase(support); lag=M.lag(support);
w=max(coh.*pc,eps); z=sum(w.*exp(1i*ph))/sum(w);
supportFrac=nSupport/nTotal; leadFrac=mean(lag>0); meanC=mean(coh,'omitnan'); groupConc=abs(z); medLag=median(lag,'omitnan');
leadStat=supportFrac*meanC*groupConc*max(0,2*leadFrac-1);
G=struct('NBlocks',nTotal,'NSupport',nSupport,'SupportFraction',supportFrac,'MeanCoherence',meanC, ...
    'PhaseConcentration',groupConc,'DriverLeadFraction',leadFrac,'MedianLagMonths',medLag,'LeadStatistic',leadStat);
end
