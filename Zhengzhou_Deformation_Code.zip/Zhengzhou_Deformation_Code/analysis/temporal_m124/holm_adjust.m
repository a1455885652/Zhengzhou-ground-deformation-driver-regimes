function q = holm_adjust(p)
p=double(p(:)); m=numel(p); q=nan(m,1); good=isfinite(p);
idx=find(good); pg=p(good); mg=numel(pg); if mg==0, return; end
[ps,ord]=sort(pg); adj=zeros(mg,1);
for i=1:mg, adj(i)=(mg-i+1)*ps(i); end
for i=2:mg, adj(i)=max(adj(i),adj(i-1)); end
adj=min(adj,1); tmp=nan(mg,1); tmp(ord)=adj; q(idx)=tmp;
end
