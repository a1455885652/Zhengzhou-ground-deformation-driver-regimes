# 机制分区输入

通过交叉拟合获得 SHAP 组成，进行组成变换与初始混合模型分析。

| 项目 | 内容 |
|---|---|
| 输入 | MATLAB 入口读取工程栅格；prepare_mechanisms_tables 使用已附带的 CrossFit_Model_Data.csv。 |
| 输出 | `project_root/SHAP_Mechanism_Zoning_V2_Output` |
| 设置 | config_shap_mechanism_v2.m；../../config/experiments/prepare_mechanisms.json |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('prepare_mechanisms')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。

若从准备好的表格开始，可在根目录运行：

```bat
.venv\Scripts\python.exe run.py analysis prepare_mechanisms_tables
```
