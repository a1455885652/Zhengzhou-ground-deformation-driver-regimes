function draw_manual_boxes_v2(ax,cfg)
for i=1:size(cfg.subsidenceBoxes,1)
    b=cfg.subsidenceBoxes(i,:);
    rectangle(ax,'Position',[min(b(1:2)),min(b(3:4)),abs(diff(b(1:2))),abs(diff(b(3:4)))], ...
        'EdgeColor','k','LineWidth',1.2,'LineStyle','-');
    text(ax,min(b(1:2)),max(b(3:4)),sprintf(' Sub%d',i),'FontWeight','bold','FontSize',10,'VerticalAlignment','bottom');
end
for i=1:size(cfg.upliftBoxes,1)
    b=cfg.upliftBoxes(i,:);
    rectangle(ax,'Position',[min(b(1:2)),min(b(3:4)),abs(diff(b(1:2))),abs(diff(b(3:4)))], ...
        'EdgeColor','k','LineWidth',1.2,'LineStyle','--');
    text(ax,min(b(1:2)),max(b(3:4)),sprintf(' Upl%d',i),'FontWeight','bold','FontSize',10,'VerticalAlignment','bottom');
end
end
