function write_mechanism_v2_rasters(cfg)
T = readtable(fullfile(cfg.pythonOutputFolder,'Mechanism_Assignment_Final.csv'),'VariableNamingRule','preserve');
[Y,R] = readgeoraster(cfg.latestVelocityFile,'OutputType','double');
if ndims(Y)>2; Y=Y(:,:,1); end
[nRows,nCols] = size(Y);
idx = double(T.PixelIndex);
if any(idx<1 | idx>nRows*nCols)
    error('PixelIndex is outside target raster dimensions.');
end

mechanism = nan(nRows,nCols);
confidence = nan(nRows,nCols);
entropy = nan(nRows,nCols);
prediction = nan(nRows,nCols);
residual = nan(nRows,nCols);

mechanism(idx) = double(T.FinalMechanism);
confidence(idx) = double(T.MaxPosterior);
entropy(idx) = double(T.NormalizedEntropy);
prediction(idx) = double(T.CrossFitPrediction);
residual(idx) = double(T.Residual);

geotiffwrite(fullfile(cfg.rasterFolder,'Mechanism_Type.tif'),single(mechanism),R,'CoordRefSysCode',4326);
geotiffwrite(fullfile(cfg.rasterFolder,'Mechanism_Confidence.tif'),single(confidence),R,'CoordRefSysCode',4326);
geotiffwrite(fullfile(cfg.rasterFolder,'Mechanism_Entropy.tif'),single(entropy),R,'CoordRefSysCode',4326);
geotiffwrite(fullfile(cfg.rasterFolder,'CrossFit_Prediction.tif'),single(prediction),R,'CoordRefSysCode',4326);
geotiffwrite(fullfile(cfg.rasterFolder,'CrossFit_Residual.tif'),single(residual),R,'CoordRefSysCode',4326);
fprintf('GeoTIFF products written to: %s\n',cfg.rasterFolder);
end
