function run_python_mechanism_v2(cfg,pythonExe)
cmd = sprintf('"%s" "%s" "%s"',pythonExe,cfg.pythonScript,cfg.pythonConfigJson);
fprintf('\nPython command:\n%s\n\n',cmd);
[status,~] = system(cmd,'-echo');
if status~=0
    error('Python mechanism V2 workflow failed. See the Python traceback above.');
end
end
