function plot_mechanism_heatmap_v2(cfg)
T = readtable(fullfile(cfg.pythonOutputFolder,'Mechanism_Driver_Profile_Long.csv'),'VariableNamingRule','preserve');
clusters = unique(double(T.MechanismCluster),'stable');
drivers = unique(string(T.Driver),'stable');
M = nan(numel(clusters),numel(drivers));
for i=1:numel(clusters)
    for j=1:numel(drivers)
        m = double(T.MechanismCluster)==clusters(i) & string(T.Driver)==drivers(j);
        if any(m); M(i,j)=double(T.MeanComposition(find(m,1))); end
    end
end
fig=figure('Color','w','Position',[80 80 1350 520]);
imagesc(M*100); colormap(parula); cb=colorbar; cb.Label.String='Mean contribution composition (%)';
set(gca,'XTick',1:numel(drivers),'XTickLabel',pretty_driver_name_v2(drivers),'YTick',1:numel(clusters),'YTickLabel',compose('M%d',clusters), ...
    'FontName','Times New Roman','FontSize',11,'LineWidth',1); xtickangle(35);
xlabel('Driver'); ylabel('Mechanism type'); title('Mechanism fingerprints based on mean |cross-fitted SHAP| composition','FontWeight','bold','FontSize',14);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_04_Mechanism_Fingerprint_Heatmap.png'),'Resolution',cfg.figureDPI);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_04_Mechanism_Fingerprint_Heatmap.tif'),'Resolution',cfg.figureDPI);
if ~zz_show_figures(), close(fig); end
end
