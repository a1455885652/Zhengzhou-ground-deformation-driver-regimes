function [roadMean,roadVectorAll,roadFilesTable] = build_road_density_mean_v2(cfg,D)
% Strictly read one FormalRoad 1-km raster for each year 2018-2025.
ny = numel(cfg.roadYears);
stack = nan([D.rasterSize ny]);
Year = nan(ny,1);
File = strings(ny,1);

for k=1:ny
    yr = cfg.roadYears(k);
    candidates = [ ...
        dir(fullfile(cfg.annualRoadFolder,sprintf('*%d*.tif',yr))); ...
        dir(fullfile(cfg.annualRoadFolder,sprintf('*%d*.tiff',yr)))];
    if isempty(candidates)
        error('Cannot find FormalRoad tif for %d: %s',yr,cfg.annualRoadFolder);
    end
    if numel(candidates)>1
        names = string({candidates.name});
        exact = contains(lower(names),'formalroad');
        candidates = candidates(exact);
    end
    if numel(candidates)~=1
        names = string({candidates.name});
        error('%d FormalRoad file count is %d, expected exactly 1. Candidates: %s', ...
            yr,numel(candidates),strjoin(names,', '));
    end
    f = fullfile(candidates(1).folder,candidates(1).name);
    [A,R] = readgeoraster(f,'OutputType','double');
    if ndims(A)>2; A=A(:,:,1); end
    assert_geographic_grid_reference_v2(R,D.R,size(A),D.rasterSize, ...
        sprintf('RoadDensity %d vs prepared grid',yr));
    stack(:,:,k) = A;
    Year(k) = yr;
    File(k) = string(f);
end

roadMean = mean(stack,3,'omitnan');
roadVectorAll = roadMean(double(D.pixelIndex(:)));
roadFilesTable = table(Year,File);
end
