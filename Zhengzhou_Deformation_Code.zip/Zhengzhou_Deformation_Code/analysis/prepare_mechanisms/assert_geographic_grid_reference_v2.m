function assert_geographic_grid_reference_v2(Ra,Rb,sizeA,sizeB,label)
if ~isequal(sizeA(1:2),sizeB(1:2))
    error('%s: raster sizes differ: [%d %d] vs [%d %d].',label,sizeA(1),sizeA(2),sizeB(1),sizeB(2));
end
if isa(Ra,'map.rasterref.GeographicCellsReference') || isa(Ra,'map.rasterref.GeographicPostingsReference')
    if ~(isa(Rb,'map.rasterref.GeographicCellsReference') || isa(Rb,'map.rasterref.GeographicPostingsReference'))
        error('%s: reference types are inconsistent.',label);
    end
    tol = 1e-9;
    if max(abs(double(Ra.LatitudeLimits)-double(Rb.LatitudeLimits)))>tol || ...
       max(abs(double(Ra.LongitudeLimits)-double(Rb.LongitudeLimits)))>tol
        error('%s: geographic limits differ.',label);
    end
else
    error('%s: expected a geographic raster reference.',label);
end
end
