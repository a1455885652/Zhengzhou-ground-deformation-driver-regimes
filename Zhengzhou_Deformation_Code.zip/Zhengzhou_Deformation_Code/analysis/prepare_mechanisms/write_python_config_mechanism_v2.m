function write_python_config_mechanism_v2(cfg)
C = struct();
C.training_csv = cfg.trainingCsv;
C.feature_metadata_csv = cfg.featureMetadataCsv;
C.output_folder = cfg.pythonOutputFolder;
C.random_seed = cfg.randomSeed;
C.n_repeats = cfg.nRepeats;
C.outer_folds = cfg.outerFolds;
C.regression_strata_bins = cfg.regressionStrataBins;
C.hyperparameter_mode = cfg.hyperparameterMode;
C.inner_cv_folds = cfg.innerCVFolds;
C.n_random_search_candidates = cfg.nRandomSearchCandidates;
C.try_gpu = cfg.tryGPU;
C.locked_params = cfg.lockedParams;
C.composition_pseudo_fraction = cfg.compositionPseudoFraction;
C.pca_explained_variance = cfg.pcaExplainedVariance;
C.gmm_k_min = cfg.gmmKMin;
C.gmm_k_max = cfg.gmmKMax;
C.gmm_n_init = cfg.gmmNInit;
C.gmm_max_iter = cfg.gmmMaxIter;
C.gmm_reg_covar = cfg.gmmRegCovar;
C.minimum_cluster_fraction = cfg.minimumClusterFraction;
C.minimum_stability_ari = cfg.minimumStabilityARI;
C.minimum_median_posterior = cfg.minimumMedianPosterior;
C.gmm_stability_replicates = cfg.gmmStabilityReplicates;
C.gmm_stability_sample_fraction = cfg.gmmStabilitySampleFraction;
C.apply_weak_spatial_regularization = cfg.applyWeakSpatialRegularization;
C.isolated_pixel_trigger = cfg.isolatedPixelTrigger;
C.regularization_lambdas = cfg.regularizationLambdas;
C.regularization_max_iterations = cfg.regularizationMaxIterations;
C.target_isolation_reduction = cfg.targetIsolationReduction;
C.maximum_changed_fraction = cfg.maximumChangedFraction;
C.maximum_posterior_drop = cfg.maximumPosteriorDrop;
C.subsidence_boxes = cfg.subsidenceBoxes;
C.uplift_boxes = cfg.upliftBoxes;
C.positive_is_subsidence = cfg.positiveIsSubsidence;
C.minimum_overall_crossfit_r2 = cfg.minimumOverallCrossFitR2;

txt = jsonencode(C,'PrettyPrint',true);
fid = fopen(cfg.pythonConfigJson,'w','n','UTF-8');
if fid<0
    error('Cannot write JSON: %s',cfg.pythonConfigJson);
end
cleanupObj = onCleanup(@() fclose(fid));
fwrite(fid,txt,'char');
end
