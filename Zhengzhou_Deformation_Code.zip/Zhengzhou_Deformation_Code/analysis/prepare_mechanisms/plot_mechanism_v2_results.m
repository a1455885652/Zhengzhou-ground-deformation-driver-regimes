function plot_mechanism_v2_results(cfg)
plot_crossfit_performance_v2(cfg);
plot_mechanism_map_v2(cfg);
plot_confidence_entropy_v2(cfg);
plot_mechanism_heatmap_v2(cfg);
plot_response_mechanism_v2(cfg);
plot_manual_zone_mechanism_v2(cfg);
plot_gmm_k_selection_v2(cfg);
end
