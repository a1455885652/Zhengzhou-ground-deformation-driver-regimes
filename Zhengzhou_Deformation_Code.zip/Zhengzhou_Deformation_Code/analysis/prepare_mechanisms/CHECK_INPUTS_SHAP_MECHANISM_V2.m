clear; clc;
cfg = config_shap_mechanism_v2();
validate_shap_mechanism_v2_inputs(cfg);
fprintf('\nAll required inputs passed. You can now run RUN_SHAP_MECHANISM_V2.m\n');
