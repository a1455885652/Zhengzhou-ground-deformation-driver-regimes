function plot_confidence_entropy_v2(cfg)
T = readtable(fullfile(cfg.pythonOutputFolder,'Mechanism_Assignment_Final.csv'),'VariableNamingRule','preserve');
fig = figure('Color','w','Position',[80 80 1300 560]);
tl=tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
ax1=nexttile(tl); scatter(ax1,double(T.Longitude),double(T.Latitude),18,double(T.MaxPosterior),'filled','MarkerEdgeColor','none');
axis(ax1,'equal'); axis(ax1,'tight'); box(ax1,'on'); colormap(ax1,parula); colorbar(ax1); title(ax1,'(a) Maximum posterior probability','FontWeight','bold');
ax2=nexttile(tl); scatter(ax2,double(T.Longitude),double(T.Latitude),18,double(T.NormalizedEntropy),'filled','MarkerEdgeColor','none');
axis(ax2,'equal'); axis(ax2,'tight'); box(ax2,'on'); colormap(ax2,parula); colorbar(ax2); title(ax2,'(b) Normalized mechanism entropy','FontWeight','bold');
for ax=[ax1 ax2]
    xlabel(ax,'Longitude (°E)'); ylabel(ax,'Latitude (°N)'); set(ax,'FontName','Times New Roman','FontSize',12,'LineWidth',1);
end
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_03_Confidence_Entropy.png'),'Resolution',cfg.figureDPI);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_03_Confidence_Entropy.tif'),'Resolution',cfg.figureDPI);
if ~zz_show_figures(), close(fig); end
end
