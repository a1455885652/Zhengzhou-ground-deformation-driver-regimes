clear; clc;
cfg = config_shap_mechanism_v2();

fprintf('==========================================================================\n');
fprintf(' Zhengzhou SHAP Mechanism Zoning V2\n');
fprintf(' Repeated nested cross-fitted XGBoost-SHAP -> CLR -> GMM -> weak spatial QC\n');
fprintf('==========================================================================\n\n');

fprintf('[1/7] Input and Python pre-flight...\n');
pythonExe = validate_shap_mechanism_v2_inputs(cfg);

fprintf('\n[2/7] Preparing a fresh, self-contained modeling dataset...\n');
ensure_folder_v2(cfg.outputRoot);
ensure_folder_v2(cfg.pythonOutputFolder);
ensure_folder_v2(cfg.figureFolder);
ensure_folder_v2(cfg.rasterFolder);
prepared = prepare_mechanism_v2_dataset(cfg);
writetable(prepared.dataTable,cfg.trainingCsv);
writetable(prepared.featureMetadata,cfg.featureMetadataCsv);
writetable(prepared.inputAudit,cfg.inputAuditCsv);
writetable(prepared.roadFilesTable,cfg.roadFilesCsv);

fprintf('Samples = %d\n',height(prepared.dataTable));
fprintf('Target mean = %.4f mm/yr; std = %.4f mm/yr; range = [%.4f, %.4f]\n', ...
    prepared.targetMean,prepared.targetStd,prepared.targetMin,prepared.targetMax);

fprintf('\n[3/7] Writing Python config...\n');
write_python_config_mechanism_v2(cfg);

fprintf('\n[4/7] Running repeated cross-fitted XGBoost-SHAP and GMM mechanism analysis...\n');
run_python_mechanism_v2(cfg,pythonExe);

fprintf('\n[5/7] Verifying Python outputs...\n');
verify_mechanism_v2_outputs(cfg);

fprintf('\n[6/7] Writing GeoTIFF products...\n');
write_mechanism_v2_rasters(cfg);

fprintf('\n[7/7] Drawing diagnostic/publication figures...\n');
plot_mechanism_v2_results(cfg);

fprintf('\n==========================================================================\n');
fprintf(' FINISHED\n');
fprintf(' Output: %s\n',cfg.outputRoot);
fprintf('==========================================================================\n');
