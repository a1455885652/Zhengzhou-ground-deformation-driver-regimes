function pythonExe = validate_shap_mechanism_v2_inputs(cfg)
fprintf('\n===== INPUT PATH AUDIT =====\n');
requiredFiles = { ...
    cfg.latestVelocityFile, ...
    cfg.maskFile, ...
    cfg.preparedMat, ...
    cfg.pythonScript};
requiredNames = { ...
    'Latest velocity GeoTIFF', ...
    '1-km mask', ...
    'Prepared variable MAT', ...
    'Python analysis script'};

for i = 1:numel(requiredFiles)
    fprintf('[REQUIRED] %-28s : %s\n',requiredNames{i},requiredFiles{i});
    if ~isfile(requiredFiles{i})
        error('Required input does not exist:\n%s',requiredFiles{i});
    end
end

fprintf('[REQUIRED] %-28s : %s\n','Annual road folder',cfg.annualRoadFolder);
if ~isfolder(cfg.annualRoadFolder)
    error('Annual road folder does not exist:\n%s',cfg.annualRoadFolder);
end

for y = reshape(cfg.roadYears,1,[])
    files = [ ...
        dir(fullfile(cfg.annualRoadFolder,sprintf('*%d*.tif',y))); ...
        dir(fullfile(cfg.annualRoadFolder,sprintf('*%d*.tiff',y)))];
    if isempty(files)
        error('No road-density tif/tiff found for year %d in:\n%s',y,cfg.annualRoadFolder);
    end
end

if isfile(cfg.latestVelocitySourceCountFile)
    fprintf('[OPTIONAL] %-28s : %s [FOUND]\n','Velocity source-count',cfg.latestVelocitySourceCountFile);
else
    fprintf('[OPTIONAL] %-28s : %s [NOT FOUND; allowed]\n','Velocity source-count',cfg.latestVelocitySourceCountFile);
end

pythonExe = resolve_python_executable_v2(cfg.pythonExe);
check_python_packages_v2(pythonExe);

fprintf('\nPython: %s\n',pythonExe);
fprintf('Input contract OK.\n');
end
