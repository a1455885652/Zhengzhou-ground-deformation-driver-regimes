clear; clc;
cfg = config_shap_mechanism_v2();

kFile = fullfile(cfg.pythonOutputFolder,'GMM_K_Selection.csv');
regFile = fullfile(cfg.pythonOutputFolder,'CrossFit_Regional_Performance.csv');
clusterFile = fullfile(cfg.pythonOutputFolder,'Mechanism_Cluster_Summary.csv');
spFile = fullfile(cfg.pythonOutputFolder,'Spatial_Regularization_Audit.csv');

required = {kFile,regFile,clusterFile,spFile};
for i=1:numel(required)
    if ~isfile(required{i}); error('Missing output: %s',required{i}); end
end

K = readtable(kFile,'VariableNamingRule','preserve');
R = readtable(regFile,'VariableNamingRule','preserve');
C = readtable(clusterFile,'VariableNamingRule','preserve');
S = readtable(spFile,'VariableNamingRule','preserve');

sel = K.Selected==1;
fprintf('================ V2 RESULT SUMMARY ================\n');
fprintf('Selected K = %d\n',K.K(find(sel,1)));
fprintf('Selected K: BIC=%.3f, ICL=%.3f, Silhouette=%.3f, Stability ARI=%.3f, Median posterior=%.3f\n', ...
    K.BIC(find(sel,1)),K.ICL(find(sel,1)),K.Silhouette(find(sel,1)), ...
    K.StabilityMeanARI(find(sel,1)),K.MedianMaxPosterior(find(sel,1)));

m = string(R.Region)=="Overall";
fprintf('\nOverall cross-fitted model:\n');
fprintf('R2=%.4f | RMSE=%.4f | MAE=%.4f | Pearson r=%.4f | Sign accuracy=%.4f\n', ...
    R.R2(m),R.RMSE(m),R.MAE(m),R.PearsonR(m),R.SignAccuracy(m));

fprintf('\nManual-zone diagnostics:\n');
for i=1:height(R)
    nm=string(R.Region(i));
    if nm~="Overall" && endsWith(nm,"_Rectangle")
        fprintf('%s: N=%d, R2=%.3f, RMSE=%.3f, signAcc=%.3f, reliable=%d\n', ...
            nm,R.N(i),R.R2(i),R.RMSE(i),R.SignAccuracy(i),R.ExplanationReliabilityFlag(i));
    end
end

fprintf('\nMechanism clusters:\n');
disp(C(:,{'MechanismCluster','N','Fraction','MeanTarget','SubsidenceFraction','UpliftFraction','TopDriver1','TopDriver2','TopDriver3'}));

ss=S.Selected==1;
fprintf('Spatial regularization lambda = %.3f | changed fraction = %.4f | isolated fraction = %.4f\n', ...
    S.Lambda(find(ss,1)),S.ChangedFraction(find(ss,1)),S.IsolatedFraction(find(ss,1)));
fprintf('===================================================\n');
