# -*- coding: utf-8 -*-
"""Zhengzhou SHAP mechanism zoning V2.

Formal workflow
---------------
1) repeated nested cross-fitting XGBoost (10 repeats x 5 outer folds by default);
2) OOF TreeSHAP only on held-out outer samples;
3) aggregate model features to 15 physical drivers;
4) form mean(|OOF SHAP|) compositions per pixel;
5) CLR transform (Aitchison geometry) + PCA;
6) GMM soft clustering, K selected by BIC subject to stability/size/confidence QC;
7) optional weak rook-neighbor ICM only for isolated salt-and-pepper labels;
8) cross-tab actual deformation response and mechanism type.

No spatial coordinates are used as clustering features.
"""

from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import xgboost as xgb
import shap

from sklearn.decomposition import PCA
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold
from sklearn.metrics import (
    adjusted_rand_score,
    mean_squared_error,
    mean_absolute_error,
    silhouette_score,
    calinski_harabasz_score,
    davies_bouldin_score,
)

warnings.filterwarnings("ignore", message=".*mismatched devices.*")
warnings.filterwarnings("ignore", category=FutureWarning)


def metric_dict(y, p):
    y = np.asarray(y, float)
    p = np.asarray(p, float)
    ok = np.isfinite(y) & np.isfinite(p)
    y = y[ok]
    p = p[ok]
    if len(y) == 0:
        return dict(
            N=0, R2=np.nan, RMSE=np.nan, MAE=np.nan, Bias=np.nan, PearsonR=np.nan
        )
    sst = np.sum((y - np.mean(y)) ** 2)
    r2 = 1.0 - np.sum((y - p) ** 2) / sst if sst > 0 else np.nan
    pr = (
        np.corrcoef(y, p)[0, 1]
        if len(y) > 1 and np.std(y) > 0 and np.std(p) > 0
        else np.nan
    )
    return dict(
        N=int(len(y)),
        R2=float(r2),
        RMSE=float(np.sqrt(mean_squared_error(y, p))),
        MAE=float(mean_absolute_error(y, p)),
        Bias=float(np.mean(p - y)),
        PearsonR=float(pr) if np.isfinite(pr) else np.nan,
    )


def test_device(try_gpu, seed):
    if not try_gpu:
        return "cpu"
    try:
        rng = np.random.default_rng(seed)
        X = rng.normal(size=(40, 4))
        y = rng.normal(size=40)
        m = xgb.XGBRegressor(
            n_estimators=5,
            max_depth=2,
            tree_method="hist",
            device="cuda",
            objective="reg:squarederror",
            random_state=seed,
            verbosity=0,
        )
        m.fit(X, y)
        _ = m.predict(X[:2])
        return "cuda"
    except Exception as exc:
        print(f"[GPU] CUDA unavailable; falling back to CPU: {exc}")
        return "cpu"


def make_model(device, seed):
    kw = dict(
        objective="reg:squarederror",
        eval_metric="rmse",
        tree_method="hist",
        random_state=int(seed),
        verbosity=0,
        n_jobs=1,
    )
    if device == "cuda":
        kw["device"] = "cuda"
    return xgb.XGBRegressor(**kw)


def parameter_space():
    return {
        "n_estimators": [300, 450, 600, 800, 1000],
        "max_depth": [2, 3, 4, 5, 6],
        "learning_rate": [0.015, 0.025, 0.04, 0.06, 0.08],
        "min_child_weight": [1, 3, 5, 8, 12],
        "subsample": [0.70, 0.80, 0.90, 1.00],
        "colsample_bytree": [0.65, 0.75, 0.85, 1.00],
        "gamma": [0.0, 0.02, 0.05, 0.10, 0.20],
        "reg_alpha": [0.0, 0.01, 0.05, 0.10, 0.50],
        "reg_lambda": [1.0, 2.0, 5.0, 10.0, 20.0],
    }


def regression_strata(y, requested_bins):
    y = np.asarray(y, float)
    q = int(max(2, requested_bins))
    while q >= 2:
        try:
            bins = pd.qcut(y, q=q, labels=False, duplicates="drop")
            bins = np.asarray(bins, int)
            counts = np.bincount(bins)
            if len(counts) >= 2 and counts.min() >= 2:
                return bins
        except Exception:
            pass
        q -= 1
    # Last-resort median split. For this dataset it should never be needed.
    return (y > np.nanmedian(y)).astype(int)


def get_shap(model, X):
    ex = shap.TreeExplainer(model)
    try:
        sv = ex.shap_values(X)
    except Exception:
        sv = ex(X).values
    sv = np.asarray(sv)
    if sv.ndim == 3:
        sv = sv[:, :, 0]
    if sv.ndim != 2:
        raise RuntimeError(f"Unexpected SHAP array shape: {sv.shape}")
    return sv


def aggregate_driver_shap(feature_shap, feature_names, feature_to_driver, drivers):
    out = np.zeros((feature_shap.shape[0], len(drivers)), dtype=float)
    for j, driver in enumerate(drivers):
        idx = [i for i, f in enumerate(feature_names) if feature_to_driver[f] == driver]
        if not idx:
            raise RuntimeError(f"No model features mapped to physical driver {driver}")
        out[:, j] = feature_shap[:, idx].sum(axis=1)
    return out


def inside(lon, lat, b):
    x0, x1, y0, y1 = [float(v) for v in b]
    return (
        (lon >= min(x0, x1))
        & (lon <= max(x0, x1))
        & (lat >= min(y0, y1))
        & (lat <= max(y0, y1))
    )


def build_manual_zone_masks(df, cfg):
    lon = df["Longitude"].to_numpy(float)
    lat = df["Latitude"].to_numpy(float)
    y = df["Target"].to_numpy(float)
    subs = np.asarray(cfg["subsidence_boxes"], float).reshape(-1, 4)
    upls = np.asarray(cfg["uplift_boxes"], float).reshape(-1, 4)
    positive_is_sub = bool(cfg["positive_is_subsidence"])
    out = {}
    for i, b in enumerate(subs, 1):
        m = inside(lon, lat, b)
        out[f"Sub{i}_Rectangle"] = m
        out[f"Sub{i}_SignConsistent"] = m & ((y > 0) if positive_is_sub else (y < 0))
    for i, b in enumerate(upls, 1):
        m = inside(lon, lat, b)
        out[f"Upl{i}_Rectangle"] = m
        out[f"Upl{i}_SignConsistent"] = m & ((y < 0) if positive_is_sub else (y > 0))
    return out


def regional_performance(df, pred, masks, positive_is_subsidence):
    y = df["Target"].to_numpy(float)
    rows = []
    all_masks = {"Overall": np.ones(len(df), dtype=bool)}
    all_masks.update(masks)
    for name, m in all_masks.items():
        yy = y[m]
        pp = pred[m]
        M = metric_dict(yy, pp)
        if len(yy):
            obs_sub = yy > 0 if positive_is_subsidence else yy < 0
            pred_sub = pp > 0 if positive_is_subsidence else pp < 0
            sign_acc = np.mean(np.sign(yy) == np.sign(pp))
            obs_sub_frac = np.mean(obs_sub)
            pred_sub_frac = np.mean(pred_sub)
            ysd = np.std(yy, ddof=1) if len(yy) > 1 else np.nan
            nrmse_sd = M["RMSE"] / ysd if np.isfinite(ysd) and ysd > 0 else np.nan
            # Diagnostic only. It does not delete or alter SHAP samples.
            reliable = (
                len(yy) >= 50
                and np.isfinite(M["R2"])
                and M["R2"] >= 0.0
                and np.isfinite(M["PearsonR"])
                and M["PearsonR"] >= 0.50
                and sign_acc >= 0.65
                and (not np.isfinite(nrmse_sd) or nrmse_sd <= 1.20)
            )
        else:
            obs_sub_frac = pred_sub_frac = sign_acc = nrmse_sd = np.nan
            reliable = False
        rows.append(
            dict(
                Region=name,
                **M,
                ObservedSubsidenceFraction=float(obs_sub_frac)
                if np.isfinite(obs_sub_frac)
                else np.nan,
                PredictedSubsidenceFraction=float(pred_sub_frac)
                if np.isfinite(pred_sub_frac)
                else np.nan,
                SignAccuracy=float(sign_acc) if np.isfinite(sign_acc) else np.nan,
                NRMSE_by_TargetSD=float(nrmse_sd) if np.isfinite(nrmse_sd) else np.nan,
                ExplanationReliabilityFlag=bool(reliable),
            )
        )
    return pd.DataFrame(rows)


def nested_or_locked_model(Xtr, ytr, cfg, device, seed):
    mode = str(cfg["hyperparameter_mode"]).lower().strip()
    if mode == "locked":
        params = dict(cfg["locked_params"])
        model = make_model(device, seed)
        model.set_params(**params)
        model.fit(Xtr, ytr)
        return model, params, np.nan
    if mode != "nested":
        raise ValueError("hyperparameter_mode must be 'nested' or 'locked'")

    inner_bins = regression_strata(ytr, int(cfg["regression_strata_bins"]))
    skf = StratifiedKFold(
        n_splits=int(cfg["inner_cv_folds"]),
        shuffle=True,
        random_state=int(seed),
    )
    splits = list(skf.split(np.zeros(len(ytr)), inner_bins))
    search = RandomizedSearchCV(
        estimator=make_model(device, seed),
        param_distributions=parameter_space(),
        n_iter=int(cfg["n_random_search_candidates"]),
        scoring="neg_root_mean_squared_error",
        cv=splits,
        random_state=int(seed),
        n_jobs=1 if device == "cuda" else -1,
        verbose=0,
        return_train_score=False,
    )
    search.fit(Xtr, ytr)
    return search.best_estimator_, dict(search.best_params_), float(-search.best_score_)


def repeated_crossfit(
    df, X, y, feature_names, feature_to_driver, drivers, cfg, device, outdir
):
    n = len(df)
    d = len(drivers)
    R = int(cfg["n_repeats"])
    K = int(cfg["outer_folds"])
    seed0 = int(cfg["random_seed"])

    pred_sum = np.zeros(n)
    pred_sq_sum = np.zeros(n)
    shap_signed_sum = np.zeros((n, d))
    shap_signed_sq_sum = np.zeros((n, d))
    shap_abs_sum = np.zeros((n, d))
    count = np.zeros(n, dtype=int)

    fold_rows = []
    repeat_rows = []

    for r in range(R):
        rep_seed = seed0 + 1009 * r
        bins = regression_strata(y, int(cfg["regression_strata_bins"]))
        outer = StratifiedKFold(n_splits=K, shuffle=True, random_state=rep_seed)
        repeat_pred = np.full(n, np.nan)

        print(f"\n========== Repeat {r + 1}/{R} ==========")
        for fold, (tr, te) in enumerate(outer.split(np.zeros(n), bins), 1):
            fold_seed = rep_seed + 97 * fold
            print(f"  Outer fold {fold}/{K}: train={len(tr)}, test={len(te)}")
            model, best_params, inner_rmse = nested_or_locked_model(
                X.iloc[tr], y[tr], cfg, device, fold_seed
            )
            p = np.asarray(model.predict(X.iloc[te]), float)
            fshap = get_shap(model, X.iloc[te])
            dshap = aggregate_driver_shap(
                fshap, feature_names, feature_to_driver, drivers
            )

            repeat_pred[te] = p
            pred_sum[te] += p
            pred_sq_sum[te] += p**2
            shap_signed_sum[te] += dshap
            shap_signed_sq_sum[te] += dshap**2
            shap_abs_sum[te] += np.abs(dshap)
            count[te] += 1

            M = metric_dict(y[te], p)
            fold_rows.append(
                dict(
                    Repeat=r + 1,
                    Fold=fold,
                    TrainN=len(tr),
                    TestN=len(te),
                    InnerCVBestRMSE=inner_rmse,
                    **M,
                    BestParamsJSON=json.dumps(best_params, sort_keys=True),
                )
            )

        if np.any(~np.isfinite(repeat_pred)):
            raise RuntimeError(
                f"Repeat {r + 1} did not generate predictions for every sample."
            )
        Mrep = metric_dict(y, repeat_pred)
        repeat_rows.append(dict(Repeat=r + 1, **Mrep))
        print(
            f"  Repeat {r + 1}: R2={Mrep['R2']:.4f}, RMSE={Mrep['RMSE']:.4f}, MAE={Mrep['MAE']:.4f}"
        )

    if not np.all(count == R):
        vals, freq = np.unique(count, return_counts=True)
        raise RuntimeError(
            f"Cross-fitting count contract failed: {dict(zip(vals.tolist(), freq.tolist()))}"
        )

    pred_mean = pred_sum / R
    pred_var = np.maximum(pred_sq_sum / R - pred_mean**2, 0)
    pred_sd = np.sqrt(pred_var * R / max(R - 1, 1)) if R > 1 else np.zeros(n)

    mean_signed = shap_signed_sum / R
    signed_var = np.maximum(shap_signed_sq_sum / R - mean_signed**2, 0)
    signed_sd = (
        np.sqrt(signed_var * R / max(R - 1, 1)) if R > 1 else np.zeros_like(mean_signed)
    )
    mean_abs = shap_abs_sum / R
    shap_cv = signed_sd / (mean_abs + 1e-12)

    base_cols = [
        "SampleID",
        "PixelIndex",
        "RasterRow",
        "RasterColumn",
        "Longitude",
        "Latitude",
        "Target",
    ]
    P = df[base_cols].copy()
    P["CrossFitPrediction"] = pred_mean
    P["PredictionSD"] = pred_sd
    P["Residual"] = pred_mean - y
    P["CrossFitCount"] = count
    P.to_csv(outdir / "CrossFit_OOF_Predictions.csv", index=False)

    def save_driver_matrix(filename, matrix):
        T = pd.DataFrame(matrix, columns=drivers)
        T.insert(0, "SampleID", df["SampleID"].to_numpy())
        T.to_csv(outdir / filename, index=False)

    save_driver_matrix("CrossFit_SHAP_Driver_MeanSigned.csv", mean_signed)
    save_driver_matrix("CrossFit_SHAP_Driver_MeanAbs.csv", mean_abs)
    save_driver_matrix("CrossFit_SHAP_Driver_SD.csv", signed_sd)
    save_driver_matrix("CrossFit_SHAP_Driver_CV.csv", shap_cv)

    pd.DataFrame(fold_rows).to_csv(outdir / "CrossFit_Fold_Metrics.csv", index=False)
    pd.DataFrame(repeat_rows).to_csv(
        outdir / "CrossFit_Repeat_Metrics.csv", index=False
    )

    masks = build_manual_zone_masks(df, cfg)
    reg = regional_performance(
        df, pred_mean, masks, bool(cfg["positive_is_subsidence"])
    )
    reg.to_csv(outdir / "CrossFit_Regional_Performance.csv", index=False)

    # Driver-level SHAP stability summary across pixels.
    rows = []
    for j, driver in enumerate(drivers):
        rows.append(
            dict(
                Driver=driver,
                MeanAbsoluteCrossFitSHAP=float(np.mean(mean_abs[:, j])),
                MedianPixelSHAP_SD=float(np.median(signed_sd[:, j])),
                MedianPixelUncertaintyRatio=float(np.median(shap_cv[:, j])),
                P90PixelUncertaintyRatio=float(np.quantile(shap_cv[:, j], 0.90)),
            )
        )
    stab = pd.DataFrame(rows).sort_values("MeanAbsoluteCrossFitSHAP", ascending=False)
    stab.to_csv(outdir / "CrossFit_SHAP_Stability_Summary.csv", index=False)

    return pred_mean, pred_sd, mean_signed, mean_abs, signed_sd, shap_cv, masks


def clr_embedding(mean_abs, cfg, outdir, drivers):
    A = np.asarray(mean_abs, float)
    if np.any(~np.isfinite(A)) or np.any(A < 0):
        raise RuntimeError("mean(|SHAP|) matrix is invalid.")
    positive = A[A > 0]
    if positive.size == 0:
        raise RuntimeError("All mean absolute SHAP values are zero.")
    pseudo = float(cfg["composition_pseudo_fraction"]) * float(np.median(positive))
    if not np.isfinite(pseudo) or pseudo <= 0:
        pseudo = 1e-12
    P = A + pseudo
    P = P / P.sum(axis=1, keepdims=True)
    L = np.log(P)
    CLR = L - L.mean(axis=1, keepdims=True)

    # CLR lies in a D-1 dimensional subspace. PCA removes the singular direction.
    pca_full = PCA(svd_solver="full", random_state=int(cfg["random_seed"]))
    Zfull = pca_full.fit_transform(CLR)
    csum = np.cumsum(pca_full.explained_variance_ratio_)
    target = float(cfg["pca_explained_variance"])
    ncomp = int(np.searchsorted(csum, target, side="left") + 1)
    ncomp = min(ncomp, CLR.shape[1] - 1)
    ncomp = max(ncomp, 2)
    Z = Zfull[:, :ncomp]

    comp = pd.DataFrame(P, columns=drivers)
    comp.insert(0, "SampleIndex", np.arange(1, len(P) + 1))
    comp.to_csv(outdir / "SHAP_Composition.csv", index=False)

    clr_df = pd.DataFrame(CLR, columns=drivers)
    clr_df.insert(0, "SampleIndex", np.arange(1, len(CLR) + 1))
    clr_df.to_csv(outdir / "SHAP_CLR.csv", index=False)

    ev = pd.DataFrame(
        {
            "PC": np.arange(1, len(pca_full.explained_variance_ratio_) + 1),
            "ExplainedVarianceRatio": pca_full.explained_variance_ratio_,
            "CumulativeExplainedVariance": csum,
            "Retained": np.arange(1, len(csum) + 1) <= ncomp,
        }
    )
    ev.to_csv(outdir / "CLR_PCA_ExplainedVariance.csv", index=False)

    loadings = pd.DataFrame(
        pca_full.components_.T[:, :ncomp],
        index=drivers,
        columns=[f"PC{i}" for i in range(1, ncomp + 1)],
    )
    loadings.index.name = "Driver"
    loadings.reset_index().to_csv(outdir / "CLR_PCA_Loadings.csv", index=False)

    with open(outdir / "CLR_Protocol.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "pseudo_value": pseudo,
                "pseudo_fraction": float(cfg["composition_pseudo_fraction"]),
                "pca_target_explained_variance": target,
                "retained_pcs": ncomp,
                "retained_cumulative_variance": float(csum[ncomp - 1]),
            },
            f,
            indent=2,
        )
    return P, CLR, Z, pca_full, ncomp


def normalized_entropy(prob):
    p = np.clip(np.asarray(prob, float), 1e-15, 1.0)
    K = p.shape[1]
    h = -np.sum(p * np.log(p), axis=1)
    return h / np.log(K) if K > 1 else np.zeros(len(p))


def fit_gmm(Z, k, cfg, seed):
    gmm = GaussianMixture(
        n_components=int(k),
        covariance_type="full",
        reg_covar=float(cfg["gmm_reg_covar"]),
        n_init=int(cfg["gmm_n_init"]),
        max_iter=int(cfg["gmm_max_iter"]),
        init_params="kmeans",
        random_state=int(seed),
    )
    gmm.fit(Z)
    prob = gmm.predict_proba(Z)
    labels = np.argmax(prob, axis=1)
    return gmm, labels, prob


def gmm_subsample_stability(Z, k, full_labels, cfg, seed):
    rng = np.random.default_rng(seed)
    B = int(cfg["gmm_stability_replicates"])
    frac = float(cfg["gmm_stability_sample_fraction"])
    n = len(Z)
    m = int(round(n * frac))
    vals = []
    for b in range(B):
        idx = rng.choice(n, size=m, replace=False)
        try:
            # Fewer n_init for the stability replicates to keep the formal run practical.
            gmm = GaussianMixture(
                n_components=int(k),
                covariance_type="full",
                reg_covar=float(cfg["gmm_reg_covar"]),
                n_init=max(5, int(cfg["gmm_n_init"]) // 2),
                max_iter=int(cfg["gmm_max_iter"]),
                init_params="kmeans",
                random_state=int(seed + 997 * (b + 1)),
            )
            gmm.fit(Z[idx])
            lab = gmm.predict(Z)
            vals.append(adjusted_rand_score(full_labels, lab))
        except Exception as exc:
            print(f"    Stability replicate failed for K={k}: {exc}")
    if not vals:
        return np.nan, np.nan, np.nan
    vals = np.asarray(vals, float)
    return (
        float(np.mean(vals)),
        float(np.std(vals, ddof=1) if len(vals) > 1 else 0),
        float(np.quantile(vals, 0.05)),
    )


def select_gmm_k(Z, cfg, outdir):
    seed = int(cfg["random_seed"])
    rows = []
    models = {}
    for k in range(int(cfg["gmm_k_min"]), int(cfg["gmm_k_max"]) + 1):
        print(f"\n[GMM] Fitting K={k}...")
        gmm, lab, prob = fit_gmm(Z, k, cfg, seed + 31 * k)
        counts = np.bincount(lab, minlength=k)
        frac = counts / len(lab)
        maxp = prob.max(axis=1)
        ent = normalized_entropy(prob)
        sil = (
            silhouette_score(Z, lab, metric="euclidean")
            if len(np.unique(lab)) > 1
            else np.nan
        )
        ch = calinski_harabasz_score(Z, lab) if len(np.unique(lab)) > 1 else np.nan
        db = davies_bouldin_score(Z, lab) if len(np.unique(lab)) > 1 else np.nan
        stab_mean, stab_sd, stab_p05 = gmm_subsample_stability(
            Z, k, lab, cfg, seed + 100000 + 101 * k
        )
        raw_entropy = float(
            np.sum(
                -np.sum(
                    np.clip(prob, 1e-15, 1.0) * np.log(np.clip(prob, 1e-15, 1.0)),
                    axis=1,
                )
            )
        )
        bic = float(gmm.bic(Z))
        # ICL approximation: BIC + 2 * classification entropy. Lower is better.
        # This favors well-separated mechanism types and discourages density over-splitting.
        icl = bic + 2.0 * raw_entropy
        row = dict(
            K=k,
            BIC=bic,
            ICL=float(icl),
            AIC=float(gmm.aic(Z)),
            Silhouette=float(sil),
            CalinskiHarabasz=float(ch),
            DaviesBouldin=float(db),
            MinClusterN=int(counts.min()),
            MinClusterFraction=float(frac.min()),
            MedianMaxPosterior=float(np.median(maxp)),
            MeanMaxPosterior=float(np.mean(maxp)),
            MeanNormalizedEntropy=float(np.mean(ent)),
            StabilityMeanARI=stab_mean,
            StabilitySDARI=stab_sd,
            StabilityP05ARI=stab_p05,
        )
        row["PassMinCluster"] = row["MinClusterFraction"] >= float(
            cfg["minimum_cluster_fraction"]
        )
        row["PassStability"] = np.isfinite(stab_mean) and stab_mean >= float(
            cfg["minimum_stability_ari"]
        )
        row["PassPosterior"] = row["MedianMaxPosterior"] >= float(
            cfg["minimum_median_posterior"]
        )
        row["Eligible"] = bool(
            row["PassMinCluster"] and row["PassStability"] and row["PassPosterior"]
        )
        rows.append(row)
        models[k] = (gmm, lab, prob)
        print(
            f"    BIC={row['BIC']:.1f}; silhouette={row['Silhouette']:.3f}; "
            f"minFrac={row['MinClusterFraction']:.3f}; medianP={row['MedianMaxPosterior']:.3f}; "
            f"stabilityARI={row['StabilityMeanARI']:.3f}; eligible={row['Eligible']}"
        )

    T = pd.DataFrame(rows)
    eligible = T[T["Eligible"]]
    if len(eligible):
        chosen_k = int(eligible.loc[eligible["ICL"].idxmin(), "K"])
        selection_rule = "minimum ICL among candidates passing min-cluster, stability, and posterior constraints; BIC retained as density-model diagnostic"
    else:
        # Transparent fallback. Penalize obvious degeneracy rather than silently failing.
        bic_scaled = (T["BIC"] - T["BIC"].min()) / max(
            T["BIC"].max() - T["BIC"].min(), 1e-12
        )
        stability = T["StabilityMeanARI"].fillna(0).clip(0, 1)
        posterior = T["MedianMaxPosterior"].clip(0, 1)
        minfrac = (
            T["MinClusterFraction"] / float(cfg["minimum_cluster_fraction"])
        ).clip(upper=1)
        score = -bic_scaled + stability + 0.5 * posterior + 0.5 * minfrac
        chosen_k = int(T.loc[score.idxmax(), "K"])
        selection_rule = (
            "fallback composite rule because no K passed all pre-specified constraints"
        )
    T["Selected"] = T["K"] == chosen_k
    T.to_csv(outdir / "GMM_K_Selection.csv", index=False)

    with open(outdir / "GMM_K_Selection_Protocol.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "selected_k": chosen_k,
                "selection_rule": selection_rule,
                "minimum_cluster_fraction": float(cfg["minimum_cluster_fraction"]),
                "minimum_stability_ari": float(cfg["minimum_stability_ari"]),
                "minimum_median_posterior": float(cfg["minimum_median_posterior"]),
                "boundary_selected": bool(
                    chosen_k in (int(cfg["gmm_k_min"]), int(cfg["gmm_k_max"]))
                ),
                "boundary_warning": "If the selected K is at Kmax, expand the candidate range before final publication interpretation."
                if chosen_k == int(cfg["gmm_k_max"])
                else "",
            },
            f,
            indent=2,
        )
    return chosen_k, models[chosen_k]


def canonicalize_labels(labels, prob):
    """Canonicalize arbitrary GMM labels by descending cluster size, then mean confidence."""
    labels = np.asarray(labels, int)
    K = prob.shape[1]
    rows = []
    for old in range(K):
        m = labels == old
        rows.append(
            (old, int(m.sum()), float(np.mean(prob[m, old])) if m.any() else 0.0)
        )
    order = sorted(rows, key=lambda x: (-x[1], -x[2], x[0]))
    mapping = {old: new for new, (old, _, _) in enumerate(order)}
    new_labels = np.array([mapping[x] for x in labels], dtype=int)
    new_prob = np.zeros_like(prob)
    for old, new in mapping.items():
        new_prob[:, new] = prob[:, old]
    return new_labels, new_prob, mapping


def rook_neighbors(rows, cols):
    rows = np.asarray(rows, int)
    cols = np.asarray(cols, int)
    lookup = {(int(r), int(c)): i for i, (r, c) in enumerate(zip(rows, cols))}
    neigh = []
    for r, c in zip(rows, cols):
        arr = []
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            j = lookup.get((int(r + dr), int(c + dc)))
            if j is not None:
                arr.append(j)
        neigh.append(np.asarray(arr, dtype=int))
    return neigh


def isolated_fraction(labels, neighbors):
    labels = np.asarray(labels, int)
    eligible = 0
    isolated = 0
    for i, nb in enumerate(neighbors):
        if len(nb) < 2:
            continue
        eligible += 1
        vals, cnt = np.unique(labels[nb], return_counts=True)
        j = int(np.argmax(cnt))
        majority = vals[j]
        frac = cnt[j] / len(nb)
        if majority != labels[i] and frac >= 0.75:
            isolated += 1
    return isolated / eligible if eligible else 0.0


def icm_regularize(prob, base_labels, neighbors, lam, max_iter):
    prob = np.clip(np.asarray(prob, float), 1e-15, 1.0)
    logp = np.log(prob)
    K = prob.shape[1]
    lab = np.asarray(base_labels, int).copy()
    for _ in range(int(max_iter)):
        new = lab.copy()
        for i, nb in enumerate(neighbors):
            if len(nb) == 0:
                continue
            counts = np.bincount(lab[nb], minlength=K).astype(float) / len(nb)
            score = logp[i] + float(lam) * counts
            new[i] = int(np.argmax(score))
        changed = np.count_nonzero(new != lab)
        lab = new
        if changed == 0:
            break
    return lab


def weak_spatial_regularization(df, base_labels, prob, cfg, outdir):
    neighbors = rook_neighbors(df["RasterRow"], df["RasterColumn"])
    base_iso = isolated_fraction(base_labels, neighbors)
    base_assigned_p = prob[np.arange(len(prob)), base_labels]
    base_mean_p = float(np.mean(base_assigned_p))
    rows = []

    # Always audit lambda=0.
    rows.append(
        dict(
            Lambda=0.0,
            IsolatedFraction=base_iso,
            IsolationReduction=0.0,
            ChangedFraction=0.0,
            MeanOriginalPosteriorOfAssignedLabel=base_mean_p,
            PosteriorDrop=0.0,
            Eligible=True,
            Selected=False,
        )
    )

    if (not bool(cfg["apply_weak_spatial_regularization"])) or base_iso <= float(
        cfg["isolated_pixel_trigger"]
    ):
        rows[0]["Selected"] = True
        pd.DataFrame(rows).to_csv(
            outdir / "Spatial_Regularization_Audit.csv", index=False
        )
        return base_labels.copy(), 0.0, base_iso

    candidates = []
    for lam in [float(x) for x in cfg["regularization_lambdas"] if float(x) > 0]:
        lab = icm_regularize(
            prob, base_labels, neighbors, lam, int(cfg["regularization_max_iterations"])
        )
        iso = isolated_fraction(lab, neighbors)
        changed = float(np.mean(lab != base_labels))
        assigned_p = prob[np.arange(len(prob)), lab]
        mean_p = float(np.mean(assigned_p))
        drop = base_mean_p - mean_p
        reduction = (base_iso - iso) / base_iso if base_iso > 0 else 0.0
        eligible = (
            reduction >= float(cfg["target_isolation_reduction"])
            and changed <= float(cfg["maximum_changed_fraction"])
            and drop <= float(cfg["maximum_posterior_drop"])
        )
        row = dict(
            Lambda=lam,
            IsolatedFraction=iso,
            IsolationReduction=reduction,
            ChangedFraction=changed,
            MeanOriginalPosteriorOfAssignedLabel=mean_p,
            PosteriorDrop=drop,
            Eligible=bool(eligible),
            Selected=False,
        )
        rows.append(row)
        candidates.append((lam, lab, row))

    valid = [x for x in candidates if x[2]["Eligible"]]
    if valid:
        # Minimal sufficient lambda: preserve the unsmoothed GMM as much as possible.
        lam, final, _ = sorted(valid, key=lambda x: x[0])[0]
    else:
        lam, final = 0.0, base_labels.copy()

    for row in rows:
        if abs(row["Lambda"] - lam) < 1e-12:
            row["Selected"] = True
    pd.DataFrame(rows).to_csv(outdir / "Spatial_Regularization_Audit.csv", index=False)
    return final, lam, isolated_fraction(final, neighbors)


def mechanism_profiles(
    df, final_labels, mean_abs, mean_signed, composition, drivers, outdir
):
    K = int(final_labels.max() + 1)
    summary_rows = []
    long_rows = []
    y = df["Target"].to_numpy(float)
    for k in range(K):
        m = final_labels == k
        n = int(m.sum())
        mean_comp = composition[m].mean(axis=0)
        order = np.argsort(mean_comp)[::-1]
        top = [drivers[j] for j in order[:3]]
        summary_rows.append(
            dict(
                MechanismCluster=k + 1,
                N=n,
                Fraction=n / len(df),
                MeanTarget=float(np.mean(y[m])),
                MedianTarget=float(np.median(y[m])),
                SDTarget=float(np.std(y[m], ddof=1)) if n > 1 else np.nan,
                SubsidenceFraction=float(np.mean(y[m] > 0)),
                UpliftFraction=float(np.mean(y[m] < 0)),
                TopDriver1=top[0],
                TopDriver2=top[1],
                TopDriver3=top[2],
                SuggestedLabel=f"M{k + 1} | {top[0]} + {top[1]} + {top[2]}",
            )
        )
        for j, d in enumerate(drivers):
            long_rows.append(
                dict(
                    MechanismCluster=k + 1,
                    Driver=d,
                    MeanComposition=float(mean_comp[j]),
                    MeanAbsCrossFitSHAP=float(np.mean(mean_abs[m, j])),
                    MeanSignedCrossFitSHAP=float(np.mean(mean_signed[m, j])),
                    MedianComposition=float(np.median(composition[m, j])),
                )
            )
    pd.DataFrame(summary_rows).to_csv(
        outdir / "Mechanism_Cluster_Summary.csv", index=False
    )
    pd.DataFrame(long_rows).to_csv(
        outdir / "Mechanism_Driver_Profile_Long.csv", index=False
    )


def response_mechanism_tables(df, final_labels, masks, outdir):
    y = df["Target"].to_numpy(float)
    K = int(final_labels.max() + 1)
    rows = []
    for k in range(K):
        m = final_labels == k
        for state, sm in (("Subsidence", y > 0), ("Uplift", y < 0), ("Zero", y == 0)):
            n = int(np.sum(m & sm))
            rows.append(
                dict(
                    MechanismCluster=k + 1,
                    ResponseState=state,
                    Count=n,
                    FractionWithinMechanism=n / max(int(np.sum(m)), 1),
                    FractionWithinResponse=n / max(int(np.sum(sm)), 1),
                )
            )
    pd.DataFrame(rows).to_csv(outdir / "Response_Mechanism_Crosstab.csv", index=False)

    # Manual-zone overlap uses rectangle definitions without sign filtering as primary.
    zone_rows = []
    for name, m in masks.items():
        if not name.endswith("_Rectangle"):
            continue
        zone_name = name.replace("_Rectangle", "")
        nzone = int(np.sum(m))
        for k in range(K):
            n = int(np.sum(m & (final_labels == k)))
            zone_rows.append(
                dict(
                    Zone=zone_name,
                    MechanismCluster=k + 1,
                    ZoneN=nzone,
                    ClusterNInZone=n,
                    FractionWithinZone=n / max(nzone, 1),
                    ZoneObservedSubsidenceFraction=float(np.mean(y[m] > 0))
                    if nzone
                    else np.nan,
                    ZoneObservedUpliftFraction=float(np.mean(y[m] < 0))
                    if nzone
                    else np.nan,
                )
            )
    pd.DataFrame(zone_rows).to_csv(
        outdir / "ManualZone_Mechanism_Overlap.csv", index=False
    )


def write_assignment(
    df,
    pred_mean,
    pred_sd,
    mean_signed,
    mean_abs,
    signed_sd,
    shap_cv,
    composition,
    base_labels,
    final_labels,
    prob,
    reg_lambda,
    drivers,
    outdir,
):
    K = prob.shape[1]
    maxp = prob.max(axis=1)
    sorted_p = np.sort(prob, axis=1)
    margin = sorted_p[:, -1] - sorted_p[:, -2] if K > 1 else np.ones(len(prob))
    ent = normalized_entropy(prob)
    y = df["Target"].to_numpy(float)

    A = df[
        [
            "SampleID",
            "PixelIndex",
            "RasterRow",
            "RasterColumn",
            "Longitude",
            "Latitude",
            "Target",
        ]
    ].copy()
    A["CrossFitPrediction"] = pred_mean
    A["PredictionSD"] = pred_sd
    A["Residual"] = pred_mean - y
    A["ResponseState"] = np.where(
        y > 0, "Subsidence", np.where(y < 0, "Uplift", "Zero")
    )
    A["BaseMechanism"] = base_labels + 1
    A["FinalMechanism"] = final_labels + 1
    A["SpatiallyChanged"] = final_labels != base_labels
    A["SelectedSpatialLambda"] = reg_lambda
    A["MaxPosterior"] = maxp
    A["PosteriorMargin"] = margin
    A["NormalizedEntropy"] = ent
    A["MeanSHAPUncertaintyRatio"] = np.mean(shap_cv, axis=1)
    A["MaxSHAPUncertaintyRatio"] = np.max(shap_cv, axis=1)
    for k in range(K):
        A[f"P_M{k + 1}"] = prob[:, k]
    A.to_csv(outdir / "Mechanism_Assignment_Final.csv", index=False)

    # Long per-pixel mechanism fingerprint, useful for later threshold/interaction analysis.
    fp = pd.DataFrame(composition, columns=drivers)
    fp.insert(0, "SampleID", df["SampleID"].to_numpy())
    fp.to_csv(outdir / "Mechanism_Fingerprint_Composition.csv", index=False)


def main(config_file):
    cfg = json.loads(Path(config_file).read_text(encoding="utf-8"))
    outdir = Path(cfg["output_folder"])
    outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(cfg["training_csv"])
    meta = pd.read_csv(cfg["feature_metadata_csv"])
    if df["SampleID"].duplicated().any():
        raise RuntimeError("SampleID must be unique.")

    feature_names = meta["Feature"].astype(str).tolist()
    feature_to_driver = dict(
        zip(meta["Feature"].astype(str), meta["Driver"].astype(str))
    )
    drivers = meta["Driver"].astype(str).drop_duplicates().tolist()
    X = df[feature_names].astype(float)
    y = df["Target"].to_numpy(float)
    if not np.isfinite(X.to_numpy()).all() or not np.isfinite(y).all():
        raise RuntimeError("Model input contains NaN/Inf.")

    print(
        f"Samples={len(df)}; model features={len(feature_names)}; physical drivers={len(drivers)}"
    )
    print(
        f"Hyperparameter mode={cfg['hyperparameter_mode']}; repeats={cfg['n_repeats']}; outer folds={cfg['outer_folds']}"
    )
    device = test_device(bool(cfg["try_gpu"]), int(cfg["random_seed"]))
    print(f"XGBoost device: {device}")

    pred_mean, pred_sd, mean_signed, mean_abs, signed_sd, shap_cv, masks = (
        repeated_crossfit(
            df, X, y, feature_names, feature_to_driver, drivers, cfg, device, outdir
        )
    )
    gate_metrics = metric_dict(y, pred_mean)
    min_r2 = float(cfg.get("minimum_overall_crossfit_r2", -np.inf))
    if (not np.isfinite(gate_metrics["R2"])) or gate_metrics["R2"] < min_r2:
        raise RuntimeError(
            f"Overall repeated cross-fitted R2={gate_metrics['R2']:.4f} is below the pre-specified "
            f"mechanism-explanation gate {min_r2:.4f}. Clustering is stopped to avoid interpreting a poor model."
        )

    print("\n[Composition] CLR/Aitchison transform + PCA...")
    composition, clr, Z, pca, ncomp = clr_embedding(mean_abs, cfg, outdir, drivers)

    print("\n[GMM] Candidate mechanism types...")
    chosen_k, (gmm, raw_labels, raw_prob) = select_gmm_k(Z, cfg, outdir)
    base_labels, prob, mapping = canonicalize_labels(raw_labels, raw_prob)

    map_df = pd.DataFrame(
        {
            "OldGMMLabel0Based": list(mapping.keys()),
            "CanonicalLabel0Based": list(mapping.values()),
        }
    ).sort_values("CanonicalLabel0Based")
    map_df["MechanismCluster"] = map_df["CanonicalLabel0Based"] + 1
    map_df.to_csv(outdir / "GMM_Label_Mapping.csv", index=False)

    print(
        f"\n[Spatial QC] Base GMM K={chosen_k}; weak regularization is optional and constrained..."
    )
    final_labels, reg_lambda, final_iso = weak_spatial_regularization(
        df, base_labels, prob, cfg, outdir
    )
    print(f"Selected lambda={reg_lambda:.3f}; final isolated fraction={final_iso:.4f}")

    write_assignment(
        df,
        pred_mean,
        pred_sd,
        mean_signed,
        mean_abs,
        signed_sd,
        shap_cv,
        composition,
        base_labels,
        final_labels,
        prob,
        reg_lambda,
        drivers,
        outdir,
    )
    mechanism_profiles(
        df, final_labels, mean_abs, mean_signed, composition, drivers, outdir
    )
    response_mechanism_tables(df, final_labels, masks, outdir)

    final_metrics = metric_dict(y, pred_mean)
    protocol = {
        "workflow": "Repeated nested cross-fitted XGBoost-SHAP + absolute-SHAP composition + CLR + GMM",
        "cross_fit": {
            "repeats": int(cfg["n_repeats"]),
            "outer_folds": int(cfg["outer_folds"]),
            "regression_strata_bins": int(cfg["regression_strata_bins"]),
            "hyperparameter_mode": cfg["hyperparameter_mode"],
            "inner_cv_folds": int(cfg["inner_cv_folds"]),
            "random_search_candidates": int(cfg["n_random_search_candidates"]),
        },
        "mechanism_fingerprint": "mean(abs(OOF TreeSHAP)) normalized to composition; signed SHAP excluded from clustering",
        "geometry": "CLR transform / Aitchison compositional geometry, followed by PCA for singularity removal and denoising",
        "clustering": "GaussianMixture soft clustering; coordinates excluded from clustering features",
        "selected_k": int(chosen_k),
        "retained_pcs": int(ncomp),
        "selected_spatial_lambda": float(reg_lambda),
        "actual_response_is_separate_from_mechanism": True,
        "positive_is_subsidence": bool(cfg["positive_is_subsidence"]),
        "overall_crossfit_metrics": final_metrics,
        "device": device,
        "xgboost_version": xgb.__version__,
        "shap_version": shap.__version__,
        "random_seed": int(cfg["random_seed"]),
    }
    (outdir / "Run_Protocol.json").write_text(
        json.dumps(protocol, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    print("\n================ FINAL CROSS-FIT METRICS ================")
    print(json.dumps(final_metrics, indent=2))
    print(f"Selected K = {chosen_k}")
    print(f"Output = {outdir}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python shap_mechanism_v2.py config.json")
    main(sys.argv[1])
