function plot_manual_zone_mechanism_v2(cfg)
T=readtable(fullfile(cfg.pythonOutputFolder,'ManualZone_Mechanism_Overlap.csv'),'VariableNamingRule','preserve');
zones=unique(string(T.Zone),'stable');
clusters=unique(double(T.MechanismCluster),'stable');
P=zeros(numel(zones),numel(clusters));
for i=1:numel(zones)
    for j=1:numel(clusters)
        m=string(T.Zone)==zones(i) & double(T.MechanismCluster)==clusters(j);
        if any(m); P(i,j)=double(T.FractionWithinZone(find(m,1))); end
    end
end
fig=figure('Color','w','Position',[100 100 980 580]);
bar(P*100,'stacked');
set(gca,'XTick',1:numel(zones),'XTickLabel',zones,'FontName','Times New Roman','FontSize',12,'LineWidth',1);
ylabel('Mechanism fraction within zone (%)','FontSize',13); ylim([0 100]); grid on; box on;
legend(compose('M%d',clusters),'Location','eastoutside','Box','off');
title('Mechanism composition of manually defined deformation zones','FontSize',14,'FontWeight','bold');
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_06_ManualZone_Mechanism_Comparison.png'),'Resolution',cfg.figureDPI);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_06_ManualZone_Mechanism_Comparison.tif'),'Resolution',cfg.figureDPI);
if ~zz_show_figures(), close(fig); end
end
