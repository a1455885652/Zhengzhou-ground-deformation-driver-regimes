function plot_gmm_k_selection_v2(cfg)
T=readtable(fullfile(cfg.pythonOutputFolder,'GMM_K_Selection.csv'),'VariableNamingRule','preserve');
K=double(T.K);
fig=figure('Color','w','Position',[80 80 1100 760]);
tl=tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
ax1=nexttile(tl); plot(ax1,K,double(T.BIC),'-o','LineWidth',1.5); hold(ax1,'on'); plot(ax1,K,double(T.ICL),'-s','LineWidth',1.5); xlabel(ax1,'K'); ylabel(ax1,'Criterion'); title(ax1,'(a) BIC and ICL'); legend(ax1,{'BIC','ICL'},'Box','off');
ax2=nexttile(tl); plot(ax2,K,double(T.Silhouette),'-o','LineWidth',1.5); xlabel(ax2,'K'); ylabel(ax2,'Silhouette'); title(ax2,'(b) Silhouette');
ax3=nexttile(tl); errorbar(ax3,K,double(T.StabilityMeanARI),double(T.StabilitySDARI),'-o','LineWidth',1.3); xlabel(ax3,'K'); ylabel(ax3,'ARI'); ylim(ax3,[0 1]); title(ax3,'(c) Subsample stability');
ax4=nexttile(tl); plot(ax4,K,double(T.MedianMaxPosterior),'-o','LineWidth',1.5); xlabel(ax4,'K'); ylabel(ax4,'Median max posterior'); ylim(ax4,[0 1]); title(ax4,'(d) Assignment confidence');
for ax=[ax1 ax2 ax3 ax4]; grid(ax,'on'); box(ax,'on'); set(ax,'FontName','Times New Roman','FontSize',12,'LineWidth',1); end
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_07_GMM_K_Selection.png'),'Resolution',cfg.figureDPI);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_07_GMM_K_Selection.tif'),'Resolution',cfg.figureDPI);
if ~zz_show_figures(), close(fig); end
end
