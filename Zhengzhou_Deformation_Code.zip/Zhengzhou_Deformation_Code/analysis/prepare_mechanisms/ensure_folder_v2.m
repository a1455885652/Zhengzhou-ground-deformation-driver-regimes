function ensure_folder_v2(folderPath)
if ~exist(folderPath,'dir')
    [ok,msg] = mkdir(folderPath);
    if ~ok
        error('Cannot create folder: %s\n%s',folderPath,msg);
    end
end
end
