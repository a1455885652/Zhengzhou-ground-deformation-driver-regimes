function out = pretty_driver_name_v2(in)
in = string(in);
out = in;
for i=1:numel(in)
    s = in(i);
    switch lower(s)
        case 'skinreservoir'; out(i) = "Skin reservoir";
        case 'subsurfacerunoff'; out(i) = "Subsurface runoff";
        case 'surfacerunoff'; out(i) = "Surface runoff";
        case 'totalprecipitation'; out(i) = "Total precipitation";
        case 'nighttimelight'; out(i) = "Nighttime light";
        case 'builtsurface'; out(i) = "Built surface";
        case 'totalloosethickness'; out(i) = "Loose-layer thickness";
        case 'roaddensity'; out(i) = "Road density";
        case 'glhymps_permeability'; out(i) = "Permeability";
        otherwise; out(i) = s;
    end
end
end
