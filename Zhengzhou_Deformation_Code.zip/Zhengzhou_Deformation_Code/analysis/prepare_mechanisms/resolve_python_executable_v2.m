function executable = resolve_python_executable_v2(preferred)
% Resolve the interpreter from the shared project configuration.
executable = zz_python_executable();
end
