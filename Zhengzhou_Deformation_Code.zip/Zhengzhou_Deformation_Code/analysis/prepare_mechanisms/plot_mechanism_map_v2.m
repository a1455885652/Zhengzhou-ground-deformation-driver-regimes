function plot_mechanism_map_v2(cfg)
T = readtable(fullfile(cfg.pythonOutputFolder,'Mechanism_Assignment_Final.csv'),'VariableNamingRule','preserve');
K = max(double(T.FinalMechanism));
fig = figure('Color','w','Position',[100 80 980 760]);
scatter(double(T.Longitude),double(T.Latitude),22,double(T.FinalMechanism),'filled','MarkerEdgeColor','none');
axis equal tight; box on; grid on;
colormap(lines(K)); cb = colorbar; cb.Ticks = 1:K; cb.TickLabels = compose('M%d',1:K);
xlabel('Longitude (°E)','FontName','Times New Roman','FontSize',13);
ylabel('Latitude (°N)','FontName','Times New Roman','FontSize',13);
title('SHAP-derived driving mechanism types (V2)','FontName','Times New Roman','FontSize',14,'FontWeight','bold');
set(gca,'FontName','Times New Roman','FontSize',12,'LineWidth',1);
hold on;
draw_manual_boxes_v2(gca,cfg);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_02_Mechanism_Map.png'),'Resolution',cfg.figureDPI);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_02_Mechanism_Map.tif'),'Resolution',cfg.figureDPI);
if ~zz_show_figures(), close(fig); end
end
