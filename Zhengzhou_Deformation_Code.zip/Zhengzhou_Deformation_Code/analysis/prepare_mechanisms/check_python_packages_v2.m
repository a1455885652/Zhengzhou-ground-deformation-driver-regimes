function check_python_packages_v2(pythonExe)
% Report dependency errors without installing or switching interpreters.
zz_check_python();
end
