function plot_crossfit_performance_v2(cfg)
T = readtable(fullfile(cfg.pythonOutputFolder,'CrossFit_OOF_Predictions.csv'),'VariableNamingRule','preserve');
y = double(T.Target); p = double(T.CrossFitPrediction);
R2 = 1-sum((y-p).^2)/sum((y-mean(y)).^2);
RMSE = sqrt(mean((p-y).^2)); MAE = mean(abs(p-y));
lo = min([y;p]); hi = max([y;p]);
fig = figure('Color','w','Position',[100 100 760 650]);
scatter(y,p,12,'filled','MarkerFaceAlpha',0.25,'MarkerEdgeAlpha',0.05); hold on;
plot([lo hi],[lo hi],'k--','LineWidth',1.2);
xlabel('Observed deformation rate (mm yr^{-1})','FontSize',13,'FontName','Times New Roman');
ylabel('Cross-fitted prediction (mm yr^{-1})','FontSize',13,'FontName','Times New Roman');
title('Repeated cross-fitted prediction performance','FontSize',14,'FontWeight','bold','FontName','Times New Roman');
text(0.04,0.95,sprintf('R^2 = %.3f\nRMSE = %.2f mm yr^{-1}\nMAE = %.2f mm yr^{-1}',R2,RMSE,MAE), ...
    'Units','normalized','VerticalAlignment','top','FontSize',12,'FontName','Times New Roman');
axis square; grid on; box on; set(gca,'FontName','Times New Roman','FontSize',12,'LineWidth',1);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_01_CrossFit_Performance.png'),'Resolution',cfg.figureDPI);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_01_CrossFit_Performance.tif'),'Resolution',cfg.figureDPI);
if ~zz_show_figures(), close(fig); end
end
