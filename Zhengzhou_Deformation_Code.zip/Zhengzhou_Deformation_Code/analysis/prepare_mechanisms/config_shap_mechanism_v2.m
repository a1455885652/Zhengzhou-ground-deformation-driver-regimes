function cfg = config_shap_mechanism_v2()
% CONFIG_SHAP_MECHANISM_V2
% 郑州市地表形变驱动机制分区 V2：
% Repeated nested cross-fitted XGBoost-SHAP + absolute-SHAP composition
% + CLR/Aitchison geometry + GMM soft clustering + optional weak spatial regularization.
%
% MATLAB R2023b。所有函数必须分别保存在独立 .m 文件中。
% 符号约定：正值 = 沉降；负值 = 抬升。

projectDir = fileparts(mfilename('fullpath'));

%% Python
cfg.pythonExe = zz_python_executable();
cfg.pythonScript = fullfile(projectDir,'shap_mechanism_v2.py');

%% 原始/已准备数据
cfg.latestVelocityFile = ...
    zz_project_path('InSAR_1km_latest_irregular_shape/04_Velocity_1km/InSAR_Velocity_1km.tif');

cfg.latestVelocitySourceCountFile = ...
    zz_project_path('InSAR_1km_latest_irregular_shape/04_Velocity_1km/InSAR_Velocity_1km_SourcePixelCount.tif');

cfg.maskFile = ...
    zz_project_path('yanmo/Zhengzhou_mask_1km.tif');

cfg.preparedMat = ...
    zz_project_path('LongTerm_Variable_Screening_Output/Variable_Screening_Results.mat');

cfg.annualRoadFolder = ...
    zz_project_path('RoadDensity_1km/Annual/FormalRoad');
cfg.roadYears = (2018:2025)';

%% 固定最终驱动变量（与主论文 ReferenceSimple 完全一致）
cfg.finalPreparedFeatures = [ ...
    "NDVI_Trend"
    "SkinReservoir_Trend"
    "SubsurfaceRunoff_Trend"
    "SurfaceRunoff_Trend"
    "TotalPrecipitation_Trend"
    "GWS_Trend"
    "NighttimeLight_Trend"
    "Population_Trend"
    "BuiltSurface"
    "DEM"
    "GLHYMPS_Permeability"
    "Silt"
    "TotalLooseThickness"];

%% 人工典型区，仅用于事后诊断，不参与模型训练或机制聚类
% [LonMin LonMax LatMin LatMax]
cfg.subsidenceBoxes = [ ...
    113.460 113.760 34.660 34.840
    113.698 113.871 34.484 34.606];

cfg.upliftBoxes = [ ...
    112.777 113.094 34.709 34.891
    112.702 112.942 34.276 34.512
    113.893 114.182 34.583 34.971];

cfg.positiveIsSubsidence = true;

%% Repeated cross-fitting
% 每个样本每次重复恰好作为一次 outer-test，因此每个样本最终有 nRepeats 套 OOF SHAP。
cfg.nRepeats = 10;
cfg.outerFolds = 5;
cfg.regressionStrataBins = 10;
cfg.randomSeed = 20260906;

% 严格默认：每个 outer fold 内部重新调参，不使用 outer-test 信息。
cfg.hyperparameterMode = 'nested';
cfg.innerCVFolds = 3;
cfg.nRandomSearchCandidates = 10;
cfg.tryGPU = true;

% 若后续仅用于快速调试，可临时改成 'locked'；正式结果请保持 'nested'。
cfg.lockedParams = struct( ...
    'subsample',0.90, ...
    'reg_lambda',2.0, ...
    'reg_alpha',0.0, ...
    'n_estimators',800, ...
    'min_child_weight',3, ...
    'max_depth',6, ...
    'learning_rate',0.06, ...
    'gamma',0.05, ...
    'colsample_bytree',0.85);

%% 机制指纹与 GMM
% 组成数据使用 mean(|OOF SHAP|)，不是 abs(mean signed SHAP)。
cfg.compositionPseudoFraction = 1e-6;
cfg.pcaExplainedVariance = 0.95;
cfg.gmmKMin = 2;
cfg.gmmKMax = 8;
cfg.gmmNInit = 20;
cfg.gmmMaxIter = 1000;
cfg.gmmRegCovar = 1e-4;

% K选择约束
cfg.minimumClusterFraction = 0.03;
cfg.minimumStabilityARI = 0.75;
cfg.minimumMedianPosterior = 0.60;
cfg.gmmStabilityReplicates = 20;
cfg.gmmStabilitySampleFraction = 0.80;

%% 弱空间正则化（绝不要求类别整体空间连续）
% 只有基础GMM结果存在较多孤立椒盐像元时才尝试。
cfg.applyWeakSpatialRegularization = true;
cfg.isolatedPixelTrigger = 0.03;
cfg.regularizationLambdas = [0 0.15 0.30 0.50 0.75 1.00];
cfg.regularizationMaxIterations = 8;
cfg.targetIsolationReduction = 0.50;
cfg.maximumChangedFraction = 0.10;
cfg.maximumPosteriorDrop = 0.03;

%% 质量控制
cfg.minimumVelocitySourcePixels = 1;
cfg.minimumLatestTargetCoverageOnPreparedSupport = 0.95;
% 若 repeated cross-fitted overall R2 低于该值，停止机制聚类，避免解释低质量模型。
cfg.minimumOverallCrossFitR2 = 0.60;

%% 输出
cfg.outputRoot = zz_project_path('SHAP_Mechanism_Zoning_V2_Output');
cfg.pythonOutputFolder = fullfile(cfg.outputRoot,'Python_Output');
cfg.figureFolder = fullfile(cfg.outputRoot,'Paper_Figures');
cfg.rasterFolder = fullfile(cfg.outputRoot,'Rasters');

cfg.trainingCsv = fullfile(cfg.outputRoot,'CrossFit_Model_Data.csv');
cfg.featureMetadataCsv = fullfile(cfg.outputRoot,'Feature_Metadata.csv');
cfg.inputAuditCsv = fullfile(cfg.outputRoot,'Input_Audit.csv');
cfg.roadFilesCsv = fullfile(cfg.outputRoot,'RoadDensity_Files_Used.csv');
cfg.roadMeanRaster = fullfile(cfg.outputRoot,'RoadDensity_Mean_2018_2025.tif');
cfg.pythonConfigJson = fullfile(cfg.outputRoot,'shap_mechanism_v2_config.json');

cfg.figureDPI = 600;
end
