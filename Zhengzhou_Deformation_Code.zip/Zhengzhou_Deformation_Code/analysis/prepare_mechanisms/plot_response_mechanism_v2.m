function plot_response_mechanism_v2(cfg)
T = readtable(fullfile(cfg.pythonOutputFolder,'Mechanism_Assignment_Final.csv'),'VariableNamingRule','preserve');
K=max(double(T.FinalMechanism));
P=zeros(K,2);
for k=1:K
    m=double(T.FinalMechanism)==k;
    n=nnz(m);
    if n>0
        P(k,1)=nnz(m & double(T.Target)>0)/n;
        P(k,2)=nnz(m & double(T.Target)<0)/n;
    end
end
fig=figure('Color','w','Position',[120 120 850 560]);
b=bar(1:K,P*100,'stacked');
b(1).FaceColor=[0.85 0.35 0.30]; b(2).FaceColor=[0.30 0.50 0.85];
set(gca,'XTick',1:K,'XTickLabel',compose('M%d',1:K),'FontName','Times New Roman','FontSize',12,'LineWidth',1);
ylabel('Fraction within mechanism (%)','FontSize',13); xlabel('Mechanism type','FontSize',13); ylim([0 100]); grid on; box on;
legend({'Subsidence (Target>0)','Uplift (Target<0)'},'Location','eastoutside','Box','off');
title('Actual deformation response within each mechanism type','FontWeight','bold','FontSize',14);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_05_Response_Mechanism_Composition.png'),'Resolution',cfg.figureDPI);
exportgraphics(fig,fullfile(cfg.figureFolder,'Fig_05_Response_Mechanism_Composition.tif'),'Resolution',cfg.figureDPI);
if ~zz_show_figures(), close(fig); end
end
