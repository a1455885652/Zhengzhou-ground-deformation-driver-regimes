function plot_ale_threshold_mechanism_comparison(cfg)

manifestFile = fullfile(cfg.thresholdDir, 'ALE_Curve_Manifest.csv');
if ~exist(manifestFile,'file')
    error('Missing %s', manifestFile);
end

M = readtable(manifestFile,'TextType','string','VariableNamingRule','preserve');

drivers = string(cfg.thresholdDrivers);
regions = ["All","M1","M2","M3","M4"];

colors = [ ...
    0.10 0.10 0.10; ...
    0.27 0.47 0.70; ...
    0.91 0.62 0.18; ...
    0.34 0.66 0.42; ...
    0.63 0.39 0.74];

f = figure('Color','w','Position',[80 50 1550 930]);
t = tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');
legendHandles = gobjects(numel(regions),1);

for d = 1:numel(drivers)
    ax = nexttile(t,d);
    hold(ax,'on');

    for r = 1:numel(regions)
        z = M(M.Region==regions(r) & M.Driver==drivers(d),:);
        if isempty(z)
            continue;
        end
        C = readtable(char(z.CurveFile(1)), 'TextType','string','VariableNamingRule','preserve');
        h = plot(ax,C.XCenter,C.ALE,'-','LineWidth',1.7,'Color',colors(r,:));
        if d == 1
            legendHandles(r) = h;
        end
    end

    yline(ax,0,'--','Color',[0.55 0.55 0.55],'LineWidth',0.7, ...
        'HandleVisibility','off');
    xlabel(ax,char(pretty_driver_name_ale(drivers(d))));
    ylabel(ax,'ALE effect (mm yr^{-1})');
    title(ax,sprintf('(%c) %s',96+d,char(pretty_driver_name_ale(drivers(d)))), ...
        'FontWeight','bold');
    set(ax,'FontName',cfg.fontName,'FontSize',cfg.fontSize,'LineWidth',1.0);
    grid(ax,'on'); ax.GridAlpha=0.10; box(ax,'on');
end

valid = isgraphics(legendHandles);
if any(valid)
    lgd = legend(legendHandles(valid),cellstr(regions(valid)), ...
        'Location','southoutside','Orientation','horizontal','Box','off');
    lgd.FontName=cfg.fontName;
    lgd.FontSize=cfg.fontSize;
end

title(t,'Mechanism-specific ALE response curves from the same global XGBoost model', ...
    'FontName',cfg.fontName,'FontSize',15,'FontWeight','bold');

exportgraphics(f,fullfile(cfg.figureDir,'Fig_ALE_Mechanism_Comparison.png'), ...
    'Resolution',cfg.figureDPI);
exportgraphics(f,fullfile(cfg.figureDir,'Fig_ALE_Mechanism_Comparison.pdf'));
if ~zz_show_figures(), close(f); end

end
