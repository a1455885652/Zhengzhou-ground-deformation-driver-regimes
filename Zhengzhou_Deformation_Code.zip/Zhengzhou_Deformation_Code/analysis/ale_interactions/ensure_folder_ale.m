function ensure_folder_ale(folderPath)

if ~exist(folderPath, 'dir')
    mkdir(folderPath);
end

end
