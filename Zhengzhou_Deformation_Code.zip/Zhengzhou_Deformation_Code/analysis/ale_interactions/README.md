# ALE 与交互作用

读取保存的模型，计算 ALE 曲线、转折位置、区间、分区差异和交互曲面。

| 项目 | 内容 |
|---|---|
| 输入 | 模型输入表、模型 JSON、元数据、最佳参数及 K=4 归属表，均已附带。 |
| 输出 | `project_root/K4_ALE_Threshold_Interaction_Output_v1_5` |
| 设置 | config_ale_threshold_interaction_v1_5.m；../../config/experiments/ale_interactions.json |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('ale_interactions')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。

Python 可分阶段调用 `ale_inputcheck`、`ale_realdatasmoke`、`ale_selftest`、`ale_threshold` 和 `ale_interaction`。三个检查入口写入 `outputs/checks`，不替换正式结果；正式计算仍使用原设置。现稿绘图请调用 `run_figure` 中的图 14、15、S6 和 S7，旧的自动输出图仅作过程检查。
