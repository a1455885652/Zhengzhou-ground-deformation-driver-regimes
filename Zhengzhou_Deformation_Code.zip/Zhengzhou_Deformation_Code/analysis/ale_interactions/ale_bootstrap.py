from __future__ import annotations

import json
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb

from ale_1d import compute_ale_1d, integrate_local_effects
from threshold_segmented import fit_segmented_thresholds, match_breakpoints


def sample_block_indices(indices, block_ids, rng):
    indices = np.asarray(indices, int)
    block_ids = np.asarray(block_ids)

    unique_blocks = np.unique(block_ids[indices])
    sampled = rng.choice(unique_blocks, size=len(unique_blocks), replace=True)

    out = []
    for b in sampled:
        out.append(indices[block_ids[indices] == b])

    return np.concatenate(out)


def fixed_model_bootstrap(
    booster,
    X,
    feature_names,
    feature,
    region_indices,
    block_ids,
    baseline_ale,
    baseline_threshold,
    cfg,
    seed,
):
    """Fast spatial bootstrap for a frozen model.

    The expensive model finite differences are computed once in baseline_ale.
    Bootstrap replicates only resample spatial blocks and re-aggregate the
    already-computed sample-level local finite differences. This is exactly
    equivalent to recomputing fixed-model ALE with the same fixed bin edges,
    while avoiding thousands of redundant XGBoost predictions.
    """
    B = int(cfg["fixed_model_bootstrap_reps"])
    K = len(baseline_ale["x_center"])

    effects = np.full((B, K), np.nan, float)
    models = np.full(B, -1, int)
    bp1 = np.full(B, np.nan, float)
    bp2 = np.full(B, np.nan, float)
    delta_bic = np.full(B, np.nan, float)

    region_indices = np.asarray(region_indices, int)
    region_blocks = np.asarray(block_ids)[region_indices]
    bin_index = np.asarray(baseline_ale["sample_bin_index"], int)
    sample_delta = np.asarray(baseline_ale["sample_delta"], float)
    sample_x = np.asarray(baseline_ale["sample_x"], float)

    if not (len(bin_index) == len(sample_delta) == len(region_indices)):
        raise RuntimeError("Baseline ALE sample arrays do not match region support.")

    unique_blocks = np.unique(region_blocks)
    block_positions = {b: np.where(region_blocks == b)[0] for b in unique_blocks}

    rng = np.random.default_rng(seed)

    for rep in range(B):
        sampled_blocks = rng.choice(
            unique_blocks, size=len(unique_blocks), replace=True
        )
        pos = np.concatenate([block_positions[b] for b in sampled_blocks])

        bins = bin_index[pos]
        ds = sample_delta[pos]
        xs = sample_x[pos]

        counts = np.bincount(bins, minlength=K).astype(int)
        local = np.full(K, np.nan, float)
        centers = np.asarray(baseline_ale["x_center"], float).copy()

        for k in range(K):
            z = bins == k
            if z.any():
                centers[k] = float(np.median(xs[z]))
            if z.sum() >= int(cfg["ale_bootstrap_min_bin_count"]):
                local[k] = float(np.mean(ds[z]))

        missing = ~np.isfinite(local)
        if missing.any():
            valid = np.where(~missing)[0]
            if len(valid) < max(3, K - 2):
                continue
            local[missing] = np.interp(np.where(missing)[0], valid, local[valid])

        effect = integrate_local_effects(local, counts)

        try:
            fit = fit_segmented_thresholds(
                x=centers,
                y=effect,
                weights=np.maximum(counts, 1),
                support_x=xs,
                search_quantile=tuple(cfg["threshold_search_quantile"]),
                min_segment_bins=int(cfg["threshold_min_segment_bins"]),
                allow_two=bool(cfg["allow_two_breakpoints"]),
            )
        except Exception:
            continue

        effects[rep, :] = effect
        models[rep] = int(fit["model"])
        delta_bic[rep] = float(fit["delta_bic_vs_null"])
        if len(fit["breakpoints"]) >= 1:
            bp1[rep] = fit["breakpoints"][0]
        if len(fit["breakpoints"]) >= 2:
            bp2[rep] = fit["breakpoints"][1]

    valid_rows = np.isfinite(effects).all(axis=1)
    min_required = min(B, max(3, int(np.ceil(0.5 * B))))
    if valid_rows.sum() < min_required:
        raise RuntimeError(
            f"Too few valid fixed-model bootstrap replicates: "
            f"{valid_rows.sum()} / {B}; minimum required={min_required}"
        )

    e = effects[valid_rows]
    main_bps = baseline_threshold["breakpoints"]
    matched = np.full((valid_rows.sum(), len(main_bps)), np.nan, float)

    rr = np.where(valid_rows)[0]
    for ii, r in enumerate(rr):
        rep_bps = [v for v in [bp1[r], bp2[r]] if np.isfinite(v)]
        matched[ii] = match_breakpoints(
            main_bps, rep_bps, baseline_threshold["x_range"]
        )

    return {
        "valid_reps": int(valid_rows.sum()),
        "effects": e,
        "models": models[valid_rows],
        "delta_bic": delta_bic[valid_rows],
        "matched_breakpoints": matched,
        "ci95_low": np.nanpercentile(e, 2.5, axis=0),
        "ci95_high": np.nanpercentile(e, 97.5, axis=0),
        "ci90_low": np.nanpercentile(e, 5, axis=0),
        "ci90_high": np.nanpercentile(e, 95, axis=0),
    }


def detect_device(try_gpu, seed):
    if not try_gpu:
        return "cpu"

    try:
        rng = np.random.default_rng(seed)
        X = rng.normal(size=(30, 4))
        y = rng.normal(size=30)
        m = xgb.XGBRegressor(
            n_estimators=4,
            max_depth=2,
            tree_method="hist",
            device="cuda",
            objective="reg:squarederror",
            random_state=seed,
            verbosity=0,
        )
        m.fit(X, y)
        _ = m.predict(X[:2])
        return "cuda"
    except Exception:
        return "cpu"


def fit_refit_model(X, y, best_params, device, seed):
    kw = dict(best_params)
    kw.update(
        {
            "objective": "reg:squarederror",
            "eval_metric": "rmse",
            "tree_method": "hist",
            "random_state": int(seed),
            "verbosity": 0,
            "n_jobs": 1 if device == "cuda" else -1,
        }
    )
    if device == "cuda":
        kw["device"] = "cuda"

    model = xgb.XGBRegressor(**kw)
    model.fit(X, y)
    return model


def _validate_refit_checkpoint(path, expected_pairs):
    try:
        T = pd.read_csv(path)
    except Exception:
        return False
    required = {"Region", "Driver", "Model", "DeltaBIC", "Breakpoint1", "Breakpoint2"}
    if not required.issubset(T.columns):
        return False
    if len(T) == 0:
        return False
    keys = set(zip(T["Region"].astype(str), T["Driver"].astype(str)))
    # A replicate may legitimately omit a region-driver only if regional support
    # falls below the formal minimum. It must nevertheless contain most formal pairs.
    if len(keys) < max(1, int(0.80 * len(expected_pairs))):
        return False
    if T[["Model"]].isna().any().any():
        return False
    return True


def run_refit_bootstrap(
    cfg,
    data,
    baseline_records,
):
    reps = int(cfg["refit_bootstrap_reps"])
    checkpoint_dir = Path(cfg["checkpoint_dir"]) / "Refit"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)

    # Protect resumable checkpoints from accidental reuse after the user
    # changes the model, confidence support, block definition, driver list,
    # or bootstrap count.
    model_hash = hashlib.sha256(Path(cfg["final_model_json"]).read_bytes()).hexdigest()
    params_hash = hashlib.sha256(Path(cfg["best_params_json"]).read_bytes()).hexdigest()
    training_hash = hashlib.sha256(Path(cfg["training_csv"]).read_bytes()).hexdigest()
    k4_hash = hashlib.sha256(Path(cfg["k4_assignment_csv"]).read_bytes()).hexdigest()
    signature_payload = {
        "project_version": cfg.get("project_version", ""),
        "model_sha256": model_hash,
        "best_params_sha256": params_hash,
        "training_csv_sha256": training_hash,
        "k4_assignment_sha256": k4_hash,
        "primary_mechanism_confidence": cfg["primary_mechanism_confidence"],
        "spatial_block_pixels": cfg["spatial_block_pixels"],
        "threshold_drivers": cfg["threshold_drivers"],
        "refit_bootstrap_reps": reps,
    }
    signature_text = json.dumps(signature_payload, sort_keys=True)
    signature_payload["signature"] = hashlib.sha256(
        signature_text.encode("utf-8")
    ).hexdigest()
    manifest_file = checkpoint_dir / "Refit_Checkpoint_Manifest.json"
    if manifest_file.exists():
        old_manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
        if old_manifest.get("signature") != signature_payload["signature"]:
            raise RuntimeError(
                "Existing refit checkpoints were created under a different "
                "formal configuration. Delete the Refit checkpoint folder "
                f"{checkpoint_dir} before rerunning."
            )
    else:
        manifest_file.write_text(
            json.dumps(signature_payload, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    X = data["X"]
    y = data["y"]
    assignment = data["assignment"]
    feature_names = data["feature_names"]

    all_idx = np.arange(len(X))
    block_ids = assignment["SpatialBlockID"].to_numpy()

    with open(cfg["best_params_json"], "r", encoding="utf-8") as f:
        best_params = json.load(f)

    device = detect_device(bool(cfg["try_gpu"]), int(cfg["random_seed"]))
    print(f"[Refit bootstrap] device={device}")

    for rep in range(reps):
        out_file = checkpoint_dir / f"refit_{rep + 1:04d}.csv"
        expected_pairs = {(rec["region"], rec["driver"]) for rec in baseline_records}
        if out_file.exists():
            if _validate_refit_checkpoint(out_file, expected_pairs):
                continue
            print(
                f"[Refit bootstrap] invalid checkpoint will be recomputed: {out_file.name}"
            )
            try:
                out_file.unlink()
            except OSError:
                pass

        rep_rng = np.random.default_rng(int(cfg["random_seed"]) + 8000 + rep)
        sampled_idx = sample_block_indices(all_idx, block_ids, rep_rng)

        model = fit_refit_model(
            X.iloc[sampled_idx],
            y[sampled_idx],
            best_params,
            device,
            int(cfg["random_seed"]) + 10000 + rep,
        )

        booster = model.get_booster()
        rows = []

        sampled_mech = assignment.iloc[sampled_idx].reset_index(drop=True)
        Xs = X.iloc[sampled_idx].reset_index(drop=True)

        for rec in baseline_records:
            region = rec["region"]
            driver = rec["driver"]
            feature = rec["feature"]
            edges = rec["edges"]

            if region == "All":
                mask = np.ones(len(Xs), dtype=bool)
            else:
                m = int(region[1:])
                mask = (sampled_mech["Mechanism"].to_numpy(int) == m) & (
                    sampled_mech["MaxPosterior"].to_numpy(float)
                    >= float(cfg["primary_mechanism_confidence"])
                )

            if mask.sum() < 100:
                continue

            Xr = Xs.loc[mask, feature_names]

            try:
                ale = compute_ale_1d(
                    booster=booster,
                    X=Xr,
                    feature_names=feature_names,
                    feature=feature,
                    target_bins=len(edges) - 1,
                    minimum_bins=int(cfg["ale_minimum_bins"]),
                    min_bin_count=int(cfg["ale_bootstrap_min_bin_count"]),
                    fixed_edges=edges,
                )

                fit = fit_segmented_thresholds(
                    x=ale["x_center"],
                    y=ale["ale"],
                    weights=np.maximum(ale["count"], 1),
                    support_x=Xr[feature].to_numpy(float),
                    search_quantile=tuple(cfg["threshold_search_quantile"]),
                    min_segment_bins=int(cfg["threshold_min_segment_bins"]),
                    allow_two=bool(cfg["allow_two_breakpoints"]),
                )

                rows.append(
                    {
                        "Region": region,
                        "Driver": driver,
                        "Model": fit["model"],
                        "DeltaBIC": fit["delta_bic_vs_null"],
                        "Breakpoint1": fit["breakpoints"][0]
                        if len(fit["breakpoints"]) > 0
                        else np.nan,
                        "Breakpoint2": fit["breakpoints"][1]
                        if len(fit["breakpoints"]) > 1
                        else np.nan,
                    }
                )
            except Exception:
                rows.append(
                    {
                        "Region": region,
                        "Driver": driver,
                        "Model": -1,
                        "DeltaBIC": np.nan,
                        "Breakpoint1": np.nan,
                        "Breakpoint2": np.nan,
                    }
                )

        pd.DataFrame(rows).to_csv(out_file, index=False)

        if (rep + 1) % 10 == 0 or rep == 0:
            print(f"[Refit bootstrap] completed {rep + 1}/{reps}")

    return device


def aggregate_refit_bootstrap(cfg, baseline_records):
    checkpoint_dir = Path(cfg["checkpoint_dir"]) / "Refit"
    reps = int(cfg["refit_bootstrap_reps"])
    files = [checkpoint_dir / f"refit_{i + 1:04d}.csv" for i in range(reps)]

    missing = [str(f) for f in files if not f.exists()]
    if missing:
        raise RuntimeError(
            f"Missing {len(missing)} expected refit bootstrap checkpoints."
        )

    expected_pairs = {(rec["region"], rec["driver"]) for rec in baseline_records}
    all_tables = []
    for f in files:
        if not _validate_refit_checkpoint(f, expected_pairs):
            raise RuntimeError(f"Invalid refit bootstrap checkpoint after run: {f}")
        t = pd.read_csv(f)
        t["ReplicateFile"] = f.name
        all_tables.append(t)

    D = pd.concat(all_tables, ignore_index=True)

    out = {}

    for rec in baseline_records:
        key = (rec["region"], rec["driver"])
        main_bps = rec["threshold"]["breakpoints"]
        q = D[(D.Region == rec["region"]) & (D.Driver == rec["driver"])]

        matched = np.full((len(q), len(main_bps)), np.nan, float)

        for ii, (_, r) in enumerate(q.iterrows()):
            rep = [v for v in [r.Breakpoint1, r.Breakpoint2] if np.isfinite(v)]
            matched[ii] = match_breakpoints(main_bps, rep, rec["threshold"]["x_range"])

        out[key] = {
            "valid_reps": int(len(q)),
            "matched_breakpoints": matched,
            "replicate_ids": q["ReplicateFile"].astype(str).to_numpy(),
            "segmented_frequency": float(np.mean(q.Model.to_numpy() > 0))
            if len(q)
            else np.nan,
        }

    return out
