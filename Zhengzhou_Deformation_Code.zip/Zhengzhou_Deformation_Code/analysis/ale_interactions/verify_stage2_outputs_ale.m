function verify_stage2_outputs_ale(cfg)

required = { ...
    fullfile(cfg.interactionDir, 'SHAP_Interaction_Strength.csv'), ...
    fullfile(cfg.interactionDir, 'SHAP_Interaction_SampleValues.csv'), ...
    fullfile(cfg.interactionDir, 'ALE2D_Surface_Manifest.csv'), ...
    fullfile(cfg.interactionDir, 'ExactInteraction_Audit.json') ...
    };

for i = 1:numel(required)
    if ~exist(required{i}, 'file')
        error('Stage 2 missing expected output: %s', required{i});
    end
end

T = readtable(fullfile(cfg.interactionDir, 'SHAP_Interaction_Strength.csv'), ...
    'TextType','string', 'VariableNamingRule','preserve');
expectedRows = 5 * size(cfg.interactionPairs,1);
if height(T) ~= expectedRows
    error('Interaction summary row count mismatch: got %d, expected %d.', ...
        height(T), expectedRows);
end

M = readtable(fullfile(cfg.interactionDir, 'ALE2D_Surface_Manifest.csv'), ...
    'TextType','string', 'VariableNamingRule','preserve');
if height(M) ~= size(cfg.ale2dTargets,1)
    error('2D ALE manifest row count mismatch.');
end

fprintf('Stage 2 interaction summary rows: %d\n', height(T));
if ismember('Status', M.Properties.VariableNames)
    fprintf('Stage 2 successful 2D ALE targets: %d/%d\n', ...
        sum(M.Status == "OK"), height(M));
end

end
