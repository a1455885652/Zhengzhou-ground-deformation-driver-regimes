function plot_ale_threshold_wholearea(cfg)

manifestFile = fullfile(cfg.thresholdDir, 'ALE_Curve_Manifest.csv');
breakFile = fullfile(cfg.thresholdDir, 'ALE_Threshold_Breakpoints.csv');

if ~exist(manifestFile,'file')
    error('Missing %s', manifestFile);
end

M = readtable(manifestFile, 'TextType','string','VariableNamingRule','preserve');
B = readtable(breakFile, 'TextType','string','VariableNamingRule','preserve');

drivers = string(cfg.thresholdDrivers);

f = figure('Color','w','Position',[80 60 1500 900]);
t = tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');

for i = 1:numel(drivers)
    ax = nexttile(t,i);
    hold(ax,'on');

    r = M(M.Region=="All" & M.Driver==drivers(i),:);
    if isempty(r)
        axis(ax,'off');
        continue;
    end

    C = readtable(char(r.CurveFile(1)), 'TextType','string','VariableNamingRule','preserve');

    fill(ax, ...
        [C.XCenter; flipud(C.XCenter)], ...
        [C.CI95_Low; flipud(C.CI95_High)], ...
        [0.88 0.88 0.88], ...
        'EdgeColor','none', ...
        'FaceAlpha',0.75);

    plot(ax,C.XCenter,C.ALE,'k-','LineWidth',2.0);
    yline(ax,0,'--','Color',[0.45 0.45 0.45],'LineWidth',0.8);

    bp = B(B.Region=="All" & B.Driver==drivers(i) & ...
        (B.ThresholdClass=="RobustThreshold" | B.ThresholdClass=="SupportedThreshold"),:);

    for k = 1:height(bp)
        if bp.ThresholdClass(k)=="RobustThreshold"
            ls = '-';
            lw = 1.5;
        else
            ls = '--';
            lw = 1.3;
        end
        xline(ax,bp.Threshold(k),ls,'LineWidth',lw,'Color',[0.70 0.10 0.10]);
    end

    xlabel(ax,char(pretty_driver_name_ale(drivers(i))));
    ylabel(ax,'ALE effect (mm yr^{-1})');
    title(ax,sprintf('(%c) %s',96+i,char(pretty_driver_name_ale(drivers(i)))), ...
        'FontWeight','bold');

    set(ax,'FontName',cfg.fontName,'FontSize',cfg.fontSize,'LineWidth',1.0);
    grid(ax,'on'); ax.GridAlpha=0.12; box(ax,'on');
end

title(t,'Whole-area nonlinear model-response curves and detected thresholds', ...
    'FontName',cfg.fontName,'FontSize',15,'FontWeight','bold');

exportgraphics(f,fullfile(cfg.figureDir,'Fig_ALE_WholeArea_6Drivers.png'), ...
    'Resolution',cfg.figureDPI);
exportgraphics(f,fullfile(cfg.figureDir,'Fig_ALE_WholeArea_6Drivers.pdf'));
if ~zz_show_figures(), close(f); end

end
