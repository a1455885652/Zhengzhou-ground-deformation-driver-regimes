clearvars -except cfg;
if exist('cfg','var')
    cfg = ensure_current_ale_config_v1_5(cfg);
else
    cfg = ensure_current_ale_config_v1_5([]);
end
fprintf('\n[REAL-DATA SMOKE TEST v1.5]\n');
ensure_folder_ale(cfg.outputRoot);
ensure_folder_ale(cfg.configDir);
configFile = fullfile(cfg.configDir,'ale_threshold_interaction_config_v1_5.json');
write_ale_threshold_config_json(cfg,configFile);
status = run_python_stage_ale(cfg,configFile,'realdatasmoke');
if status ~= 0
    error('Real-data smoke test failed. Do NOT start Stage 1 yet.');
end
smokeFile = fullfile(cfg.auditDir,'RealData_SmokeTest_v1_5.json');
if ~exist(smokeFile,'file')
    % Backend filename is retained for backward compatibility; the JSON itself records v1.5.
    error('Smoke-test completion file not produced: %s',smokeFile);
end
disp('REAL-DATA SMOKE TEST PASSED.');
disp('You may now run RUN_STAGE1_ALE_THRESHOLDS.');
