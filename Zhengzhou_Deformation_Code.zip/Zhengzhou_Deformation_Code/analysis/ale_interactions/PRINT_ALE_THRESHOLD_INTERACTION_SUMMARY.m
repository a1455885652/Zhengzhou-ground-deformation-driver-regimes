clear; clc;

cfg = config_ale_threshold_interaction_v1_5();

summaryFile = fullfile(cfg.outputRoot,'RESULT_SUMMARY.txt');

if ~exist(summaryFile,'file')
    error('RESULT_SUMMARY.txt not found. Run Stage 1 and Stage 2 first.');
end

fprintf('\n============================================================\n');
fprintf(' ALE THRESHOLD + INTERACTION RESULT SUMMARY\n');
fprintf('============================================================\n\n');

fprintf('%s\n', fileread(summaryFile));

fprintf('\nMain threshold table:\n%s\n', ...
    fullfile(cfg.thresholdDir,'ALE_Threshold_Breakpoints.csv'));
fprintf('\nMain interaction table:\n%s\n', ...
    fullfile(cfg.interactionDir,'SHAP_Interaction_Strength.csv'));
