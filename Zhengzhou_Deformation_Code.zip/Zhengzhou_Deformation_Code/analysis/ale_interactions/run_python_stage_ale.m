function status = run_python_stage_ale(cfg, configFile, stageName)

pythonExe = resolve_python_executable_ale(cfg);
projectDir = fileparts(mfilename('fullpath'));
backendFile = fullfile(projectDir, 'ale_threshold_interaction_backend.py');

if ~exist(backendFile, 'file')
    error('Python backend not found: %s', backendFile);
end

cmd = sprintf('"%s" "%s" --config "%s" --stage %s', ...
    pythonExe, backendFile, configFile, stageName);

fprintf('\nRunning Python stage: %s\n', stageName);
fprintf('%s\n\n', cmd);

status = system(cmd);

end
