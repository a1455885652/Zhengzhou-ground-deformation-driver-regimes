clearvars -except cfg;

if exist('cfg','var')
    cfg = ensure_current_ale_config_v1_5(cfg);
else
    cfg = ensure_current_ale_config_v1_5([]);
end

fprintf('\n[SELF TEST] Synthetic ALE threshold and interaction test\n');

ensure_folder_ale(cfg.configDir);
configFile = fullfile(cfg.configDir, 'ale_threshold_interaction_config_v1_5.json');
write_ale_threshold_config_json(cfg, configFile);

status = run_python_stage_ale(cfg, configFile, 'selftest');

if status ~= 0
    error('Synthetic backend self-test failed.');
end

disp('ALL ALE THRESHOLD + INTERACTION SELF TESTS PASSED.');
