clearvars -except cfg;

if exist('cfg','var')
    cfg = ensure_current_ale_config_v1_5(cfg);
else
    cfg = ensure_current_ale_config_v1_5([]);
end

fprintf('\n============================================================\n');
fprintf(' STAGE 3: publication figures\n');
fprintf('============================================================\n');

ensure_folder_ale(cfg.figureDir);

plot_ale_threshold_wholearea(cfg);
plot_ale_threshold_mechanism_comparison(cfg);
plot_interaction_strength_matrix(cfg);
plot_ale2d_selected_interactions(cfg);

disp('STAGE 3 COMPLETED.');
