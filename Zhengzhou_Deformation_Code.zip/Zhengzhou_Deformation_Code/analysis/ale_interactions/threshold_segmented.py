from __future__ import annotations

import itertools
import numpy as np


def _wls(X, y, w):
    sw = np.sqrt(np.maximum(w, 1e-12))
    A = X * sw[:, None]
    b = y * sw
    beta, *_ = np.linalg.lstsq(A, b, rcond=None)
    pred = X @ beta
    resid = y - pred
    sse = float(np.sum(w * resid * resid) / max(np.mean(w), 1e-12))
    return beta, pred, sse


def _bic(sse, n, k):
    return float(n * np.log(max(sse / max(n, 1), 1e-15)) + k * np.log(max(n, 2)))


def fit_segmented_thresholds(
    x,
    y,
    weights,
    support_x,
    search_quantile=(0.08, 0.92),
    min_segment_bins=3,
    allow_two=True,
):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    w = np.asarray(weights, float)
    support_x = np.asarray(support_x, float)

    good = np.isfinite(x) & np.isfinite(y) & np.isfinite(w)
    x, y, w = x[good], y[good], w[good]

    order = np.argsort(x)
    x, y, w = x[order], y[order], w[order]
    n = len(x)

    if n < 3:
        raise RuntimeError("Too few ALE points even for a linear response model.")

    X0 = np.c_[np.ones(n), x]
    b0, p0, sse0 = _wls(X0, y, w)
    bic0 = _bic(sse0, n, 2)

    best = {
        "model": 0,
        "breakpoints": [],
        "beta": b0,
        "pred": p0,
        "sse": sse0,
        "bic": bic0,
        "bic_null": bic0,
        "delta_bic_vs_null": 0.0,
    }

    # Coarse-support variables (especially GWS) may have only a few unique
    # ALE bins inside one mechanism. In that case we retain the valid linear
    # ALE response rather than manufacturing a breakpoint from inadequate
    # support.
    if n < 2 * min_segment_bins + 1:
        best["slopes"] = [float(b0[1])]
        best["slope_changes"] = []
        best["normalized_slope_changes"] = []
        best["breakpoint_quantiles"] = []
        best["x_range"] = float(np.nanmax(support_x) - np.nanmin(support_x))
        return best

    qlo, qhi = search_quantile
    xlo = float(np.quantile(support_x, qlo))
    xhi = float(np.quantile(support_x, qhi))

    candidate = []
    for k in range(min_segment_bins - 1, n - min_segment_bins):
        t = float(0.5 * (x[k] + x[k + 1]))
        if xlo <= t <= xhi:
            candidate.append(t)

    for t in candidate:
        H = np.maximum(0.0, x - t)
        X1 = np.c_[np.ones(n), x, H]
        beta, pred, sse = _wls(X1, y, w)
        bic = _bic(sse, n, 4)  # intercept, slope, hinge coefficient, breakpoint

        if bic < best["bic"]:
            best = {
                "model": 1,
                "breakpoints": [t],
                "beta": beta,
                "pred": pred,
                "sse": sse,
                "bic": bic,
                "bic_null": bic0,
                "delta_bic_vs_null": bic0 - bic,
            }

    if allow_two and len(candidate) >= 2:
        for t1, t2 in itertools.combinations(candidate, 2):
            i1 = np.searchsorted(x, t1, side="right")
            i2 = np.searchsorted(x, t2, side="right")

            if i1 < min_segment_bins:
                continue
            if i2 - i1 < min_segment_bins:
                continue
            if n - i2 < min_segment_bins:
                continue

            H1 = np.maximum(0.0, x - t1)
            H2 = np.maximum(0.0, x - t2)
            X2 = np.c_[np.ones(n), x, H1, H2]
            beta, pred, sse = _wls(X2, y, w)
            bic = _bic(sse, n, 6)

            if bic < best["bic"]:
                best = {
                    "model": 2,
                    "breakpoints": [float(t1), float(t2)],
                    "beta": beta,
                    "pred": pred,
                    "sse": sse,
                    "bic": bic,
                    "bic_null": bic0,
                    "delta_bic_vs_null": bic0 - bic,
                }

    x_iqr = float(np.subtract(*np.quantile(support_x, [0.75, 0.25])))
    ale_range = float(np.quantile(y, 0.95) - np.quantile(y, 0.05))
    ale_range = max(abs(ale_range), 1e-12)

    if best["model"] == 0:
        slopes = [float(best["beta"][1])]
        changes = []
    elif best["model"] == 1:
        b = best["beta"]
        slopes = [float(b[1]), float(b[1] + b[2])]
        changes = [float(b[2])]
    else:
        b = best["beta"]
        slopes = [
            float(b[1]),
            float(b[1] + b[2]),
            float(b[1] + b[2] + b[3]),
        ]
        changes = [float(b[2]), float(b[3])]

    norm_changes = [float(abs(c) * max(x_iqr, 1e-12) / ale_range) for c in changes]

    bp_quantiles = [float(np.mean(support_x <= t)) for t in best["breakpoints"]]

    best["slopes"] = slopes
    best["slope_changes"] = changes
    best["normalized_slope_changes"] = norm_changes
    best["breakpoint_quantiles"] = bp_quantiles
    best["x_range"] = float(np.nanmax(support_x) - np.nanmin(support_x))

    return best


def match_breakpoints(main_breakpoints, replicate_breakpoints, x_range):
    main = np.asarray(main_breakpoints, float)
    rep = np.asarray(replicate_breakpoints, float)

    out = np.full(len(main), np.nan, float)
    if len(main) == 0 or len(rep) == 0:
        return out

    max_dist = 0.35 * max(float(x_range), 1e-12)

    if len(main) == 1:
        j = int(np.argmin(np.abs(rep - main[0])))
        if abs(rep[j] - main[0]) <= max_dist:
            out[0] = rep[j]
        return out

    if len(main) == 2 and len(rep) >= 2:
        rep = np.sort(rep)
        cand = rep[:2] if len(rep) == 2 else rep
        best_pair = None
        best_cost = np.inf
        for i in range(len(cand)):
            for j in range(i + 1, len(cand)):
                cost = abs(cand[i] - main[0]) + abs(cand[j] - main[1])
                if cost < best_cost:
                    best_cost = cost
                    best_pair = (cand[i], cand[j])
        if best_pair is not None:
            if abs(best_pair[0] - main[0]) <= max_dist:
                out[0] = best_pair[0]
            if abs(best_pair[1] - main[1]) <= max_dist:
                out[1] = best_pair[1]
        return out

    # One replicate threshold but two main thresholds.
    j = int(np.argmin(np.abs(main - rep[0])))
    if abs(main[j] - rep[0]) <= max_dist:
        out[j] = rep[0]

    return out
