function cfg = ensure_current_ale_config_v1_5(cfgIn)
% Prevent reuse of stale cfg from older project versions.
requiredFields = {'projectVersion','trainingCsv','featureMetadataCsv','finalModelJson', ...
    'bestParamsJson','k4AssignmentCsv','outputRoot','configDir','pythonExe', ...
    'thresholdDrivers','interactionPairs','ale2dTargets'};
valid = nargin >= 1 && isstruct(cfgIn) && ~isempty(cfgIn);
if valid
    for i = 1:numel(requiredFields)
        if ~isfield(cfgIn,requiredFields{i})
            valid = false;
            break;
        end
    end
end
if valid
    valid = strcmp(string(cfgIn.projectVersion),"v1.5");
end
if valid
    cfg = cfgIn;
else
    cfg = config_ale_threshold_interaction_v1_5();
    if nargin >= 1 && ~isempty(cfgIn)
        fprintf('[CONFIG] Stale/incompatible cfg discarded; formal v1.5 reloaded.\n');
    else
        fprintf('[CONFIG] Loaded formal ALE Threshold + Interaction v1.5 configuration.\n');
    end
end
end
