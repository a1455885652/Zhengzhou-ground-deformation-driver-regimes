function plot_ale2d_selected_interactions(cfg)

manifestFile = fullfile(cfg.interactionDir, 'ALE2D_Surface_Manifest.csv');
M = readtable(manifestFile,'TextType','string','VariableNamingRule','preserve');

if ismember('Status', M.Properties.VariableNames)
    M = M(M.Status == "OK", :);
end

if isempty(M)
    warning('ALE2D surface manifest is empty.');
    return;
end

n = height(M);
nShow = min(n,6);

f = figure('Color','w','Position',[60 40 1500 950]);
t = tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');

for i = 1:nShow
    ax = nexttile(t,i);
    T = readtable(char(M.SurfaceFile(i)), 'TextType','string','VariableNamingRule','preserve');

    ux = unique(T.XCenter,'sorted');
    uy = unique(T.YCenter,'sorted');

    support = T.DisplaySupported;
    if isstring(support) || iscellstr(support)
        support = strcmpi(string(support),"true") | string(support)=="1";
    else
        support = logical(support);
    end

    Z = nan(numel(uy),numel(ux));

    for k = 1:height(T)
        [~,ix] = min(abs(ux-T.XCenter(k)));
        [~,iy] = min(abs(uy-T.YCenter(k)));
        if support(k)
            Z(iy,ix) = T.ALE2D(k);
        end
    end

    [Xg,Yg] = meshgrid(ux,uy);
    surf(ax,Xg,Yg,zeros(size(Z)),Z,'EdgeColor','none','FaceColor','flat');
    view(ax,2);
    set(ax,'YDir','normal');
    colormap(ax,turbo(256));
    cb=colorbar(ax);
    cb.Label.String='2D ALE interaction effect';

    xlabel(ax,char(pretty_driver_name_ale(M.Driver1(i))));
    ylabel(ax,char(pretty_driver_name_ale(M.Driver2(i))));
    title(ax,sprintf('(%c) %s: %s × %s', ...
        96+i,char(M.Region(i)), ...
        char(pretty_driver_name_ale(M.Driver1(i))), ...
        char(pretty_driver_name_ale(M.Driver2(i)))), ...
        'FontWeight','bold');

    set(ax,'FontName',cfg.fontName,'FontSize',cfg.fontSize,'LineWidth',1.0);
    box(ax,'on');
end

title(t,'Representative two-dimensional ALE interaction surfaces', ...
    'FontName',cfg.fontName,'FontSize',15,'FontWeight','bold');

exportgraphics(f,fullfile(cfg.figureDir,'Fig_ALE2D_Selected_Interactions.png'), ...
    'Resolution',cfg.figureDPI);
exportgraphics(f,fullfile(cfg.figureDir,'Fig_ALE2D_Selected_Interactions.pdf'));
if ~zz_show_figures(), close(f); end

end
