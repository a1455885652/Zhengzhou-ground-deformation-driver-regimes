from __future__ import annotations

import numpy as np
import pandas as pd
import xgboost as xgb
from scipy.interpolate import griddata

from ale_1d import quantile_edges


def _predict(booster, arr, feature_names):
    return booster.predict(xgb.DMatrix(arr, feature_names=feature_names))


def choose_2d_edges(x, y, target_bins, minimum_bins, minimum_occupied_fraction):
    for bins in range(int(target_bins), int(minimum_bins) - 1, -1):
        ex = np.unique(np.quantile(x, np.linspace(0, 1, bins + 1)))
        ey = np.unique(np.quantile(y, np.linspace(0, 1, bins + 1)))

        nx, ny = len(ex) - 1, len(ey) - 1
        if nx < minimum_bins or ny < minimum_bins:
            continue

        ix = np.clip(np.searchsorted(ex[1:-1], x, side="right"), 0, nx - 1)
        iy = np.clip(np.searchsorted(ey[1:-1], y, side="right"), 0, ny - 1)

        counts = np.zeros((ny, nx), int)
        np.add.at(counts, (iy, ix), 1)

        occupied = np.mean(counts > 0)
        if occupied >= float(minimum_occupied_fraction):
            return ex, ey, counts

    # Fallback: keep the richest valid quantile grid rather than failing.
    ex = quantile_edges(x, target_bins, minimum_bins)
    ey = quantile_edges(y, target_bins, minimum_bins)
    nx, ny = len(ex) - 1, len(ey) - 1
    ix = np.clip(np.searchsorted(ex[1:-1], x, side="right"), 0, nx - 1)
    iy = np.clip(np.searchsorted(ey[1:-1], y, side="right"), 0, ny - 1)
    counts = np.zeros((ny, nx), int)
    np.add.at(counts, (iy, ix), 1)
    return ex, ey, counts


def integrate_ale2d(local, counts, min_cell_count):
    """Accumulate local second differences and remove first-order margins.

    Unsupported cells are nearest-filled ONLY to allow the cumulative integral
    to be evaluated. The returned support masks always preserve which cells
    were actually observed, so plotting/code can hide unsupported cells.
    """
    local = np.asarray(local, float)
    counts = np.asarray(counts, int)
    ny, nx = local.shape

    strong = (counts >= int(min_cell_count)) & np.isfinite(local)
    observed = counts > 0

    if strong.sum() < max(4, int(0.20 * nx * ny)):
        raise RuntimeError("Too few supported cells for 2D ALE integration.")

    yy, xx = np.mgrid[0:ny, 0:nx]
    points = np.c_[yy[strong], xx[strong]]
    values = local[strong]
    filled = griddata(points, values, (yy, xx), method="nearest")

    # Double cumulative sum of local second-order effects.
    g = np.cumsum(np.cumsum(filled, axis=0), axis=1)

    # Weighted double centering removes first-order row/column structure,
    # leaving the second-order interaction component on the ALE scale.
    W = counts.astype(float)
    row_mean = np.zeros(ny)
    col_mean = np.zeros(nx)

    for r in range(ny):
        ww = W[r]
        row_mean[r] = np.sum(g[r] * ww) / ww.sum() if ww.sum() > 0 else 0.0

    for c in range(nx):
        ww = W[:, c]
        col_mean[c] = np.sum(g[:, c] * ww) / ww.sum() if ww.sum() > 0 else 0.0

    grand = np.sum(g * W) / max(W.sum(), 1.0)
    effect = g - row_mean[:, None] - col_mean[None, :] + grand

    supported_values = effect[observed]
    amplitude = float(
        np.quantile(supported_values, 0.95) - np.quantile(supported_values, 0.05)
    )

    return effect, observed, strong, amplitude


def compute_ale2d(
    booster,
    X,
    feature_names,
    feature1,
    feature2,
    target_bins,
    minimum_bins,
    min_cell_count,
    minimum_occupied_fraction,
    fixed_edges=None,
):
    Xdf = X if isinstance(X, pd.DataFrame) else pd.DataFrame(X, columns=feature_names)
    arr = Xdf[feature_names].to_numpy(float, copy=True)

    j1 = feature_names.index(feature1)
    j2 = feature_names.index(feature2)

    x = arr[:, j1].copy()
    y = arr[:, j2].copy()

    if fixed_edges is None:
        ex, ey, _ = choose_2d_edges(
            x, y, target_bins, minimum_bins, minimum_occupied_fraction
        )
    else:
        ex, ey = fixed_edges
        ex = np.asarray(ex, float)
        ey = np.asarray(ey, float)

    nx, ny = len(ex) - 1, len(ey) - 1

    ix = np.clip(np.searchsorted(ex[1:-1], x, side="right"), 0, nx - 1)
    iy = np.clip(np.searchsorted(ey[1:-1], y, side="right"), 0, ny - 1)

    xlo, xhi = ex[ix], ex[ix + 1]
    ylo, yhi = ey[iy], ey[iy + 1]

    LL = arr.copy()
    LH = arr.copy()
    HL = arr.copy()
    HH = arr.copy()

    LL[:, j1], LL[:, j2] = xlo, ylo
    LH[:, j1], LH[:, j2] = xlo, yhi
    HL[:, j1], HL[:, j2] = xhi, ylo
    HH[:, j1], HH[:, j2] = xhi, yhi

    P = _predict(booster, np.vstack([LL, LH, HL, HH]), feature_names)

    n = len(arr)
    pLL, pLH, pHL, pHH = P[:n], P[n : 2 * n], P[2 * n : 3 * n], P[3 * n : 4 * n]
    d2 = pHH - pLH - pHL + pLL

    counts = np.zeros((ny, nx), int)
    sums = np.zeros((ny, nx), float)
    np.add.at(counts, (iy, ix), 1)
    np.add.at(sums, (iy, ix), d2)

    local = np.full((ny, nx), np.nan, float)
    z = counts >= int(min_cell_count)
    local[z] = sums[z] / counts[z]

    effect, observed, strong, amplitude = integrate_ale2d(local, counts, min_cell_count)

    xcenter = 0.5 * (ex[:-1] + ex[1:])
    ycenter = 0.5 * (ey[:-1] + ey[1:])

    return {
        "x_edges": ex,
        "y_edges": ey,
        "x_center": xcenter,
        "y_center": ycenter,
        "effect": effect,
        "count": counts,
        "observed": observed,
        "strong_support": strong,
        "local_second_difference": local,
        "amplitude": amplitude,
        "occupied_fraction": float(np.mean(observed)),
        # Sample-level finite differences are retained so spatial bootstrap
        # can be performed exactly for a frozen model without re-predicting.
        "sample_ix": ix,
        "sample_iy": iy,
        "sample_d2": d2,
    }


def bootstrap_ale2d_amplitude(
    baseline_surface,
    region_indices,
    block_ids,
    reps,
    min_cell_count,
    seed,
):
    region_indices = np.asarray(region_indices, int)
    region_blocks = np.asarray(block_ids)[region_indices]

    ix = np.asarray(baseline_surface["sample_ix"], int)
    iy = np.asarray(baseline_surface["sample_iy"], int)
    d2 = np.asarray(baseline_surface["sample_d2"], float)

    if not (len(ix) == len(iy) == len(d2) == len(region_indices)):
        raise RuntimeError(
            "2D ALE bootstrap sample arrays do not match region support."
        )

    ny = len(baseline_surface["y_center"])
    nx = len(baseline_surface["x_center"])

    unique_blocks = np.unique(region_blocks)
    block_positions = {b: np.where(region_blocks == b)[0] for b in unique_blocks}

    rng = np.random.default_rng(seed)
    amplitudes = np.full(int(reps), np.nan, float)

    for rep in range(int(reps)):
        sampled_blocks = rng.choice(
            unique_blocks, size=len(unique_blocks), replace=True
        )
        pos = np.concatenate([block_positions[b] for b in sampled_blocks])

        counts = np.zeros((ny, nx), int)
        sums = np.zeros((ny, nx), float)
        np.add.at(counts, (iy[pos], ix[pos]), 1)
        np.add.at(sums, (iy[pos], ix[pos]), d2[pos])

        local = np.full((ny, nx), np.nan, float)
        z = counts >= int(min_cell_count)
        local[z] = sums[z] / counts[z]

        try:
            _, _, _, amp = integrate_ale2d(local, counts, min_cell_count)
            amplitudes[rep] = amp
        except Exception:
            continue

    valid = amplitudes[np.isfinite(amplitudes)]
    min_required = min(int(reps), max(5, int(np.ceil(0.50 * int(reps)))))
    if len(valid) < min_required:
        raise RuntimeError(
            f"Too few valid 2D ALE bootstrap replicates: {len(valid)}/{reps}"
        )

    return {
        "valid_reps": int(len(valid)),
        "ci95_low": float(np.percentile(valid, 2.5)),
        "ci95_high": float(np.percentile(valid, 97.5)),
        "ci90_low": float(np.percentile(valid, 5.0)),
        "ci90_high": float(np.percentile(valid, 95.0)),
    }
