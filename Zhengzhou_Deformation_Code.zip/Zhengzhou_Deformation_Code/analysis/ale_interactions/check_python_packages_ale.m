function check_python_packages_ale(cfg)
% Report dependency errors without installing or switching interpreters.
zz_check_python();
end
