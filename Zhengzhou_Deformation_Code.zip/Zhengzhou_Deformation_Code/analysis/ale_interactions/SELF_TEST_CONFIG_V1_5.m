clear; clc;
fprintf('[CONFIG SELF TEST v1.5]\n');
cfg = struct(); cfg.projectVersion='legacy'; cfg.expectedFeatureCount=999;
cfg = ensure_current_ale_config_v1_5(cfg);
assert(strcmp(string(cfg.projectVersion),"v1.5"));
assert(~isfield(cfg,'expectedFeatureCount'));
assert(size(cfg.interactionPairs,2)==2);
assert(size(cfg.ale2dTargets,2)==3);
disp('CONFIG SELF TEST PASSED.');
