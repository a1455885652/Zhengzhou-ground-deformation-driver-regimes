function cfg = config_ale_threshold_interaction()
% Backward-compatible wrapper for formal v1.5.
cfg = config_ale_threshold_interaction_v1_5();
end
