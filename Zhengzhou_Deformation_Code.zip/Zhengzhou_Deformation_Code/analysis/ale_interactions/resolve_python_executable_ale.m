function executable = resolve_python_executable_ale(cfg)
% Resolve the interpreter from the shared project configuration.
executable = zz_python_executable();
end
