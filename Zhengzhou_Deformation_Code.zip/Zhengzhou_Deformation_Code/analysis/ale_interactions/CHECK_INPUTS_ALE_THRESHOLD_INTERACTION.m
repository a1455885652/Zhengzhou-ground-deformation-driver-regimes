clearvars -except cfg;
if exist('cfg','var')
    cfg = ensure_current_ale_config_v1_5(cfg);
else
    cfg = ensure_current_ale_config_v1_5([]);
end

fprintf('\n[CHECK] ALE threshold + interaction inputs v1.5\n');
requiredFiles = {cfg.trainingCsv,cfg.featureMetadataCsv,cfg.finalModelJson,cfg.bestParamsJson,cfg.finalFitMetricsCsv,cfg.k4AssignmentCsv};
for i = 1:numel(requiredFiles)
    if ~exist(requiredFiles{i},'file')
        error('Missing required input file:\n%s',requiredFiles{i});
    end
end
if ~exist(cfg.pythonExe,'file')
    error('Python executable not found:\n%s',cfg.pythonExe);
end

fprintf('All required files exist.\n');
fprintf('Metadata column names are NOT validated by MATLAB in v1.5.\n');
fprintf('The Python backend will normalize/reconstruct metadata from the saved XGBoost model signature.\n');
fprintf('No model feature count is hard-coded.\n');

check_python_packages_ale(cfg);
ensure_folder_ale(cfg.outputRoot);
ensure_folder_ale(cfg.configDir);
configFile = fullfile(cfg.configDir,'ale_threshold_interaction_config_v1_5.json');
write_ale_threshold_config_json(cfg,configFile);
status = run_python_stage_ale(cfg,configFile,'inputcheck');
if status ~= 0
    error('Python authoritative input/model/K4 identity check failed.');
end

disp('INPUT CHECK PASSED.');
