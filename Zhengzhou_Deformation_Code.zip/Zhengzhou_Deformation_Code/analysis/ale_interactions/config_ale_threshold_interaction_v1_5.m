function cfg = config_ale_threshold_interaction_v1_5()
% Zhengzhou K4 ALE threshold + interaction configuration v1.5.
% MATLAB R2023b compatible.
%
% Formal principles:
% 1) The saved ReferenceSimple XGBoost model is frozen.
% 2) Saved XGBoost feature_names are the authoritative model signature.
% 3) M1-M4 use the SAME global model; mechanisms are empirical support subsets.
% 4) Positive Target = subsidence; negative Target = uplift.
% 5) Thresholds are predictive/model-response thresholds, not causal thresholds.

cfg.projectVersion = 'v1.5';

% Python
cfg.pythonExe = zz_python_executable();
cfg.tryGPU = true;
cfg.randomSeed = 20260908;

% Frozen ReferenceSimple model/data
cfg.referenceRoot = zz_project_path('XGBoost_SHAP_Latest1km_ReferenceSimple_Output');
cfg.trainingCsv = fullfile(cfg.referenceRoot, 'XGBoost_Model_Data.csv');
cfg.featureMetadataCsv = fullfile(cfg.referenceRoot, 'Feature_Metadata.csv');
cfg.finalModelJson = fullfile(cfg.referenceRoot, 'Python_Output', 'XGBoost_Final_Model.json');
cfg.bestParamsJson = fullfile(cfg.referenceRoot, 'Python_Output', 'Best_Params.json');
cfg.finalFitMetricsCsv = fullfile(cfg.referenceRoot, 'Python_Output', 'FinalModel_TrainingFit.csv');

% Sample count is frozen. Feature count is NOT hard-coded.
cfg.expectedSampleCount = 7081;

% Final recommended K=4 assignment.
cfg.k4AssignmentCsv = ...
    zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output/Python_Output/K4_Assignment.csv');

% Fingerprint of the accepted final K4 solution.
cfg.expectedMechanismCounts = [2279 1794 1522 1486];
cfg.expectedMechanismTargetMeans = [-7.565327 -0.918266 -6.810094 -3.293053];
cfg.mechanismTargetMeanTolerance = 0.01;

% Geometry/version matching tolerances.
cfg.coordinateToleranceDegrees = 1e-7;
cfg.targetTolerance = 1e-5;

% Clean v1.5 output root prevents stale checkpoints from older versions.
cfg.outputRoot = zz_project_path('K4_ALE_Threshold_Interaction_Output_v1_5');
cfg.auditDir = fullfile(cfg.outputRoot, '00_Audit');
cfg.thresholdDir = fullfile(cfg.outputRoot, '01_Thresholds');
cfg.interactionDir = fullfile(cfg.outputRoot, '02_Interactions');
cfg.figureDir = fullfile(cfg.outputRoot, '03_Figures');
cfg.checkpointDir = fullfile(cfg.outputRoot, '04_Checkpoints');
cfg.configDir = fullfile(cfg.outputRoot, 'Config');

% Mechanism support
cfg.primaryMechanismConfidence = 0.65;
cfg.sensitivityMechanismConfidence = 0.70;
cfg.spatialBlockPixels = 5;  % ~= 5 km blocks on the 1-km grid
cfg.minimumRegionSamples = 150;

% 1D ALE threshold analysis
cfg.thresholdDrivers = { ...
    'GWS', ...
    'SurfaceRunoff', ...
    'SubsurfaceRunoff', ...
    'SkinReservoir', ...
    'TotalPrecipitation', ...
    'BuiltSurface'};

cfg.aleTargetBins = 20;
cfg.aleMinimumBins = 6;
cfg.aleMinBinCount = 25;
cfg.aleBootstrapMinBinCount = 10;

cfg.thresholdSearchQuantile = [0.08 0.92];
cfg.thresholdMinSegmentBins = 3;
cfg.allowTwoBreakpoints = true;

cfg.fixedModelBootstrapReps = 500;
cfg.refitBootstrapReps = 120;

% Tier A: robust predictive threshold.
cfg.robustMinDeltaBIC = 4.0;
cfg.robustMinFixedDetection = 0.60;
cfg.robustMinRefitDetection = 0.45;
cfg.robustMinNormalizedSlopeChange = 0.15;
cfg.robustMaxCI95WidthFraction = 0.50;

% Tier B: supported threshold, deliberately somewhat more permissive.
cfg.supportedMinDeltaBIC = 1.5;
cfg.supportedMinFixedDetection = 0.45;
cfg.supportedMinRefitDetection = 0.30;
cfg.supportedMinNormalizedSlopeChange = 0.08;
cfg.supportedMaxCI90WidthFraction = 0.65;

% Tier C: candidate only; never call it a robust threshold.
cfg.candidateMinDeltaBIC = 0.5;
cfg.candidateMinFixedDetection = 0.25;
cfg.candidateMinNormalizedSlopeChange = 0.05;

% Interaction analysis
cfg.interactionPairs = { ...
    'GWS',                'BuiltSurface'; ...
    'GWS',                'TotalLooseThickness'; ...
    'GWS',                'SurfaceRunoff'; ...
    'TotalPrecipitation', 'SurfaceRunoff'; ...
    'SkinReservoir',      'BuiltSurface'; ...
    'SurfaceRunoff',      'SubsurfaceRunoff'};

cfg.interactionBootstrapReps = 400;
cfg.exactInteractionChunkRows = 100;
cfg.interactionMinRegionSamples = 150;

cfg.strongInteractionTopRank = 3;
cfg.strongInteractionTop3Freq = 0.65;
cfg.strongInteractionMinShare = 0.12;

cfg.supportedInteractionTopRank = 4;
cfg.supportedInteractionTop3Freq = 0.45;
cfg.supportedInteractionMinShare = 0.08;

% 2D ALE
cfg.ale2dTargetBins = 9;
cfg.ale2dMinimumBins = 6;
cfg.ale2dMinCellCount = 8;
cfg.ale2dMinimumOccupiedFraction = 0.45;
cfg.ale2dBootstrapReps = 150;

cfg.ale2dTargets = { ...
    'All', 'GWS',                'BuiltSurface'; ...
    'M1',  'GWS',                'BuiltSurface'; ...
    'M2',  'TotalPrecipitation', 'SurfaceRunoff'; ...
    'M3',  'SurfaceRunoff',      'SubsurfaceRunoff'; ...
    'M3',  'GWS',                'SurfaceRunoff'; ...
    'M4',  'SkinReservoir',      'BuiltSurface'};

% Real-data smoke test
cfg.smokeFixedBootstrapReps = 8;
cfg.smokeInteractionRows = 64;
cfg.smokeAle2dBootstrapReps = 6;

% Plotting
cfg.figureDPI = 450;
cfg.fontName = 'Times New Roman';
cfg.fontSize = 12;

end
