from __future__ import annotations

import json
import re
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb


def _normalise_string_list(value, field_name):
    """Return a clean list[str] and never iterate through characters of a string."""
    if value is None:
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, (list, tuple)):
        raise RuntimeError(
            f"Config field {field_name} must be a string list; got {type(value).__name__}."
        )

    out = []
    for item in value:
        if isinstance(item, (list, tuple)):
            for sub in item:
                s = str(sub).strip()
                if s:
                    out.append(s)
        else:
            s = str(item).strip()
            if s:
                out.append(s)
    return out


def _normalise_fixed_width_rows(value, width, field_name):
    """Normalise JSON matrix-like fields written by MATLAB.

    Formal v1.5 MATLAB writes a cell-of-row-cells, which jsonencode emits as
    nested arrays. This parser also accepts a flat row-major list from older
    files, but rejects malformed rows before any scientific calculation.
    """
    if value is None:
        return []
    if isinstance(value, str):
        raise RuntimeError(
            f"Config field {field_name} must contain rows of width {width}, not one string."
        )
    if not isinstance(value, (list, tuple)):
        raise RuntimeError(
            f"Config field {field_name} must be a list; got {type(value).__name__}."
        )

    if len(value) == 0:
        return []

    # Correct nested form.
    if all(isinstance(row, (list, tuple)) for row in value):
        rows = []
        for i, row in enumerate(value, start=1):
            if len(row) != width:
                raise RuntimeError(
                    f"Config field {field_name} row {i} has width {len(row)}; expected {width}."
                )
            cleaned = [str(x).strip() for x in row]
            if any(x == "" for x in cleaned):
                raise RuntimeError(
                    f"Config field {field_name} row {i} contains an empty value."
                )
            rows.append(cleaned)
        return rows

    # Legacy flat form. Never treat each string as an iterable row.
    if all(not isinstance(x, (list, tuple, dict)) for x in value):
        flat = [str(x).strip() for x in value]
        if len(flat) % width != 0:
            raise RuntimeError(
                f"Flat config field {field_name} has {len(flat)} values, not divisible by row width {width}."
            )
        return [flat[i : i + width] for i in range(0, len(flat), width)]

    raise RuntimeError(f"Config field {field_name} mixes nested and scalar entries.")


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    # Normalize immediately so every downstream module sees one stable shape.
    cfg["threshold_drivers"] = _normalise_string_list(
        cfg.get("threshold_drivers", []), "threshold_drivers"
    )
    cfg["interaction_pairs"] = _normalise_fixed_width_rows(
        cfg.get("interaction_pairs", []), 2, "interaction_pairs"
    )
    cfg["ale2d_targets"] = _normalise_fixed_width_rows(
        cfg.get("ale2d_targets", []), 3, "ale2d_targets"
    )

    return cfg


def ensure_dirs(cfg):
    for key in [
        "output_root",
        "audit_dir",
        "threshold_dir",
        "interaction_dir",
        "figure_dir",
        "checkpoint_dir",
    ]:
        Path(cfg[key]).mkdir(parents=True, exist_ok=True)

    (Path(cfg["threshold_dir"]) / "Curves").mkdir(parents=True, exist_ok=True)
    (Path(cfg["threshold_dir"]) / "BootstrapFixed").mkdir(parents=True, exist_ok=True)
    (Path(cfg["threshold_dir"]) / "BootstrapRefit").mkdir(parents=True, exist_ok=True)
    (Path(cfg["interaction_dir"]) / "ALE2D").mkdir(parents=True, exist_ok=True)
    (Path(cfg["checkpoint_dir"]) / "Refit").mkdir(parents=True, exist_ok=True)
    (Path(cfg["checkpoint_dir"]) / "InteractionExact").mkdir(
        parents=True, exist_ok=True
    )


def _parse_mechanism_series(k4):
    if "MechanismCluster" in k4.columns:
        v = k4["MechanismCluster"]
    elif "FinalMechanism" in k4.columns:
        v = k4["FinalMechanism"]
    else:
        raise RuntimeError("K4 assignment needs MechanismCluster or FinalMechanism.")

    if np.issubdtype(v.dtype, np.number):
        out = pd.to_numeric(v, errors="raise").astype(int).to_numpy()
    else:
        s = v.astype(str).str.strip().str.upper().str.replace("M", "", regex=False)
        out = pd.to_numeric(s, errors="raise").astype(int).to_numpy()

    if not set(np.unique(out)).issubset({1, 2, 3, 4}):
        raise RuntimeError(f"Unexpected K4 mechanism labels: {np.unique(out)}")
    return out


def _infer_metadata_row(feature):
    feature = str(feature)

    if feature.endswith("_Trend"):
        driver = feature[:-6]
        ftype = "Continuous"
    elif feature.startswith("GUM_Cat_"):
        driver = "GUM"
        ftype = "CategoricalDummy"
    elif feature == "RoadDensity_Mean_2018_2025":
        driver = "RoadDensity"
        ftype = "Continuous"
    else:
        driver = feature
        ftype = "Continuous"

    return {
        "Feature": feature,
        "Driver": driver,
        "FeatureType": ftype,
        "MetadataSource": "AutoInferredFromSavedModelFeatureName",
    }


def _clean_column_name(name):
    s = str(name).replace("\ufeff", "").strip()
    return s


def _canonical_header_key(name):
    return re.sub(r"[^a-z0-9]+", "", _clean_column_name(name).lower())


def _normalise_dataframe_headers(df):
    out = df.copy()
    out.columns = [_clean_column_name(c) for c in out.columns]
    return out


def _detect_metadata_columns(raw_meta):
    aliases_feature = {
        "feature",
        "featurename",
        "modelfeature",
        "encodedfeature",
        "predictor",
        "predictorname",
        "inputfeature",
    }
    aliases_driver = {
        "driver",
        "drivername",
        "originaldriver",
        "factor",
        "factorname",
        "originalfactor",
        "sourcevariable",
        "physicaldriver",
    }
    aliases_type = {"featuretype", "type", "datatype", "variabletype", "predictortype"}

    mapping = {}
    for c in raw_meta.columns:
        k = _canonical_header_key(c)
        if k in aliases_feature and "Feature" not in mapping:
            mapping["Feature"] = c
        elif k in aliases_driver and "Driver" not in mapping:
            mapping["Driver"] = c
        elif k in aliases_type and "FeatureType" not in mapping:
            mapping["FeatureType"] = c
    return mapping


def reconcile_metadata(raw_meta, model_features):
    """Reconcile metadata without allowing metadata formatting to alter the model.

    The saved XGBoost feature_names are authoritative. Feature_Metadata.csv is
    descriptive metadata only. If its headers are renamed, whitespace/BOM
    polluted, incomplete, or even unusable, metadata is reconstructed from the
    saved model feature names and the event is explicitly audited.
    """
    raw_meta = _normalise_dataframe_headers(raw_meta)
    detected = _detect_metadata_columns(raw_meta)

    feature_col = detected.get("Feature")
    driver_col = detected.get("Driver")
    type_col = detected.get("FeatureType")

    reconstruction_mode = "OriginalMetadata"
    metadata_rows_used = 0

    if feature_col is None:
        # Cannot identify which raw row describes which saved model feature.
        # Reconstruct all descriptive metadata from the authoritative model.
        meta = pd.DataFrame([_infer_metadata_row(f) for f in model_features])
        missing = list(model_features)
        extras = []
        reconstruction_mode = "FullReconstruction_NoRecognizableFeatureColumn"
    else:
        meta = pd.DataFrame()
        meta["Feature"] = (
            raw_meta[feature_col]
            .astype(str)
            .str.replace("\ufeff", "", regex=False)
            .str.strip()
        )
        meta = meta[meta["Feature"].ne("") & meta["Feature"].ne("nan")].copy()

        if driver_col is not None:
            d = raw_meta.loc[meta.index, driver_col].astype(str).str.strip()
            meta["Driver"] = d
        else:
            meta["Driver"] = [_infer_metadata_row(f)["Driver"] for f in meta["Feature"]]
            reconstruction_mode = "PartialReconstruction_DriverInferred"

        if type_col is not None:
            meta["FeatureType"] = (
                raw_meta.loc[meta.index, type_col].astype(str).str.strip()
            )
        else:
            meta["FeatureType"] = [
                _infer_metadata_row(f)["FeatureType"] for f in meta["Feature"]
            ]

        if meta["Feature"].duplicated().any():
            # Keep the first descriptive row only; duplicates cannot change model inputs.
            meta = meta.drop_duplicates(subset="Feature", keep="first")
            reconstruction_mode = "MetadataDuplicatesCollapsed"

        extras = [f for f in meta["Feature"].tolist() if f not in model_features]
        meta = meta[meta["Feature"].isin(model_features)].copy()
        metadata_rows_used = len(meta)
        meta["MetadataSource"] = "OriginalFeatureMetadata"

        present = set(meta["Feature"].tolist())
        missing = [f for f in model_features if f not in present]
        if missing:
            additions = pd.DataFrame([_infer_metadata_row(f) for f in missing])
            meta = pd.concat([meta, additions], ignore_index=True, sort=False)
            if reconstruction_mode == "OriginalMetadata":
                reconstruction_mode = "PartialReconstruction_MissingRowsInferred"

        # Exact saved-model order is authoritative.
        meta = meta.set_index("Feature").loc[model_features].reset_index()

    if "MetadataSource" not in meta.columns:
        meta["MetadataSource"] = "AutoInferredFromSavedModelFeatureName"

    audit_info = {
        "MetadataReconstructionMode": reconstruction_mode,
        "DetectedFeatureColumn": "" if feature_col is None else str(feature_col),
        "DetectedDriverColumn": "" if driver_col is None else str(driver_col),
        "DetectedFeatureTypeColumn": "" if type_col is None else str(type_col),
        "OriginalMetadataColumnNames": ";".join(str(c) for c in raw_meta.columns),
        "OriginalMetadataRowsUsed": int(metadata_rows_used),
    }
    return meta, missing, extras, audit_info


def _validate_k4_probability_fields(k4, mechanism):
    posterior = pd.to_numeric(k4["MaxPosterior"], errors="raise").to_numpy(float)
    if not np.isfinite(posterior).all() or np.any((posterior < 0) | (posterior > 1)):
        raise RuntimeError("K4 MaxPosterior must be finite and lie in [0,1].")

    pcols = ["P_M1", "P_M2", "P_M3", "P_M4"]
    if all(c in k4.columns for c in pcols):
        P = k4[pcols].to_numpy(float)
        if not np.isfinite(P).all():
            raise RuntimeError("K4 posterior probability columns contain NaN/Inf.")
        if np.max(np.abs(P.sum(axis=1) - 1.0)) > 1e-6:
            raise RuntimeError("K4 P_M1..P_M4 rows do not sum to 1.")
        if np.max(np.abs(P.max(axis=1) - posterior)) > 1e-8:
            raise RuntimeError("K4 MaxPosterior disagrees with P_M1..P_M4.")
        argmax = P.argmax(axis=1) + 1
        if not np.array_equal(argmax, mechanism):
            raise RuntimeError("K4 MechanismCluster disagrees with posterior argmax.")

    return posterior


def _geometry_audit(df, aligned_k4, cfg):
    required = [
        "PixelIndex",
        "RasterRow",
        "RasterColumn",
        "Longitude",
        "Latitude",
        "Target",
    ]
    missing = [c for c in required if c not in aligned_k4.columns]
    if missing:
        raise RuntimeError(
            "K4 assignment is missing geometry/version audit columns: "
            + ", ".join(missing)
        )

    if not np.array_equal(
        pd.to_numeric(df["PixelIndex"], errors="raise").to_numpy(np.int64),
        pd.to_numeric(aligned_k4["PixelIndex"], errors="raise").to_numpy(np.int64),
    ):
        raise RuntimeError(
            "K4 PixelIndex does not match the ReferenceSimple model table."
        )

    for c in ["RasterRow", "RasterColumn"]:
        if not np.array_equal(
            pd.to_numeric(df[c], errors="raise").to_numpy(np.int64),
            pd.to_numeric(aligned_k4[c], errors="raise").to_numpy(np.int64),
        ):
            raise RuntimeError(
                f"K4 {c} does not match the ReferenceSimple model table."
            )

    coord_tol = float(cfg.get("coordinate_tolerance_degrees", 1e-7))
    for c in ["Longitude", "Latitude"]:
        diff = np.max(
            np.abs(
                pd.to_numeric(df[c], errors="raise").to_numpy(float)
                - pd.to_numeric(aligned_k4[c], errors="raise").to_numpy(float)
            )
        )
        if not np.isfinite(diff) or diff > coord_tol:
            raise RuntimeError(
                f"K4 {c} mismatch: max abs difference={diff:.9g}, tolerance={coord_tol}."
            )

    target_tol = float(cfg.get("target_tolerance", 1e-5))
    tdiff = np.max(
        np.abs(
            pd.to_numeric(df["Target"], errors="raise").to_numpy(float)
            - pd.to_numeric(aligned_k4["Target"], errors="raise").to_numpy(float)
        )
    )
    if not np.isfinite(tdiff) or tdiff > target_tol:
        raise RuntimeError(
            f"K4 Target mismatch: max abs difference={tdiff:.9g}, tolerance={target_tol}."
        )


def align_and_validate_k4(df, k4, cfg):
    if len(k4) != len(df):
        raise RuntimeError(f"K4 row count mismatch: got {len(k4)}, expected {len(df)}.")
    if "PixelIndex" not in k4.columns or "MaxPosterior" not in k4.columns:
        raise RuntimeError("K4 assignment must contain PixelIndex and MaxPosterior.")
    if k4["PixelIndex"].duplicated().any():
        raise RuntimeError("K4 PixelIndex is not unique.")
    if df["PixelIndex"].duplicated().any():
        raise RuntimeError("Training PixelIndex is not unique.")

    mechanism_raw = _parse_mechanism_series(k4)
    _ = _validate_k4_probability_fields(k4, mechanism_raw)

    # First try SampleID only when it is genuinely a 1:1 identity key.
    method = None
    aligned = None
    if "SampleID" in k4.columns and not k4["SampleID"].duplicated().any():
        if set(df["SampleID"].tolist()) == set(k4["SampleID"].tolist()):
            candidate = df[["SampleID"]].merge(
                k4, on="SampleID", how="left", validate="one_to_one", sort=False
            )
            try:
                _geometry_audit(df, candidate, cfg)
                aligned = candidate
                method = "SampleID"
            except Exception:
                aligned = None

    # PixelIndex is the robust fallback across outputs that regenerated SampleID.
    if aligned is None:
        candidate = df[["PixelIndex"]].merge(
            k4,
            on="PixelIndex",
            how="left",
            validate="one_to_one",
            sort=False,
            suffixes=("_Training", ""),
        )
        if candidate["MaxPosterior"].isna().any():
            raise RuntimeError(
                "K4 cannot be aligned to the ReferenceSimple table by SampleID or PixelIndex."
            )
        _geometry_audit(df, candidate, cfg)
        aligned = candidate
        method = "PixelIndex"

    mechanism = _parse_mechanism_series(aligned)
    posterior = _validate_k4_probability_fields(aligned, mechanism)

    counts = np.array([(mechanism == m).sum() for m in [1, 2, 3, 4]], dtype=int)
    expected_counts = np.asarray(cfg.get("expected_mechanism_counts", []), dtype=int)
    if expected_counts.size == 4 and not np.array_equal(counts, expected_counts):
        raise RuntimeError(
            "K4 mechanism-count fingerprint mismatch. "
            f"Got {counts.tolist()}, expected {expected_counts.tolist()}. "
            "This usually means a non-final K4 assignment was selected."
        )

    target = pd.to_numeric(aligned["Target"], errors="raise").to_numpy(float)
    means = np.array([target[mechanism == m].mean() for m in [1, 2, 3, 4]], float)
    expected_means = np.asarray(cfg.get("expected_mechanism_target_means", []), float)
    if expected_means.size == 4:
        tol = float(cfg.get("mechanism_target_mean_tolerance", 0.01))
        if np.max(np.abs(means - expected_means)) > tol:
            raise RuntimeError(
                "K4 mechanism target-mean fingerprint mismatch. "
                f"Got {means.tolist()}, expected approximately {expected_means.tolist()}, "
                f"tolerance={tol}."
            )

    out = aligned.copy()
    out["MechanismResolved"] = mechanism
    out["MaxPosteriorResolved"] = posterior

    audit = {
        "AlignmentMethod": method,
        "N": int(len(out)),
        "M1Count": int(counts[0]),
        "M2Count": int(counts[1]),
        "M3Count": int(counts[2]),
        "M4Count": int(counts[3]),
        "M1TargetMean": float(means[0]),
        "M2TargetMean": float(means[1]),
        "M3TargetMean": float(means[2]),
        "M4TargetMean": float(means[3]),
    }
    return out, audit


def _read_csv_robust(path):
    path = str(path)
    last_error = None
    for enc in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            df = pd.read_csv(path, encoding=enc)
            if len(df.columns) == 1:
                # Retry delimiter inference for semicolon/tab exports.
                try:
                    alt = pd.read_csv(path, encoding=enc, sep=None, engine="python")
                    if len(alt.columns) > len(df.columns):
                        df = alt
                except Exception:
                    pass
            return _normalise_dataframe_headers(df)
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f"Cannot read CSV file {path}: {last_error}")


def load_analysis_inputs(cfg):
    ensure_dirs(cfg)

    df = _read_csv_robust(cfg["training_csv"])
    raw_meta = _read_csv_robust(cfg["feature_metadata_csv"])
    k4 = _read_csv_robust(cfg["k4_assignment_csv"])

    required = [
        "SampleID",
        "PixelIndex",
        "RasterRow",
        "RasterColumn",
        "Longitude",
        "Latitude",
        "Target",
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"Training CSV missing columns: {missing}")

    if df["SampleID"].duplicated().any():
        raise RuntimeError("Training SampleID is not unique.")

    expected_n = int(cfg.get("expected_sample_count", len(df)))
    if len(df) != expected_n:
        raise RuntimeError(
            f"Training sample count mismatch: got {len(df)}, expected {expected_n}."
        )

    booster = xgb.Booster()
    booster.load_model(cfg["final_model_json"])
    model_features = booster.feature_names
    if model_features is None or len(model_features) == 0:
        raise RuntimeError(
            "Saved XGBoost model has no feature_names; model signature cannot be verified."
        )
    feature_names = [str(x) for x in model_features]

    if len(set(feature_names)) != len(feature_names):
        raise RuntimeError("Saved XGBoost feature_names are not unique.")

    missing_training = [f for f in feature_names if f not in df.columns]
    if missing_training:
        raise RuntimeError(
            "Saved XGBoost model requires features missing from XGBoost_Model_Data.csv: "
            + ", ".join(missing_training)
        )

    meta, metadata_missing, metadata_extras, metadata_audit_info = reconcile_metadata(
        raw_meta, feature_names
    )

    driver_to_features = {}
    for driver, g in meta.groupby(meta["Driver"].astype(str), sort=False):
        driver_to_features[str(driver)] = g["Feature"].astype(str).tolist()

    formal_drivers = set(str(x) for x in cfg.get("threshold_drivers", []))
    for pair in cfg.get("interaction_pairs", []):
        formal_drivers.update([str(pair[0]), str(pair[1])])
    unresolved = sorted(d for d in formal_drivers if d not in driver_to_features)
    if unresolved:
        raise RuntimeError(
            "Formal drivers are absent from reconciled model metadata: "
            + ", ".join(unresolved)
        )

    aligned_k4, k4_audit = align_and_validate_k4(df, k4, cfg)
    mechanism = aligned_k4["MechanismResolved"].to_numpy(int)
    posterior = aligned_k4["MaxPosteriorResolved"].to_numpy(float)

    assignment = pd.DataFrame(
        {
            "SampleID": df["SampleID"].to_numpy(),
            "PixelIndex": df["PixelIndex"].to_numpy(),
            "Mechanism": mechanism,
            "MaxPosterior": posterior,
        }
    )

    block_size = int(cfg["spatial_block_pixels"])
    br = ((df["RasterRow"].to_numpy(int) - 1) // block_size).astype(int)
    bc = ((df["RasterColumn"].to_numpy(int) - 1) // block_size).astype(int)
    assignment["SpatialBlockID"] = br.astype(str) + "_" + bc.astype(str)

    X = df[feature_names].copy()
    y = df["Target"].to_numpy(float)

    if not np.isfinite(X.to_numpy(float)).all():
        raise RuntimeError("Model feature matrix contains NaN or Inf.")
    if not np.isfinite(y).all():
        raise RuntimeError("Target contains NaN or Inf.")

    return {
        "df": df,
        "raw_meta": raw_meta,
        "meta": meta,
        "metadata_missing": metadata_missing,
        "metadata_extras": metadata_extras,
        "metadata_audit_info": metadata_audit_info,
        "k4": k4,
        "aligned_k4": aligned_k4,
        "k4_audit": k4_audit,
        "assignment": assignment,
        "feature_names": feature_names,
        "driver_to_features": driver_to_features,
        "X": X,
        "y": y,
        "booster": booster,
    }


def get_single_feature(driver_to_features, driver):
    fs = driver_to_features.get(driver, [])
    if len(fs) != 1:
        raise RuntimeError(
            f"Driver {driver} must map to exactly one continuous model feature; got {fs}"
        )
    return fs[0]


def region_mask(assignment, region, primary_conf):
    if region == "All":
        return np.ones(len(assignment), dtype=bool)
    if not region.startswith("M"):
        raise ValueError(region)
    m = int(region[1:])
    return (assignment["Mechanism"].to_numpy(int) == m) & (
        assignment["MaxPosterior"].to_numpy(float) >= float(primary_conf)
    )


def region_mask_allk4(assignment, region):
    if region == "All":
        return np.ones(len(assignment), dtype=bool)
    m = int(region[1:])
    return assignment["Mechanism"].to_numpy(int) == m


def booster_predict(booster, X, feature_names):
    dm = xgb.DMatrix(X, feature_names=feature_names)
    return booster.predict(dm)


def audit_inputs(cfg, data):
    out = Path(cfg["audit_dir"])
    out.mkdir(parents=True, exist_ok=True)

    df = data["df"]
    assignment = data["assignment"]
    feature_names = data["feature_names"]
    booster = data["booster"]

    pred = booster_predict(booster, data["X"], feature_names)
    y = data["y"]

    sse = float(np.sum((y - pred) ** 2))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - sse / sst
    rmse = float(np.sqrt(np.mean((y - pred) ** 2)))
    mae = float(np.mean(np.abs(y - pred)))
    bias = float(np.mean(pred - y))
    pearson = float(np.corrcoef(y, pred)[0, 1])

    audit_row = {
        "N": len(df),
        "SavedModelFeatureCount": len(feature_names),
        "OriginalMetadataRowCount": len(data["raw_meta"]),
        "ReconciledMetadataRowCount": len(data["meta"]),
        "AutoReconciledMetadataRows": len(data["metadata_missing"]),
        "IgnoredExtraMetadataRows": len(data["metadata_extras"]),
        "R2_LoadedFinalModel": r2,
        "RMSE_LoadedFinalModel": rmse,
        "MAE_LoadedFinalModel": mae,
        "Bias_LoadedFinalModel": bias,
        "PearsonR_LoadedFinalModel": pearson,
    }

    fit_file = Path(cfg.get("final_fit_metrics_csv", ""))
    max_diff = 0.0
    if fit_file.exists():
        ref = pd.read_csv(fit_file).iloc[0]
        mapping = {
            "R2": r2,
            "RMSE": rmse,
            "MAE": mae,
            "Bias": bias,
            "PearsonR": pearson,
        }
        for key, value in mapping.items():
            if key in ref.index:
                diff = abs(float(ref[key]) - float(value))
                audit_row[f"Reference_{key}"] = float(ref[key])
                audit_row[f"AbsDiff_{key}"] = diff
                max_diff = max(max_diff, diff)
        audit_row["MaximumMetricDifference"] = max_diff
        if max_diff > 1e-4:
            raise RuntimeError(
                "Loaded model/data do not reproduce FinalModel_TrainingFit.csv; "
                f"maximum metric difference={max_diff:.6g}."
            )

    pd.DataFrame([audit_row]).to_csv(out / "ReferenceModel_Audit.csv", index=False)
    pd.DataFrame([data["k4_audit"]]).to_csv(out / "K4_Identity_Audit.csv", index=False)

    rows = [{"Region": "All", "ConfidenceRule": "All", "N": len(df)}]
    for m in range(1, 5):
        for conf in [
            float(cfg["primary_mechanism_confidence"]),
            float(cfg["sensitivity_mechanism_confidence"]),
        ]:
            mask = (assignment["Mechanism"].to_numpy(int) == m) & (
                assignment["MaxPosterior"].to_numpy(float) >= conf
            )
            rows.append(
                {
                    "Region": f"M{m}",
                    "ConfidenceRule": f">={conf:.2f}",
                    "N": int(mask.sum()),
                }
            )
        mask = assignment["Mechanism"].to_numpy(int) == m
        rows.append(
            {"Region": f"M{m}", "ConfidenceRule": "AllK4", "N": int(mask.sum())}
        )

    pd.DataFrame(rows).to_csv(out / "Mechanism_Support_Audit.csv", index=False)
    data["meta"].to_csv(out / "Feature_Metadata_Reconciled.csv", index=False)
    pd.DataFrame(
        {
            "FeatureOrder": np.arange(1, len(feature_names) + 1),
            "Feature": feature_names,
        }
    ).to_csv(out / "SavedModel_FeatureSignature.csv", index=False)

    metadata_audit = {
        "OriginalMetadataRows": int(len(data["raw_meta"])),
        "SavedModelFeatureCount": int(len(feature_names)),
        "AutoReconciledMissing": ";".join(data["metadata_missing"]),
        "IgnoredMetadataExtras": ";".join(data["metadata_extras"]),
    }
    metadata_audit.update(data.get("metadata_audit_info", {}))
    pd.DataFrame([metadata_audit]).to_csv(
        out / "Feature_Metadata_Audit.csv", index=False
    )
