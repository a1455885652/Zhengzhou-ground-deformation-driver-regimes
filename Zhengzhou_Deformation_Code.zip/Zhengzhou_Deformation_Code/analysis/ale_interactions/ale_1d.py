from __future__ import annotations

import numpy as np
import pandas as pd
import xgboost as xgb


def quantile_edges(x, target_bins, minimum_bins):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size < 20:
        raise RuntimeError("Too few values for ALE.")

    for nbin in range(int(target_bins), int(minimum_bins) - 1, -1):
        q = np.linspace(0.0, 1.0, nbin + 1)
        e = np.unique(np.quantile(x, q))
        if len(e) - 1 >= int(minimum_bins):
            return e

    raise RuntimeError("Could not construct enough unique quantile ALE bins.")


def _predict(booster, arr, feature_names):
    d = xgb.DMatrix(arr, feature_names=feature_names)
    return booster.predict(d)


def integrate_local_effects(local, counts):
    local = np.asarray(local, float)
    counts = np.asarray(counts, float)
    g_bound = np.r_[0.0, np.cumsum(local)]
    effect = 0.5 * (g_bound[:-1] + g_bound[1:])
    if counts.sum() > 0:
        effect = effect - np.average(effect, weights=np.maximum(counts, 1))
    else:
        effect = effect - np.mean(effect)
    return effect


def compute_ale_1d(
    booster,
    X,
    feature_names,
    feature,
    target_bins,
    minimum_bins,
    min_bin_count,
    fixed_edges=None,
):
    if feature not in feature_names:
        raise RuntimeError(f"Feature {feature} is not in model.")

    Xdf = X if isinstance(X, pd.DataFrame) else pd.DataFrame(X, columns=feature_names)
    arr = Xdf[feature_names].to_numpy(float, copy=True)
    j = feature_names.index(feature)
    x = arr[:, j].copy()

    edges = (
        np.asarray(fixed_edges, float)
        if fixed_edges is not None
        else quantile_edges(x, target_bins, minimum_bins)
    )

    K = len(edges) - 1
    if K < minimum_bins:
        raise RuntimeError(f"Only {K} ALE bins available.")

    b = np.searchsorted(edges[1:-1], x, side="right")
    b = np.clip(b, 0, K - 1)

    lo = edges[b]
    hi = edges[b + 1]

    A = arr.copy()
    B = arr.copy()
    A[:, j] = lo
    B[:, j] = hi

    stacked = np.vstack([A, B])
    pred = _predict(booster, stacked, feature_names)
    p_lo = pred[: len(arr)]
    p_hi = pred[len(arr) :]
    delta = p_hi - p_lo

    counts = np.bincount(b, minlength=K).astype(int)
    local = np.full(K, np.nan, float)
    centers = np.full(K, np.nan, float)

    for k in range(K):
        idx = b == k
        if idx.any():
            centers[k] = float(np.median(x[idx]))
        else:
            centers[k] = float(0.5 * (edges[k] + edges[k + 1]))

        if counts[k] >= int(min_bin_count):
            local[k] = float(np.mean(delta[idx]))

    missing = ~np.isfinite(local)
    if missing.any():
        valid = np.where(~missing)[0]
        if len(valid) < max(3, K - 2):
            raise RuntimeError(f"Too many unsupported ALE bins: {missing.sum()} of {K}")
        local[missing] = np.interp(np.where(missing)[0], valid, local[valid])

    effect = integrate_local_effects(local, counts)

    return {
        "edges": edges,
        "x_center": centers,
        "x_low": edges[:-1],
        "x_high": edges[1:],
        "ale": effect,
        "local_effect": local,
        "count": counts,
        "sample_bin_index": b,
        "sample_delta": delta,
        "sample_x": x,
    }
