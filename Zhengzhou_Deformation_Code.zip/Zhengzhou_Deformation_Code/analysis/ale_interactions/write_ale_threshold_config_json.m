function write_ale_threshold_config_json(cfg, outFile)

J = struct();
J.project_version = cfg.projectVersion;
J.python_exe = cfg.pythonExe;
J.try_gpu = cfg.tryGPU;
J.random_seed = cfg.randomSeed;
J.training_csv = cfg.trainingCsv;
J.feature_metadata_csv = cfg.featureMetadataCsv;
J.final_model_json = cfg.finalModelJson;
J.best_params_json = cfg.bestParamsJson;
J.final_fit_metrics_csv = cfg.finalFitMetricsCsv;
J.expected_sample_count = cfg.expectedSampleCount;
J.k4_assignment_csv = cfg.k4AssignmentCsv;
J.expected_mechanism_counts = cfg.expectedMechanismCounts;
J.expected_mechanism_target_means = cfg.expectedMechanismTargetMeans;
J.mechanism_target_mean_tolerance = cfg.mechanismTargetMeanTolerance;
J.coordinate_tolerance_degrees = cfg.coordinateToleranceDegrees;
J.target_tolerance = cfg.targetTolerance;
J.output_root = cfg.outputRoot;
J.audit_dir = cfg.auditDir;
J.threshold_dir = cfg.thresholdDir;
J.interaction_dir = cfg.interactionDir;
J.figure_dir = cfg.figureDir;
J.checkpoint_dir = cfg.checkpointDir;
J.primary_mechanism_confidence = cfg.primaryMechanismConfidence;
J.sensitivity_mechanism_confidence = cfg.sensitivityMechanismConfidence;
J.spatial_block_pixels = cfg.spatialBlockPixels;
J.minimum_region_samples = cfg.minimumRegionSamples;

% Force one-dimensional string list.
J.threshold_drivers = reshape(cfg.thresholdDrivers,1,[]);
J.ale_target_bins = cfg.aleTargetBins;
J.ale_minimum_bins = cfg.aleMinimumBins;
J.ale_min_bin_count = cfg.aleMinBinCount;
J.ale_bootstrap_min_bin_count = cfg.aleBootstrapMinBinCount;
J.threshold_search_quantile = cfg.thresholdSearchQuantile;
J.threshold_min_segment_bins = cfg.thresholdMinSegmentBins;
J.allow_two_breakpoints = cfg.allowTwoBreakpoints;
J.fixed_model_bootstrap_reps = cfg.fixedModelBootstrapReps;
J.refit_bootstrap_reps = cfg.refitBootstrapReps;
J.robust_min_delta_bic = cfg.robustMinDeltaBIC;
J.robust_min_fixed_detection = cfg.robustMinFixedDetection;
J.robust_min_refit_detection = cfg.robustMinRefitDetection;
J.robust_min_normalized_slope_change = cfg.robustMinNormalizedSlopeChange;
J.robust_max_ci95_width_fraction = cfg.robustMaxCI95WidthFraction;
J.supported_min_delta_bic = cfg.supportedMinDeltaBIC;
J.supported_min_fixed_detection = cfg.supportedMinFixedDetection;
J.supported_min_refit_detection = cfg.supportedMinRefitDetection;
J.supported_min_normalized_slope_change = cfg.supportedMinNormalizedSlopeChange;
J.supported_max_ci90_width_fraction = cfg.supportedMaxCI90WidthFraction;
J.candidate_min_delta_bic = cfg.candidateMinDeltaBIC;
J.candidate_min_fixed_detection = cfg.candidateMinFixedDetection;
J.candidate_min_normalized_slope_change = cfg.candidateMinNormalizedSlopeChange;

% IMPORTANT: MATLAB jsonencode can flatten a 2-D cell array.
% Wrap every row in its own cell so Python receives a true nested list.
pairRows = cell(size(cfg.interactionPairs,1),1);
for i = 1:size(cfg.interactionPairs,1)
    pairRows{i} = reshape(cfg.interactionPairs(i,:),1,[]);
end
J.interaction_pairs = pairRows;
J.interaction_bootstrap_reps = cfg.interactionBootstrapReps;
J.exact_interaction_chunk_rows = cfg.exactInteractionChunkRows;
J.interaction_min_region_samples = cfg.interactionMinRegionSamples;
J.strong_interaction_top_rank = cfg.strongInteractionTopRank;
J.strong_interaction_top3_freq = cfg.strongInteractionTop3Freq;
J.strong_interaction_min_share = cfg.strongInteractionMinShare;
J.supported_interaction_top_rank = cfg.supportedInteractionTopRank;
J.supported_interaction_top3_freq = cfg.supportedInteractionTop3Freq;
J.supported_interaction_min_share = cfg.supportedInteractionMinShare;
J.ale2d_target_bins = cfg.ale2dTargetBins;
J.ale2d_minimum_bins = cfg.ale2dMinimumBins;
J.ale2d_min_cell_count = cfg.ale2dMinCellCount;
J.ale2d_minimum_occupied_fraction = cfg.ale2dMinimumOccupiedFraction;
J.ale2d_bootstrap_reps = cfg.ale2dBootstrapReps;

targetRows = cell(size(cfg.ale2dTargets,1),1);
for i = 1:size(cfg.ale2dTargets,1)
    targetRows{i} = reshape(cfg.ale2dTargets(i,:),1,[]);
end
J.ale2d_targets = targetRows;

J.smoke_fixed_bootstrap_reps = cfg.smokeFixedBootstrapReps;
J.smoke_interaction_rows = cfg.smokeInteractionRows;
J.smoke_ale2d_bootstrap_reps = cfg.smokeAle2dBootstrapReps;
J.figure_dpi = cfg.figureDPI;

ensure_folder_ale(fileparts(outFile));
fid = fopen(outFile,'w');
if fid < 0
    error('Cannot write config JSON: %s', outFile);
end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s',jsonencode(J,PrettyPrint=true));
end
