clearvars -except cfg;

if exist('cfg','var')
    cfg = ensure_current_ale_config_v1_5(cfg);
else
    cfg = ensure_current_ale_config_v1_5([]);
end

fprintf('\n============================================================\n');
fprintf(' STAGE 1: 1D ALE + segmented thresholds + spatial bootstrap\n');
fprintf('============================================================\n');

ensure_folder_ale(cfg.outputRoot);
ensure_folder_ale(cfg.configDir);

configFile = fullfile(cfg.configDir, 'ale_threshold_interaction_config_v1_5.json');
write_ale_threshold_config_json(cfg, configFile);

status = run_python_stage_ale(cfg, configFile, 'threshold');

if status ~= 0
    error('Python threshold stage failed.');
end

verify_stage1_outputs_ale(cfg);

disp('STAGE 1 COMPLETED.');
