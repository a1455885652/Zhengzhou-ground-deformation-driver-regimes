clear; clc;

cfg = config_ale_threshold_interaction_v1_5();

% QUICK DIAGNOSTIC IS ONLY FOR INPUT / THRESHOLD PIPELINE TESTING.
% The formal exact interaction stage intentionally evaluates ALL modeling
% samples and is therefore not shortened here.
cfg.fixedModelBootstrapReps = 40;
cfg.refitBootstrapReps = 12;

cfg.outputRoot = fullfile(cfg.outputRoot, 'QUICK_DIAGNOSTIC');
cfg.thresholdDir = fullfile(cfg.outputRoot, '01_Thresholds');
cfg.interactionDir = fullfile(cfg.outputRoot, '02_Interactions');
cfg.figureDir = fullfile(cfg.outputRoot, '03_Figures');
cfg.auditDir = fullfile(cfg.outputRoot, '00_Audit');
cfg.checkpointDir = fullfile(cfg.outputRoot, '04_Checkpoints');
cfg.configDir = fullfile(cfg.outputRoot, 'Config');

ensure_folder_ale(cfg.outputRoot);
ensure_folder_ale(cfg.configDir);

CHECK_INPUTS_ALE_THRESHOLD_INTERACTION;
SELF_TEST_ALE_THRESHOLD_INTERACTION;
RUN_REALDATA_SMOKE_TEST_ALE_V1_5;
RUN_STAGE1_ALE_THRESHOLDS;

disp(' ');
disp('QUICK THRESHOLD DIAGNOSTIC COMPLETED.');
disp('Formal Stage 2 exact interactions were intentionally NOT run.');
disp('Run RUN_STAGE2_INTERACTIONS for the manuscript-grade exact interaction analysis.');
