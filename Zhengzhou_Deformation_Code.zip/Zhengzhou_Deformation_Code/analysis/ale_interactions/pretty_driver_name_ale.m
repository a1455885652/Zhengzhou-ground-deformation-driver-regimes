function s = pretty_driver_name_ale(driver)

driver = string(driver);

switch driver
    case "GWS"
        s = "GWS";
    case "SurfaceRunoff"
        s = "Surface runoff";
    case "SubsurfaceRunoff"
        s = "Subsurface runoff";
    case "SkinReservoir"
        s = "Skin reservoir";
    case "TotalPrecipitation"
        s = "Total precipitation";
    case "BuiltSurface"
        s = "Built surface";
    case "TotalLooseThickness"
        s = "Loose-layer thickness";
    otherwise
        s = driver;
end

end
