from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import xgboost as xgb

from ale_io import get_single_feature, region_mask
from ale_bootstrap import sample_block_indices
from ale2d import compute_ale2d, bootstrap_ale2d_amplitude


def _sha256_file(path, chunk=1024 * 1024):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _interaction_signature(cfg, data, pairs):
    sample_ids = np.asarray(data["df"]["SampleID"], dtype=np.int64)
    h = hashlib.sha256()
    h.update(sample_ids.tobytes())
    h.update(json.dumps(pairs, sort_keys=True).encode("utf-8"))
    model_hash = _sha256_file(cfg["final_model_json"])
    training_hash = _sha256_file(cfg["training_csv"])
    metadata_hash = _sha256_file(cfg["feature_metadata_csv"])
    h.update(model_hash.encode("ascii"))
    h.update(training_hash.encode("ascii"))
    h.update(metadata_hash.encode("ascii"))
    return {
        "signature": h.hexdigest(),
        "n_samples": int(len(sample_ids)),
        "pairs": [list(x) for x in pairs],
        "model_sha256": model_hash,
        "training_csv_sha256": training_hash,
        "feature_metadata_sha256": metadata_hash,
        "method": "exact_xgboost_pred_interactions_full_sample",
    }


def selected_interaction_values(cfg, data):
    """Extract exact native XGBoost pairwise SHAP interactions for ALL samples.

    Only the six pre-specified pair columns are retained, but the native exact
    interaction matrix is evaluated for every sample. No approx_contribs=True
    shortcut is used. The calculation is chunked and checkpointed, so an
    interrupted run can resume without recomputing completed chunks.
    """
    X = data["X"]
    feature_names = data["feature_names"]
    booster = data["booster"]
    f2d = data["driver_to_features"]

    pairs = [tuple(x) for x in cfg["interaction_pairs"]]
    feature_pairs = [
        (get_single_feature(f2d, a), get_single_feature(f2d, b)) for a, b in pairs
    ]

    chunk_rows = int(cfg.get("exact_interaction_chunk_rows", 100))
    if chunk_rows < 1:
        raise RuntimeError("exact_interaction_chunk_rows must be >= 1")

    checkpoint_dir = Path(cfg["checkpoint_dir"]) / "InteractionExact"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    manifest_file = checkpoint_dir / "ExactInteraction_Checkpoint_Manifest.json"

    signature = _interaction_signature(cfg, data, pairs)
    if manifest_file.exists():
        old = json.loads(manifest_file.read_text(encoding="utf-8"))
        if old.get("signature") != signature["signature"]:
            raise RuntimeError(
                "Existing exact-interaction checkpoints were generated from a "
                "different model/sample/pair configuration. Delete the folder "
                f"{checkpoint_dir} before rerunning."
            )
    else:
        manifest_file.write_text(
            json.dumps(signature, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    n = len(X)
    n_pairs = len(pairs)
    out = np.full((n, n_pairs), np.nan, dtype=np.float64)

    t0 = time.time()
    total_chunks = int(np.ceil(n / chunk_rows))

    for chunk_id, start in enumerate(range(0, n, chunk_rows), start=1):
        stop = min(start + chunk_rows, n)
        cfile = checkpoint_dir / f"interaction_chunk_{start:06d}_{stop:06d}.npz"

        use_checkpoint = False
        if cfile.exists():
            try:
                z = np.load(cfile)
                values = np.asarray(z["values"], float)
                starts = int(z["start"])
                stops = int(z["stop"])
                use_checkpoint = (
                    starts == start
                    and stops == stop
                    and values.shape == (stop - start, n_pairs)
                    and np.isfinite(values).all()
                )
            except Exception:
                use_checkpoint = False

            if not use_checkpoint:
                print(
                    f"[Exact interaction] invalid checkpoint will be recomputed: {cfile.name}"
                )
                try:
                    cfile.unlink()
                except OSError:
                    pass

        if use_checkpoint:
            out[start:stop] = values
        else:
            dm = xgb.DMatrix(
                X.iloc[start:stop],
                feature_names=feature_names,
            )

            # IMPORTANT: exact native TreeSHAP interaction values.
            # Do not set approx_contribs=True; it can suppress off-diagonal
            # interactions for this fitted tree ensemble.
            I = booster.predict(dm, pred_interactions=True)

            if I.ndim != 3:
                raise RuntimeError(f"Unexpected XGBoost interaction shape: {I.shape}")
            expected = len(feature_names) + 1  # + bias row/column
            if I.shape[1] != expected or I.shape[2] != expected:
                raise RuntimeError(
                    f"Unexpected interaction matrix size {I.shape}; expected "
                    f"(*,{expected},{expected})."
                )

            values = np.zeros((stop - start, n_pairs), float)
            for j, (fa, fb) in enumerate(feature_pairs):
                ia = feature_names.index(fa)
                ib = feature_names.index(fb)

                # SHAP interaction matrices are symmetric. The off-diagonal
                # term phi_ij contributes to feature i and again to feature j;
                # 2*phi_ij is therefore the full pair contribution to f(x).
                values[:, j] = 2.0 * I[:, ia, ib]

            np.savez_compressed(
                cfile,
                start=np.int64(start),
                stop=np.int64(stop),
                values=values.astype(np.float32),
            )
            out[start:stop] = values

        if chunk_id == 1 or chunk_id % 5 == 0 or chunk_id == total_chunks:
            elapsed = time.time() - t0
            done = stop
            rate = done / max(elapsed, 1e-9)
            eta = (n - done) / max(rate, 1e-9)
            print(
                f"[Exact interaction] chunk {chunk_id}/{total_chunks}; "
                f"rows {start}:{stop}; elapsed={elapsed / 60:.1f} min; "
                f"ETA~{eta / 60:.1f} min"
            )

    if not np.isfinite(out).all():
        raise RuntimeError("Exact interaction extraction produced NaN/Inf.")

    cols = [f"{a}__{b}" for a, b in pairs]
    values_df = pd.DataFrame(out, columns=cols)

    audit = dict(signature)
    audit.update(
        {
            "chunk_rows": chunk_rows,
            "xgboost_version": xgb.__version__,
            "elapsed_seconds_this_run": float(time.time() - t0),
            "note": (
                "Every modeling sample is evaluated with exact native XGBoost "
                "pred_interactions=True. Only pre-specified pair columns are retained."
            ),
        }
    )
    Path(cfg["interaction_dir"]).mkdir(parents=True, exist_ok=True)
    (Path(cfg["interaction_dir"]) / "ExactInteraction_Audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    return values_df, pairs


def interaction_strength_bootstrap(cfg, data, sample_values, pairs):
    assignment = data["assignment"]
    block_ids = assignment["SpatialBlockID"].to_numpy()
    B = int(cfg["interaction_bootstrap_reps"])
    rng = np.random.default_rng(int(cfg["random_seed"]) + 30000)

    regions = ["All", "M1", "M2", "M3", "M4"]
    rows = []

    for region in regions:
        mask = region_mask(
            assignment, region, float(cfg["primary_mechanism_confidence"])
        )
        indices = np.where(mask)[0]

        if len(indices) < int(cfg.get("interaction_min_region_samples", 150)):
            raise RuntimeError(
                f"{region} has only {len(indices)} samples for interaction analysis."
            )

        values = np.abs(sample_values.iloc[indices].to_numpy(float))
        observed = values.mean(axis=0)
        share = observed / max(observed.sum(), 1e-15)
        rank = pd.Series(-observed).rank(method="min").astype(int).to_numpy()

        boot_strength = np.full((B, len(pairs)), np.nan, float)
        boot_rank = np.full((B, len(pairs)), np.nan, float)
        boot_share = np.full((B, len(pairs)), np.nan, float)

        for b in range(B):
            samp = sample_block_indices(indices, block_ids, rng)
            v = np.abs(sample_values.iloc[samp].to_numpy(float)).mean(axis=0)
            boot_strength[b] = v
            boot_share[b] = v / max(v.sum(), 1e-15)
            boot_rank[b] = pd.Series(-v).rank(method="min").to_numpy()

        top3freq = np.mean(boot_rank <= 3, axis=0)

        for j, (a, bdrv) in enumerate(pairs):
            r = int(rank[j])
            s = float(share[j])
            t3 = float(top3freq[j])

            if (
                r <= int(cfg["strong_interaction_top_rank"])
                and t3 >= float(cfg["strong_interaction_top3_freq"])
                and s >= float(cfg["strong_interaction_min_share"])
            ):
                cls = "StrongInteraction"
            elif (
                r <= int(cfg["supported_interaction_top_rank"])
                and t3 >= float(cfg["supported_interaction_top3_freq"])
                and s >= float(cfg["supported_interaction_min_share"])
            ):
                cls = "SupportedInteraction"
            else:
                cls = "SecondaryInteraction"

            rows.append(
                {
                    "Region": region,
                    "Driver1": a,
                    "Driver2": bdrv,
                    "Pair": f"{a}__{bdrv}",
                    "N": int(len(indices)),
                    "MeanAbsPairSHAPInteraction": float(observed[j]),
                    "NormalizedShareAmongSelected": s,
                    "RankAmongSelected": r,
                    "BootstrapTop3Frequency": t3,
                    "BootstrapCI95_Low": float(
                        np.nanpercentile(boot_strength[:, j], 2.5)
                    ),
                    "BootstrapCI95_High": float(
                        np.nanpercentile(boot_strength[:, j], 97.5)
                    ),
                    "BootstrapShareCI95_Low": float(
                        np.nanpercentile(boot_share[:, j], 2.5)
                    ),
                    "BootstrapShareCI95_High": float(
                        np.nanpercentile(boot_share[:, j], 97.5)
                    ),
                    "InteractionClass": cls,
                }
            )

    return pd.DataFrame(rows)


def run_ale2d_targets(cfg, data):
    outdir = Path(cfg["interaction_dir"]) / "ALE2D"
    outdir.mkdir(parents=True, exist_ok=True)

    assignment = data["assignment"]
    X = data["X"]
    feature_names = data["feature_names"]
    booster = data["booster"]
    f2d = data["driver_to_features"]
    block_ids = assignment["SpatialBlockID"].to_numpy()

    manifest = []

    for target_i, target in enumerate(cfg["ale2d_targets"]):
        region, d1, d2 = target
        pair_name = f"{region}__{d1}__{d2}"
        try:
            f1 = get_single_feature(f2d, d1)
            f2 = get_single_feature(f2d, d2)

            mask = region_mask(
                assignment, region, float(cfg["primary_mechanism_confidence"])
            )
            idx = np.where(mask)[0]
            if len(idx) < int(cfg.get("minimum_region_samples", 150)):
                raise RuntimeError(f"insufficient regional support: N={len(idx)}")

            Xr = X.iloc[idx]

            surface = compute_ale2d(
                booster=booster,
                X=Xr,
                feature_names=feature_names,
                feature1=f1,
                feature2=f2,
                target_bins=int(cfg["ale2d_target_bins"]),
                minimum_bins=int(cfg["ale2d_minimum_bins"]),
                min_cell_count=int(cfg["ale2d_min_cell_count"]),
                minimum_occupied_fraction=float(cfg["ale2d_minimum_occupied_fraction"]),
            )

            rows = []
            for iy, yc in enumerate(surface["y_center"]):
                for ix, xc in enumerate(surface["x_center"]):
                    rows.append(
                        {
                            "Region": region,
                            "Driver1": d1,
                            "Driver2": d2,
                            "XCenter": xc,
                            "YCenter": yc,
                            "ALE2D": surface["effect"][iy, ix],
                            "CellCount": int(surface["count"][iy, ix]),
                            "ObservedCell": bool(surface["observed"][iy, ix]),
                            "DisplaySupported": bool(surface["observed"][iy, ix]),
                            "StrongSupport": bool(surface["strong_support"][iy, ix]),
                        }
                    )

            file = outdir / f"ALE2D_{pair_name}.csv"
            pd.DataFrame(rows).to_csv(file, index=False)

            boot = bootstrap_ale2d_amplitude(
                baseline_surface=surface,
                region_indices=idx,
                block_ids=block_ids,
                reps=int(cfg["ale2d_bootstrap_reps"]),
                min_cell_count=max(4, int(cfg["ale2d_min_cell_count"]) // 2),
                seed=int(cfg["random_seed"]) + 40000 + target_i,
            )

            manifest.append(
                {
                    "Region": region,
                    "Driver1": d1,
                    "Driver2": d2,
                    "Status": "OK",
                    "Error": "",
                    "SurfaceFile": str(file),
                    "N": int(len(idx)),
                    "XBins": int(len(surface["x_center"])),
                    "YBins": int(len(surface["y_center"])),
                    "OccupiedFraction": surface["occupied_fraction"],
                    "ALE2DAmplitude": surface["amplitude"],
                    "AmplitudeBootstrapValid": int(boot["valid_reps"]),
                    "AmplitudeCI95_Low": float(boot["ci95_low"]),
                    "AmplitudeCI95_High": float(boot["ci95_high"]),
                    "AmplitudeCI90_Low": float(boot["ci90_low"]),
                    "AmplitudeCI90_High": float(boot["ci90_high"]),
                }
            )

            print(
                f"[2D ALE] {region} {d1} x {d2}: N={len(idx)}, "
                f"grid={len(surface['x_center'])}x{len(surface['y_center'])}, "
                f"occupied={surface['occupied_fraction']:.2f}, "
                f"bootstrap={boot['valid_reps']}"
            )

        except Exception as e:
            manifest.append(
                {
                    "Region": region,
                    "Driver1": d1,
                    "Driver2": d2,
                    "Status": "Failed",
                    "Error": str(e),
                    "SurfaceFile": "",
                    "N": np.nan,
                    "XBins": np.nan,
                    "YBins": np.nan,
                    "OccupiedFraction": np.nan,
                    "ALE2DAmplitude": np.nan,
                    "AmplitudeBootstrapValid": 0,
                    "AmplitudeCI95_Low": np.nan,
                    "AmplitudeCI95_High": np.nan,
                    "AmplitudeCI90_Low": np.nan,
                    "AmplitudeCI90_High": np.nan,
                }
            )
            print(f"[2D ALE] {pair_name}: FAILED but Stage 2 continues: {e}")

    return pd.DataFrame(manifest)
