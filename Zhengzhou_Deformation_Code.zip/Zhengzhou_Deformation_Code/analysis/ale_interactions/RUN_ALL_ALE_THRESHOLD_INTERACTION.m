clear; clc;

disp('============================================================');
disp(' Zhengzhou K4 ALE Threshold + Interaction Analysis v1.5');
disp('============================================================');

cfg = config_ale_threshold_interaction_v1_5();
ensure_folder_ale(cfg.outputRoot);
ensure_folder_ale(cfg.configDir);

SELF_TEST_CONFIG_V1_5;
CHECK_INPUTS_ALE_THRESHOLD_INTERACTION;
SELF_TEST_ALE_THRESHOLD_INTERACTION;
RUN_REALDATA_SMOKE_TEST_ALE_V1_5;
RUN_STAGE1_ALE_THRESHOLDS;
RUN_STAGE2_INTERACTIONS;
RUN_STAGE3_PAPER_FIGURES;

disp(' ');
disp('ALL ALE THRESHOLD + INTERACTION STAGES COMPLETED.');
disp(['Output root: ', cfg.outputRoot]);
