function verify_stage1_outputs_ale(cfg)

required = { ...
    fullfile(cfg.thresholdDir, 'ALE_Threshold_Summary.csv'), ...
    fullfile(cfg.thresholdDir, 'ALE_Threshold_Breakpoints.csv'), ...
    fullfile(cfg.thresholdDir, 'Threshold_Sensitivity.csv'), ...
    fullfile(cfg.thresholdDir, 'Threshold_Mechanism_Contrasts.csv'), ...
    fullfile(cfg.thresholdDir, 'ALE_Curve_Manifest.csv') ...
    };

for i = 1:numel(required)
    if ~exist(required{i}, 'file')
        error('Stage 1 missing expected output: %s', required{i});
    end
end

T = readtable(fullfile(cfg.thresholdDir, 'ALE_Threshold_Summary.csv'), ...
    'TextType','string', 'VariableNamingRule','preserve');

expectedRows = 5 * numel(cfg.thresholdDrivers);
if height(T) ~= expectedRows
    error('Stage 1 summary row count mismatch: got %d, expected %d.', ...
        height(T), expectedRows);
end

if ~all(ismember({'Region','Driver','Status','OverallThresholdEvidence'}, ...
        T.Properties.VariableNames))
    error('Stage 1 summary is missing required columns.');
end

fprintf('Stage 1 summary rows: %d\n', height(T));
fprintf('Stage 1 successful primary combinations: %d/%d\n', ...
    sum(T.Status == "OK"), height(T));

end
