from __future__ import annotations

import argparse
import json
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import xgboost as xgb

from ale_io import (
    load_config,
    ensure_dirs,
    load_analysis_inputs,
    audit_inputs,
    get_single_feature,
    region_mask,
    region_mask_allk4,
)
from ale_1d import compute_ale_1d
from threshold_segmented import fit_segmented_thresholds
from ale_bootstrap import (
    fixed_model_bootstrap,
    run_refit_bootstrap,
    aggregate_refit_bootstrap,
)
from interaction_analysis import (
    selected_interaction_values,
    interaction_strength_bootstrap,
    run_ale2d_targets,
)
from ale2d import compute_ale2d, bootstrap_ale2d_amplitude

warnings.filterwarnings("ignore", message=".*mismatched devices.*")


def _curve_dataframe(region, driver, feature, ale, fixed=None):
    T = pd.DataFrame(
        {
            "Region": region,
            "Driver": driver,
            "Feature": feature,
            "Bin": np.arange(1, len(ale["x_center"]) + 1),
            "XLow": ale["x_low"],
            "XHigh": ale["x_high"],
            "XCenter": ale["x_center"],
            "ALE": ale["ale"],
            "BinCount": ale["count"],
        }
    )

    if fixed is None:
        T["CI95_Low"] = np.nan
        T["CI95_High"] = np.nan
        T["CI90_Low"] = np.nan
        T["CI90_High"] = np.nan
    else:
        T["CI95_Low"] = fixed["ci95_low"]
        T["CI95_High"] = fixed["ci95_high"]
        T["CI90_Low"] = fixed["ci90_low"]
        T["CI90_High"] = fixed["ci90_high"]

    return T


def _summarize_breakpoints(
    cfg, region, driver, feature, main_fit, fixed, refit_info, support_x
):
    rows = []

    bps = main_fit["breakpoints"]
    if not bps:
        return rows

    x_range = max(float(np.max(support_x) - np.min(support_x)), 1e-12)

    fixed_matched = fixed["matched_breakpoints"]
    refit_matched = refit_info["matched_breakpoints"]

    for j, t in enumerate(bps):
        fvals = fixed_matched[:, j] if fixed_matched.shape[1] > j else np.array([])
        rvals = refit_matched[:, j] if refit_matched.shape[1] > j else np.array([])

        fvalid = np.isfinite(fvals)
        rvalid = np.isfinite(rvals)

        fixed_freq = float(np.mean(fvalid)) if len(fvalid) else np.nan
        refit_freq = float(np.mean(rvalid)) if len(rvalid) else np.nan

        f_ci95 = (
            np.nanpercentile(fvals, [2.5, 97.5]) if fvalid.any() else [np.nan, np.nan]
        )
        f_ci90 = np.nanpercentile(fvals, [5, 95]) if fvalid.any() else [np.nan, np.nan]

        width95 = (
            float((f_ci95[1] - f_ci95[0]) / x_range)
            if np.all(np.isfinite(f_ci95))
            else np.inf
        )
        width90 = (
            float((f_ci90[1] - f_ci90[0]) / x_range)
            if np.all(np.isfinite(f_ci90))
            else np.inf
        )

        norm_change = (
            main_fit["normalized_slope_changes"][j]
            if j < len(main_fit["normalized_slope_changes"])
            else np.nan
        )

        delta_bic = float(main_fit["delta_bic_vs_null"])

        if (
            delta_bic >= float(cfg["robust_min_delta_bic"])
            and fixed_freq >= float(cfg["robust_min_fixed_detection"])
            and refit_freq >= float(cfg["robust_min_refit_detection"])
            and norm_change >= float(cfg["robust_min_normalized_slope_change"])
            and width95 <= float(cfg["robust_max_ci95_width_fraction"])
        ):
            cls = "RobustThreshold"

        elif (
            delta_bic >= float(cfg["supported_min_delta_bic"])
            and fixed_freq >= float(cfg["supported_min_fixed_detection"])
            and refit_freq >= float(cfg["supported_min_refit_detection"])
            and norm_change >= float(cfg["supported_min_normalized_slope_change"])
            and width90 <= float(cfg["supported_max_ci90_width_fraction"])
        ):
            cls = "SupportedThreshold"

        elif (
            delta_bic >= float(cfg["candidate_min_delta_bic"])
            and fixed_freq >= float(cfg["candidate_min_fixed_detection"])
            and norm_change >= float(cfg["candidate_min_normalized_slope_change"])
        ):
            cls = "CandidateThreshold"

        else:
            cls = "UnstableThreshold"

        rows.append(
            {
                "Region": region,
                "Driver": driver,
                "Feature": feature,
                "BreakpointIndex": j + 1,
                "Threshold": float(t),
                "ThresholdQuantile": float(main_fit["breakpoint_quantiles"][j]),
                "ThresholdClass": cls,
                "MainModel": int(main_fit["model"]),
                "DeltaBIC_vs_Linear": delta_bic,
                "NormalizedSlopeChange": float(norm_change),
                "FixedBootstrapDetectionFrequency": fixed_freq,
                "RefitBootstrapDetectionFrequency": refit_freq,
                "FixedCI95_Low": float(f_ci95[0]),
                "FixedCI95_High": float(f_ci95[1]),
                "FixedCI90_Low": float(f_ci90[0]),
                "FixedCI90_High": float(f_ci90[1]),
                "CI95WidthFractionOfFeatureRange": width95,
                "CI90WidthFractionOfFeatureRange": width90,
                "SlopeBeforeOrPreviousSegment": float(main_fit["slopes"][j]),
                "SlopeAfter": float(main_fit["slopes"][j + 1]),
            }
        )

    return rows


def _threshold_class_rank(cls):
    order = {
        "RobustThreshold": 4,
        "SupportedThreshold": 3,
        "CandidateThreshold": 2,
        "UnstableThreshold": 1,
    }
    return order.get(str(cls), 0)


def _ci_excludes_zero(lo, hi):
    return bool(np.isfinite(lo) and np.isfinite(hi) and (lo > 0 or hi < 0))


def build_threshold_mechanism_contrasts(cfg, baseline_records, refit, breakpoint_rows):
    """Compare M1-M4 breakpoint locations using spatial-bootstrap distributions.

    This is a secondary mechanism-difference analysis. It does not manufacture
    a breakpoint where either mechanism lacks one. Fixed-model and refit
    bootstrap distributions are compared separately.
    """
    import itertools

    B = pd.DataFrame(breakpoint_rows)
    if B.empty:
        return pd.DataFrame(
            columns=[
                "Driver",
                "BreakpointIndex",
                "RegionA",
                "RegionB",
                "ThresholdA",
                "ThresholdB",
                "Difference_AminusB",
                "FixedBootstrapCommonN",
                "FixedDiffCI95_Low",
                "FixedDiffCI95_High",
                "FixedDiffCI90_Low",
                "FixedDiffCI90_High",
                "RefitBootstrapCommonN",
                "RefitDiffCI90_Low",
                "RefitDiffCI90_High",
                "ContrastClass",
            ]
        )

    recmap = {(r["region"], r["driver"]): r for r in baseline_records}
    rows = []
    mechanisms = ["M1", "M2", "M3", "M4"]

    for driver in [str(x) for x in cfg["threshold_drivers"]]:
        for region_a, region_b in itertools.combinations(mechanisms, 2):
            qa = B[(B.Region == region_a) & (B.Driver == driver)]
            qb = B[(B.Region == region_b) & (B.Driver == driver)]
            if qa.empty or qb.empty:
                continue

            common_bp = sorted(
                set(qa.BreakpointIndex.astype(int))
                & set(qb.BreakpointIndex.astype(int))
            )
            for bp_idx in common_bp:
                ra = qa[qa.BreakpointIndex.astype(int) == bp_idx].iloc[0]
                rb = qb[qb.BreakpointIndex.astype(int) == bp_idx].iloc[0]

                reca = recmap[(region_a, driver)]
                recb = recmap[(region_b, driver)]
                j = bp_idx - 1

                fa = reca["fixed"]["matched_breakpoints"][:, j]
                fb = recb["fixed"]["matched_breakpoints"][:, j]
                fa = fa[np.isfinite(fa)]
                fb = fb[np.isfinite(fb)]

                # The mechanism bootstraps use independent random streams. Pairing
                # equal-length prefixes is therefore a Monte-Carlo draw from the
                # independent difference distribution.
                nf = min(len(fa), len(fb))
                if nf > 0:
                    fdiff = fa[:nf] - fb[:nf]
                    f95 = np.percentile(fdiff, [2.5, 97.5])
                    f90 = np.percentile(fdiff, [5, 95])
                else:
                    f95 = [np.nan, np.nan]
                    f90 = [np.nan, np.nan]

                info_a = refit[(region_a, driver)]
                info_b = refit[(region_b, driver)]
                vals_a = info_a["matched_breakpoints"][:, j]
                vals_b = info_b["matched_breakpoints"][:, j]
                ids_a = info_a.get("replicate_ids", np.arange(len(vals_a)).astype(str))
                ids_b = info_b.get("replicate_ids", np.arange(len(vals_b)).astype(str))
                map_a = {
                    str(rid): val for rid, val in zip(ids_a, vals_a) if np.isfinite(val)
                }
                map_b = {
                    str(rid): val for rid, val in zip(ids_b, vals_b) if np.isfinite(val)
                }
                common_ids = sorted(set(map_a) & set(map_b))
                nr = len(common_ids)
                if nr > 0:
                    rdiff = np.array(
                        [map_a[rid] - map_b[rid] for rid in common_ids], float
                    )
                    r90 = np.percentile(rdiff, [5, 95])
                else:
                    r90 = [np.nan, np.nan]

                fixed95 = _ci_excludes_zero(f95[0], f95[1])
                fixed90 = _ci_excludes_zero(f90[0], f90[1])
                refit90 = _ci_excludes_zero(r90[0], r90[1])

                min_rank = min(
                    _threshold_class_rank(ra.ThresholdClass),
                    _threshold_class_rank(rb.ThresholdClass),
                )

                if min_rank >= 3 and fixed95 and refit90 and nf >= 30 and nr >= 20:
                    cclass = "RobustMechanismDifference"
                elif min_rank >= 2 and fixed90 and nf >= 20:
                    cclass = "SupportedMechanismDifference"
                else:
                    cclass = "NoStableMechanismDifference"

                rows.append(
                    {
                        "Driver": driver,
                        "BreakpointIndex": int(bp_idx),
                        "RegionA": region_a,
                        "RegionB": region_b,
                        "ThresholdClassA": ra.ThresholdClass,
                        "ThresholdClassB": rb.ThresholdClass,
                        "ThresholdA": float(ra.Threshold),
                        "ThresholdB": float(rb.Threshold),
                        "Difference_AminusB": float(ra.Threshold - rb.Threshold),
                        "FixedBootstrapCommonN": int(nf),
                        "FixedDiffCI95_Low": float(f95[0]),
                        "FixedDiffCI95_High": float(f95[1]),
                        "FixedDiffCI90_Low": float(f90[0]),
                        "FixedDiffCI90_High": float(f90[1]),
                        "RefitBootstrapCommonN": int(nr),
                        "RefitDiffCI90_Low": float(r90[0]),
                        "RefitDiffCI90_High": float(r90[1]),
                        "ContrastClass": cclass,
                    }
                )

    return pd.DataFrame(rows)


def stage_threshold(cfg):
    data = load_analysis_inputs(cfg)
    audit_inputs(cfg, data)

    outdir = Path(cfg["threshold_dir"])
    curve_dir = outdir / "Curves"
    fixed_dir = outdir / "BootstrapFixed"
    curve_dir.mkdir(parents=True, exist_ok=True)
    fixed_dir.mkdir(parents=True, exist_ok=True)

    assignment = data["assignment"]
    X = data["X"]
    booster = data["booster"]
    feature_names = data["feature_names"]
    f2d = data["driver_to_features"]

    regions = ["All", "M1", "M2", "M3", "M4"]
    drivers = [str(x) for x in cfg["threshold_drivers"]]

    baseline_records = []
    curve_manifest = []
    pre_rows = []
    sensitivity_rows = []
    failure_rows = []
    pre_by_key = {}

    print("\n[Threshold] baseline ALE + fixed-model spatial bootstrap")

    for region in regions:
        mask = region_mask(
            assignment, region, float(cfg["primary_mechanism_confidence"])
        )
        indices = np.where(mask)[0]

        if len(indices) < int(cfg.get("minimum_region_samples", 150)):
            raise RuntimeError(
                f"{region} has too few primary-support samples: {len(indices)}"
            )

        for d_i, driver in enumerate(drivers):
            feature = get_single_feature(f2d, driver)
            Xr = X.iloc[indices]
            key = (region, driver)

            try:
                ale = compute_ale_1d(
                    booster=booster,
                    X=Xr,
                    feature_names=feature_names,
                    feature=feature,
                    target_bins=int(cfg["ale_target_bins"]),
                    minimum_bins=int(cfg["ale_minimum_bins"]),
                    min_bin_count=int(cfg["ale_min_bin_count"]),
                )

                fit = fit_segmented_thresholds(
                    x=ale["x_center"],
                    y=ale["ale"],
                    weights=np.maximum(ale["count"], 1),
                    support_x=Xr[feature].to_numpy(float),
                    search_quantile=tuple(cfg["threshold_search_quantile"]),
                    min_segment_bins=int(cfg["threshold_min_segment_bins"]),
                    allow_two=bool(cfg["allow_two_breakpoints"]),
                )

                fixed = fixed_model_bootstrap(
                    booster=booster,
                    X=X,
                    feature_names=feature_names,
                    feature=feature,
                    region_indices=indices,
                    block_ids=assignment["SpatialBlockID"].to_numpy(),
                    baseline_ale=ale,
                    baseline_threshold=fit,
                    cfg=cfg,
                    seed=int(cfg["random_seed"]) + 1000 * regions.index(region) + d_i,
                )

                curve_file = curve_dir / f"ALE_{region}_{driver}.csv"
                _curve_dataframe(region, driver, feature, ale, fixed).to_csv(
                    curve_file, index=False
                )

                np.savez_compressed(
                    fixed_dir / f"FixedBootstrap_{region}_{driver}.npz",
                    effects=fixed["effects"],
                    matched_breakpoints=fixed["matched_breakpoints"],
                    models=fixed["models"],
                    delta_bic=fixed["delta_bic"],
                )

                curve_manifest.append(
                    {
                        "Region": region,
                        "Driver": driver,
                        "Feature": feature,
                        "N": len(indices),
                        "Bins": len(ale["x_center"]),
                        "Status": "OK",
                        "CurveFile": str(curve_file),
                    }
                )

                pre = {
                    "Region": region,
                    "Driver": driver,
                    "Feature": feature,
                    "Status": "OK",
                    "Error": "",
                    "N": len(indices),
                    "ALEBins": len(ale["x_center"]),
                    "UniqueFeatureValues": int(Xr[feature].nunique()),
                    "SelectedSegmentedModel": int(fit["model"]),
                    "NumberOfBreakpoints": len(fit["breakpoints"]),
                    "DeltaBIC_vs_Linear": float(fit["delta_bic_vs_null"]),
                    "FixedBootstrapValidReps": fixed["valid_reps"],
                    "FixedBootstrapSegmentedFrequency": float(
                        np.mean(fixed["models"] > 0)
                    ),
                }
                pre_rows.append(pre)
                pre_by_key[key] = pre

                baseline_records.append(
                    {
                        "region": region,
                        "driver": driver,
                        "feature": feature,
                        "edges": ale["edges"],
                        "ale": ale,
                        "threshold": fit,
                        "fixed": fixed,
                        "indices": indices,
                    }
                )

                print(
                    f"[Threshold] {region} x {driver}: "
                    f"N={len(indices)} bins={len(ale['x_center'])} "
                    f"model={fit['model']} deltaBIC={fit['delta_bic_vs_null']:.2f}"
                )

            except Exception as e:
                row = {
                    "Region": region,
                    "Driver": driver,
                    "Feature": feature,
                    "Status": "InsufficientOrFailedSupport",
                    "Error": str(e),
                    "N": len(indices),
                    "ALEBins": np.nan,
                    "UniqueFeatureValues": int(Xr[feature].nunique()),
                    "SelectedSegmentedModel": -1,
                    "NumberOfBreakpoints": 0,
                    "DeltaBIC_vs_Linear": np.nan,
                    "FixedBootstrapValidReps": 0,
                    "FixedBootstrapSegmentedFrequency": np.nan,
                }
                pre_rows.append(row)
                pre_by_key[key] = row
                failure_rows.append(row.copy())
                print(
                    f"[Threshold] {region} x {driver}: skipped but analysis continues: {e}"
                )
                continue

            # Sensitivity analyses only after the primary curve is valid.
            for sens_name, sens_mask in [
                (
                    f"C{int(round(100 * float(cfg['sensitivity_mechanism_confidence'])))}",
                    (
                        np.ones(len(assignment), dtype=bool)
                        if region == "All"
                        else (
                            (assignment["Mechanism"].to_numpy(int) == int(region[1:]))
                            & (
                                assignment["MaxPosterior"].to_numpy(float)
                                >= float(cfg["sensitivity_mechanism_confidence"])
                            )
                        )
                    ),
                ),
                ("AllK4", region_mask_allk4(assignment, region)),
            ]:
                sidx = np.where(sens_mask)[0]
                if len(sidx) < int(cfg.get("minimum_region_samples", 150)):
                    sensitivity_rows.append(
                        {
                            "Region": region,
                            "Driver": driver,
                            "Sensitivity": sens_name,
                            "N": len(sidx),
                            "SelectedModel": -1,
                            "DeltaBIC_vs_Linear": np.nan,
                            "Breakpoint1": np.nan,
                            "Breakpoint2": np.nan,
                            "Status": "InsufficientSupport",
                            "Error": "regional support below minimum",
                        }
                    )
                    continue

                try:
                    sale = compute_ale_1d(
                        booster=booster,
                        X=X.iloc[sidx],
                        feature_names=feature_names,
                        feature=feature,
                        target_bins=int(cfg["ale_target_bins"]),
                        minimum_bins=int(cfg["ale_minimum_bins"]),
                        min_bin_count=int(cfg["ale_min_bin_count"]),
                    )
                    sfit = fit_segmented_thresholds(
                        x=sale["x_center"],
                        y=sale["ale"],
                        weights=np.maximum(sale["count"], 1),
                        support_x=X.iloc[sidx][feature].to_numpy(float),
                        search_quantile=tuple(cfg["threshold_search_quantile"]),
                        min_segment_bins=int(cfg["threshold_min_segment_bins"]),
                        allow_two=bool(cfg["allow_two_breakpoints"]),
                    )
                    sensitivity_rows.append(
                        {
                            "Region": region,
                            "Driver": driver,
                            "Sensitivity": sens_name,
                            "N": len(sidx),
                            "SelectedModel": sfit["model"],
                            "DeltaBIC_vs_Linear": sfit["delta_bic_vs_null"],
                            "Breakpoint1": sfit["breakpoints"][0]
                            if len(sfit["breakpoints"]) > 0
                            else np.nan,
                            "Breakpoint2": sfit["breakpoints"][1]
                            if len(sfit["breakpoints"]) > 1
                            else np.nan,
                            "Status": "OK",
                            "Error": "",
                        }
                    )
                except Exception as e:
                    sensitivity_rows.append(
                        {
                            "Region": region,
                            "Driver": driver,
                            "Sensitivity": sens_name,
                            "N": len(sidx),
                            "SelectedModel": -1,
                            "DeltaBIC_vs_Linear": np.nan,
                            "Breakpoint1": np.nan,
                            "Breakpoint2": np.nan,
                            "Status": "Failed",
                            "Error": str(e),
                        }
                    )

    pd.DataFrame(curve_manifest).to_csv(outdir / "ALE_Curve_Manifest.csv", index=False)
    pd.DataFrame(pre_rows).to_csv(
        outdir / "ALE_Threshold_Summary_PreRefit.csv", index=False
    )
    pd.DataFrame(sensitivity_rows).to_csv(
        outdir / "Threshold_Sensitivity.csv", index=False
    )
    failure_columns = [
        "Region",
        "Driver",
        "Feature",
        "Status",
        "Error",
        "N",
        "ALEBins",
        "UniqueFeatureValues",
        "SelectedSegmentedModel",
        "NumberOfBreakpoints",
        "DeltaBIC_vs_Linear",
        "FixedBootstrapValidReps",
        "FixedBootstrapSegmentedFrequency",
    ]
    pd.DataFrame(failure_rows, columns=failure_columns).to_csv(
        outdir / "Threshold_Analysis_Failures.csv", index=False
    )

    if len(baseline_records) == 0:
        raise RuntimeError(
            "No valid primary ALE analysis remained after support checks."
        )

    print("\n[Threshold] refit spatial block bootstrap")
    device = run_refit_bootstrap(cfg, data, baseline_records)
    refit = aggregate_refit_bootstrap(cfg, baseline_records)

    breakpoint_rows = []
    final_by_key = {}

    for rec in baseline_records:
        key = (rec["region"], rec["driver"])
        pre = pre_by_key[key]
        refit_info = refit[key]

        br = _summarize_breakpoints(
            cfg=cfg,
            region=rec["region"],
            driver=rec["driver"],
            feature=rec["feature"],
            main_fit=rec["threshold"],
            fixed=rec["fixed"],
            refit_info=refit_info,
            support_x=X.iloc[rec["indices"]][rec["feature"]].to_numpy(float),
        )
        breakpoint_rows.extend(br)

        classes = [x["ThresholdClass"] for x in br]
        if "RobustThreshold" in classes:
            overall = "RobustThresholdPresent"
        elif "SupportedThreshold" in classes:
            overall = "SupportedThresholdPresent"
        elif "CandidateThreshold" in classes:
            overall = "CandidateThresholdPresent"
        elif rec["threshold"]["model"] == 0:
            overall = "NoDetectedThreshold"
        else:
            overall = "OnlyUnstableThreshold"

        row = dict(pre)
        row.update(
            {
                "RefitBootstrapDevice": device,
                "RefitBootstrapValidReps": refit_info["valid_reps"],
                "RefitBootstrapSegmentedFrequency": refit_info["segmented_frequency"],
                "OverallThresholdEvidence": overall,
            }
        )
        final_by_key[key] = row

    # Failed primary combinations remain explicit rows instead of aborting the project.
    for row in pre_rows:
        key = (row["Region"], row["Driver"])
        if key not in final_by_key:
            rr = dict(row)
            rr.update(
                {
                    "RefitBootstrapDevice": "NotRun",
                    "RefitBootstrapValidReps": 0,
                    "RefitBootstrapSegmentedFrequency": np.nan,
                    "OverallThresholdEvidence": "InsufficientDataSupport",
                }
            )
            final_by_key[key] = rr

    final_summary = [final_by_key[(r, d)] for r in regions for d in drivers]

    breakpoint_columns = [
        "Region",
        "Driver",
        "Feature",
        "BreakpointIndex",
        "Threshold",
        "ThresholdQuantile",
        "ThresholdClass",
        "MainModel",
        "DeltaBIC_vs_Linear",
        "NormalizedSlopeChange",
        "FixedBootstrapDetectionFrequency",
        "RefitBootstrapDetectionFrequency",
        "FixedCI95_Low",
        "FixedCI95_High",
        "FixedCI90_Low",
        "FixedCI90_High",
        "CI95WidthFractionOfFeatureRange",
        "CI90WidthFractionOfFeatureRange",
        "SlopeBeforeOrPreviousSegment",
        "SlopeAfter",
    ]
    pd.DataFrame(breakpoint_rows, columns=breakpoint_columns).to_csv(
        outdir / "ALE_Threshold_Breakpoints.csv", index=False
    )
    pd.DataFrame(final_summary).to_csv(
        outdir / "ALE_Threshold_Summary.csv", index=False
    )

    contrasts = build_threshold_mechanism_contrasts(
        cfg, baseline_records, refit, breakpoint_rows
    )
    contrasts.to_csv(outdir / "Threshold_Mechanism_Contrasts.csv", index=False)

    protocol = {
        "main_model": "Frozen ReferenceSimple global XGBoost_Final_Model.json",
        "model_feature_signature": "Saved XGBoost feature_names; no hard-coded feature count",
        "mechanism_analysis": "Same global model; empirical support subsets M1-M4",
        "primary_mechanism_confidence": cfg["primary_mechanism_confidence"],
        "ale_bins_target": cfg["ale_target_bins"],
        "ale_bins_minimum": cfg["ale_minimum_bins"],
        "fixed_model_spatial_bootstrap_reps": cfg["fixed_model_bootstrap_reps"],
        "refit_spatial_bootstrap_reps": cfg["refit_bootstrap_reps"],
        "threshold_classes": {
            "TierA": "RobustThreshold",
            "TierB": "SupportedThreshold",
            "TierC": "CandidateThreshold",
        },
        "failed_combinations": "Retained as InsufficientDataSupport; never replaced by fabricated thresholds",
        "interpretation": "Predictive/model-response thresholds; not causal physical thresholds",
    }
    with open(outdir / "Threshold_Run_Protocol.json", "w", encoding="utf-8") as f:
        json.dump(protocol, f, indent=2, ensure_ascii=False)

    write_result_summary(cfg)


def stage_interaction(cfg):
    data = load_analysis_inputs(cfg)
    audit_inputs(cfg, data)

    outdir = Path(cfg["interaction_dir"])

    print("\n[Interaction] extracting native XGBoost SHAP interaction values")
    sample_values, pairs = selected_interaction_values(cfg, data)

    sample_out = sample_values.copy()
    meta_cols = [
        "SampleID",
        "PixelIndex",
        "RasterRow",
        "RasterColumn",
        "Longitude",
        "Latitude",
        "Target",
    ]
    for col in reversed(meta_cols):
        sample_out.insert(0, col, data["df"][col].to_numpy())
    sample_out.insert(7, "Mechanism", data["assignment"]["Mechanism"].to_numpy())
    sample_out.insert(8, "MaxPosterior", data["assignment"]["MaxPosterior"].to_numpy())
    sample_out.insert(
        9, "SpatialBlockID", data["assignment"]["SpatialBlockID"].to_numpy()
    )
    sample_out.to_csv(outdir / "SHAP_Interaction_SampleValues.csv", index=False)

    print("[Interaction] spatial bootstrap strength ranking")
    strength = interaction_strength_bootstrap(cfg, data, sample_values, pairs)
    strength.to_csv(outdir / "SHAP_Interaction_Strength.csv", index=False)

    print("[Interaction] representative 2D ALE surfaces")
    manifest = run_ale2d_targets(cfg, data)
    manifest.to_csv(outdir / "ALE2D_Surface_Manifest.csv", index=False)

    protocol = {
        "interaction_values": "Exact native XGBoost pred_interactions on every modeling sample; no approximate interaction shortcut; off-diagonal pair term multiplied by 2 to recover total pair contribution",
        "interaction_strength": "Mean absolute selected pair contribution with spatial block bootstrap",
        "interaction_classes": "Descriptive strength classes, not p-value significance tests",
        "ale2d": "Second-order local finite-difference ALE with weighted double-centering",
        "ale2d_missing_cells": "Nearest fill only for numerical integration; original occupancy retained in output masks",
    }
    with open(outdir / "Interaction_Run_Protocol.json", "w", encoding="utf-8") as f:
        json.dump(protocol, f, indent=2, ensure_ascii=False)

    write_result_summary(cfg)


def write_result_summary(cfg):
    root = Path(cfg["output_root"])
    lines = []

    tfile = Path(cfg["threshold_dir"]) / "ALE_Threshold_Summary.csv"
    bfile = Path(cfg["threshold_dir"]) / "ALE_Threshold_Breakpoints.csv"
    if tfile.exists():
        T = pd.read_csv(tfile)
        lines.append("THRESHOLD ANALYSIS")
        lines.append("------------------")
        for cls, n in T["OverallThresholdEvidence"].value_counts().items():
            lines.append(f"{cls}: {n}")
        lines.append("")

    if bfile.exists():
        try:
            B = pd.read_csv(bfile)
        except pd.errors.EmptyDataError:
            B = pd.DataFrame()
        if len(B):
            lines.append("Breakpoints by class:")
            for cls, n in B["ThresholdClass"].value_counts().items():
                lines.append(f"  {cls}: {n}")
            lines.append("")

    cfile = Path(cfg["threshold_dir"]) / "Threshold_Mechanism_Contrasts.csv"
    if cfile.exists():
        C = pd.read_csv(cfile)
        if len(C):
            lines.append("MECHANISM THRESHOLD CONTRASTS")
            lines.append("-----------------------------")
            for cls, n in C["ContrastClass"].value_counts().items():
                lines.append(f"{cls}: {n}")
            lines.append("")

    if (Path(cfg["interaction_dir"]) / "SHAP_Interaction_Strength.csv").exists():
        I = pd.read_csv(Path(cfg["interaction_dir"]) / "SHAP_Interaction_Strength.csv")
        lines.append("INTERACTION ANALYSIS")
        lines.append("--------------------")
        for region in ["All", "M1", "M2", "M3", "M4"]:
            q = (
                I[I.Region == region]
                .sort_values("MeanAbsPairSHAPInteraction", ascending=False)
                .head(3)
            )
            lines.append(f"{region} top interactions:")
            for _, r in q.iterrows():
                lines.append(
                    f"  {r.Pair}: strength={r.MeanAbsPairSHAPInteraction:.4g}, "
                    f"class={r.InteractionClass}"
                )
        lines.append("")

    lines.append("IMPORTANT:")
    lines.append(
        "Thresholds are predictive/model-response thresholds, not causal physical thresholds."
    )
    lines.append(
        "Interaction classes are descriptive model-interaction strength categories, not causal significance tests."
    )

    (root / "RESULT_SUMMARY.txt").write_text("\n".join(lines), encoding="utf-8")


def stage_inputcheck(cfg):
    data = load_analysis_inputs(cfg)
    audit_inputs(cfg, data)

    print("PYTHON INPUT/MODEL/K4 IDENTITY CHECK PASSED.")
    print(f"Training samples: {len(data['df'])}")
    print(f"Saved model feature count: {len(data['feature_names'])}")
    print(f"Metadata rows on disk: {len(data['raw_meta'])}")
    print(f"Reconciled metadata rows: {len(data['meta'])}")
    print(
        f"Metadata mode: {data.get('metadata_audit_info', {}).get('MetadataReconstructionMode', '')}"
    )
    print(f"K4 alignment method: {data['k4_audit']['AlignmentMethod']}")
    print(
        "K4 counts: "
        f"M1={data['k4_audit']['M1Count']}, "
        f"M2={data['k4_audit']['M2Count']}, "
        f"M3={data['k4_audit']['M3Count']}, "
        f"M4={data['k4_audit']['M4Count']}"
    )
    if data["metadata_missing"]:
        print("Metadata rows auto-reconciled from saved model signature:")
        for f in data["metadata_missing"]:
            print(f"  {f}")
    if data["metadata_extras"]:
        print("Extra metadata rows ignored because they are not in the saved model:")
        for f in data["metadata_extras"]:
            print(f"  {f}")


def stage_realdatasmoke(cfg):
    from copy import deepcopy

    data = load_analysis_inputs(cfg)
    audit_inputs(cfg, data)

    assignment = data["assignment"]
    X = data["X"]
    booster = data["booster"]
    feature_names = data["feature_names"]
    f2d = data["driver_to_features"]
    block_ids = assignment["SpatialBlockID"].to_numpy()

    smoke = {
        "ProjectVersion": cfg.get("project_version", ""),
        "InputIdentity": "PASSED",
        "BaselineALE": [],
        "FixedBootstrap": [],
        "ExactInteraction": {},
        "ALE2D": [],
    }

    # 1) Baseline ALE + segmented threshold for all 30 formal region-driver combinations.
    regions = ["All", "M1", "M2", "M3", "M4"]
    drivers = [str(x) for x in cfg["threshold_drivers"]]
    baseline_cache = {}

    for ri, region in enumerate(regions):
        mask = region_mask(
            assignment, region, float(cfg["primary_mechanism_confidence"])
        )
        idx = np.where(mask)[0]
        if len(idx) < int(cfg.get("minimum_region_samples", 150)):
            raise RuntimeError(f"Smoke test: {region} support too small: N={len(idx)}")

        for di, driver in enumerate(drivers):
            feature = get_single_feature(f2d, driver)
            Xr = X.iloc[idx]
            ale = compute_ale_1d(
                booster=booster,
                X=Xr,
                feature_names=feature_names,
                feature=feature,
                target_bins=int(cfg["ale_target_bins"]),
                minimum_bins=int(cfg["ale_minimum_bins"]),
                min_bin_count=int(cfg["ale_min_bin_count"]),
            )
            fit = fit_segmented_thresholds(
                x=ale["x_center"],
                y=ale["ale"],
                weights=np.maximum(ale["count"], 1),
                support_x=Xr[feature].to_numpy(float),
                search_quantile=tuple(cfg["threshold_search_quantile"]),
                min_segment_bins=int(cfg["threshold_min_segment_bins"]),
                allow_two=bool(cfg["allow_two_breakpoints"]),
            )
            baseline_cache[(region, driver)] = (idx, feature, ale, fit)
            smoke["BaselineALE"].append(
                {
                    "Region": region,
                    "Driver": driver,
                    "N": int(len(idx)),
                    "Bins": int(len(ale["x_center"])),
                    "Model": int(fit["model"]),
                    "DeltaBIC": float(fit["delta_bic_vs_null"]),
                }
            )

    # 2) Fixed-model spatial bootstrap on representative diverse combinations.
    smoke_cfg = deepcopy(cfg)
    smoke_cfg["fixed_model_bootstrap_reps"] = int(
        cfg.get("smoke_fixed_bootstrap_reps", 8)
    )
    representatives = [
        ("All", "BuiltSurface"),
        ("M1", "GWS"),
        ("M2", "SkinReservoir"),
        ("M3", "SubsurfaceRunoff"),
        ("M4", "TotalPrecipitation"),
    ]
    for j, key in enumerate(representatives):
        idx, feature, ale, fit = baseline_cache[key]
        fb = fixed_model_bootstrap(
            booster=booster,
            X=X,
            feature_names=feature_names,
            feature=feature,
            region_indices=idx,
            block_ids=block_ids,
            baseline_ale=ale,
            baseline_threshold=fit,
            cfg=smoke_cfg,
            seed=int(cfg["random_seed"]) + 90000 + j,
        )
        smoke["FixedBootstrap"].append(
            {
                "Region": key[0],
                "Driver": key[1],
                "ValidReps": int(fb["valid_reps"]),
            }
        )

    # 3) Exact native TreeSHAP identity test on spatially distributed real rows.
    nrows = min(int(cfg.get("smoke_interaction_rows", 64)), len(X))
    rows = np.linspace(0, len(X) - 1, nrows).round().astype(int)
    dm = xgb.DMatrix(X.iloc[rows], feature_names=feature_names)
    pred = booster.predict(dm)
    contrib = booster.predict(dm, pred_contribs=True)
    inter = booster.predict(dm, pred_interactions=True)

    expected_dim = len(feature_names) + 1
    if inter.shape != (nrows, expected_dim, expected_dim):
        raise RuntimeError(f"Smoke exact interaction shape mismatch: {inter.shape}")
    row_sum_err = float(np.max(np.abs(inter.sum(axis=2) - contrib)))
    total_sum_err = float(np.max(np.abs(inter.sum(axis=(1, 2)) - pred)))
    if row_sum_err > 1e-4 or total_sum_err > 1e-3:
        raise RuntimeError(
            f"Exact TreeSHAP identity failed: row_sum_err={row_sum_err}, total_sum_err={total_sum_err}"
        )

    pair_means = {}
    for d1, d2 in cfg["interaction_pairs"]:
        f1 = get_single_feature(f2d, d1)
        f2 = get_single_feature(f2d, d2)
        i = feature_names.index(f1)
        j = feature_names.index(f2)
        pair_means[f"{d1}__{d2}"] = float(np.mean(np.abs(2.0 * inter[:, i, j])))
    if sum(v > 1e-12 for v in pair_means.values()) < 3:
        raise RuntimeError(
            f"Too few non-zero exact interaction pairs in smoke test: {pair_means}"
        )

    smoke["ExactInteraction"] = {
        "Rows": int(nrows),
        "RowSumIdentityMaxAbsError": row_sum_err,
        "TotalPredictionIdentityMaxAbsError": total_sum_err,
        "MeanAbsSelectedPairs": pair_means,
    }

    # 4) All six formal 2D ALE targets with a small bootstrap.
    for ti, (region, d1, d2) in enumerate(cfg["ale2d_targets"]):
        mask = region_mask(
            assignment, region, float(cfg["primary_mechanism_confidence"])
        )
        idx = np.where(mask)[0]
        f1 = get_single_feature(f2d, d1)
        f2 = get_single_feature(f2d, d2)
        surf = compute_ale2d(
            booster=booster,
            X=X.iloc[idx],
            feature_names=feature_names,
            feature1=f1,
            feature2=f2,
            target_bins=int(cfg["ale2d_target_bins"]),
            minimum_bins=int(cfg["ale2d_minimum_bins"]),
            min_cell_count=int(cfg["ale2d_min_cell_count"]),
            minimum_occupied_fraction=float(cfg["ale2d_minimum_occupied_fraction"]),
        )
        boot = bootstrap_ale2d_amplitude(
            baseline_surface=surf,
            region_indices=idx,
            block_ids=block_ids,
            reps=int(cfg.get("smoke_ale2d_bootstrap_reps", 6)),
            min_cell_count=max(4, int(cfg["ale2d_min_cell_count"]) // 2),
            seed=int(cfg["random_seed"]) + 91000 + ti,
        )
        smoke["ALE2D"].append(
            {
                "Region": region,
                "Driver1": d1,
                "Driver2": d2,
                "XBins": int(len(surf["x_center"])),
                "YBins": int(len(surf["y_center"])),
                "OccupiedFraction": float(surf["occupied_fraction"]),
                "Amplitude": float(surf["amplitude"]),
                "BootstrapValid": int(boot["valid_reps"]),
            }
        )

    smoke["Status"] = "PASSED"
    outfile = Path(cfg["audit_dir"]) / "RealData_SmokeTest_v1_5.json"
    outfile.write_text(
        json.dumps(smoke, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print("REAL-DATA SMOKE TEST PASSED.")
    print(f"Audit: {outfile}")


def stage_selftest(cfg):
    from threshold_segmented import fit_segmented_thresholds
    from ale_1d import compute_ale_1d
    from ale2d import compute_ale2d

    rng = np.random.default_rng(12345)
    n = 1400
    x = rng.uniform(-1, 1, n)
    z = rng.uniform(-1, 1, n)
    w = rng.normal(size=n)

    y = (
        1.3 * x
        + 3.2 * np.maximum(0, x - 0.20)
        + 2.0 * x * z
        + 0.15 * w
        + rng.normal(scale=0.15, size=n)
    )

    X = pd.DataFrame({"x": x, "z": z, "w": w})

    model = xgb.XGBRegressor(
        n_estimators=350,
        max_depth=4,
        learning_rate=0.04,
        min_child_weight=3,
        subsample=0.9,
        colsample_bytree=1.0,
        objective="reg:squarederror",
        tree_method="hist",
        random_state=12345,
        n_jobs=-1,
        verbosity=0,
    )
    model.fit(X, y)
    booster = model.get_booster()

    ale = compute_ale_1d(
        booster,
        X,
        ["x", "z", "w"],
        "x",
        target_bins=20,
        minimum_bins=10,
        min_bin_count=25,
    )
    fit = fit_segmented_thresholds(
        ale["x_center"],
        ale["ale"],
        np.maximum(ale["count"], 1),
        x,
        search_quantile=(0.08, 0.92),
        min_segment_bins=3,
        allow_two=True,
    )

    if fit["model"] == 0:
        raise RuntimeError(
            "Synthetic threshold self-test failed: no breakpoint detected."
        )

    nearest = min(abs(np.asarray(fit["breakpoints"]) - 0.20))
    if nearest > 0.30:
        raise RuntimeError(
            f"Synthetic threshold self-test failed: nearest breakpoint is too far from 0.20: {fit['breakpoints']}"
        )

    dm = xgb.DMatrix(X, feature_names=["x", "z", "w"])
    I = booster.predict(dm, pred_interactions=True)
    ix, iz, iw = 0, 1, 2
    xz = np.mean(np.abs(2 * I[:, ix, iz]))
    xw = np.mean(np.abs(2 * I[:, ix, iw]))

    if not (xz > 1.15 * xw):
        raise RuntimeError(f"Synthetic interaction self-test failed: xz={xz}, xw={xw}")

    surf = compute_ale2d(
        booster,
        X,
        ["x", "z", "w"],
        "x",
        "z",
        target_bins=8,
        minimum_bins=6,
        min_cell_count=8,
        minimum_occupied_fraction=0.4,
    )

    if surf["amplitude"] <= 0.05:
        raise RuntimeError("Synthetic 2D ALE amplitude is unexpectedly small.")

    print("SYNTHETIC SELF TEST PASSED.")
    print(f"Detected breakpoints: {fit['breakpoints']}")
    print(f"Mean |x-z interaction|={xz:.4f}; mean |x-w interaction|={xw:.4f}")
    print(f"2D ALE amplitude={surf['amplitude']:.4f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument(
        "--stage",
        required=True,
        choices=["inputcheck", "realdatasmoke", "selftest", "threshold", "interaction"],
    )
    args = ap.parse_args()

    cfg = load_config(args.config)
    ensure_dirs(cfg)

    if args.stage == "inputcheck":
        stage_inputcheck(cfg)
    elif args.stage == "realdatasmoke":
        stage_realdatasmoke(cfg)
    elif args.stage == "selftest":
        stage_selftest(cfg)
    elif args.stage == "threshold":
        stage_threshold(cfg)
    elif args.stage == "interaction":
        stage_interaction(cfg)


if __name__ == "__main__":
    main()
