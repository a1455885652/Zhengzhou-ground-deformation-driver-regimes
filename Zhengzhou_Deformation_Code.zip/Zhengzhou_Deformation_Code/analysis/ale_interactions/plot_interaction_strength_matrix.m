function plot_interaction_strength_matrix(cfg)

file = fullfile(cfg.interactionDir, 'SHAP_Interaction_Strength.csv');
T = readtable(file,'TextType','string','VariableNamingRule','preserve');

regions = ["All","M1","M2","M3","M4"];
pairs = unique(T.Pair,'stable');

A = nan(numel(regions),numel(pairs));

for i = 1:numel(regions)
    for j = 1:numel(pairs)
        q = T(T.Region==regions(i) & T.Pair==pairs(j),:);
        if ~isempty(q)
            A(i,j) = q.NormalizedShareAmongSelected(1);
        end
    end
end

f = figure('Color','w','Position',[100 100 1300 600]);
ax = axes(f);

imagesc(ax,A);
colormap(ax,parula(256));
cb = colorbar(ax);
cb.Label.String = 'Normalized interaction share';
cb.FontName = cfg.fontName;

set(ax, ...
    'XTick',1:numel(pairs), ...
    'XTickLabel',strrep(cellstr(pairs),'__',' × '), ...
    'YTick',1:numel(regions), ...
    'YTickLabel',cellstr(regions), ...
    'FontName',cfg.fontName, ...
    'FontSize',cfg.fontSize);

xtickangle(ax,25);

for i = 1:size(A,1)
    for j = 1:size(A,2)
        if isfinite(A(i,j))
            text(ax,j,i,sprintf('%.2f',A(i,j)), ...
                'HorizontalAlignment','center', ...
                'FontName',cfg.fontName, ...
                'FontSize',cfg.fontSize-1, ...
                'Color','k');
        end
    end
end

xlabel(ax,'Pre-specified driver pair');
ylabel(ax,'Region / mechanism');
title(ax,'SHAP interaction strength across the whole area and M1-M4', ...
    'FontWeight','bold');

exportgraphics(f,fullfile(cfg.figureDir,'Fig_Interaction_Strength_Matrix.png'), ...
    'Resolution',cfg.figureDPI);
exportgraphics(f,fullfile(cfg.figureDir,'Fig_Interaction_Strength_Matrix.pdf'));
if ~zz_show_figures(), close(f); end

end
