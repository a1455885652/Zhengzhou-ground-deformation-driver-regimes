function B = make_spatial_blocks_holdout(cache,sel,cfg)
row=double(cache.K4.RasterRow(sel)); col=double(cache.K4.RasterColumn(sel));
bs=cfg.blockPixels;
br=floor((row-1)/bs)+1; bc=floor((col-1)/bs)+1;
key=br*100000+bc; [u,~,g]=unique(key);
blockID=[]; pixelLists={}; nPixels=[]; brOut=[]; bcOut=[];
for k=1:numel(u)
    ii=find(g==k);
    if numel(ii)<cfg.minimumPixelsPer5kmBlock, continue; end
    blockID(end+1,1)=numel(blockID)+1; %#ok<AGROW>
    pixelLists{end+1,1}=sel(ii); %#ok<AGROW>
    nPixels(end+1,1)=numel(ii); %#ok<AGROW>
    brOut(end+1,1)=br(ii(1)); bcOut(end+1,1)=bc(ii(1)); %#ok<AGROW>
end
if numel(blockID)<2*cfg.minimumBlocksPerSet
    error('Only %d eligible 5-km M3 blocks; need at least %d.',numel(blockID),2*cfg.minimumBlocksPerSet);
end
B=struct('blockID',blockID,'pixelLists',{pixelLists},'nPixels',nPixels,'blockRow',brOut,'blockCol',bcOut);
end
