%% CHECK_INPUTS_M3_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_m3_runoff_holdout();
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence is required.'); end
if ~isfile(cfg.cache.dynamicMat), error('Missing dynamic cache: %s',cfg.cache.dynamicMat); end
if ~isfile(cfg.cache.rateMat), error('Missing centered-W6 rate cache: %s',cfg.cache.rateMat); end
cache=load_wavelet_cache(cfg); rate=load_centered_rate_cache(cfg);
if ~isequal(size(rate.Vrate,1),numel(cache.months)) || size(rate.Vrate,2)~=height(cache.K4), error('Rate cache dimensions do not match dynamic cache.'); end
for nm=cfg.driverNames, find_driver_index_cache(cache,nm); end
sel=select_m3_confident_pixels(cache,cfg); B=make_spatial_blocks_holdout(cache,sel,cfg); S=split_blocks_supercheckerboard(B,cfg);
ensure_folder(cfg.output.root); ensure_folder(cfg.output.tables);
T=write_split_table(B,S,fullfile(cfg.output.tables,'M3_SpatialHoldout_Split.csv'));
fprintf('M3 pixels after confidence/support audit: %d\n',numel(sel));
fprintf('Eligible 5-km blocks: %d; Discovery=%d; Validation=%d\n',height(T),sum(T.Set=="Discovery"),sum(T.Set=="Validation"));
fprintf('INPUT CHECK PASSED.\n');
