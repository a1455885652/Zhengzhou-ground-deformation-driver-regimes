function plot_validation_block_lags(M,S,driverName,file)
valid=M.valid & isfinite(M.lag); if ~any(valid), return; end
fig=figure('Visible','off','Position',[100 100 760 620]);
scatter(S.blockCol(valid),S.blockRow(valid),70,M.lag(valid),'filled'); set(gca,'YDir','reverse'); axis equal tight; colorbar;
xlabel('5-km block column'); ylabel('5-km block row'); title(sprintf('M3 %s locked-window validation block lag (months)',driverName));
exportgraphics(fig,file,'Resolution',220); if ~zz_show_figures(), close(fig); end
end
