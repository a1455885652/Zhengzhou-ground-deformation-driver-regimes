%% RUN_ALL_M3_HOLDOUT.m
clear; clc;
projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
SELF_TEST_M3_HOLDOUT;
CHECK_INPUTS_M3_HOLDOUT;
RUN_M3_RUNOFF_HOLDOUT;
