%% SELF_TEST_M3_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_m3_runoff_holdout();
if exist('wcoherence','file')~=2, error('Wavelet Toolbox / wcoherence is required.'); end
fprintf('Running M3 spatial-holdout self tests...\n'); rng(20260907,'twister');

% 1) Superblock split keeps every ~10-km superblock entirely in one set.
B=struct(); B.blockID=(1:32)'; B.blockRow=repelem((1:8)',4); B.blockCol=repmat((1:4)',8,1); B.nPixels=20*ones(32,1); B.pixelLists=arrayfun(@(x)x,1:32,'UniformOutput',false)';
cfg2=cfg; cfg2.minimumBlocksPerSet=4; S=split_blocks_supercheckerboard(B,cfg2);
key=S.superRow*1000+S.superCol;
for k=unique(key)'
    ii=find(key==k); inD=ismember(ii,S.discoveryIndex); inV=ismember(ii,S.validationIndex); assert(~(any(inD)&&any(inV)),'A superblock was split across discovery/validation.');
end

% 2) Phase convention: +1 month driver lead at 8-month period.
phi=2*pi*1/8; lag=phi/(2*pi)*8; assert(abs(lag-1)<1e-12,'Phase-to-lag convention failed.');

% 3) Synthetic block wavelet signal: validation locked mask should recover positive lag.
n=84; t=(1:n)'; nB=18; X=zeros(n,nB); Y=zeros(n,nB);
for b=1:nB
    x=sin(2*pi*t/8+0.1*randn)+0.25*randn(n,1);
    y=0.30*randn(n,1); y(2:end)=1.2*x(1:end-1)+0.30*randn(n-1,1); % driver leads by one month
    X(:,b)=preprocess_wavelet_series(x,1); Y(:,b)=preprocess_wavelet_series(y,1);
end
G=compute_group_lead_map(X,Y,cfg2);
periodMask=G.period>=6 & G.period<=10; timeMask=false(1,n); timeMask(15:70)=true; mask=periodMask(:)&timeMask; % implicit expansion
M=extract_locked_block_metrics(X,Y,mask,cfg2); A=aggregate_locked_group_metric(M,cfg2);
assert(A.DriverLeadFraction>0.60,'Synthetic driver-leading fraction too small.');
assert(A.MedianLagMonths>0.25 && A.MedianLagMonths<2.0,'Synthetic lag recovery failed.');

% 4) Holm adjustment.
q=holm_adjust([0.01;0.04]); assert(all(abs(q-[0.02;0.04])<1e-12),'Holm adjustment failed.');
fprintf('ALL M3 SPATIAL-HOLDOUT SELF TESTS PASSED.\n');
