%% RUN_M3_RUNOFF_HOLDOUT.m
clear; clc; projectDir=fileparts(mfilename('fullpath')); addpath(projectDir);
cfg=config_m3_runoff_holdout();
ensure_folder(cfg.output.root); ensure_folder(cfg.output.checkpoints); ensure_folder(cfg.output.figures); ensure_folder(cfg.output.tables);
cache=load_wavelet_cache(cfg); rate=load_centered_rate_cache(cfg);
sel=select_m3_confident_pixels(cache,cfg); B=make_spatial_blocks_holdout(cache,sel,cfg); S=split_blocks_supercheckerboard(B,cfg);
write_split_table(B,S,fullfile(cfg.output.tables,'M3_SpatialHoldout_Split.csv'));
Bdisc=subset_blocks(B,S.discoveryIndex); Bval=subset_blocks(B,S.validationIndex);
Rs=cell(numel(cfg.driverNames),1);
for i=1:numel(cfg.driverNames)
    Rs{i}=run_one_driver_holdout(cache,rate,Bdisc,Bval,cfg,cfg.driverNames(i));
end
T=finalize_holdout_results(Rs,cfg); writetable(T,fullfile(cfg.output.root,'FINAL_M3_RUNOFF_HOLDOUT_INFERENCE.csv'));
write_holdout_summary(T,S,cfg,fullfile(cfg.output.root,'RESULT_SUMMARY.txt'));
save(fullfile(cfg.output.root,'M3_Runoff_Holdout_AllResults.mat'),'Rs','T','S','cfg','-v7.3');
disp(T); fprintf('Finished. Output: %s\n',cfg.output.root);
