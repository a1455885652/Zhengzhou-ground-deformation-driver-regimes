function T = finalize_holdout_results(Rs,cfg)
n=numel(Rs); p=ones(n,1); for i=1:n, p(i)=Rs{i}.ValidationP; end
q=holm_adjust(p);
vars={'Driver','DiscoveryClusterP','DiscoveryStartMonth','DiscoveryEndMonth','DiscoveryPeriodMinMonths','DiscoveryPeriodMaxMonths','DiscoveryLagMonths','ValidationLeadP','HolmP','ValidationNBlocks','ValidationNSupport', ...
    'ValidationSupportFraction','ValidationPhaseConcentration','ValidationLeadFraction','ValidationMedianLagMonths', ...
    'LagCI95_Low','LagCI95_High','LagCI90_Low','LagCI90_High','DiscoveryValidationLagDifference','ClaimClass'};
T=table('Size',[0 numel(vars)],'VariableTypes',{'string','double','datetime','datetime','double','double','double','double','double','double','double','double','double','double','double','double','double','double','double','double','string'},'VariableNames',vars);
for i=1:n
    R=Rs{i};
    if isempty(R.LockedRow) || isempty(R.ValidationGroup)
        row=table(string(R.Driver),NaN,NaT,NaT,NaN,NaN,NaN,R.ValidationP,q(i),0,0,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,"NoDiscoveryCluster",'VariableNames',vars);
        T=[T;row]; continue;
    end
    dLag=double(R.LockedRow.MedianLagMonths); g=R.ValidationGroup; ci=R.LagCI; diff=abs(dLag-ci.Median);
    confirm = q(i)<=cfg.validation.holmAlpha && g.SupportFraction>=cfg.validation.confirm.minimumSupportFraction && ...
        g.PhaseConcentration>=cfg.validation.confirm.minimumPhaseConcentration && g.DriverLeadFraction>=cfg.validation.confirm.minimumLeadFraction && ...
        g.NSupport>=cfg.validation.confirm.minimumSupportingBlocks && ci.Low95>0 && diff<=cfg.validation.confirm.maximumDiscoveryValidationLagDifference;
    support = q(i)<=cfg.validation.supportiveHolmAlpha && g.SupportFraction>=cfg.validation.support.minimumSupportFraction && ...
        g.PhaseConcentration>=cfg.validation.support.minimumPhaseConcentration && g.DriverLeadFraction>=cfg.validation.support.minimumLeadFraction && ...
        g.NSupport>=cfg.validation.support.minimumSupportingBlocks && ci.Low90>0 && diff<=cfg.validation.support.maximumDiscoveryValidationLagDifference;
    if confirm, claim="ConfirmedSpatialHoldoutLag"; elseif support, claim="SupportedSpatialHoldoutLag"; elseif ci.Low90>0 && g.DriverLeadFraction>=0.55, claim="DirectionalReplication_NotAdjustedSignificant"; else, claim="NotReplicated"; end
    row=table(string(R.Driver),double(R.LockedRow.ClusterP_FWER),R.LockedRow.StartMonth,R.LockedRow.EndMonth,double(R.LockedRow.PeriodMinMonths),double(R.LockedRow.PeriodMaxMonths),dLag,R.ValidationP,q(i),g.NBlocks,g.NSupport,g.SupportFraction, ...
        g.PhaseConcentration,g.DriverLeadFraction,ci.Median,ci.Low95,ci.High95,ci.Low90,ci.High90,diff,claim,'VariableNames',vars);
    T=[T;row];
end
end
