# M3 径流时间分析

执行 M3 两项预设径流假设的发现与验证，输出时间窗和相位滞后汇总。

| 项目 | 内容 |
|---|---|
| 输入 | 与 M124 相同的两项时间缓存及 K=4 归属表。 |
| 输出 | `project_root/M3_Runoff_SpatialHoldout_Output` |
| 设置 | config_m3_runoff_holdout.m |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('temporal_m3')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。
