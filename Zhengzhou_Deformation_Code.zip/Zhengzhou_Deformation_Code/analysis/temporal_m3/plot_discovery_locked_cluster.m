function plot_discovery_locked_cluster(G,mask,months,driverName,file)
if isempty(mask) || ~any(mask,'all'), return; end
fig=figure('Visible','off','Position',[100 100 1100 560]);
x=1:numel(months);
imagesc(x,G.period,G.stat); axis xy; colorbar; hold on;
contour(x,G.period,double(mask),[0.5 0.5],'k','LineWidth',1.5);
ylabel('Period (months)'); xlabel('Time'); title(sprintf('M3 %s discovery group lead statistic; locked cluster outlined',driverName));
set(gca,'YScale','log');
nt=min(8,numel(x)); tick=unique(round(linspace(1,numel(x),nt))); xticks(tick); xticklabels(string(months(tick),'yyyy-MM')); xtickangle(30);
exportgraphics(fig,file,'Resolution',220); if ~zz_show_figures(), close(fig); end
end
