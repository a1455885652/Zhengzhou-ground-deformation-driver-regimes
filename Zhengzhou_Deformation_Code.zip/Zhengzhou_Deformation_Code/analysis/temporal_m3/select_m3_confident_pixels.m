function sel = select_m3_confident_pixels(cache,cfg)
K4=cache.K4;
sel=find(double(K4.MechanismCluster)==cfg.mechanism & double(K4.MaxPosterior)>=cfg.minimumPosterior);
if isempty(sel), error('No M3 pixels pass MaxPosterior >= %.2f.',cfg.minimumPosterior); end
if isfield(cache,'coverCum')
    good=double(cache.coverCum(sel))>=cfg.minimumTemporalCoverage;
    if isfield(cache,'coverDriver')
        for j=1:size(cache.coverDriver,2)
            good=good & double(cache.coverDriver(sel,j))>=cfg.minimumTemporalCoverage;
        end
    end
    sel=sel(good);
end
if numel(sel)<100, error('Only %d M3 pixels remain after support audit.',numel(sel)); end
end
