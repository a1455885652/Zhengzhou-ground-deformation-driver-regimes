function S = split_blocks_supercheckerboard(B,cfg)
f=cfg.superBlockFactor;
sr=floor((B.blockRow-1)/f)+1;
sc=floor((B.blockCol-1)/f)+1;
% Entire superblock is assigned together. This prevents splitting adjacent
% 5-km blocks that share the same ~10-km spatial unit.
parity=mod(sr+sc+cfg.splitOffset,2);
disc=find(parity==0); val=find(parity==1);
if numel(disc)<cfg.minimumBlocksPerSet || numel(val)<cfg.minimumBlocksPerSet
    error('Spatial split is too imbalanced: discovery=%d validation=%d.',numel(disc),numel(val));
end
S=struct('discoveryIndex',disc(:),'validationIndex',val(:),'superRow',sr(:),'superCol',sc(:), ...
    'discoveryBlockID',B.blockID(disc),'validationBlockID',B.blockID(val));
end
