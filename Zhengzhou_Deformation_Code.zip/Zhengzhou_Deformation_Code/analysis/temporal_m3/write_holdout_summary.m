function write_holdout_summary(T,split,cfg,file)
fid=fopen(file,'w'); if fid<0, error('Cannot write %s',file); end; c=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'M3 runoff spatial discovery-validation summary\n');
fprintf(fid,'Created: %s\n\n',char(datetime('now')));
fprintf(fid,'Design: ~10-km superblocks assigned wholly to Discovery/Validation.\n');
fprintf(fid,'Discovery 5-km blocks: %d\n',numel(split.discoveryBlockID));
fprintf(fid,'Validation 5-km blocks: %d\n\n',numel(split.validationBlockID));
fprintf(fid,'Validation never re-selects time, period, cluster, or lag.\n');
fprintf(fid,'Directional alternative: driver leads deformation.\n');
fprintf(fid,'Two pre-specified hypotheses corrected using Holm.\n\n');
for i=1:height(T)
    fprintf(fid,'%s\n',T.Driver(i));
    fprintf(fid,'  Discovery cluster p = %.6f\n',T.DiscoveryClusterP(i));
    fprintf(fid,'  Discovery lag = %.3f months\n',T.DiscoveryLagMonths(i));
    fprintf(fid,'  Validation one-sided p = %.6f; Holm p = %.6f\n',T.ValidationLeadP(i),T.HolmP(i));
    fprintf(fid,'  Validation support = %.1f%%; driver-leading blocks = %.1f%%\n',100*T.ValidationSupportFraction(i),100*T.ValidationLeadFraction(i));
    fprintf(fid,'  Validation median lag = %.3f months; 95%% CI [%.3f, %.3f]\n',T.ValidationMedianLagMonths(i),T.LagCI95_Low(i),T.LagCI95_High(i));
    fprintf(fid,'  Claim = %s\n\n',T.ClaimClass(i));
end
fprintf(fid,'Interpretation boundary: this is internal spatial holdout replication, not external causal validation.\n');
end
