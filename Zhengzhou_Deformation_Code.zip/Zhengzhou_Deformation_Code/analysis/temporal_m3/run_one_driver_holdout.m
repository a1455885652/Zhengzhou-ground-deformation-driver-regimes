function R = run_one_driver_holdout(cache,rate,Bdisc,Bval,cfg,driverName)
name=string(driverName); j=find_driver_index_cache(cache,name);
checkpoint=fullfile(cfg.output.checkpoints,sprintf('M3_%s_Holdout.mat',name));
if cfg.output.resume && isfile(checkpoint), S=load(checkpoint,'R'); R=S.R; fprintf('  Resume %s\n',name); return; end
fprintf('\n=== M3 %s ===\n',name);
D=build_block_wavelet_matrices_holdout(cache,rate,Bdisc,cfg,j);
V=build_block_wavelet_matrices_holdout(cache,rate,Bval,cfg,j);
fprintf('  Discovery blocks=%d; Validation blocks=%d\n',size(D.XZ,2),size(V.XZ,2));
G=compute_group_lead_map(D.XZ,D.YZ,cfg);
th=estimate_discovery_scale_thresholds(D.XZ,D.YZ,cfg,cfg.randomSeed+1000*j);
nullMax=estimate_discovery_null_maxmass(D.XZ,D.YZ,th,cfg,cfg.randomSeed+2000*j);
T=summarize_discovery_clusters(G,th,nullMax,D.months,cfg);
writetable(T,fullfile(cfg.output.tables,sprintf('M3_%s_DiscoveryClusters.csv',name)));
[mask,locked]=choose_locked_cluster(G,T,th,cfg);
if isempty(locked)
    R=struct('Driver',name,'DiscoveryTable',T,'LockedRow',locked,'LockedMask',mask,'DiscoveryMatrices',D,'ValidationMatrices',V, ...
        'ValidationMetric',[],'ValidationGroup',[],'ValidationP',1,'NullValidation',[],'LagCI',[], 'Status',"NoDiscoveryCluster");
    save(checkpoint,'R','-v7.3'); return;
end
fprintf('  Locked discovery cluster p=%.4f, lag=%.3f months, %s to %s, %.2f-%.2f months\n', ...
    locked.ClusterP_FWER,locked.MedianLagMonths,string(locked.StartMonth),string(locked.EndMonth),locked.PeriodMinMonths,locked.PeriodMaxMonths);
M=extract_locked_block_metrics(V.XZ,V.YZ,mask,cfg); GV=aggregate_locked_group_metric(M,cfg);
[p,nullStat]=validation_surrogate_p(V.XZ,V.YZ,mask,GV.LeadStatistic,cfg,cfg.randomSeed+3000*j);
CI=bootstrap_validation_lag(M,cfg,cfg.randomSeed+4000*j);
Tb=table(V.blockIDs(:),V.blockRow(:),V.blockCol(:),V.nPixels(:),M.valid(:),M.coherence(:),M.phaseConcentration(:),M.phase(:),M.lag(:), ...
    'VariableNames',{'BlockID','BlockRow','BlockCol','Npixels','Valid','MeanCoherence','PhaseConcentration','AdjustedPhaseRad','LagMonths'});
writetable(Tb,fullfile(cfg.output.tables,sprintf('M3_%s_ValidationBlocks.csv',name)));
R=struct('Driver',name,'DiscoveryTable',T,'LockedRow',locked,'LockedMask',mask,'DiscoveryGroupMap',G, ...
    'DiscoveryMatrices',D,'ValidationMatrices',V,'ValidationMetric',M,'ValidationGroup',GV,'ValidationP',p, ...
    'NullValidation',nullStat,'LagCI',CI,'Status',"Validated");
save(checkpoint,'R','-v7.3');
if cfg.output.makeFigures
    plot_discovery_locked_cluster(G,mask,D.months,name,fullfile(cfg.output.figures,sprintf('M3_%s_DiscoveryLockedCluster.png',name)));
    plot_validation_block_lags(M,V,name,fullfile(cfg.output.figures,sprintf('M3_%s_ValidationBlockLag.png',name)));
end
save_locked_cluster_cells(mask,G,D.months,fullfile(cfg.output.tables,sprintf('M3_%s_LockedClusterCells.csv',name)));
end
