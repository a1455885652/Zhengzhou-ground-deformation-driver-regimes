function plot_response_composition_k45(cfg)
T4 = readtable(fullfile(cfg.pythonResultDir,'Response_Mechanism_Crosstab_K4.csv'),'VariableNamingRule','preserve');
T5 = readtable(fullfile(cfg.pythonResultDir,'Response_Mechanism_Crosstab_K5.csv'),'VariableNamingRule','preserve');

fig = figure('Color','w','Position',[100 100 1300 560]);
tl = tiledlayout(1,2,'TileSpacing','compact','Padding','compact');

ax1 = nexttile(tl,1);
plot_response_panel_k45(ax1,T4,4,'(a) K = 4');
ax2 = nexttile(tl,2);
plot_response_panel_k45(ax2,T5,5,'(b) K = 5');

set(findall(fig,'Type','axes'),'FontName','Times New Roman','FontSize',12,'LineWidth',1);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_06_Response_Composition_K4_K5.png'),'Resolution',600);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_06_Response_Composition_K4_K5.tif'),'Resolution',600);
if ~zz_show_figures(), close(fig); end
end
