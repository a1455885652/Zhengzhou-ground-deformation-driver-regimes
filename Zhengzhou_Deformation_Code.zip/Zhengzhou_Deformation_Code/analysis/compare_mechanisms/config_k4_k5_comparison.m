function cfg = config_k4_k5_comparison()
% Strict K=4 vs K=5 comparison for SHAP mechanism zoning V2.
% MATLAB R2023b compatible. No local/nested functions.

cfg.projectVersion = 'v1.0';

% Existing V2 output root. No XGBoost retraining is performed.
cfg.v2Root = zz_project_path('SHAP_Mechanism_Zoning_V2_Output');
cfg.pythonOut = fullfile(cfg.v2Root, 'Python_Output');

% New supplementary output root.
cfg.outputRoot = zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output');
cfg.figureDir = fullfile(cfg.outputRoot, 'Paper_Figures');
cfg.pythonResultDir = fullfile(cfg.outputRoot, 'Python_Output');

% Required V2 inputs.
cfg.modelDataFile = fullfile(cfg.v2Root, 'CrossFit_Model_Data.csv');
cfg.shapCLRFile = fullfile(cfg.pythonOut, 'SHAP_CLR.csv');
cfg.shapCompositionFile = fullfile(cfg.pythonOut, 'SHAP_Composition.csv');
cfg.meanAbsSHAPFile = fullfile(cfg.pythonOut, 'CrossFit_SHAP_Driver_MeanAbs.csv');
cfg.meanSignedSHAPFile = fullfile(cfg.pythonOut, 'CrossFit_SHAP_Driver_MeanSigned.csv');
cfg.kSelectionFile = fullfile(cfg.pythonOut, 'GMM_K_Selection.csv');
cfg.k5AssignmentFile = fullfile(cfg.pythonOut, 'Mechanism_Assignment_Final.csv');
cfg.clrProtocolFile = fullfile(cfg.pythonOut, 'CLR_Protocol.json');
cfg.v2ConfigFile = fullfile(cfg.v2Root, 'shap_mechanism_v2_config.json');

% Python executable used by the previous experiment.
cfg.pythonExe = zz_python_executable();

% Pre-registered strict decision criteria.
cfg.minimumClusterFraction = 0.03;
cfg.minimumMedianPosterior = 0.60;
cfg.minimumStabilityMeanARI = 0.80;
cfg.minimumStabilityP05ARI = 0.75;

% Exact K4 refit uses the same settings as V2. These values are audited
% against shap_mechanism_v2_config.json before execution.
cfg.randomSeed = 20260906;
cfg.gmmNInit = 10; % Representative K4 assignment; selection metrics remain original V2 n_init=20
cfg.gmmMaxIter = 1000;
cfg.gmmRegCovar = 1e-4;

% Expected sign-consistent manual-zone counts for the current dataset.
% Set strictZoneCountCheck=false only if the underlying sample set changes.
cfg.strictZoneCountCheck = true;
cfg.expectedZoneNames = {'Sub1','Sub2','Upl1','Upl2','Upl3'};
cfg.expectedZoneN = [320 79 293 332 797];

% Manual zones, WGS84. Positive Target=subsidence; negative Target=uplift.
cfg.Sub1 = [113.460 113.760 34.660 34.840];
cfg.Sub2 = [113.698 113.871 34.484 34.606];
cfg.Upl1 = [112.777 113.094 34.709 34.891];
cfg.Upl2 = [112.702 112.942 34.276 34.512];
cfg.Upl3 = [113.893 114.182 34.583 34.971];

end
