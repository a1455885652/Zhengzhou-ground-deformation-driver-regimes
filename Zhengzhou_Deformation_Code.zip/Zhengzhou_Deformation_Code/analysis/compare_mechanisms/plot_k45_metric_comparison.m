function plot_k45_metric_comparison(cfg)
T = readtable(fullfile(cfg.pythonResultDir,'K4_K5_Strict_Decision.csv'), 'VariableNamingRule','preserve');

fig = figure('Color','w','Position',[100 100 1250 720]);
tl = tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

ax = nexttile(tl,1);
bar(ax,categorical(string(T.K)),T.StabilityMeanARI);
yline(ax,cfg.minimumStabilityMeanARI,'--','Threshold','LineWidth',1.2);
ylim(ax,[0 1]); ylabel(ax,'Mean ARI'); title(ax,'(a) Mean bootstrap stability'); grid(ax,'on');

ax = nexttile(tl,2);
bar(ax,categorical(string(T.K)),T.StabilityP05ARI);
yline(ax,cfg.minimumStabilityP05ARI,'--','Threshold','LineWidth',1.2);
ylim(ax,[0 1]); ylabel(ax,'5th percentile ARI'); title(ax,'(b) Lower-tail stability'); grid(ax,'on');

ax = nexttile(tl,3);
bar(ax,categorical(string(T.K)),T.MedianMaxPosterior);
yline(ax,cfg.minimumMedianPosterior,'--','Threshold','LineWidth',1.2);
ylim(ax,[0 1]); ylabel(ax,'Median max posterior'); title(ax,'(c) Assignment confidence'); grid(ax,'on');

ax = nexttile(tl,4);
bar(ax,categorical(string(T.K)),T.ICL/1000);
ylabel(ax,'ICL (×10^3; lower is better)'); title(ax,'(d) Model-selection fit'); grid(ax,'on');

set(findall(fig,'Type','axes'),'FontName','Times New Roman','FontSize',12,'LineWidth',1);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_01_K4_K5_Strict_Comparison.png'),'Resolution',600);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_01_K4_K5_Strict_Comparison.tif'),'Resolution',600);
if ~zz_show_figures(), close(fig); end
end
