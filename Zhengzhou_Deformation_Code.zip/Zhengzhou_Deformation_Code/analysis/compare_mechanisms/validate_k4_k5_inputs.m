function validate_k4_k5_inputs(cfg)
requiredFiles = { ...
    cfg.modelDataFile, ...
    cfg.shapCLRFile, ...
    cfg.shapCompositionFile, ...
    cfg.meanAbsSHAPFile, ...
    cfg.meanSignedSHAPFile, ...
    cfg.kSelectionFile, ...
    cfg.k5AssignmentFile, ...
    cfg.clrProtocolFile, ...
    cfg.v2ConfigFile};

fprintf('===== K4/K5 INPUT AUDIT =====\n');
for i = 1:numel(requiredFiles)
    f = requiredFiles{i};
    if ~isfile(f)
        error('Required input does not exist:\n%s', f);
    end
    d = dir(f);
    fprintf('[OK] %s  (%.2f MB)\n', f, d.bytes/1024/1024);
end

Tmodel = readtable(cfg.modelDataFile, 'VariableNamingRule','preserve');
Tclr = readtable(cfg.shapCLRFile, 'VariableNamingRule','preserve');
Tcomp = readtable(cfg.shapCompositionFile, 'VariableNamingRule','preserve');
Tk = readtable(cfg.kSelectionFile, 'VariableNamingRule','preserve');
Tk5 = readtable(cfg.k5AssignmentFile, 'VariableNamingRule','preserve');

if height(Tmodel) ~= height(Tclr) || height(Tmodel) ~= height(Tcomp) || height(Tmodel) ~= height(Tk5)
    error('Row-count mismatch: model=%d, CLR=%d, composition=%d, K5=%d.', ...
        height(Tmodel), height(Tclr), height(Tcomp), height(Tk5));
end

mustModel = {'SampleID','Longitude','Latitude','Target','RasterRow','RasterColumn','PixelIndex'};
for i = 1:numel(mustModel)
    if ~ismember(mustModel{i}, Tmodel.Properties.VariableNames)
        error('CrossFit_Model_Data.csv missing variable: %s', mustModel{i});
    end
end

if ~ismember('SampleIndex', Tclr.Properties.VariableNames)
    error('SHAP_CLR.csv missing SampleIndex.');
end
if ~ismember('SampleIndex', Tcomp.Properties.VariableNames)
    error('SHAP_Composition.csv missing SampleIndex.');
end

if ~all(ismember([4 5], Tk.K))
    error('GMM_K_Selection.csv must contain both K=4 and K=5.');
end

mustK5 = {'SampleID','FinalMechanism','MaxPosterior','NormalizedEntropy'};
for i = 1:numel(mustK5)
    if ~ismember(mustK5{i}, Tk5.Properties.VariableNames)
        error('Mechanism_Assignment_Final.csv missing variable: %s', mustK5{i});
    end
end

% Verify row identity instead of relying only on row count.
if any(double(Tmodel.SampleID) ~= double(Tk5.SampleID))
    error('SampleID order mismatch between CrossFit_Model_Data.csv and Mechanism_Assignment_Final.csv.');
end
if any(double(Tclr.SampleIndex) ~= (1:height(Tclr))')
    error('SHAP_CLR.csv SampleIndex is not sequential 1..N.');
end
if any(double(Tcomp.SampleIndex) ~= (1:height(Tcomp))')
    error('SHAP_Composition.csv SampleIndex is not sequential 1..N.');
end

fprintf('Samples: %d\n', height(Tmodel));
fprintf('K4/K5 rows found in original GMM metrics.\n');

% Verify sign-consistent zones now, before any clustering.
Tzones = build_signconsistent_zone_masks(Tmodel, cfg);
for i = 1:numel(cfg.expectedZoneNames)
    z = cfg.expectedZoneNames{i};
    n = sum(Tzones.(z));
    fprintf('%s sign-consistent N = %d\n', z, n);
    if cfg.strictZoneCountCheck && n ~= cfg.expectedZoneN(i)
        error('%s sign-consistent count is %d, expected %d. Check coordinates/sample set.', ...
            z, n, cfg.expectedZoneN(i));
    end
end

fprintf('===============================\n');
end
