function mask = in_box_k45(lon, lat, box4)
mask = lon >= box4(1) & lon <= box4(2) & ...
       lat >= box4(3) & lat <= box4(4);
end
