# K=4 与 K=5 比较

拟合并比较两套机制分区，输出归属概率、机制特征、典型区组成及选择标准。

| 项目 | 内容 |
|---|---|
| 输入 | SHAP_Mechanism_Zoning_V2_Output 中的组成、CLR 和 SHAP 表。compare_mechanisms_tables 可直接使用附带表格。 |
| 输出 | `project_root/SHAP_Mechanism_K4_K5_Comparison_Output` |
| 设置 | config_k4_k5_comparison.m；../../config/experiments/compare_mechanisms.json |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('compare_mechanisms')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。

若从准备好的表格开始，可在根目录运行：

```bat
.venv\Scripts\python.exe run.py analysis compare_mechanisms_tables
```
