function plot_k45_profile_heatmaps(cfg)
P4 = readtable(fullfile(cfg.pythonResultDir,'K4_Mechanism_Profile_Long.csv'),'VariableNamingRule','preserve');
P5 = readtable(fullfile(cfg.pythonResultDir,'K5_Mechanism_Profile_Long.csv'),'VariableNamingRule','preserve');

drivers = unique(string(P4.Driver),'stable');
A4 = profile_matrix_k45(P4,drivers,4);
A5 = profile_matrix_k45(P5,drivers,5);
pretty = pretty_driver_name_k45(drivers);

fig = figure('Color','w','Position',[80 70 1500 720]);
tl = tiledlayout(2,1,'TileSpacing','compact','Padding','compact');

ax1 = nexttile(tl,1);
imagesc(ax1,100*A4); colorbar(ax1); title(ax1,'(a) K = 4 mean SHAP composition (%)');
set(ax1,'XTick',1:numel(drivers),'XTickLabel',pretty,'YTick',1:4,'YTickLabel',compose('M%d',1:4)); xtickangle(ax1,30);

ax2 = nexttile(tl,2);
imagesc(ax2,100*A5); colorbar(ax2); title(ax2,'(b) K = 5 mean SHAP composition (%)');
set(ax2,'XTick',1:numel(drivers),'XTickLabel',pretty,'YTick',1:5,'YTickLabel',compose('M%d',1:5)); xtickangle(ax2,30);

set(findall(fig,'Type','axes'),'FontName','Times New Roman','FontSize',11,'LineWidth',1);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_03_K4_K5_Driver_Profile_Heatmaps.png'),'Resolution',600);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_03_K4_K5_Driver_Profile_Heatmaps.tif'),'Resolution',600);
if ~zz_show_figures(), close(fig); end
end
