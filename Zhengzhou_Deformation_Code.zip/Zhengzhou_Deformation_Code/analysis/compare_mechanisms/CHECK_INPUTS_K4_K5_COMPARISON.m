function CHECK_INPUTS_K4_K5_COMPARISON()
clc;
cfg = config_k4_k5_comparison();
validate_k4_k5_inputs(cfg);
fprintf('\nAll K4/K5 comparison inputs passed validation.\n');
end
