function Tzones = build_signconsistent_zone_masks(T, cfg)
lon = double(T.Longitude);
lat = double(T.Latitude);
y = double(T.Target);

Tzones = table;
Tzones.SampleID = T.SampleID;
Tzones.Sub1 = in_box_k45(lon, lat, cfg.Sub1) & y > 0;
Tzones.Sub2 = in_box_k45(lon, lat, cfg.Sub2) & y > 0;
Tzones.Upl1 = in_box_k45(lon, lat, cfg.Upl1) & y < 0;
Tzones.Upl2 = in_box_k45(lon, lat, cfg.Upl2) & y < 0;
Tzones.Upl3 = in_box_k45(lon, lat, cfg.Upl3) & y < 0;
end
