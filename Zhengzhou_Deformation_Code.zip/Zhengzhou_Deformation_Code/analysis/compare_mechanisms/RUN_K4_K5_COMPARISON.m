function RUN_K4_K5_COMPARISON()
clc;


cfg = config_k4_k5_comparison();
validate_k4_k5_inputs(cfg);
ensure_folder_k45(cfg.outputRoot);
ensure_folder_k45(cfg.figureDir);
ensure_folder_k45(cfg.pythonResultDir);

jsonFile = write_k45_config_json(cfg);
run_python_k45_comparison(cfg, jsonFile);
verify_k45_outputs(cfg);
plot_k45_metric_comparison(cfg);
plot_k45_mechanism_maps(cfg);
plot_k45_profile_heatmaps(cfg);
plot_k5_to_k4_merge_matrix(cfg);
plot_signconsistent_zone_comparison(cfg);
plot_response_composition_k45(cfg);
PRINT_K4_K5_DECISION_SUMMARY();

fprintf('\nK4/K5 comparison completed.\nOutput: %s\n', cfg.outputRoot);
end
