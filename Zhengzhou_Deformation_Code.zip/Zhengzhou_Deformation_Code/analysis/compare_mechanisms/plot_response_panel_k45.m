function plot_response_panel_k45(ax,T,K,panelTitle)
subs = zeros(K,1);
upl = zeros(K,1);
for k = 1:K
    i1 = T.MechanismCluster==k & string(T.ResponseState)=="Subsidence";
    i2 = T.MechanismCluster==k & string(T.ResponseState)=="Uplift";
    if any(i1), subs(k)=T.FractionWithinMechanism(find(i1,1)); end
    if any(i2), upl(k)=T.FractionWithinMechanism(find(i2,1)); end
end
bar(ax,100*[subs upl],'stacked');
ylim(ax,[0 100]); grid(ax,'on');
xlabel(ax,'Mechanism'); ylabel(ax,'Observed response (%)');
set(ax,'XTick',1:K,'XTickLabel',compose('M%d',1:K));
title(ax,panelTitle);
legend(ax,{'Subsidence','Uplift'},'Location','best','Box','off');
end
