function executable = resolve_python_executable_k45(cfg)
% Resolve the interpreter from the shared project configuration.
executable = zz_python_executable();
end
