function plot_signconsistent_zone_comparison(cfg)
T4 = readtable(fullfile(cfg.pythonResultDir,'ManualZone_SignConsistent_Overlap_K4.csv'),'VariableNamingRule','preserve');
T5 = readtable(fullfile(cfg.pythonResultDir,'ManualZone_SignConsistent_Overlap_K5.csv'),'VariableNamingRule','preserve');

zones = string(cfg.expectedZoneNames);
fig = figure('Color','w','Position',[80 70 1450 760]);
tl = tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
for i = 1:numel(zones)
    ax = nexttile(tl,i);
    z = zones(i);
    a4 = T4(string(T4.Zone)==z,:);
    a5 = T5(string(T5.Zone)==z,:);
    vals = zeros(5,2);
    vals(1:4,1) = a4.FractionWithinZone;
    vals(1:5,2) = a5.FractionWithinZone;
    bar(ax,100*vals,'grouped');
    ylim(ax,[0 100]); grid(ax,'on');
    title(ax,sprintf('%s (N=%d)',z,a5.ZoneN(1)));
    xlabel(ax,'Mechanism ID'); ylabel(ax,'Fraction (%)');
    set(ax,'XTick',1:5,'XTickLabel',compose('M%d',1:5));
    legend(ax,{'K=4','K=5'},'Location','best','Box','off');
end
ax = nexttile(tl,6); axis(ax,'off');
text(ax,0,0.8,'Sign-consistent definition','FontWeight','bold','FontSize',13,'FontName','Times New Roman');
text(ax,0,0.63,'Sub1/Sub2: rectangle + Target > 0','FontSize',12,'FontName','Times New Roman');
text(ax,0,0.50,'Upl1/Upl2/Upl3: rectangle + Target < 0','FontSize',12,'FontName','Times New Roman');
text(ax,0,0.34,sprintf('Expected N: %s',mat2str(cfg.expectedZoneN)),'FontSize',12,'FontName','Times New Roman');
set(findall(fig,'Type','axes'),'FontName','Times New Roman','FontSize',11,'LineWidth',1);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_05_SignConsistent_ManualZone_Comparison.png'),'Resolution',600);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_05_SignConsistent_ManualZone_Comparison.tif'),'Resolution',600);
if ~zz_show_figures(), close(fig); end
end
