function run_python_k45_comparison(cfg, jsonFile)
pyExe = resolve_python_executable_k45(cfg);
check_python_packages_k45(pyExe);

scriptFile = fullfile(fileparts(mfilename('fullpath')), 'gmm_k4_k5_compare.py');
if ~isfile(scriptFile)
    error('Missing Python helper: %s', scriptFile);
end

if startsWith(pyExe,'py ') || strcmp(pyExe,'python')
    cmd = sprintf('%s "%s" "%s"', pyExe, scriptFile, jsonFile);
else
    cmd = sprintf('"%s" "%s" "%s"', pyExe, scriptFile, jsonFile);
end

fprintf('\nRunning exact K4 refit and strict K4/K5 comparison...\n');
fprintf('%s\n\n', cmd);
[status,msg] = system(cmd, '-echo');
if status ~= 0
    error('K4/K5 Python comparison failed.\n%s', msg);
end
end
