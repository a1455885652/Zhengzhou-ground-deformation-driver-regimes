function plot_k5_to_k4_merge_matrix(cfg)
T = readtable(fullfile(cfg.pythonResultDir,'K4_K5_Crosstab.csv'),'VariableNamingRule','preserve');
A = T{:,2:end};
rowSums = sum(A,2);
An = A ./ max(rowSums,1);

fig = figure('Color','w','Position',[150 100 820 620]);
ax = axes(fig);
imagesc(ax,100*An);
cb = colorbar(ax); cb.Label.String = 'Fraction within K4 cluster (%)';
xlabel(ax,'K5 mechanism'); ylabel(ax,'K4 mechanism');
title(ax,'K5 subdivisions within K4 mechanisms');
set(ax,'XTick',1:5,'XTickLabel',compose('K5-M%d',1:5), ...
    'YTick',1:4,'YTickLabel',compose('K4-M%d',1:4), ...
    'FontName','Times New Roman','FontSize',12,'LineWidth',1);
for r = 1:4
    for c = 1:5
        text(ax,c,r,sprintf('%.1f',100*An(r,c)),'HorizontalAlignment','center','FontSize',11,'FontName','Times New Roman');
    end
end
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_04_K5_to_K4_Merge_Matrix.png'),'Resolution',600);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_04_K5_to_K4_Merge_Matrix.tif'),'Resolution',600);
if ~zz_show_figures(), close(fig); end
end
