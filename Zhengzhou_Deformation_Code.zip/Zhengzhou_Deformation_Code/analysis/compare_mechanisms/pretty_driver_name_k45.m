function s = pretty_driver_name_k45(s)
s = string(s);
s = replace(s,'SkinReservoir','Skin reservoir');
s = replace(s,'SubsurfaceRunoff','Subsurface runoff');
s = replace(s,'SurfaceRunoff','Surface runoff');
s = replace(s,'TotalPrecipitation','Total precipitation');
s = replace(s,'NighttimeLight','Nighttime light');
s = replace(s,'BuiltSurface','Built surface');
s = replace(s,'GLHYMPS_Permeability','Permeability');
s = replace(s,'TotalLooseThickness','Loose-layer thickness');
s = replace(s,'RoadDensity','Road density');
end
