function plot_k45_mechanism_maps(cfg)
T4 = readtable(fullfile(cfg.pythonResultDir,'K4_Assignment.csv'),'VariableNamingRule','preserve');
T5 = readtable(fullfile(cfg.pythonResultDir,'K5_Assignment_Audited.csv'),'VariableNamingRule','preserve');

fig = figure('Color','w','Position',[100 80 1450 620]);
tl = tiledlayout(1,2,'TileSpacing','compact','Padding','compact');

ax1 = nexttile(tl,1);
scatter(ax1,T4.Longitude,T4.Latitude,11,T4.MechanismCluster,'filled');
axis(ax1,'equal'); box(ax1,'on'); xlabel(ax1,'Longitude'); ylabel(ax1,'Latitude'); title(ax1,'(a) K = 4');
cb1 = colorbar(ax1); cb1.Ticks = 1:4; cb1.TickLabels = compose('M%d',1:4);

ax2 = nexttile(tl,2);
scatter(ax2,T5.Longitude,T5.Latitude,11,T5.MechanismCluster,'filled');
axis(ax2,'equal'); box(ax2,'on'); xlabel(ax2,'Longitude'); ylabel(ax2,'Latitude'); title(ax2,'(b) K = 5');
cb2 = colorbar(ax2); cb2.Ticks = 1:5; cb2.TickLabels = compose('M%d',1:5);

set(findall(fig,'Type','axes'),'FontName','Times New Roman','FontSize',12,'LineWidth',1);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_02_K4_K5_Mechanism_Maps.png'),'Resolution',600);
exportgraphics(fig,fullfile(cfg.figureDir,'Fig_02_K4_K5_Mechanism_Maps.tif'),'Resolution',600);
if ~zz_show_figures(), close(fig); end
end
