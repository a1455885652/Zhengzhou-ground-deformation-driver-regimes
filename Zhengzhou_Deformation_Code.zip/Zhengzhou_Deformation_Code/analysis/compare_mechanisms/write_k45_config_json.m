function jsonFile = write_k45_config_json(cfg)
ensure_folder_k45(cfg.outputRoot);

S = struct;
S.model_data_file = cfg.modelDataFile;
S.shap_clr_file = cfg.shapCLRFile;
S.shap_composition_file = cfg.shapCompositionFile;
S.mean_abs_shap_file = cfg.meanAbsSHAPFile;
S.mean_signed_shap_file = cfg.meanSignedSHAPFile;
S.original_k_selection_file = cfg.kSelectionFile;
S.original_k5_assignment_file = cfg.k5AssignmentFile;
S.clr_protocol_file = cfg.clrProtocolFile;
S.v2_config_file = cfg.v2ConfigFile;
S.output_dir = cfg.pythonResultDir;
S.random_seed = cfg.randomSeed;
S.gmm_n_init = cfg.gmmNInit;
S.gmm_max_iter = cfg.gmmMaxIter;
S.gmm_reg_covar = cfg.gmmRegCovar;
S.minimum_cluster_fraction = cfg.minimumClusterFraction;
S.minimum_median_posterior = cfg.minimumMedianPosterior;
S.minimum_stability_mean_ari = cfg.minimumStabilityMeanARI;
S.minimum_stability_p05_ari = cfg.minimumStabilityP05ARI;
S.strict_zone_count_check = cfg.strictZoneCountCheck;
S.expected_zone_names = cfg.expectedZoneNames;
S.expected_zone_n = cfg.expectedZoneN;
S.Sub1 = cfg.Sub1;
S.Sub2 = cfg.Sub2;
S.Upl1 = cfg.Upl1;
S.Upl2 = cfg.Upl2;
S.Upl3 = cfg.Upl3;

jsonFile = fullfile(cfg.outputRoot, 'k4_k5_comparison_config.json');
fid = fopen(jsonFile,'w');
if fid < 0
    error('Cannot create config JSON: %s', jsonFile);
end
cleanupObj = onCleanup(@() fclose(fid));
fwrite(fid, jsonencode(S, 'PrettyPrint', true), 'char');
clear cleanupObj;
end
