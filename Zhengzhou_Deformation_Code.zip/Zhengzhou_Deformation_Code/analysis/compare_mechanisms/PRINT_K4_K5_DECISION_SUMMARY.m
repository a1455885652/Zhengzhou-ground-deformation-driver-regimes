function PRINT_K4_K5_DECISION_SUMMARY()
cfg = config_k4_k5_comparison();
f = fullfile(cfg.pythonResultDir,'K4_K5_Strict_Decision.csv');
if ~isfile(f)
    error('Run RUN_K4_K5_COMPARISON first.');
end
T = readtable(f,'VariableNamingRule','preserve');

fprintf('\n================ K4 vs K5 STRICT DECISION ================\n');
disp(T(:,{'K','ICL','MinClusterFraction','MedianMaxPosterior','StabilityMeanARI','StabilityP05ARI','PassStrictQC','Recommended'}));

rec = T.K(logical(T.Recommended));
if isempty(rec)
    fprintf('Decision: no K passes all pre-registered strict criteria.\n');
else
    fprintf('Recommended K = %d\n',rec(1));
end

mergeFile = fullfile(cfg.pythonResultDir,'K5_to_K4_Merge_Audit.csv');
if isfile(mergeFile)
    fprintf('\nK5 -> K4 merge audit:\n');
    disp(readtable(mergeFile,'VariableNamingRule','preserve'));
end

fprintf('===========================================================\n');
end
