function A = profile_matrix_k45(P,drivers,K)
A = nan(K,numel(drivers));
for k = 1:K
    for j = 1:numel(drivers)
        idx = P.MechanismCluster == k & string(P.Driver) == drivers(j);
        if any(idx)
            A(k,j) = P.MeanComposition(find(idx,1));
        end
    end
end
end
