import sys, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.mixture import GaussianMixture
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score


def norm_entropy(prob):
    p = np.clip(np.asarray(prob, float), 1e-15, 1.0)
    return -np.sum(p * np.log(p), axis=1) / np.log(p.shape[1])


def canonicalize(labels, prob):
    labels = np.asarray(labels, int)
    K = prob.shape[1]
    rows = []
    for old in range(K):
        m = labels == old
        rows.append(
            (old, int(m.sum()), float(np.mean(prob[m, old])) if m.any() else 0.0)
        )
    order = sorted(rows, key=lambda x: (-x[1], -x[2], x[0]))
    mp = {old: new for new, (old, _, _) in enumerate(order)}
    nl = np.array([mp[x] for x in labels], int)
    npb = np.zeros_like(prob)
    for old, new in mp.items():
        npb[:, new] = prob[:, old]
    return nl, npb, mp


def response_state(y):
    a = np.full(len(y), "Zero", dtype=object)
    a[y > 0] = "Subsidence"
    a[y < 0] = "Uplift"
    return a


def in_box(lon, lat, b):
    return (lon >= b[0]) & (lon <= b[1]) & (lat >= b[2]) & (lat <= b[3])


def zone_masks(model, cfg):
    lon = model.Longitude.to_numpy(float)
    lat = model.Latitude.to_numpy(float)
    y = model.Target.to_numpy(float)
    return {
        "Sub1": in_box(lon, lat, cfg["Sub1"]) & (y > 0),
        "Sub2": in_box(lon, lat, cfg["Sub2"]) & (y > 0),
        "Upl1": in_box(lon, lat, cfg["Upl1"]) & (y < 0),
        "Upl2": in_box(lon, lat, cfg["Upl2"]) & (y < 0),
        "Upl3": in_box(lon, lat, cfg["Upl3"]) & (y < 0),
    }


def profile_long(comp, meanabs, meansigned, labels, drivers, K):
    rows = []
    for k0 in range(K):
        m = labels == k0
        for j, d in enumerate(drivers):
            rows.append(
                {
                    "MechanismCluster": k0 + 1,
                    "Driver": d,
                    "MeanComposition": float(np.mean(comp[m, j])),
                    "MedianComposition": float(np.median(comp[m, j])),
                    "MeanAbsCrossFitSHAP": float(np.mean(meanabs[m, j])),
                    "MeanSignedCrossFitSHAP": float(np.mean(meansigned[m, j])),
                }
            )
    return pd.DataFrame(rows)


def cluster_summary(model, comp, labels, prob, drivers, K):
    y = model.Target.to_numpy(float)
    rs = response_state(y)
    rows = []
    for k0 in range(K):
        m = labels == k0
        mc = comp[m].mean(axis=0)
        top = np.argsort(mc)[::-1][:3]
        rows.append(
            {
                "MechanismCluster": k0 + 1,
                "N": int(m.sum()),
                "Fraction": float(m.mean()),
                "MeanTarget": float(y[m].mean()),
                "MedianTarget": float(np.median(y[m])),
                "SubsidenceFraction": float(np.mean(rs[m] == "Subsidence")),
                "UpliftFraction": float(np.mean(rs[m] == "Uplift")),
                "MedianMaxPosterior": float(np.median(prob[m].max(axis=1))),
                "MeanNormalizedEntropy": float(np.mean(norm_entropy(prob[m]))),
                "TopDriver1": drivers[top[0]],
                "TopDriver2": drivers[top[1]],
                "TopDriver3": drivers[top[2]],
            }
        )
    return pd.DataFrame(rows)


def pairwise_aitchison(clr, labels, K):
    cent = np.vstack([clr[labels == k].mean(axis=0) for k in range(K)])
    D = np.sqrt(((cent[:, None, :] - cent[None, :, :]) ** 2).sum(axis=2))
    out = pd.DataFrame(
        D,
        index=[f"M{i + 1}" for i in range(K)],
        columns=[f"M{i + 1}" for i in range(K)],
    )
    out.index.name = "Mechanism"
    return out


def manual_overlap(labels, K, masks):
    rows = []
    for z, m in masks.items():
        n = int(m.sum())
        for k0 in range(K):
            c = int(np.sum(m & (labels == k0)))
            rows.append(
                {
                    "Zone": z,
                    "MechanismCluster": k0 + 1,
                    "ZoneN": n,
                    "ClusterNInZone": c,
                    "FractionWithinZone": c / n if n else np.nan,
                }
            )
    return pd.DataFrame(rows)


def response_crosstab(labels, K, y):
    rs = response_state(y)
    rows = []
    for k0 in range(K):
        mk = labels == k0
        nk = mk.sum()
        for state in ["Subsidence", "Uplift", "Zero"]:
            c = int(np.sum(mk & (rs == state)))
            rows.append(
                {
                    "MechanismCluster": k0 + 1,
                    "ResponseState": state,
                    "Count": c,
                    "FractionWithinMechanism": c / nk if nk else np.nan,
                }
            )
    return pd.DataFrame(rows)


def main(cfg_file):
    cfg = json.load(open(cfg_file, encoding="utf-8"))
    out = Path(cfg["output_dir"])
    out.mkdir(parents=True, exist_ok=True)

    model = pd.read_csv(cfg["model_data_file"])
    clr_df = pd.read_csv(cfg["shap_clr_file"])
    comp_df = pd.read_csv(cfg["shap_composition_file"])
    abs_df = pd.read_csv(cfg["mean_abs_shap_file"])
    signed_df = pd.read_csv(cfg["mean_signed_shap_file"])
    ksel = pd.read_csv(cfg["original_k_selection_file"])
    k5a = pd.read_csv(cfg["original_k5_assignment_file"])
    v2cfg = json.load(open(cfg["v2_config_file"], encoding="utf-8"))
    clrprot = json.load(open(cfg["clr_protocol_file"], encoding="utf-8"))

    drivers = [c for c in clr_df.columns if c != "SampleIndex"]
    # Driver CSVs use the same 15 physical-driver columns.
    absdrivers = [c for c in abs_df.columns if c not in ("SampleIndex", "SampleID")]
    sigdrivers = [c for c in signed_df.columns if c not in ("SampleIndex", "SampleID")]
    if set(drivers) != set(absdrivers) or set(drivers) != set(sigdrivers):
        raise RuntimeError(
            "Driver columns differ between CLR and cross-fit SHAP tables."
        )
    abs_df = (
        abs_df[["SampleIndex"] + drivers]
        if "SampleIndex" in abs_df.columns
        else abs_df[["SampleID"] + drivers]
    )
    signed_df = (
        signed_df[["SampleIndex"] + drivers]
        if "SampleIndex" in signed_df.columns
        else signed_df[["SampleID"] + drivers]
    )

    N = len(model)
    if not (
        len(clr_df) == len(comp_df) == len(abs_df) == len(signed_df) == len(k5a) == N
    ):
        raise RuntimeError("Input row-count mismatch.")
    if not np.array_equal(model.SampleID.to_numpy(), k5a.SampleID.to_numpy()):
        raise RuntimeError("K5 assignment SampleID order differs from model data.")

    # Audit that comparison uses exactly the original V2 settings.
    audits = {
        "random_seed": (int(cfg["random_seed"]), int(v2cfg["random_seed"])),
        "gmm_max_iter": (int(cfg["gmm_max_iter"]), int(v2cfg["gmm_max_iter"])),
        "gmm_reg_covar": (float(cfg["gmm_reg_covar"]), float(v2cfg["gmm_reg_covar"])),
    }
    for name, (a, b) in audits.items():
        if not np.isclose(a, b):
            raise RuntimeError(f"Config mismatch for {name}: comparison={a}, V2={b}")
    if int(cfg["gmm_n_init"]) > int(v2cfg["gmm_n_init"]):
        raise RuntimeError("Comparison n_init must not exceed original V2 n_init.")

    CLR = clr_df[drivers].to_numpy(float)
    P = comp_df[drivers].to_numpy(float)
    A = abs_df[drivers].to_numpy(float)
    S = signed_df[drivers].to_numpy(float)
    ncomp = int(clrprot["retained_pcs"])
    pca = PCA().fit(CLR)
    Z = pca.transform(CLR)[:, :ncomp]
    retained = float(np.cumsum(pca.explained_variance_ratio_)[ncomp - 1])
    if abs(retained - float(clrprot["retained_cumulative_variance"])) > 1e-8:
        raise RuntimeError(
            "PCA reconstruction does not match original V2 CLR protocol."
        )

    # High-fidelity K4 refit for assignment/profile diagnostics. The formal K-selection
    # metrics are read from the original V2 table (n_init=20). To keep this supplement
    # fast, K4 assignment uses n_init=10 and must reproduce the original BIC/ICL closely.
    seed = int(cfg["random_seed"]) + 31 * 4
    print(
        f"Fitting representative K4 GMM with n_init={int(cfg['gmm_n_init'])} ...",
        flush=True,
    )
    g4 = GaussianMixture(
        n_components=4,
        covariance_type="full",
        reg_covar=float(cfg["gmm_reg_covar"]),
        n_init=int(cfg["gmm_n_init"]),
        max_iter=int(cfg["gmm_max_iter"]),
        init_params="kmeans",
        random_state=seed,
    )
    g4.fit(Z)
    p4raw = g4.predict_proba(Z)
    l4raw = np.argmax(p4raw, axis=1)
    l4, p4, map4 = canonicalize(l4raw, p4raw)

    # K5 is taken from the completed V2 run (lambda=0 there), avoiding a slow unnecessary refit.
    l5 = k5a.FinalMechanism.to_numpy(int) - 1
    p5 = np.column_stack([k5a[f"P_M{i}"].to_numpy(float) for i in range(1, 6)])
    if not np.array_equal(l5, np.argmax(p5, axis=1)):
        raise RuntimeError(
            "FinalMechanism is inconsistent with K5 posterior columns; expected lambda=0 V2 result."
        )

    # Reproduce the K4 likelihood diagnostics and compare to original V2 table.
    bic4 = float(g4.bic(Z))
    aic4 = float(g4.aic(Z))
    rawent4 = float(
        np.sum(
            -np.sum(np.clip(p4raw, 1e-15, 1) * np.log(np.clip(p4raw, 1e-15, 1)), axis=1)
        )
    )
    icl4 = bic4 + 2 * rawent4
    row4 = ksel.loc[ksel.K == 4].iloc[0]
    bic_diff = bic4 - float(row4.BIC)
    icl_diff = icl4 - float(row4.ICL)
    if abs(bic_diff) > 2.0 or abs(icl_diff) > 2.0:
        raise RuntimeError(
            f"K4 representative refit audit failed: BIC/ICL differ too much from V2 selection table. BIC={bic4}, expected={row4.BIC}; ICL={icl4}, expected={row4.ICL}"
        )

    # Original K-selection metrics are the pre-registered stability evidence; no XGBoost or GMM stability rerun needed.
    rows = []
    for k in [4, 5]:
        r = ksel.loc[ksel.K == k].iloc[0]
        strict = (
            float(r.MinClusterFraction) >= float(cfg["minimum_cluster_fraction"])
            and float(r.MedianMaxPosterior) >= float(cfg["minimum_median_posterior"])
            and float(r.StabilityMeanARI) >= float(cfg["minimum_stability_mean_ari"])
            and float(r.StabilityP05ARI) >= float(cfg["minimum_stability_p05_ari"])
        )
        rows.append(
            {
                "K": k,
                "BIC": float(r.BIC),
                "ICL": float(r.ICL),
                "AIC": float(r.AIC),
                "Silhouette": float(r.Silhouette),
                "DaviesBouldin": float(r.DaviesBouldin),
                "MinClusterFraction": float(r.MinClusterFraction),
                "MedianMaxPosterior": float(r.MedianMaxPosterior),
                "MeanMaxPosterior": float(r.MeanMaxPosterior),
                "MeanNormalizedEntropy": float(r.MeanNormalizedEntropy),
                "StabilityMeanARI": float(r.StabilityMeanARI),
                "StabilitySDARI": float(r.StabilitySDARI),
                "StabilityP05ARI": float(r.StabilityP05ARI),
                "PassStrictQC": bool(strict),
                "Recommended": False,
            }
        )
    dec = pd.DataFrame(rows)
    passed = dec[dec.PassStrictQC]
    if len(passed) == 1:
        recommended = int(passed.K.iloc[0])
        rule = "Only one candidate passed all strict pre-registered QC thresholds."
    elif len(passed) > 1:
        recommended = int(passed.loc[passed.ICL.idxmin(), "K"])
        rule = "Both candidates passed strict QC; lower ICL selected."
    else:
        recommended = None
        rule = "Neither candidate passed all strict QC thresholds; no automatic recommendation."
    if recommended is not None:
        dec.loc[dec.K == recommended, "Recommended"] = True
    dec.to_csv(out / "K4_K5_Strict_Decision.csv", index=False)

    # Assignment tables.
    def assign_table(labels, prob, K):
        t = model[
            [
                "SampleID",
                "PixelIndex",
                "RasterRow",
                "RasterColumn",
                "Longitude",
                "Latitude",
                "Target",
            ]
        ].copy()
        t["ResponseState"] = response_state(t.Target.to_numpy(float))
        t["MechanismCluster"] = labels + 1
        t["MaxPosterior"] = prob.max(axis=1)
        ps = np.sort(prob, axis=1)
        t["PosteriorMargin"] = ps[:, -1] - ps[:, -2]
        t["NormalizedEntropy"] = norm_entropy(prob)
        for j in range(K):
            t[f"P_M{j + 1}"] = prob[:, j]
        return t

    a4 = assign_table(l4, p4, 4)
    a5 = assign_table(l5, p5, 5)
    a4.to_csv(out / "K4_Assignment.csv", index=False)
    a5.to_csv(out / "K5_Assignment_Audited.csv", index=False)

    # K4-K5 correspondence and information agreement.
    ct = pd.crosstab(
        pd.Series(l4 + 1, name="K4"), pd.Series(l5 + 1, name="K5")
    ).reindex(index=range(1, 5), columns=range(1, 6), fill_value=0)
    ct.reset_index().to_csv(out / "K4_K5_Crosstab.csv", index=False)
    merge = []
    for k5 in range(1, 6):
        col = ct[k5]
        k4 = int(col.idxmax())
        c = int(col.max())
        n = int(col.sum())
        merge.append(
            {
                "K5Mechanism": k5,
                "BestMatchingK4Mechanism": k4,
                "N": n,
                "NInBestK4": c,
                "FractionMappedToBestK4": c / n,
            }
        )
    pd.DataFrame(merge).to_csv(out / "K5_to_K4_Merge_Audit.csv", index=False)
    agree = {
        "ARI_K4_vs_K5": float(adjusted_rand_score(l4, l5)),
        "NMI_K4_vs_K5": float(normalized_mutual_info_score(l4, l5)),
    }
    pd.DataFrame([agree]).to_csv(out / "K4_K5_Agreement.csv", index=False)

    # Profiles and Aitchison centroid distances.
    profile_long(P, A, S, l4, drivers, 4).to_csv(
        out / "K4_Mechanism_Profile_Long.csv", index=False
    )
    profile_long(P, A, S, l5, drivers, 5).to_csv(
        out / "K5_Mechanism_Profile_Long.csv", index=False
    )
    cluster_summary(model, P, l4, p4, drivers, 4).to_csv(
        out / "K4_Cluster_Summary.csv", index=False
    )
    cluster_summary(model, P, l5, p5, drivers, 5).to_csv(
        out / "K5_Cluster_Summary.csv", index=False
    )
    pairwise_aitchison(CLR, l4, 4).to_csv(out / "K4_Aitchison_Distance_Matrix.csv")
    pairwise_aitchison(CLR, l5, 5).to_csv(out / "K5_Aitchison_Distance_Matrix.csv")

    # Correct manual zones: rectangle AND sign-consistent actual InSAR target.
    masks = zone_masks(model, cfg)
    if bool(cfg["strict_zone_count_check"]):
        for z, nexp in zip(cfg["expected_zone_names"], cfg["expected_zone_n"]):
            if int(masks[z].sum()) != int(nexp):
                raise RuntimeError(f"{z} N={masks[z].sum()}, expected {nexp}")
    manual_overlap(l4, 4, masks).to_csv(
        out / "ManualZone_SignConsistent_Overlap_K4.csv", index=False
    )
    manual_overlap(l5, 5, masks).to_csv(
        out / "ManualZone_SignConsistent_Overlap_K5.csv", index=False
    )
    response_crosstab(l4, 4, model.Target.to_numpy(float)).to_csv(
        out / "Response_Mechanism_Crosstab_K4.csv", index=False
    )
    response_crosstab(l5, 5, model.Target.to_numpy(float)).to_csv(
        out / "Response_Mechanism_Crosstab_K5.csv", index=False
    )

    protocol = {
        "purpose": "Strict supplementary decision between K=4 and K=5 after completed SHAP mechanism zoning V2.",
        "no_xgboost_retraining": True,
        "k4_fit": "Representative K4 refit using the same V2 CLR, PCA, covariance model, regularization and K-specific random seed; n_init=10 for speed. Formal K-selection metrics remain the original V2 n_init=20 results.",
        "k5_source": "Existing completed V2 assignment; no spatial regularization was used in V2 (lambda=0).",
        "stability_source": "Original V2 GMM_K_Selection.csv; it already contains the pre-specified 80% subsample stability analysis.",
        "strict_thresholds": {
            "minimum_cluster_fraction": cfg["minimum_cluster_fraction"],
            "minimum_median_posterior": cfg["minimum_median_posterior"],
            "minimum_stability_mean_ari": cfg["minimum_stability_mean_ari"],
            "minimum_stability_p05_ari": cfg["minimum_stability_p05_ari"],
        },
        "decision_rule": rule,
        "recommended_k": recommended,
        "manual_zones": "Sub1/Sub2 = rectangle AND Target>0; Upl1/Upl2/Upl3 = rectangle AND Target<0.",
        "positive_is_subsidence": True,
        "retained_pcs": ncomp,
        "k4_refit_n_init": int(cfg["gmm_n_init"]),
        "original_v2_n_init": int(v2cfg["gmm_n_init"]),
        "k4_refit_bic_audit_difference": bic_diff,
        "k4_refit_icl_audit_difference": icl_diff,
        "ARI_K4_vs_K5": agree["ARI_K4_vs_K5"],
        "NMI_K4_vs_K5": agree["NMI_K4_vs_K5"],
    }
    json.dump(
        protocol,
        open(out / "Decision_Protocol.json", "w", encoding="utf-8"),
        indent=2,
        ensure_ascii=False,
    )
    with open(out / "Decision_Summary.txt", "w", encoding="utf-8") as f:
        f.write("K=4 vs K=5 strict comparison\n")
        f.write(dec.to_string(index=False) + "\n\n")
        f.write(f"Decision rule: {rule}\nRecommended K: {recommended}\n")
        f.write(
            f"ARI(K4,K5)={agree['ARI_K4_vs_K5']:.6f}; NMI={agree['NMI_K4_vs_K5']:.6f}\n"
        )
    print(
        f"Comparison completed. Recommended K={recommended}. Output={out}", flush=True
    )


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python gmm_k4_k5_compare.py <config.json>")
    main(sys.argv[1])
