function result = mechanism_group_ablation_cv( ...
    X,Y,driverNames,foldId,fullCV,cfg)
% MECHANISM_GROUP_ABLATION_CV
%
% 删除整个物理机制组后重新训练。
% 用于判断高度相关变量作为一个“信息束”是否重要。

drivers=unique(driverNames,'stable');

mechanisms=strings(numel(drivers),1);

for d=1:numel(drivers)
    mechanisms(d)=get_driver_mechanism_group(drivers(d));
end

mechanismList=unique(mechanisms,'stable');

baseRMSE=fullCV.foldTable.RMSE;
nF=numel(baseRMSE);

rows={};

for m=1:numel(mechanismList)

    mechanism=mechanismList(m);

    driverInMechanism=drivers(mechanisms==mechanism);

    removeCols=ismember(driverNames,driverInMechanism);
    keepCols=~removeCols;

    fprintf('  drop mechanism: %s (%d drivers)\n', ...
        mechanism,numel(driverInMechanism));

    cv=spatial_cv_tree_metrics_v2( ...
        X(:,keepCols), ...
        Y, ...
        foldId, ...
        cfg.nTreesAblation, ...
        cfg.minLeafSize, ...
        cfg.randomSeed+7000+m);

    delta=cv.foldTable.RMSE-baseRMSE;

    rows(end+1,:)={ ...
        char(mechanism), ...
        strjoin(cellstr(driverInMechanism),'; '), ...
        numel(driverInMechanism), ...
        mean(delta,'omitnan'), ...
        median(delta,'omitnan'), ...
        std(delta,'omitnan'), ...
        mean(delta>0,'omitnan'), ...
        cv.meanRMSE}; %#ok<AGROW>

end

T=cell2table(rows, ...
    'VariableNames', ...
    {'MechanismGroup','Drivers','NDrivers','MeanDeltaRMSE', ...
     'MedianDeltaRMSE','StdDeltaRMSE','PositiveFoldFraction', ...
     'MeanRMSEWithoutGroup'});

T=sortrows(T,'MeanDeltaRMSE','descend');

result=struct();
result.table=T;

end
