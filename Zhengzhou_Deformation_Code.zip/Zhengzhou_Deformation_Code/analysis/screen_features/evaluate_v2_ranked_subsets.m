function result=evaluate_v2_ranked_subsets( ...
    X,Y,driverNames,foldId,rankedDrivers,cfg)
% EVALUATE_V2_RANKED_SUBSETS
%
% 在descriptor压缩以后，再按照V2 driver ranking逐步增加driver。
% 用同一Spatial Block CV评价。
%
% 1-SE仅作为“统计候选集”，不直接宣布为最终驱动因素。

nDrivers=numel(rankedDrivers);

kValues=(cfg.minRankedSubsetDrivers:nDrivers)';

nK=numel(kValues);

meanRMSE=nan(nK,1);
stdRMSE=nan(nK,1);
seRMSE=nan(nK,1);
meanMAE=nan(nK,1);
meanR2=nan(nK,1);

for i=1:nK

    k=kValues(i);

    currentDrivers=rankedDrivers(1:k);

    cols=ismember(driverNames,currentDrivers);

    fprintf('  top-%d drivers, %d compressed descriptors\n', ...
        k,nnz(cols));

    cv=spatial_cv_tree_metrics_v2( ...
        X(:,cols), ...
        Y, ...
        foldId, ...
        cfg.nTreesSubset, ...
        cfg.minLeafSize, ...
        cfg.randomSeed+9000+k);

    meanRMSE(i)=cv.meanRMSE;
    stdRMSE(i)=cv.stdRMSE;
    seRMSE(i)=cv.seRMSE;
    meanMAE(i)=cv.meanMAE;
    meanR2(i)=cv.meanR2;

end

[bestRMSE,bestIdx]=min(meanRMSE);

threshold=bestRMSE+seRMSE(bestIdx);

eligible=find(meanRMSE<=threshold);

selectedIdx=eligible(1);

selectedK=kValues(selectedIdx);

SelectedBy1SE=false(nK,1);
SelectedBy1SE(selectedIdx)=true;

performanceTable=table( ...
    kValues,meanRMSE,stdRMSE,seRMSE,meanMAE,meanR2,SelectedBy1SE, ...
    'VariableNames', ...
    {'NDrivers','MeanRMSE','StdRMSE','SERMSE','MeanMAE','MeanR2', ...
     'SelectedBy1SE'});

result=struct();
result.performanceTable=performanceTable;
result.bestK=kValues(bestIdx);
result.bestRMSE=bestRMSE;
result.oneSEThreshold=threshold;
result.selectedK=selectedK;

end
