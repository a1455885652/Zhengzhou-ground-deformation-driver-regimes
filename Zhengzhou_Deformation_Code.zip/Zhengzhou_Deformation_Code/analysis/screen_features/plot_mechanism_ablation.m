function plot_mechanism_ablation(T,outputFile)
% PLOT_MECHANISM_ABLATION

fig=figure('Visible','off','Position',[100 100 1000 600]);

barh(T.MeanDeltaRMSE);

set(gca, ...
    'YDir','reverse', ...
    'YTick',1:height(T), ...
    'YTickLabel',cellstr(string(T.MechanismGroup)));

xlabel('\DeltaRMSE after removing entire mechanism group');
ylabel('Mechanism group');
title('Mechanism-group ablation under spatial CV');

xline(0,'--');
grid on;

exportgraphics(fig,outputFile,'Resolution',300);

if ~zz_show_figures(), close(fig); end

end
