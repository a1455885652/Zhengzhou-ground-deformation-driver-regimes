function Z = build_spatial_trend_design(lon,lat)
% BUILD_SPATIAL_TREND_DESIGN
% 二阶空间趋势面设计矩阵。

lon = double(lon(:));
lat = double(lat(:));

x = lon-mean(lon);
y = lat-mean(lat);

sx = std(x);
sy = std(y);

if sx <= 0
    sx = 1;
end

if sy <= 0
    sy = 1;
end

x = x/sx;
y = y/sy;

Z = [ ...
    ones(size(x)), ...
    x, ...
    y, ...
    x.^2, ...
    y.^2, ...
    x.*y];

end
