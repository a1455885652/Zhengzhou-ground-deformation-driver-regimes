function vif=calculate_vif_matrix_v2(X)
% CALCULATE_VIF_MATRIX_V2
%
% 仅作解释稳定性诊断，不作为自动删除硬阈值。

X=double(X);

nP=size(X,2);
vif=nan(nP,1);

for j=1:nP

    y=X(:,j);

    other=setdiff(1:nP,j);

    if isempty(other)
        vif(j)=1;
        continue;
    end

    if std(y)<=1e-12
        vif(j)=Inf;
        continue;
    end

    Z=X(:,other);

    mu=mean(Z,1);
    sd=std(Z,0,1);
    sd(sd<=1e-12)=1;

    Z=(Z-mu)./sd;

    y=(y-mean(y))/std(y);

    Z=[ones(size(Z,1),1),Z];

    beta=pinv(Z)*y;

    pred=Z*beta;

    sst=sum((y-mean(y)).^2);
    sse=sum((y-pred).^2);

    if sst<=0
        vif(j)=Inf;
        continue;
    end

    R2=1-sse/sst;

    if R2>=1
        vif(j)=Inf;
    else
        vif(j)=1/(1-R2);
    end

end

end
