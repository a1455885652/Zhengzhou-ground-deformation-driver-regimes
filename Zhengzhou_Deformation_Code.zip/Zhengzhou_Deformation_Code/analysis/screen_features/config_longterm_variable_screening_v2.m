function cfg = config_longterm_variable_screening_v2()
% CONFIG_LONGTERM_VARIABLE_SCREENING_V2

%% V1输入

cfg.v1ResultMat = ...
    zz_project_path('LongTerm_Variable_Screening_Output/Variable_Screening_Results.mat');

%% 输出

cfg.outputRoot = ...
    zz_project_path('LongTerm_Variable_Screening_V2_Output');

%% 随机种子

cfg.randomSeed = 20260829;

%% Spatial Block CV
% 若V1 workspace已有foldId，则直接沿用，不重新划分。

cfg.spatialBlockSizeKm = 12;
cfg.nSpatialFolds = 5;

%% TreeBagger

cfg.nTreesDescriptor = 80;
cfg.nTreesAblation   = 160;
cfg.nTreesSubset     = 140;

cfg.minLeafSize = 8;

%% Driver内部descriptor压缩

% descriptor综合评价：
% raw Spearman + 控制空间趋势后的Spearman
cfg.descriptorWeightRaw = 0.35;
cfg.descriptorWeightSpatialResidual = 0.65;

% primary与secondary高度相关时，不允许同时保留
cfg.maxWithinDriverDescriptorCorr = 0.80;

% 第二descriptor至少使Spatial-CV RMSE改善1%，才保留
cfg.secondDescriptorMinRelativeGain = 0.01;

% 每个连续dynamic driver最多保留2个descriptor
cfg.maxDescriptorsPerDriver = 2;

%% V2 driver总排名权重

cfg.weightRawSpearman = 0.10;
cfg.weightSpatialResidualSpearman = 0.25;
cfg.weightDropColumnDeltaRMSE = 0.45;
cfg.weightDropColumnStability = 0.20;

%% Ranked subset

cfg.minRankedSubsetDrivers = 5;

%% 机制平衡候选集

% 只有整组删除后平均RMSE变差，并且>=60%的fold方向一致，
% 才要求统计候选集中至少有这个机制组的一个代表driver。
cfg.mechanismMinPositiveFoldFraction = 0.60;

%% “证据支持”表阈值，只作为人工复核，不自动定稿

cfg.evidenceMinPositiveFoldFraction = 0.60;
cfg.evidenceMinSpatialResidualRho = 0.15;
cfg.evidenceMinRawRho = 0.20;

%% 强空间梯度诊断

cfg.strongSpatialTrendR2 = 0.70;

end
