function result = compress_driver_descriptors( ...
    X, Y, featureNames, driverNames, foldId, spatialFeatureTable, cfg)
% COMPRESS_DRIVER_DESCRIPTORS
%
% 每个driver内部：
% - Static连续变量通常只有1列，直接保留；
% - GUM dummy全部保留；
% - 动态/年度driver从Mean/Trend/DStd/SeasonAmp中先选primary；
% - secondary必须：
%     与primary |rho| < threshold
%     且 primary+secondary 相比 primary-only
%     Spatial-CV RMSE至少改善指定比例。
%
% 最多保留2个descriptor。

drivers = unique(driverNames,'stable');

keepMask = false(size(driverNames));

rows = {};

for g = 1:numel(drivers)

    driver = drivers(g);

    cols = find(driverNames==driver);

    fprintf('  %-24s : %d descriptor(s)\n',driver,numel(cols));

    % GUM类别dummy必须作为整体保留
    if driver == "GUM"

        keepMask(cols) = true;

        for q = 1:numel(cols)
            rows(end+1,:) = { ...
                char(driver), ...
                char(featureNames(cols(q))), ...
                true, ...
                'Categorical dummy retained as a group', ...
                NaN,NaN,NaN,NaN}; %#ok<AGROW>
        end

        continue;
    end

    % 只有一个descriptor
    if numel(cols)==1

        keepMask(cols) = true;

        ft = spatialFeatureTable( ...
            spatialFeatureTable.Feature==featureNames(cols),:);

        rows(end+1,:) = { ...
            char(driver), ...
            char(featureNames(cols)), ...
            true, ...
            'Single descriptor', ...
            abs(ft.RawSpearman), ...
            abs(ft.SpatialResidualSpearman), ...
            NaN,NaN}; %#ok<AGROW>

        continue;
    end

    rawAbs = zeros(numel(cols),1);
    residAbs = zeros(numel(cols),1);

    for q = 1:numel(cols)

        ft = spatialFeatureTable( ...
            spatialFeatureTable.Feature==featureNames(cols(q)),:);

        rawAbs(q) = abs(ft.RawSpearman);
        residAbs(q) = abs(ft.SpatialResidualSpearman);

    end

    descriptorScore = ...
        cfg.descriptorWeightRaw .* rawAbs + ...
        cfg.descriptorWeightSpatialResidual .* residAbs;

    [~,bestLocal] = max(descriptorScore);

    primaryCol = cols(bestLocal);

    keepMask(primaryCol)=true;

    baseCV = spatial_cv_tree_metrics_v2( ...
        X(:,primaryCol), ...
        Y, ...
        foldId, ...
        cfg.nTreesDescriptor, ...
        cfg.minLeafSize, ...
        cfg.randomSeed+1000+g);

    bestSecondaryCol = NaN;
    bestSecondaryGain = 0;
    bestPairCorr = NaN;

    candidateLocals = setdiff(1:numel(cols),bestLocal);

    for c = candidateLocals

        candidateCol = cols(c);

        pairRho = corr( ...
            X(:,primaryCol), ...
            X(:,candidateCol), ...
            'Type','Spearman', ...
            'Rows','complete');

        if abs(pairRho) >= cfg.maxWithinDriverDescriptorCorr
            continue;
        end

        pairCV = spatial_cv_tree_metrics_v2( ...
            X(:,[primaryCol,candidateCol]), ...
            Y, ...
            foldId, ...
            cfg.nTreesDescriptor, ...
            cfg.minLeafSize, ...
            cfg.randomSeed+2000+g*10+c);

        relativeGain = ...
            (baseCV.meanRMSE-pairCV.meanRMSE) / ...
            max(baseCV.meanRMSE,eps);

        if relativeGain > bestSecondaryGain
            bestSecondaryGain = relativeGain;
            bestSecondaryCol = candidateCol;
            bestPairCorr = pairRho;
        end

    end

    if isfinite(bestSecondaryCol) && ...
            bestSecondaryGain >= cfg.secondDescriptorMinRelativeGain && ...
            cfg.maxDescriptorsPerDriver >= 2

        keepMask(bestSecondaryCol)=true;

    else

        bestSecondaryCol = NaN;
        bestSecondaryGain = 0;
        bestPairCorr = NaN;

    end

    for q = 1:numel(cols)

        col = cols(q);

        selected = keepMask(col);

        if col==primaryCol

            reason = 'Primary descriptor';

        elseif isfinite(bestSecondaryCol) && col==bestSecondaryCol

            reason = 'Secondary descriptor improves Spatial-CV RMSE';

        else

            reason = 'Removed within-driver redundancy';

        end

        rows(end+1,:) = { ...
            char(driver), ...
            char(featureNames(col)), ...
            selected, ...
            reason, ...
            rawAbs(q), ...
            residAbs(q), ...
            bestSecondaryGain, ...
            bestPairCorr}; %#ok<AGROW>

    end

end

T = cell2table( ...
    rows, ...
    'VariableNames', ...
    {'Driver','Feature','Selected','Reason', ...
     'AbsRawSpearman','AbsSpatialResidualSpearman', ...
     'BestSecondaryRelativeRMSEGain','PrimarySecondarySpearman'});

result = struct();
result.keepMask = keepMask;
result.table = T;

end
