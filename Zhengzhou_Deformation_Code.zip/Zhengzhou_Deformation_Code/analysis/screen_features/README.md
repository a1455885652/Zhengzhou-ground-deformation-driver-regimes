# 变量筛选

压缩同一驱动因素的描述量，计算排序、逐项删除与机制组消融结果。

| 项目 | 内容 |
|---|---|
| 输入 | LongTerm_Variable_Screening_Output/Variable_Screening_Results.mat（已附带）。 |
| 输出 | `project_root/LongTerm_Variable_Screening_V2_Output` |
| 设置 | config_longterm_variable_screening_v2.m |

在代码包根目录的 MATLAB 命令窗口运行：

```matlab
run_project('screen_features')
```

路径统一读取 `config/paths.json`。本目录仅在运行对应阶段时加入 MATLAB 路径；不要将其他实验的同名辅助函数一起加入。
