function result = diagnose_spatial_trend_features( ...
    X, Y, featureNames, driverNames, lon, lat, cfg)
% DIAGNOSE_SPATIAL_TREND_FEATURES
%
% 用二阶经纬度空间趋势面：
% 1, x, y, x^2, y^2, xy
%
% 分别拟合Y和每个feature。
% 再计算残差之间的Spearman，以减弱共同大尺度空间梯度造成的伪相关。
%
% 这里仅用于筛选诊断，并不修改最终XGBoost输入值。

Z = build_spatial_trend_design(lon,lat);

yFit = Z * (Z\Y);
yResidual = Y-yFit;

nP = size(X,2);

rawRho = nan(nP,1);
rawP = nan(nP,1);
residRho = nan(nP,1);
residP = nan(nP,1);
spatialR2 = nan(nP,1);

for j = 1:nP

    x = X(:,j);

    if std(x) <= 1e-12
        rawRho(j) = 0;
        rawP(j) = 1;
        residRho(j) = 0;
        residP(j) = 1;
        spatialR2(j) = 1;
        continue;
    end

    [rawRho(j),rawP(j)] = corr( ...
        x,Y,'Type','Spearman','Rows','complete');

    xFit = Z*(Z\x);
    xResidual = x-xFit;

    sst = sum((x-mean(x)).^2);
    sse = sum((x-xFit).^2);

    if sst > 0
        spatialR2(j) = max(0,min(1,1-sse/sst));
    else
        spatialR2(j) = 1;
    end

    if std(xResidual) <= 1e-12 || std(yResidual) <= 1e-12
        residRho(j) = 0;
        residP(j) = 1;
    else
        [residRho(j),residP(j)] = corr( ...
            xResidual, ...
            yResidual, ...
            'Type','Spearman', ...
            'Rows','complete');
    end

end

strongGradient = spatialR2 >= cfg.strongSpatialTrendR2;

T = table( ...
    featureNames(:), ...
    driverNames(:), ...
    rawRho, ...
    rawP, ...
    residRho, ...
    residP, ...
    spatialR2, ...
    strongGradient, ...
    'VariableNames', ...
    {'Feature','Driver','RawSpearman','RawPValue', ...
     'SpatialResidualSpearman','SpatialResidualPValue', ...
     'SpatialTrendR2','StrongSpatialGradient'});

result = struct();
result.featureTable = T;
result.yResidual = yResidual;

end
