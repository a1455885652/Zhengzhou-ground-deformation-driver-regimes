function write_v2_protocol( ...
    cfg,fullCV,subsetResult,statisticalDrivers,balancedDrivers,outputFile)
% WRITE_V2_PROTOCOL

fid=fopen(outputFile,'w');

fprintf(fid,'ZHENGZHOU LONG-TERM VARIABLE SCREENING V2\n');
fprintf(fid,'==========================================\n\n');

fprintf(fid,'Purpose:\n');
fprintf(fid,'Resolve descriptor redundancy, correlated-driver substitution,\n');
fprintf(fid,'and common spatial-gradient confounding observed in V1.\n\n');

fprintf(fid,'Stage 1: Spatial-trend diagnostics\n');
fprintf(fid,'  Fit second-order lon/lat trend surfaces to Y and every predictor.\n');
fprintf(fid,'  Calculate Spearman correlation between spatial residuals.\n');
fprintf(fid,'  This is a screening diagnostic only; original predictors are not altered.\n\n');

fprintf(fid,'Stage 2: Within-driver descriptor compression\n');
fprintf(fid,'  Primary descriptor score = %.2f raw Spearman + %.2f spatial-residual Spearman.\n', ...
    cfg.descriptorWeightRaw,cfg.descriptorWeightSpatialResidual);
fprintf(fid,'  A second descriptor is retained only when |rho| < %.2f and Spatial-CV RMSE improves >= %.2f%%.\n\n', ...
    cfg.maxWithinDriverDescriptorCorr, ...
    100*cfg.secondDescriptorMinRelativeGain);

fprintf(fid,'Stage 3: Leave-one-driver-out retraining\n');
fprintf(fid,'  Every physical driver is fully removed and the model is retrained.\n');
fprintf(fid,'  DeltaRMSE = RMSE_without_driver - RMSE_full.\n\n');

fprintf(fid,'Stage 4: Mechanism-group ablation\n');
fprintf(fid,'  Correlated physical variables are also evaluated as mechanism bundles.\n\n');

fprintf(fid,'V2 ranking weights:\n');
fprintf(fid,'  Raw Spearman                 %.2f\n',cfg.weightRawSpearman);
fprintf(fid,'  Spatial-residual Spearman    %.2f\n',cfg.weightSpatialResidualSpearman);
fprintf(fid,'  Drop-column DeltaRMSE        %.2f\n',cfg.weightDropColumnDeltaRMSE);
fprintf(fid,'  Drop-column stability        %.2f\n\n',cfg.weightDropColumnStability);

fprintf(fid,'Compressed full-model Spatial CV:\n');
fprintf(fid,'  Mean RMSE = %.8f\n',fullCV.meanRMSE);
fprintf(fid,'  Mean MAE  = %.8f\n',fullCV.meanMAE);
fprintf(fid,'  Mean R2   = %.8f\n\n',fullCV.meanR2);

fprintf(fid,'Ranked subset:\n');
fprintf(fid,'  Best-RMSE K = %d\n',subsetResult.bestK);
fprintf(fid,'  1-SE statistical K = %d\n\n',subsetResult.selectedK);

fprintf(fid,'Statistical 1-SE candidate drivers:\n');

for k=1:numel(statisticalDrivers)
    fprintf(fid,'  %02d %s\n',k,statisticalDrivers(k));
end

fprintf(fid,'\nMechanism-balanced candidate drivers:\n');

for k=1:numel(balancedDrivers)
    fprintf(fid,'  %02d %s\n',k,balancedDrivers(k));
end

fprintf(fid,'\nIMPORTANT:\n');
fprintf(fid,'Neither candidate set is automatically considered final.\n');
fprintf(fid,'Final inclusion must combine spatial-CV evidence, collinearity,\n');
fprintf(fid,'spatial-gradient diagnostics, mechanism-group ablation, and physical meaning.\n');

fclose(fid);

end
