function group = get_driver_mechanism_group(driver)
% GET_DRIVER_MECHANISM_GROUP
% 物理机制分组。
%
% 该分组只用于：
%   - 整组消融诊断
%   - 机制平衡候选集
%
% 不改变原始变量值。

driver=string(driver);

switch driver

    case {"Dewpoint","TotalPrecipitation","TotalEvaporation"}
        group="AtmosphericHydroclimate";

    case {"SkinReservoir","SoilWater_0_289cm", ...
          "SurfaceRunoff","SubsurfaceRunoff"}
        group="SurfaceSoilHydrology";

    case {"GWS","TWS"}
        group="WaterStorage";

    case {"NDVI"}
        group="Vegetation";

    case {"Population","NighttimeLight","BuiltSurface","RoadDensity"}
        group="AnthropogenicUrbanization";

    case {"DEM","Slope","Relief"}
        group="Terrain";

    case {"GLHYMPS_Permeability","GLHYMPS_Porosity","DepthToBedrock"}
        group="Hydrogeology";

    case {"BDOD","Clay","Silt","GUM","TotalLooseThickness"}
        group="SoilSediment";

    otherwise
        group="Other";

end

end
