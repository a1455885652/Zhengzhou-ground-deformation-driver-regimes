function plot_v2_subset_performance(T,selectedK,bestK,outputFile)
% PLOT_V2_SUBSET_PERFORMANCE

fig=figure('Visible','off','Position',[100 100 900 600]);

errorbar( ...
    T.NDrivers,T.MeanRMSE,T.SERMSE,'-o','LineWidth',1.2);

hold on;

xline(bestK,'--');
xline(selectedK,':');

xlabel('Number of ranked physical drivers');
ylabel('Spatial-CV RMSE');
title('V2 ranked subset performance');
grid on;

exportgraphics(fig,outputFile,'Resolution',300);

if ~zz_show_figures(), close(fig); end

end
