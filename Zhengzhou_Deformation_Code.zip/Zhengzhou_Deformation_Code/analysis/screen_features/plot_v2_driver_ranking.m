function plot_v2_driver_ranking( ...
    ranking,statisticalDrivers,balancedDrivers,outputFile)
% PLOT_V2_DRIVER_RANKING

fig=figure('Visible','off','Position',[100 100 1100 760]);

barh(ranking.CompositeScore);

set(gca, ...
    'YDir','reverse', ...
    'YTick',1:height(ranking), ...
    'YTickLabel',cellstr(ranking.Driver));

xlabel('V2 composite screening score');
ylabel('Physical driver');
title('Long-term deformation driver screening V2');
grid on;
hold on;

for k=1:height(ranking)

    if ismember(ranking.Driver(k),statisticalDrivers)
        label='  1-SE';
    elseif ismember(ranking.Driver(k),balancedDrivers)
        label='  mechanism';
    else
        label='';
    end

    if ~isempty(label)
        text(ranking.CompositeScore(k),k,label, ...
            'VerticalAlignment','middle');
    end
end

exportgraphics(fig,outputFile,'Resolution',300);

if ~zz_show_figures(), close(fig); end

end
