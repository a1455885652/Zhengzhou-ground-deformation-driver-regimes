function balancedDrivers=build_mechanism_balanced_candidate_set( ...
    statisticalDrivers,ranking,mechanismTable,cfg)
% BUILD_MECHANISM_BALANCED_CANDIDATE_SET
%
% 从统计1-SE集合出发。
%
% 如果某个机制组：
%   MeanDeltaRMSE > 0
%   PositiveFoldFraction >= threshold
%
% 说明整组信息对跨空间预测有稳定正贡献。
% 若统计1-SE集合里一个该机制组变量都没有，
% 则补入该组中V2排名最高的driver。
%
% 该集合仍然只是“candidate”，需要最终人工复核。

balancedDrivers=string(statisticalDrivers(:));

for m=1:height(mechanismTable)

    row=mechanismTable(m,:);

    mechanism=string(row.MechanismGroup);

    supported = ...
        row.MeanDeltaRMSE>0 && ...
        row.PositiveFoldFraction>=cfg.mechanismMinPositiveFoldFraction;

    if ~supported
        continue;
    end

    existing=ranking(ismember(ranking.Driver,balancedDrivers),:);

    if any(existing.MechanismGroup==mechanism)
        continue;
    end

    candidates=ranking(ranking.MechanismGroup==mechanism,:);

    if isempty(candidates)
        continue;
    end

    balancedDrivers(end+1,1)=candidates.Driver(1); %#ok<AGROW>

end

% 按总排名排序
[~,loc]=ismember(balancedDrivers,ranking.Driver);
[~,order]=sort(loc);

balancedDrivers=balancedDrivers(order);

balancedDrivers=unique(balancedDrivers,'stable');

end
