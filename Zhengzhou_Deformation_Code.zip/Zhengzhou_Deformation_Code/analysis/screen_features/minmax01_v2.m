function z=minmax01_v2(x)
% MINMAX01_V2

x=double(x(:));

xmin=min(x,[],'omitnan');
xmax=max(x,[],'omitnan');

if ~isfinite(xmin)||~isfinite(xmax)||abs(xmax-xmin)<eps
    z=zeros(size(x));
else
    z=(x-xmin)/(xmax-xmin);
end

z(~isfinite(z))=0;

end
