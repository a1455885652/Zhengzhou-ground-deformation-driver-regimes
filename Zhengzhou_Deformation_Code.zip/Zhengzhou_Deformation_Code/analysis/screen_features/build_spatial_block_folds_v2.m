function foldId=build_spatial_block_folds_v2( ...
    lon,lat,blockSizeKm,nFolds,randomSeed)
% BUILD_SPATIAL_BLOCK_FOLDS_V2
% V1 foldId缺失时的兜底函数。

rng(randomSeed);

lat0=mean(lat);
lon0=mean(lon);

xKm=(lon-lon0).*(111.320*cosd(lat0));
yKm=(lat-lat0).*110.574;

bx=floor((xKm-min(xKm))/blockSizeKm)+1;
by=floor((yKm-min(yKm))/blockSizeKm)+1;

pairs=[bx(:),by(:)];

[~,~,blockIndex]=unique(pairs,'rows','stable');

nBlocks=max(blockIndex);

centroids=zeros(nBlocks,2);

for b=1:nBlocks
    use=blockIndex==b;
    centroids(b,1)=mean(xKm(use));
    centroids(b,2)=mean(yKm(use));
end

if nBlocks<nFolds
    error('空间block数量少于CV折数。');
end

blockFold=kmeans( ...
    centroids,nFolds, ...
    'Replicates',20, ...
    'MaxIter',1000);

foldId=blockFold(blockIndex);

end
