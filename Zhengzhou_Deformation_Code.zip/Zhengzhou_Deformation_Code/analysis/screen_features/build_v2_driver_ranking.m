function ranking = build_v2_driver_ranking( ...
    compressedDriverNames, spatialFeatureTable, dropTable, cfg)
% BUILD_V2_DRIVER_RANKING

drivers=unique(compressedDriverNames,'stable');
nD=numel(drivers);

raw=zeros(nD,1);
resid=zeros(nD,1);
delta=zeros(nD,1);
stability=zeros(nD,1);
mechanism=strings(nD,1);
maxSpatialTrendR2=zeros(nD,1);

for d=1:nD

    driver=drivers(d);

    ft=spatialFeatureTable( ...
        spatialFeatureTable.Driver==driver,:);

    raw(d)=max(abs(ft.RawSpearman));
    resid(d)=max(abs(ft.SpatialResidualSpearman));
    maxSpatialTrendR2(d)=max(ft.SpatialTrendR2);

    dt=dropTable(dropTable.Driver==driver,:);

    if isempty(dt)
        delta(d)=0;
        stability(d)=0;
    else
        delta(d)=dt.MeanDeltaRMSE;
        stability(d)=dt.PositiveFoldFraction;
    end

    mechanism(d)=get_driver_mechanism_group(driver);

end

% 只有正的drop-column贡献用于正向重要性评分
deltaPositive=max(delta,0);

rawNorm=minmax01_v2(raw);
residNorm=minmax01_v2(resid);
deltaNorm=minmax01_v2(deltaPositive);
stabilityNorm=minmax01_v2(stability);

score= ...
    cfg.weightRawSpearman*rawNorm + ...
    cfg.weightSpatialResidualSpearman*residNorm + ...
    cfg.weightDropColumnDeltaRMSE*deltaNorm + ...
    cfg.weightDropColumnStability*stabilityNorm;

[~,order]=sort(score,'descend');

drivers=drivers(order);
mechanism=mechanism(order);
raw=raw(order);
resid=resid(order);
delta=delta(order);
stability=stability(order);
maxSpatialTrendR2=maxSpatialTrendR2(order);
score=score(order);

Rank=(1:nD)';

ranking=table( ...
    Rank,drivers,mechanism,raw,resid,maxSpatialTrendR2, ...
    delta,stability,score, ...
    'VariableNames', ...
    {'Rank','Driver','MechanismGroup','AbsRawSpearman', ...
     'AbsSpatialResidualSpearman','MaxDescriptorSpatialTrendR2', ...
     'MeanDropColumnDeltaRMSE','PositiveFoldFraction','CompositeScore'});

end
