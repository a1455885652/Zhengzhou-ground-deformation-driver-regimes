function result = spatial_cv_tree_metrics_v2( ...
    X, Y, foldId, nTrees, minLeafSize, randomSeed)
% SPATIAL_CV_TREE_METRICS_V2

folds = unique(foldId(:))';
nF = numel(folds);

RMSE = nan(nF,1);
MAE = nan(nF,1);
R2 = nan(nF,1);
NTrain = nan(nF,1);
NTest = nan(nF,1);

for i = 1:nF

    f = folds(i);

    train = foldId~=f;
    test = foldId==f;

    NTrain(i)=nnz(train);
    NTest(i)=nnz(test);

    rng(randomSeed + f);

    nPredictors = size(X,2);

    if nPredictors==1
        numPredictorsToSample = 1;
    else
        numPredictorsToSample = ...
            max(1,round(sqrt(nPredictors)));
    end

    model = TreeBagger( ...
        nTrees, ...
        X(train,:), ...
        Y(train), ...
        'Method','regression', ...
        'MinLeafSize',minLeafSize, ...
        'NumPredictorsToSample',numPredictorsToSample, ...
        'OOBPrediction','off');

    pred = predict(model,X(test,:));

    M = regression_metrics_v2(Y(test),pred);

    RMSE(i)=M.RMSE;
    MAE(i)=M.MAE;
    R2(i)=M.R2;

end

Fold = folds(:);

foldTable = table( ...
    Fold,NTrain,NTest,RMSE,MAE,R2);

result = struct();
result.foldTable = foldTable;
result.meanRMSE = mean(RMSE,'omitnan');
result.stdRMSE = std(RMSE,'omitnan');
result.seRMSE = result.stdRMSE/sqrt(nF);
result.meanMAE = mean(MAE,'omitnan');
result.meanR2 = mean(R2,'omitnan');

end
