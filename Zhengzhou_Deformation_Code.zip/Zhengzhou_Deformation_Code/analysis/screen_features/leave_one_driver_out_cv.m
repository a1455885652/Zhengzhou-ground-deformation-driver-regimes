function result = leave_one_driver_out_cv( ...
    X,Y,driverNames,foldId,fullCV,cfg)
% LEAVE_ONE_DRIVER_OUT_CV
%
% 与Permutation不同：
% 每次彻底删除一个物理driver的全部descriptor，然后重新训练模型。
%
% DeltaRMSE = RMSE_without_driver - RMSE_full
%
% >0：删除该driver后性能下降，说明driver提供独立贡献。
% <0：删除后反而更好，说明driver可能冗余/不稳定。

drivers=unique(driverNames,'stable');
nD=numel(drivers);
folds=unique(foldId(:))';
nF=numel(folds);

baseRMSE = fullCV.foldTable.RMSE;

delta = nan(nD,nF);
withoutRMSE = nan(nD,nF);

for d=1:nD

    fprintf('  [%d/%d] drop %s\n',d,nD,drivers(d));

    keep = driverNames~=drivers(d);

    if nnz(keep)==0
        continue;
    end

    cv = spatial_cv_tree_metrics_v2( ...
        X(:,keep), ...
        Y, ...
        foldId, ...
        cfg.nTreesAblation, ...
        cfg.minLeafSize, ...
        cfg.randomSeed+5000+d);

    withoutRMSE(d,:) = cv.foldTable.RMSE';

    delta(d,:) = ...
        withoutRMSE(d,:) - baseRMSE';

end

meanDelta = mean(delta,2,'omitnan');
medianDelta = median(delta,2,'omitnan');
stdDelta = std(delta,0,2,'omitnan');

positiveFraction = ...
    mean(delta>0,2,'omitnan');

meanWithoutRMSE = ...
    mean(withoutRMSE,2,'omitnan');

T = table( ...
    drivers, ...
    meanDelta, ...
    medianDelta, ...
    stdDelta, ...
    positiveFraction, ...
    meanWithoutRMSE, ...
    'VariableNames', ...
    {'Driver','MeanDeltaRMSE','MedianDeltaRMSE','StdDeltaRMSE', ...
     'PositiveFoldFraction','MeanRMSEWithoutDriver'});

T = sortrows(T,'MeanDeltaRMSE','descend');

result=struct();
result.table=T;
result.deltaRMSEByFold=delta;
result.withoutRMSEByFold=withoutRMSE;

end
