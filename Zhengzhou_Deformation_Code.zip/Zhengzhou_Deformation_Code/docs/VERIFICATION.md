# Verification for the 2026-09-19 code release

## Completed checks

| Check | Result |
|---|---|
| Dependency installation and `pip check` | Passed in a clean Linux Python 3.12 environment with the release pins. |
| Imports and pinned-version comparison | All distributions in `requirements.txt` passed. |
| Python parsing and undefined-name checks | Passed. |
| MATLAB static parsing | 439 `.m` files parsed without warnings or errors using MISS_HIT 0.9.44. |
| Original Python analysis function bodies | 120 functions/classes across 11 analysis modules were AST-identical to their supplied versions. |
| Saved XGBoost model | Loaded successfully; recalculated fit metrics agreed with the archived fit table within the check tolerance. |
| SHAP compatibility and additivity | TreeSHAP contributions plus the expected value reproduced saved-model predictions. |
| ALE input/model/assignment check | Passed on the supplied input table, model and mechanism assignment. |
| ALE real-data smoke check | Passed the supplied backend's ALE, bootstrap, interaction and surface checks with its smoke-test budget. |
| Python manuscript figures | Figs. 7, 8, 9, 11, 13, 14 and S7 generated from the supplied results; exported PNG files were opened and visually inspected. |
| Bundled data integrity | Original numerical tables/model retained; path-bearing JSON changes tracked in `data_files.csv`. |

Figure checks included current figure names, preview controls, portable font fallback and legible panel spacing. Plot outputs from the verification run are not included in the source archive; regenerate them with the registered entries.

## What was not executed

MATLAB and GMT were not installed in the verification environment. Static parsing does not establish numerical agreement of MATLAB reruns or validate map rendering. Windows batch/PowerShell files and Python 3.10 on Windows were not executed here. The original satellite/predictor rasters, complete monthly caches and original GNSS series were unavailable, so the full experiment sequence was not rerun from source observations.

The figure and model checks reuse the supplied data and saved model. They do not constitute a new training run or a new scientific validation experiment. The missing or unconfirmed original figure sources are listed in `FIGURES.md`.

## Repeatable checks

```bat
.venv\Scripts\python.exe tools\check_environment.py
.venv\Scripts\python.exe tools\verify_derived_inputs.py
.venv\Scripts\python.exe run.py analysis ale_inputcheck --no-preview
.venv\Scripts\python.exe run.py analysis ale_realdatasmoke --no-preview
.venv\Scripts\python.exe run.py figure Fig14 --no-preview
```

Environment and saved-model reports are written under `outputs/`. The three ALE check entries also write under `outputs/checks/`, leaving the supplied formal result tables intact. Full scientific stages use the output locations documented in `WORKFLOW.md`.
