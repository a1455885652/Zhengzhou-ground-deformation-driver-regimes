# Figure-to-code index

Numbers in this table follow the revised manuscript. Some source functions and CSV files retain older internal numbers; the selected entry and exported figure name below are authoritative.

| Figure | Entry | Selected code | Input/result group | Status |
|---|---|---|---|---|
| Fig. 1 | — | External published illustration | Source publication | No project plotting source; original image is not bundled. |
| Fig. 2 | `Fig02` | `plots/Fig02_S1/zz_plot_fig02.m` | `LongTerm_Variable_Screening_V2_Output` | Selected MATLAB ranking plot. |
| Fig. 3 | — | `analysis/gnss_validation/`; candidate map in `legacy/Fig03_GMT/` | Original GNSS and displacement rasters | GNSS analysis and candidate map found; final composite not confirmed. |
| Fig. 4 | — | `legacy/Fig04_GMT_8epochs/` | Cumulative-displacement XYZ files | Candidate produces eight epochs; manuscript has nine. It is not labelled as the final layout. |
| Fig. 5 | — | Not recovered | Original ellipse/centroid-map results needed | Source unavailable in the supplied archives. |
| Fig. 6 | `Fig06` | `plots/Fig06/zz_plot_fig06.m` | `Test_Predictions.csv` | Exports ordered-prediction and density-scatter panels separately. |
| Fig. 7 | `Fig07` | `plots/Fig07_08/plot_shap_reference_style.py` | Model `Python_Output/SHAP_*.csv` | Generated with Fig. 8; current output `Fig07_SHAP_Summary.*`. |
| Fig. 8 | `Fig08` | Same as Fig. 7 | Regional SHAP tables | Current output `Fig08_Regional_SHAP.*`. |
| Fig. 9 | `Fig09` | `plots/Fig09/plot_driver_groups.py` | Model grouped SHAP importance tables | Current output `Fig09_Driver_Category_Contribution.*`. |
| Fig. 10a | `Fig10a` | `plots/Fig10a/plot_mechanism_fingerprints.m` | `K4_Mechanism_Profile_Long.csv` | Reads `MeanComposition` directly; no manual rounded matrix. |
| Fig. 10b–d | — | `legacy/Fig10bcd_GMT/` | K=4 assignment and posterior rasters | Candidate GMT maps retained; exact final map variants not confirmed. |
| Fig. 11 | `Fig11` | `plots/Fig11/plot_mechanism_composition.py` | `Response_Mechanism_Crosstab_K4.csv`, `ManualZone_SignConsistent_Overlap_K4.csv` | Current output `Fig11_Mechanism_Composition.*`. |
| Fig. 12 | `Fig12` | `plots/Fig12_S2_S5/plot_signed_shap_heatmap_matlab.m` | `Discussion_Supplement/Table_S4_MeanSignedSHAP_MechanismFingerprint.csv` | Selected source; exported as `Fig12_Signed_SHAP.*`. |
| Fig. 13 | `Fig13` | `plots/Fig13/plot_hydrologic_lags.py` | M124 and M3 summary CSVs | Final revised Python implementation. Older MATLAB layout is retained locally. |
| Fig. 14 | `Fig14` | `plots/Fig14/plot_ale_breakpoints.py` | ALE curves and `ALE_Threshold_Breakpoints.csv` | Final revised plot; breakpoint and pointwise ALE intervals shown separately. |
| Fig. 15 | `Fig15` | `plots/Fig15/plot_shap_interactions.m` | `SHAP_Interaction_Strength.csv` | Current output `Fig15_SHAP_Interactions.*`. |
| Fig. S1 | `S1` | `plots/Fig02_S1/zz_plot_s1.m` | Screening subset diagnostics | Selected MATLAB source. |
| Fig. S2 | `S2` | `plots/Fig12_S2_S5/plot_mechanism_vs_state_matlab.m` | Association and response-percentage tables | Exported as `FigS2_Mechanism_Response.*`. |
| Fig. S3 | `S3` | `plots/Fig12_S2_S5/plot_boundary_uncertainty_matlab.m` | Boundary uncertainty table | Exported as `FigS3_Boundary_Uncertainty.*`. |
| Fig. S4 | `S4` | `plots/Fig12_S2_S5/plot_zone_diversity_matlab.m` | Regional mechanism diversity table | Exported as `FigS4_Regional_Diversity.*`. |
| Fig. S5 | `S5` | `plots/Fig12_S2_S5/plot_K4_K5_comparison_publication.m` | K=4/K=5 selection, profiles and assignments | Exported as `FigS5_K4_K5_Comparison.*`. |
| Fig. S6 | `S6` | `plots/S6/plot_FigS6_ALE2D_Interactions.m` | Six saved ALE2D surfaces | Numeric coordinates retained; no relabelling of data values as low/medium/high. |
| Fig. S7 | `S7` | `plots/S7/plot_gws_comparison.py` | All/M1–M4 GWS curves and `Threshold_Mechanism_Contrasts.csv` | Curves plus M1−M2, M1−M3 and M2−M3 breakpoint differences. |

Fig. 12 and Figs. S2–S4 are generated together by `run_mechanism_figures_matlab.m`. Fig. S5 is a separate entry in the same directory. The selected scripts identify the result source; for the older MATLAB plots, exact font and manual assembly differences from the manuscript have not been validated here.

Fig. 6 uses ordered cumulative percentage on the left. Its exported panels are `Fig06a_Ordered_Predictions.*` and `Fig06b_Observed_Predicted.*`. The manuscript's composite arrangement is not silently recreated as a different statistical figure.

Fig. 13 uses the definition implemented in the final revision: the support fraction is calculated from the relevant evaluated blocks, with the phase-quality denominator handled explicitly by the script. It does not infer a denominator from the height or length of plotted marks.

Fig. 14's coloured bands are pointwise 95% ALE intervals; the vertical tinted intervals are fixed-model 95% breakpoint intervals. Fig. S7b distinguishes fixed-model 95% intervals from refit 90% intervals. Unit labels come from the revised table and shared metadata; changing a label does not convert the values.

The GMT map candidates require external rasters/vector data. `legacy/Fig03_GNSS_v4` contains an earlier display-calibration prototype and is not the independent GNSS validation entry. See its local README before use.
