# Workflow

## Regenerate figures from supplied results

The default configuration uses the bundled `data/` directory. Install the environment once and run a figure entry from `run.py` or MATLAB's `run_figure`. No model fitting is needed to redraw the selected figures. Figure inputs and output names are listed in `FIGURES.md`.

## Recompute analyses from prepared tables

The following commands use the prepared model tables and saved SHAP compositions:

```bat
.venv\Scripts\python.exe run.py analysis fit_model_tables
.venv\Scripts\python.exe run.py analysis prepare_mechanisms_tables
.venv\Scripts\python.exe run.py analysis compare_mechanisms_tables
.venv\Scripts\python.exe run.py analysis mechanism_statistics
.venv\Scripts\python.exe run.py analysis ale_inputcheck
.venv\Scripts\python.exe run.py analysis ale_threshold
.venv\Scripts\python.exe run.py analysis ale_interaction
```

`fit_model_tables` and `prepare_mechanisms_tables` run different stored workflows. The latter generates the cross-fit SHAP composition used by the mechanism comparison; it is not replaced by the former's global SHAP table.

These commands write to the original output names under `project_root`. Work on a copy of `data/` when retaining the supplied outputs as a comparison baseline. The dispatcher materializes path-resolved experiment configurations under `outputs/configs/` and does not modify their numeric settings.

`ale_realdatasmoke` checks the numerical path on supplied real inputs with a limited bootstrap budget. `ale_selftest` uses synthetic functions to check numerical routines. Neither entry constitutes a replacement for the complete threshold or interaction runs.

## Recompute from original raster inputs

Populate the predictor folders referenced by each module's `config_*.m` file under `project_root`. Retain the file naming patterns and source units expected by those readers. `external_paths` specifies additional raster/vector inputs that live outside this tree.

In MATLAB, use this dependency order:

```matlab
run_project('prepare_features')
run_project('screen_features')
run_project('fit_model')
run_project('prepare_mechanisms')
run_project('compare_mechanisms')
run_project('mechanism_statistics')
run_project('prepare_monthly_deformation')
run_project('prepare_dynamic_cache')
run_project('prepare_rate_cache')
run_project('temporal_m124')
run_project('temporal_m3')
run_project('ale_interactions')
```

The temporal branch requires `K4_WaveletPhaseLag_Cache/K4_Wavelet_DynamicCube.mat` and `K4_WaveletPhaseLag_Cache/K4_CenteredW6_RateCube.mat`. These full caches were not supplied and are not included. Generate them from the corresponding monthly inputs, or use the original caches if already available.

GNSS validation is a separate branch:

```matlab
run_project('gnss_validation')
```

It reads original station records under `project_root/GNSS` and the explicit `external_paths.gnss_insar_raster` directory. Sign conversion, datum matching, interpolation and quality-control settings remain visible in the module configuration. The older GNSS display prototype under `legacy/` is not used by this entry.

The historical hierarchical wavelet routines remain in `analysis/prepare_temporal` because that source project also supplies the cache builders. They are documented in its README and are not substitutes for the M1/M2/M4 and M3 analysis entries.

## Configuration rules

- `config/paths.json`: locations, selected Python interpreter and preview setting.
- `config/experiments/*.json`: archived Python experiment settings with path tokens.
- Module-local `config_*.m`: original MATLAB scientific settings and input naming rules.
- `config/feature_units.json`: unit labels used by the final ALE plots. It does not rescale numeric data.
- `config/tasks.json`: public task names, selected scripts and aliases.

Random seeds, bootstrap counts, selected hypotheses and model settings remain explicit. A different platform, XGBoost device or numerical library can affect rerun results; use the saved model and supplied curves when the purpose is to reproduce the published figure values.
