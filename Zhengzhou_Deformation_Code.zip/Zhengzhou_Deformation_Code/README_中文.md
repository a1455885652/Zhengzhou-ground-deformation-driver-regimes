# 郑州地表形变研究代码

本代码包按“实验模块—论文图号”整理。先看本文件；查某一张图用什么代码，直接看 [图号对照表](docs/FIGURES.md)。每个实验和绘图目录另有 README，说明用途、输入和输出。

## 先运行哪一个文件

1. 将整个压缩包解压到固定目录。
2. 首次使用，运行 `setup_environment.bat`，创建 Python 环境并安装 `requirements.txt` 中的依赖。
3. 在该目录打开命令行，运行以下命令查看入口和绘图：

```bat
.venv\Scripts\python.exe run.py list
.venv\Scripts\python.exe run.py figure Fig14
.venv\Scripts\python.exe run.py figure S7
```

MATLAB 中将当前文件夹切换到代码包根目录，然后运行：

```matlab
run_project('list')
run_figure('Fig06')
run_figure('Fig10a')
```

图 7、8 共用一个入口 `Fig07_08`；图 12 与 S2—S4 共用 `Fig12_S2_S4`。输入单独的图号也能找到相应入口。部分 MATLAB 图输出分图，按对照表进行拼版。

## 使用你现在的 G 盘工程

默认配置使用代码包自带的 `data`，可先重画已有结果。要读取你现在的完整工程，执行一次：

```bat
.venv\Scripts\python.exe tools\configure.py --project-root "G:\ZHENGZHOU\zhengzhou\1km"
```

如果继续使用原来已经安装好依赖的 Python，可以同时指定：

```bat
py -3.10 tools\configure.py --project-root "G:\ZHENGZHOU\zhengzhou\1km" --python-exe "C:\Users\admin\AppData\Local\Programs\Python\Python310\python.exe"
```

这样只需维护 `config/paths.json`，不必逐个修改脚本。`project_root` 表示原始工程及结果所在目录；`figure_output` 表示论文图输出目录。两者可以不同。

外部影像、行政区边界等原来位于其他磁盘的文件，通过 `external_paths` 单独指定。GNSS 对照所用影像目录为 `gnss_insar_raster`；月末累计形变目录为 `monthly_deformation`。请让这两个配置指向对应的真实输入文件夹。

## Python 环境与预览窗口

完整环境说明在 [environment.txt](environment.txt)，可安装的依赖清单在 [requirements.txt](requirements.txt)。

所有 MATLAB 启动器使用同一个 Python。运行实验、画图、检查环境均不会自动安装包。检查失败时，会保留具体报错，不再一律提示“缺少依赖”。需要检查现有环境时执行：

```bat
.venv\Scripts\python.exe tools\check_environment.py
```

安装包属于某一个 Python 环境。移动项目文件夹，并不会自动把另一位置的环境迁移过来；虚拟环境本身也不应直接搬动。固定代码目录后创建一次 `.venv`，或在配置中指定原有 Python，可避免每次误用不同解释器。

`preview` 默认是 `true`，绘图后窗口保留，手动关闭后结束 Python 绘图程序。只导出文件时加 `--no-preview`。MATLAB 也读取同一预览设置。MATLAB 的纯命令行批处理模式退出后无法保留窗口，需要预览时在桌面版 MATLAB 内运行。

## 每组代码的作用

| 目录 | 作用 |
|---|---|
| `analysis/prepare_features` | 构建长期特征描述量，生成初始筛选工作空间。 |
| `analysis/screen_features` | 描述量压缩、驱动因素排序及消融分析。 |
| `analysis/fit_model` | XGBoost 模型训练、预测与 SHAP 计算。 |
| `analysis/prepare_mechanisms` | 生成交叉拟合 SHAP 组成与初始机制分区。 |
| `analysis/compare_mechanisms` | 比较 K=4、K=5 分区，输出分区归属和机制特征。 |
| `analysis/prepare_temporal` | 准备月序列、动态缓存和中心滑动形变速率。 |
| `analysis/temporal_m124` | M1、M2、M4 水文关系的时间分析。 |
| `analysis/temporal_m3` | M3 两项预设径流关系的时间分析。 |
| `analysis/ale_interactions` | ALE 曲线、转折位置与区间，以及变量交互作用。 |
| `analysis/mechanism_statistics` | 机制与形变状态关联、边界不确定性和典型区多样性。 |
| `analysis/gnss_validation` | GNSS 与 InSAR 时间匹配和对照。 |
| `plots` | 按现稿图号整理的绘图代码。 |
| `preprocessing/raster_tools` | 原有栅格处理及经纬度文本导出工具。 |
| `examples/deformation_scenarios` | 人工构造形变情景的示例，不作为观测资料。 |
| `legacy` | 找到的历史绘图候选版本，保留用途说明。 |

不要使用 `addpath(genpath(...))` 将所有 MATLAB 子目录一起加入路径。不同实验有同名辅助函数，统一入口会为当前任务加载正确目录。

## 附带数据与可复现范围

`data` 中附带现有结果表、筛选工作空间及保存的模型，便于直接重画论文图和检查分析输入。从原始影像完整重跑，还需要原始预测因子栅格、GNSS 观测和月序列输入；这些文件未随当前结果包提供。

完整分析会按原工程的文件名写回 `project_root`。若需保留附带的结果作对照，先复制 `data` 到另一个工作目录，再把 `project_root` 指向该副本。

最终图 3 的整幅组合图、图 4 的完整最终版尚未确认；图 5 的原始绘图代码未找到。图 1 为外部文献图片。已有候选脚本、缺失部分和当前图号之间的对应关系，均写在 `docs/FIGURES.md`，未用猜测的代码替代。

本次已进行 Python 环境、语法、实际数据输入与绘图检查；MATLAB 进行了静态解析检查。当前检查环境没有 MATLAB、Windows GMT 或完整原始影像，因此不将这些部分写成“已完整重跑”。具体记录见 `docs/VERIFICATION.md`。
