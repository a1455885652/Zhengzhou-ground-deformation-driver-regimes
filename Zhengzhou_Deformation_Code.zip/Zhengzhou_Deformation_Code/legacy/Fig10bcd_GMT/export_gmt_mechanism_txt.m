function export_gmt_mechanism_txt(cfg)
%EXPORT_GMT_MECHANISM_TXT Export GMT6 XYZ inputs from final K=4 assignment.
%
% Outputs three requested panel datasets:
%   mechanism_type.txt        lon lat mechanism(1..4)
%   assignment_confidence.txt lon lat maximum posterior probability
%   assignment_uncertainty.txt lon lat normalized entropy
%
% Additional probability XYZ files are intentionally exported because the GMT
% mechanism map is smoothed from P(M1)...P(M4), then classified by the maximum
% probability. This avoids interpolating categorical labels directly.

if ~isfile(cfg.k4AssignmentCsv)
    error('K4 assignment CSV does not exist:\n%s', cfg.k4AssignmentCsv);
end

if ~exist(cfg.outputDir, 'dir')
    mkdir(cfg.outputDir);
end

T = readtable(cfg.k4AssignmentCsv, 'VariableNamingRule', 'preserve');

required = {'Longitude','Latitude','Target','MechanismCluster', ...
    'MaxPosterior','NormalizedEntropy','P_M1','P_M2','P_M3','P_M4'};
for k = 1:numel(required)
    if ~ismember(required{k}, T.Properties.VariableNames)
        error('Required column is missing from K4_Assignment.csv: %s', required{k});
    end
end

lon = double(T.Longitude);
lat = double(T.Latitude);
target = double(T.Target);
mech = double(T.MechanismCluster);
conf = double(T.MaxPosterior);
ent = double(T.NormalizedEntropy);
p1 = double(T.P_M1);
p2 = double(T.P_M2);
p3 = double(T.P_M3);
p4 = double(T.P_M4);

% Only final model-support samples with a valid observed deformation target are
% exported. Therefore locations absent from K4_Assignment remain unclassified.
valid = isfinite(lon) & isfinite(lat) & isfinite(target) & ...
        isfinite(mech) & mech >= 1 & mech <= 4 & ...
        isfinite(conf) & isfinite(ent) & ...
        isfinite(p1) & isfinite(p2) & isfinite(p3) & isfinite(p4);

lon = lon(valid);
lat = lat(valid);
mech = mech(valid);
conf = conf(valid);
ent = ent(valid);
p1 = p1(valid);
p2 = p2(valid);
p3 = p3(valid);
p4 = p4(valid);

% Sort by latitude and longitude only for clean, deterministic text files.
[~, order] = sortrows([lat, lon], [1 2]);
lon = lon(order); lat = lat(order);
mech = mech(order); conf = conf(order); ent = ent(order);
p1 = p1(order); p2 = p2(order); p3 = p3(order); p4 = p4(order);

write_xyz_file(fullfile(cfg.outputDir,'mechanism_type.txt'), lon, lat, mech);
write_xyz_file(fullfile(cfg.outputDir,'assignment_confidence.txt'), lon, lat, conf);
write_xyz_file(fullfile(cfg.outputDir,'assignment_uncertainty.txt'), lon, lat, ent);
write_xyz_file(fullfile(cfg.outputDir,'prob_M1.txt'), lon, lat, p1);
write_xyz_file(fullfile(cfg.outputDir,'prob_M2.txt'), lon, lat, p2);
write_xyz_file(fullfile(cfg.outputDir,'prob_M3.txt'), lon, lat, p3);
write_xyz_file(fullfile(cfg.outputDir,'prob_M4.txt'), lon, lat, p4);
write_xyz_file(fullfile(cfg.outputDir,'model_support.txt'), lon, lat, ones(size(lon)));

% Export the five fixed zones as GMT multi-segment line files.
write_zone_rectangles(fullfile(cfg.outputDir,'zones_sub.txt'), cfg.subZones);
write_zone_rectangles(fullfile(cfg.outputDir,'zones_upl.txt'), cfg.uplZones);
write_zone_labels(fullfile(cfg.outputDir,'zone_labels.txt'), cfg.subZones, cfg.uplZones);

% Original 1-km node spacing estimated from the actual assignment coordinates.
[dx, dy] = estimate_grid_spacing(lon, lat);
rgrid = [min(lon), max(lon), min(lat), max(lat)];

% Export a BAT include file so the GMT script does not hard-code grid alignment.
fid = fopen(fullfile(cfg.outputDir,'gmt_data_config.bat'), 'w');
if fid < 0
    error('Cannot create gmt_data_config.bat');
end
cleanupObj = onCleanup(@() fclose(fid));
fprintf(fid, '@echo off\r\n');
fprintf(fid, 'set RGRID=%.8f/%.8f/%.8f/%.8f\r\n', rgrid(1), rgrid(2), rgrid(3), rgrid(4));
fprintf(fid, 'set IORIG=%.8f/%.8f\r\n', dx, dy);
fprintf(fid, 'set RMAP=%.8f/%.8f/%.8f/%.8f\r\n', cfg.mapRegion(1), cfg.mapRegion(2), cfg.mapRegion(3), cfg.mapRegion(4));
fprintf(fid, 'set NPOINTS=%d\r\n', numel(lon));
clear cleanupObj;

fprintf('Exported %d valid K=4 mechanism samples.\n', numel(lon));
fprintf('Original grid spacing: dLon = %.8f deg, dLat = %.8f deg\n', dx, dy);
fprintf('Data grid region: %.8f/%.8f/%.8f/%.8f\n', rgrid);
fprintf('Display region: %.8f/%.8f/%.8f/%.8f\n', cfg.mapRegion);
end
