# Fig10bcd_GMT

Recovered mechanism-map candidates and MATLAB raster exporters. Several alternatives use different posterior-map presentations. The exact final b–d variants are not confirmed. The scripts use the shared path configuration; inspect the input layer names before running a selected candidate.

These files are not invoked by the final-figure registry.

Available scripts:

- `RUN_EXPORT_GMT_MECHANISM_TXT.m`
- `config_gmt_mechanism_export.m`
- `estimate_grid_spacing.m`
- `export_gmt_mechanism_txt.m`
- `gmt_draw_mechanism_3panel.bat`
- `write_xyz_file.m`
- `write_zone_labels.m`
- `write_zone_rectangles.m`
