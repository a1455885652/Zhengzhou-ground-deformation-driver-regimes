function write_zone_rectangles(filePath, zones)
%WRITE_ZONE_RECTANGLES Write GMT multi-segment rectangles.
% zones columns: west east south north

fid = fopen(filePath, 'w');
if fid < 0
    error('Cannot create file: %s', filePath);
end
cleanupObj = onCleanup(@() fclose(fid));

for i = 1:size(zones,1)
    w = zones(i,1); e = zones(i,2);
    s = zones(i,3); n = zones(i,4);
    fprintf(fid, '>\n');
    fprintf(fid, '%.8f %.8f\n', w, s);
    fprintf(fid, '%.8f %.8f\n', e, s);
    fprintf(fid, '%.8f %.8f\n', e, n);
    fprintf(fid, '%.8f %.8f\n', w, n);
    fprintf(fid, '%.8f %.8f\n', w, s);
end
end
