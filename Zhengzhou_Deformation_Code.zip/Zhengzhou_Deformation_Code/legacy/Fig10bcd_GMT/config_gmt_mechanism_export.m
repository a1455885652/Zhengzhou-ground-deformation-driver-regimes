function cfg = config_gmt_mechanism_export()
%CONFIG_GMT_MECHANISM_EXPORT Paths and fixed settings for GMT6 mechanism maps.

cfg.k4AssignmentCsv = [[zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output') filesep] ...
    'Python_Output\K4_Assignment.csv'];

cfg.outputDir = zz_project_path('Figure/Mechanism_GMT6/work_txt');

% Final display region. It is intentionally larger than the valid mechanism area
% so that DEM and the north arrow have enough surrounding space.
cfg.mapRegion = [112.55, 114.30, 34.18, 35.08];

% Fixed five zones used throughout the paper.
cfg.subZones = [ ...
    113.460, 113.760, 34.660, 34.840; ... % Sub_zone1
    113.698, 113.871, 34.484, 34.606  ... % Sub_zone2
    ];

cfg.uplZones = [ ...
    112.777, 113.094, 34.709, 34.891; ... % Upl_zone1
    112.702, 112.942, 34.276, 34.512; ... % Upl_zone2
    113.893, 114.182, 34.583, 34.971  ... % Upl_zone3
    ];
end
