clc;
clear;

cfg = config_gmt_mechanism_export();
export_gmt_mechanism_txt(cfg);

fprintf('\nGMT input text files are ready:\n%s\n', cfg.outputDir);
