@echo off
setlocal EnableExtensions EnableDelayedExpansion
call "%~dp0..\..\runtime\zz_paths.bat"
if errorlevel 1 exit /b 1

REM Zhengzhou K=4 SHAP mechanism map - GMT 6, Windows batch
REM Three panels: mechanism type / assignment confidence / uncertainty

where gmt >nul 2>nul
if errorlevel 1 (
  echo [ERROR] GMT6 command ^"gmt^" was not found in PATH.
  pause
  exit /b 1
)

set "PROJECT=%ZZ_PROJECT_ROOT%\Figure\Mechanism_GMT6"
set "TXT_DIR=%PROJECT%\work_txt"
set "WORK=%PROJECT%\gmt_work"
set "OUT=%PROJECT%\output"

REM Real DEM used in the deformation map. This may be an ENVI/GDAL-readable grid.
set "DEM=%ZZ_DEM%"

if not exist "%TXT_DIR%\gmt_data_config.bat" (
  echo [ERROR] Missing %TXT_DIR%\gmt_data_config.bat
  echo Run RUN_EXPORT_GMT_MECHANISM_TXT.m in MATLAB first.
  pause
  exit /b 1
)
call "%TXT_DIR%\gmt_data_config.bat"

if not exist "%DEM%" (
  echo [ERROR] DEM does not exist: %DEM%
  pause
  exit /b 1
)

if not exist "%WORK%" mkdir "%WORK%"
if not exist "%OUT%" mkdir "%OUT%"
cd /d "%WORK%"

REM Fine DISPLAY grid only. Analysis remains at the original ~1-km support.
set "IFINE=0.001"
set "PROJ=-JM8.8c"

del /q *.nc *.txt *.cpt 2>nul

copy /y "%~dp0cpt\mechanism.cpt" mechanism.cpt >nul
copy /y "%~dp0cpt\confidence.cpt" confidence.cpt >nul
copy /y "%~dp0cpt\uncertainty.cpt" uncertainty.cpt >nul
copy /y "%~dp0cpt\dem_light.cpt" dem_light.cpt >nul

REM 1. Very-light DEM background, same visual family as deformation map
echo [1/6] Preparing DEM background...
gmt grdcut "%DEM%" -R%RMAP% -Gdem_cut.nc
if errorlevel 1 goto :fail

gmt grdgradient dem_cut.nc -A315 -Ne0.16 -Gdem_shade.nc
if errorlevel 1 goto :fail

REM 2. Reconstruct exact original model-support mask
echo [2/6] Building model-support mask...
gmt xyz2grd "%TXT_DIR%\model_support.txt" -R%RGRID% -I%IORIG% -Gsupport_1km.nc
if errorlevel 1 goto :fail

gmt grdsample support_1km.nc -R%RGRID% -I%IFINE% -nn -Gsupport_fine.nc
if errorlevel 1 goto :fail

REM 3. Smooth P(M1..M4) surfaces then classify by maximum probability
REM    IMPORTANT: category numbers themselves are NOT interpolated.
echo [3/6] Fitting smooth mechanism probability surfaces...
for %%K in (1 2 3 4) do (
  gmt surface "%TXT_DIR%\prob_M%%K.txt" -R%RGRID% -I%IFINE% -T0.35 -Gp%%K_raw.nc
  if errorlevel 1 goto :fail
  gmt grdclip p%%K_raw.nc -Sb0/0 -Sa1/1 -Gp%%K_clip.nc
  if errorlevel 1 goto :fail
  gmt grdmath p%%K_clip.nc support_fine.nc MUL = p%%K.nc
  if errorlevel 1 goto :fail
)

gmt grdmath p1.nc p2.nc GE p1.nc p3.nc GE AND p1.nc p4.nc GE AND = i1.nc
gmt grdmath p2.nc p1.nc GT p2.nc p3.nc GE AND p2.nc p4.nc GE AND = i2.nc
gmt grdmath p3.nc p1.nc GT p3.nc p2.nc GT AND p3.nc p4.nc GE AND = i3.nc
gmt grdmath p4.nc p1.nc GT p4.nc p2.nc GT AND p4.nc p3.nc GT AND = i4.nc

gmt grdmath i1.nc 1 MUL i2.nc 2 MUL ADD i3.nc 3 MUL ADD i4.nc 4 MUL ADD support_fine.nc MUL = mechanism_smooth.nc
if errorlevel 1 goto :fail

REM 4. Smooth continuous confidence and uncertainty surfaces
echo [4/6] Fitting confidence and uncertainty surfaces...
gmt surface "%TXT_DIR%\assignment_confidence.txt" -R%RGRID% -I%IFINE% -T0.35 -Gconfidence_raw.nc
if errorlevel 1 goto :fail
gmt grdclip confidence_raw.nc -Sb0.5/0.5 -Sa1/1 -Gconfidence_clip.nc
gmt grdmath confidence_clip.nc support_fine.nc MUL = confidence_smooth.nc

gmt surface "%TXT_DIR%\assignment_uncertainty.txt" -R%RGRID% -I%IFINE% -T0.35 -Guncertainty_raw.nc
if errorlevel 1 goto :fail
gmt grdclip uncertainty_raw.nc -Sb0/0 -Sa1/1 -Guncertainty_clip.nc
gmt grdmath uncertainty_clip.nc support_fine.nc MUL = uncertainty_smooth.nc

REM 5. Prepare simple black-white north arrow matching reference figure
(
  echo 114.2300 35.0450
  echo 114.2300 34.9750
  echo 114.2040 34.9900
  echo 114.2300 35.0450
) > north_black.txt
(
  echo 114.2300 35.0450
  echo 114.2300 34.9750
  echo 114.2560 34.9900
  echo 114.2300 35.0450
) > north_white.txt
(
  echo 114.2300 35.0630 N
) > north_label.txt

REM Mechanism legend, deliberately only M1-M4.
(
  echo N 4
  echo S 0.10c r 0.30c 63/131/194 0.25p,63/131/194 0.55c M1
  echo S 0.10c r 0.30c 232/158/52 0.25p,232/158/52 0.55c M2
  echo S 0.10c r 0.30c 86/166/105 0.25p,86/166/105 0.55c M3
  echo S 0.10c r 0.30c 158/102/192 0.25p,158/102/192 0.55c M4
) > mechanism_legend.txt

REM 6. Draw final three-panel figure
echo [5/6] Drawing final 3-panel GMT figure...

gmt begin "%OUT%\Zhengzhou_SHAP_Mechanism_3Panel_GMT6" png,pdf
  gmt set FONT_TITLE 14p,Times-Bold ^
          FONT_LABEL 11p,Times-Roman ^
          FONT_ANNOT_PRIMARY 9p,Times-Roman ^
          FONT_ANNOT_SECONDARY 9p,Times-Roman ^
          MAP_FRAME_TYPE plain ^
          MAP_FRAME_PEN 1p,black ^
          MAP_TICK_PEN_PRIMARY 0.8p,black ^
          MAP_GRID_PEN_PRIMARY 0.20p,gray70,- ^
          MAP_TITLE_OFFSET 0.12c ^
          MAP_LABEL_OFFSET 0.12c ^
          MAP_ANNOT_OFFSET_PRIMARY 0.08c ^
          FORMAT_GEO_MAP ddd:mmF ^
          GMT_GRAPHICS_DPU 600

  gmt subplot begin 1x3 -Fs8.8c/5.2c -M0.35c/0.15c

    REM ---------------- Panel (a) ----------------
    gmt subplot set 0,0
    gmt basemap -R%RMAP% %PROJ% -Bxa0.4f0.2 -Bya0.2f0.1 -BWSen+t"(a) Mechanism type"
    gmt grdimage dem_cut.nc -R%RMAP% %PROJ% -Cdem_light.cpt -Idem_shade.nc
    gmt grdimage mechanism_smooth.nc -R%RMAP% %PROJ% -Cmechanism.cpt -nn -t8
    call :draw_zones_and_north
    gmt legend mechanism_legend.txt -DjBC+w5.8c+o0c/-1.05c -F+gwhite@0+p0p

    REM ---------------- Panel (b) ----------------
    gmt subplot set 0,1
    gmt basemap -R%RMAP% %PROJ% -Bxa0.4f0.2 -Bya0.2f0.1 -BWSen+t"(b) Assignment confidence"
    gmt grdimage dem_cut.nc -R%RMAP% %PROJ% -Cdem_light.cpt -Idem_shade.nc
    gmt grdimage confidence_smooth.nc -R%RMAP% %PROJ% -Cconfidence.cpt -nc -t10
    call :draw_zones_and_north
    gmt colorbar -Cconfidence.cpt -DjBC+w6.2c/0.25c+o0c/-1.05c+h -Bxa0.1f0.05+l"Maximum posterior probability"

    REM ---------------- Panel (c) ----------------
    gmt subplot set 0,2
    gmt basemap -R%RMAP% %PROJ% -Bxa0.4f0.2 -Bya0.2f0.1 -BWSen+t"(c) Assignment uncertainty"
    gmt grdimage dem_cut.nc -R%RMAP% %PROJ% -Cdem_light.cpt -Idem_shade.nc
    gmt grdimage uncertainty_smooth.nc -R%RMAP% %PROJ% -Cuncertainty.cpt -nc -t10
    call :draw_zones_and_north
    gmt colorbar -Cuncertainty.cpt -DjBC+w6.2c/0.25c+o0c/-1.05c+h -Bxa0.2f0.1+l"Normalized entropy"

  gmt subplot end

gmt end show
if errorlevel 1 goto :fail

echo [6/6] Done.
echo Output:
echo %OUT%\Zhengzhou_SHAP_Mechanism_3Panel_GMT6.png
echo %OUT%\Zhengzhou_SHAP_Mechanism_3Panel_GMT6.pdf
pause
exit /b 0

:draw_zones_and_north
REM Five fixed deformation zones. Same convention as the deformation-rate map.
gmt plot "%TXT_DIR%\zones_sub.txt" -R%RMAP% %PROJ% -W1.25p,black,--
gmt plot "%TXT_DIR%\zones_upl.txt" -R%RMAP% %PROJ% -W1.25p,red,--
gmt text "%TXT_DIR%\zone_labels.txt" -R%RMAP% %PROJ% -F+f8.5p,Times-Bold,black+jBL -Gwhite@35 -C0.03c

REM Black-white north arrow placed in the expanded upper-right blank area.
gmt plot north_black.txt -R%RMAP% %PROJ% -Gblack -W0.8p,black
gmt plot north_white.txt -R%RMAP% %PROJ% -Gwhite -W0.8p,black
gmt text north_label.txt -R%RMAP% %PROJ% -F+f13p,Times-Bold,black+jBC
exit /b 0

:fail
echo.
echo [ERROR] GMT drawing stopped because a command failed.
echo Check the command immediately above this message.
pause
exit /b 1
