function write_zone_labels(filePath, subZones, uplZones)
%WRITE_ZONE_LABELS Write label anchors for the five fixed zones.

fid = fopen(filePath, 'w');
if fid < 0
    error('Cannot create file: %s', filePath);
end
cleanupObj = onCleanup(@() fclose(fid));

for i = 1:size(subZones,1)
    w = subZones(i,1); n = subZones(i,4);
    fprintf(fid, '%.8f %.8f Sub_zone%d\n', w + 0.008, n + 0.012, i);
end
for i = 1:size(uplZones,1)
    w = uplZones(i,1); n = uplZones(i,4);
    fprintf(fid, '%.8f %.8f Upl_zone%d\n', w + 0.008, n + 0.012, i);
end
end
