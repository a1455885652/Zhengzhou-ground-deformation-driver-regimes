function write_xyz_file(filePath, lon, lat, value)
%WRITE_XYZ_FILE Write a three-column GMT XYZ file without a header.

fid = fopen(filePath, 'w');
if fid < 0
    error('Cannot create file: %s', filePath);
end
cleanupObj = onCleanup(@() fclose(fid));

for i = 1:numel(lon)
    fprintf(fid, '%.8f %.8f %.12g\n', lon(i), lat(i), value(i));
end
end
