function [dx, dy] = estimate_grid_spacing(lon, lat)
%ESTIMATE_GRID_SPACING Estimate regular longitude/latitude node spacing.

ux = unique(round(lon(:), 8));
uy = unique(round(lat(:), 8));

if numel(ux) < 2 || numel(uy) < 2
    error('Insufficient unique coordinates to estimate grid spacing.');
end

dxAll = diff(sort(ux));
dyAll = diff(sort(uy));

dxAll = dxAll(dxAll > 1e-8);
dyAll = dyAll(dyAll > 1e-8);

dx = median(dxAll);
dy = median(dyAll);

if ~isfinite(dx) || ~isfinite(dy) || dx <= 0 || dy <= 0
    error('Failed to estimate valid grid spacing.');
end
end
