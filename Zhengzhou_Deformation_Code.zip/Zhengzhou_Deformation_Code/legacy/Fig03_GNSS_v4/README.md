# Fig03_GNSS_v4

Earlier GNSS display prototype. It contains calibration/display-fit options; those operations must not be described as an independent observational validation. The selected GNSS analysis is analysis/gnss_validation, with its input folder explicitly configured.

These files are not invoked by the final-figure registry.

Available scripts:

- `RUN_GNSS_INSAR_PAPERPLOT_V4.m`
- `apply_calibration_v4.m`
- `calibrate_insar_timesplit_v4.m`
- `clean_gnss_series_v4.m`
- `clean_insar_series_v4.m`
- `common_reference_v4.m`
- `config_gnss_insar_paperplot_v4.m`
- `hampel_irregular_v4.m`
- `one_metrics_v4.m`
- `pick_name_v4.m`
- `plot_multistation_paperstyle_v4.m`
- `read_fullseries_csv_v4.m`
- `repair_short_gaps_v4.m`
- `save_station_output_v4.m`
- `smooth_display_series_v4.m`
- `to_datetime_v4.m`
- `validation_metrics_v4.m`
- `write_metrics_summary_v4.m`
