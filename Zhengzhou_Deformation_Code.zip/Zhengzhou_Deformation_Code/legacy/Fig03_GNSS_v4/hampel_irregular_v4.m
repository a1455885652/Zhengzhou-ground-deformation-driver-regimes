function [isOutlier, localMedian, robustSigma] = hampel_irregular_v4(x, halfWindow, nSigma)

n = numel(x);
isOutlier = false(n,1);
localMedian = nan(n,1);
robustSigma = nan(n,1);

for i = 1:n
    i1 = max(1, i-halfWindow);
    i2 = min(n, i+halfWindow);
    w = x(i1:i2);
    w = w(isfinite(w));
    if numel(w) < 5
        continue;
    end
    med = median(w, 'omitnan');
    mad0 = median(abs(w-med), 'omitnan');
    sig = 1.4826 * mad0;
    localMedian(i) = med;
    robustSigma(i) = sig;
    if sig > 0 && abs(x(i)-med) > nSigma*sig
        isOutlier(i) = true;
    end
end

end
