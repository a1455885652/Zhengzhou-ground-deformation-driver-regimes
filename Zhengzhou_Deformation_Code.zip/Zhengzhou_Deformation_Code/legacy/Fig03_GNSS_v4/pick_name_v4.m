function out = pick_name_v4(names, candidates)

normNames = lower(regexprep(names, '[^A-Za-z0-9]', ''));

for i = 1:numel(candidates)
    c = lower(regexprep(candidates(i), '[^A-Za-z0-9]', ''));
    idx = find(normNames == c, 1);
    if ~isempty(idx)
        out = char(names(idx));
        return;
    end
end

error('Required column not found. Available columns: %s', strjoin(names, ', '));

end
