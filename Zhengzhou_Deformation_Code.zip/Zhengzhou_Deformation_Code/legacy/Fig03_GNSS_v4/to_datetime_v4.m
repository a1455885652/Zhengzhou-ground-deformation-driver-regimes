function t = to_datetime_v4(x)

if isdatetime(x)
    t = x;
    return;
end

if isnumeric(x)
    t = datetime(x, 'ConvertFrom', 'datenum');
    return;
end

s = string(x);
t = NaT(size(s));

fmts = ["yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm","yyyy-MM-dd HH", ...
        "yyyy/MM/dd HH:mm:ss","yyyy/MM/dd HH:mm","yyyy-MM-dd"];

for k = 1:numel(fmts)
    idx = isnat(t) & strlength(strtrim(s)) > 0;
    if ~any(idx), break; end
    try
        tmp = datetime(s(idx), 'InputFormat', fmts(k));
        t(idx) = tmp;
    catch
    end
end

end
