function plot_multistation_paperstyle_v4(R, cfg)

n = numel(R);

fig = figure('Color','w', ...
    'Position',[60 40 cfg.figure.width cfg.figure.height]);

tl = tiledlayout(ceil(n/2), 2, ...
    'TileSpacing','compact', ...
    'Padding','compact');

for k = 1:n
    ax = nexttile(tl);
    hold(ax,'on');

    G = R(k).GNSS;
    I = R(k).InSAR;

    plot(ax, G.Time, G.Plot, 'k--', ...
        'LineWidth', cfg.figure.lineWidthGNSS);

    if cfg.figure.showRawInSAR
        plot(ax, I.Time, I.Plot, '-', 'LineWidth', 1.0);
    end

    if cfg.figure.showCalibrated
        plot(ax, I.Time, I.CalibratedPlot, 'r-', ...
            'LineWidth', cfg.figure.lineWidthInSAR);
    else
        plot(ax, I.Time, I.Plot, 'r-', ...
            'LineWidth', cfg.figure.lineWidthInSAR);
    end

    ax.FontName = cfg.figure.fontName;
    ax.FontSize = cfg.figure.fontSize;
    ax.LineWidth = 1.0;
    box(ax,'on');
    grid(ax,'off');

    ylabel(ax,'Cumulative deformation (mm)');
    xlabel(ax,'Time');

    letter = char('a' + k - 1);
    title(ax, sprintf('(%s) %s', letter, R(k).Station), ...
        'FontWeight','bold', ...
        'FontName',cfg.figure.fontName);

    if cfg.figure.showMetrics
        if cfg.figure.showCalibrated
            M = R(k).Metrics.Calibrated;
        else
            M = R(k).Metrics.Raw;
        end

        yl = ylim(ax);
        xl = xlim(ax);
        xText = xl(1) + 0.06*(xl(2)-xl(1));
        yText = yl(1) + 0.29*(yl(2)-yl(1));

        txt = sprintf('R = %.2f\\nRMSE = %.1f mm\\nBias = %.1f mm', ...
            M.R, M.RMSE, M.Bias);

        text(ax, xText, yText, txt, ...
            'FontName',cfg.figure.fontName, ...
            'FontSize',cfg.figure.fontSize-1, ...
            'VerticalAlignment','top');
    end

    legend(ax, {'GNSS','InSAR'}, ...
        'Location','northeast', ...
        'Box','off', ...
        'FontName',cfg.figure.fontName);
end

exportgraphics(fig, fullfile(cfg.outputDir,'Fig_GNSS_InSAR_PaperStyle_v4.png'),'Resolution',cfg.figure.dpi);
exportgraphics(fig, fullfile(cfg.outputDir,'Fig_GNSS_InSAR_PaperStyle_v4.tif'),'Resolution',cfg.figure.dpi);
exportgraphics(fig, fullfile(cfg.outputDir,'Fig_GNSS_InSAR_PaperStyle_v4.pdf'),'ContentType','vector');

drawnow; % Keep the exported figure open for preview.
end
