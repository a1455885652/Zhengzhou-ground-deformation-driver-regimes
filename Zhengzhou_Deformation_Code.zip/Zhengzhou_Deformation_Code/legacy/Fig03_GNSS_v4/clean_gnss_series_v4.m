function G = clean_gnss_series_v4(t, x, cfg)

valid = ~isnat(t) & isfinite(x);
t = t(valid);
x = x(valid);

[t, idx] = sort(t);
x = x(idx);

[tUnique, ~, ic] = unique(t);
xUnique = accumarray(ic, x, [], @median);
t = tUnique;
x = xUnique;

[outlier, localMed, robustSigma] = hampel_irregular_v4(x, cfg.gnss.hampelHalfWindow, cfg.gnss.hampelNSigma);

xClean = x;
xClean(outlier) = NaN;
xClean = repair_short_gaps_v4(t, xClean, cfg.gnss.maxGapHoursForRepair/24);

G.Time = t;
G.Raw = x;
G.Clean = xClean;
G.IsOutlier = outlier;
G.LocalMedian = localMed;
G.RobustSigma = robustSigma;

end
