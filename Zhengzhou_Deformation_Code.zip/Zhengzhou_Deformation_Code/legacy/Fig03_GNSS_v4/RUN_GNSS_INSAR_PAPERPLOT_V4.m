clear; clc; % Keep existing figure windows open.

cfg = config_gnss_insar_paperplot_v4();

if ~exist(cfg.outputDir, 'dir')
    mkdir(cfg.outputDir);
end

F = dir(fullfile(cfg.inputDir, '*_FullSeries.csv'));
if isempty(F)
    error('No *_FullSeries.csv files found in: %s', cfg.inputDir);
end

stationResults = struct([]);

for k = 1:numel(F)
    filePath = fullfile(F(k).folder, F(k).name);
    fprintf('[%d/%d] %s\n', k, numel(F), F(k).name);

    D = read_fullseries_csv_v4(filePath);

    G = clean_gnss_series_v4(D.GNSSTime, D.GNSSmm, cfg);
    I = clean_insar_series_v4(D.InSARTime, D.InSARmm, cfg);

    [G, I] = common_reference_v4(G, I, cfg);

    C = calibrate_insar_timesplit_v4(I.Time, I.Clean, G.Time, G.Clean, cfg);

    G.Plot = smooth_display_series_v4(G.Time, G.Clean, cfg.gnss.plotSmoothDays);
    I.Plot = smooth_display_series_v4(I.Time, I.Clean, cfg.insar.plotSmoothDays);

    if cfg.calibration.enable
        I.Calibrated = apply_calibration_v4(I.Clean, C.Intercept, C.Slope);
        I.CalibratedPlot = smooth_display_series_v4(I.Time, I.Calibrated, cfg.insar.plotSmoothDays);
    else
        I.Calibrated = I.Clean;
        I.CalibratedPlot = I.Plot;
    end

    station = erase(F(k).name, '_FullSeries.csv');

    M = validation_metrics_v4(C.ValidationGNSS, C.ValidationInSARRaw, C.ValidationInSARCalibrated);

    stationResults(k).Station = station;
    stationResults(k).GNSS = G;
    stationResults(k).InSAR = I;
    stationResults(k).Calibration = C;
    stationResults(k).Metrics = M;

    save_station_output_v4(cfg, station, G, I, C, M);
end

plot_multistation_paperstyle_v4(stationResults, cfg);
write_metrics_summary_v4(stationResults, cfg);

fprintf('\nFinished.\n');
fprintf('Main figure: %s\n', fullfile(cfg.outputDir, 'Fig_GNSS_InSAR_PaperStyle_v4.png'));
