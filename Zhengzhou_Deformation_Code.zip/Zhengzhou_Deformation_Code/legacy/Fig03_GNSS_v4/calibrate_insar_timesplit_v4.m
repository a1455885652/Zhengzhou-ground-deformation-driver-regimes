function C = calibrate_insar_timesplit_v4(tI, xI, tG, yG, cfg)

C = struct();
C.Intercept = 0;
C.Slope = 1;

validI = ~isnat(tI) & isfinite(xI);
tI = tI(validI);
xI = xI(validI);

yAtI = interp1(datenum(tG), yG, datenum(tI), 'linear', NaN);

valid = isfinite(xI) & isfinite(yAtI);
tc = tI(valid);
x = xI(valid);
y = yAtI(valid);

C.CommonTime = tc;
C.CommonGNSS = y;
C.CommonInSARRaw = x;

n = numel(x);
if ~cfg.calibration.enable || n < (cfg.calibration.minCalibrationEpochs + cfg.calibration.minValidationEpochs)
    C.CalibrationIndex = false(n,1);
    C.ValidationIndex = true(n,1);
    C.ValidationGNSS = y;
    C.ValidationInSARRaw = x;
    C.ValidationInSARCalibrated = x;
    return;
end

nCal = max(cfg.calibration.minCalibrationEpochs, floor(cfg.calibration.fraction*n));
nCal = min(nCal, n-cfg.calibration.minValidationEpochs);

idxCal = false(n,1);
idxCal(1:nCal) = true;
idxVal = ~idxCal;

if cfg.calibration.useRobustFit
    b = robustfit(x(idxCal), y(idxCal));
    a = b(1);
    s = b(2);
else
    p = polyfit(x(idxCal), y(idxCal), 1);
    s = p(1);
    a = p(2);
end

C.Intercept = a;
C.Slope = s;
C.CalibrationIndex = idxCal;
C.ValidationIndex = idxVal;
C.ValidationGNSS = y(idxVal);
C.ValidationInSARRaw = x(idxVal);
C.ValidationInSARCalibrated = a + s*x(idxVal);

end
