function save_station_output_v4(cfg, station, G, I, C, M)

safeStation = regexprep(station,'[\\/:*?"<>|]','_');
folder = fullfile(cfg.outputDir,'Station_Data');
if ~exist(folder,'dir'), mkdir(folder); end

TG = table(G.Time, G.Raw, G.Clean, G.Plot, G.IsOutlier, ...
    'VariableNames', {'Time','Raw_mm','Clean_mm','Plot_mm','Outlier'});
writetable(TG, fullfile(folder,[safeStation '_GNSS.csv']));

TI = table(I.Time, I.Raw, I.Clean, I.Plot, I.Calibrated, I.CalibratedPlot, I.IsOutlier, ...
    'VariableNames', {'Time','Raw_mm','Clean_mm','Plot_mm','Calibrated_mm','CalibratedPlot_mm','Outlier'});
writetable(TI, fullfile(folder,[safeStation '_InSAR.csv']));

TC = table(C.CommonTime, C.CommonGNSS, C.CommonInSARRaw, ...
    'VariableNames', {'Time','GNSS_mm','InSAR_Raw_mm'});
writetable(TC, fullfile(folder,[safeStation '_CommonEpochs.csv']));

P = table(string(station), C.Intercept, C.Slope, ...
    M.Raw.N, M.Raw.R, M.Raw.RMSE, M.Raw.MAE, M.Raw.Bias, ...
    M.Calibrated.N, M.Calibrated.R, M.Calibrated.RMSE, M.Calibrated.MAE, M.Calibrated.Bias, ...
    'VariableNames', {'Station','CalibrationIntercept','CalibrationSlope', ...
    'Raw_N','Raw_R','Raw_RMSE','Raw_MAE','Raw_Bias', ...
    'Cal_N','Cal_R','Cal_RMSE','Cal_MAE','Cal_Bias'});

writetable(P, fullfile(folder,[safeStation '_Metrics.csv']));

end
