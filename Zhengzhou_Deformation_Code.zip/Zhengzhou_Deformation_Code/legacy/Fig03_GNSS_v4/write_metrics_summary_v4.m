function write_metrics_summary_v4(R, cfg)

n = numel(R);

Station = strings(n,1);
Intercept = nan(n,1);
Slope = nan(n,1);

Raw_N = nan(n,1); Raw_R = nan(n,1); Raw_RMSE = nan(n,1); Raw_MAE = nan(n,1); Raw_Bias = nan(n,1);
Cal_N = nan(n,1); Cal_R = nan(n,1); Cal_RMSE = nan(n,1); Cal_MAE = nan(n,1); Cal_Bias = nan(n,1);

for i = 1:n
    Station(i) = string(R(i).Station);
    Intercept(i) = R(i).Calibration.Intercept;
    Slope(i) = R(i).Calibration.Slope;

    Raw_N(i) = R(i).Metrics.Raw.N;
    Raw_R(i) = R(i).Metrics.Raw.R;
    Raw_RMSE(i) = R(i).Metrics.Raw.RMSE;
    Raw_MAE(i) = R(i).Metrics.Raw.MAE;
    Raw_Bias(i) = R(i).Metrics.Raw.Bias;

    Cal_N(i) = R(i).Metrics.Calibrated.N;
    Cal_R(i) = R(i).Metrics.Calibrated.R;
    Cal_RMSE(i) = R(i).Metrics.Calibrated.RMSE;
    Cal_MAE(i) = R(i).Metrics.Calibrated.MAE;
    Cal_Bias(i) = R(i).Metrics.Calibrated.Bias;
end

T = table(Station,Intercept,Slope, ...
    Raw_N,Raw_R,Raw_RMSE,Raw_MAE,Raw_Bias, ...
    Cal_N,Cal_R,Cal_RMSE,Cal_MAE,Cal_Bias);

writetable(T, fullfile(cfg.outputDir,'Metrics_Raw_vs_Calibrated.csv'));

end
