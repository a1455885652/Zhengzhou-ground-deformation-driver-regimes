function I = clean_insar_series_v4(t, x, cfg)

valid = ~isnat(t) & isfinite(x);
t = t(valid);
x = x(valid);

[t, idx] = sort(t);
x = x(idx);

[tUnique, ~, ic] = unique(t);
xUnique = accumarray(ic, x, [], @median);
t = tUnique;
x = xUnique;

[outlier, localMed, robustSigma] = hampel_irregular_v4(x, cfg.insar.hampelHalfWindow, cfg.insar.hampelNSigma);

xClean = x;
xClean(outlier) = NaN;
xClean = repair_short_gaps_v4(t, xClean, cfg.insar.maxGapDaysForRepair);

I.Time = t;
I.Raw = x;
I.Clean = xClean;
I.IsOutlier = outlier;
I.LocalMedian = localMed;
I.RobustSigma = robustSigma;

end
