function cfg = config_gnss_insar_paperplot_v4()

cfg.inputDir = zz_project_path('GNSS_InSAR_Validation_Output_v3/Full_TimeSeries_3x3');
cfg.outputDir = zz_project_path('GNSS_InSAR_PaperPlot_v4');

cfg.gnss.hampelHalfWindow = 8;
cfg.gnss.hampelNSigma = 4.5;
cfg.gnss.maxGapHoursForRepair = 12;
cfg.gnss.plotSmoothDays = 5;

cfg.insar.hampelHalfWindow = 3;
cfg.insar.hampelNSigma = 5.0;
cfg.insar.maxGapDaysForRepair = 30;
cfg.insar.plotSmoothDays = 18;

cfg.reference.maxGNSSDistanceHours = 18;

cfg.calibration.enable = true;
cfg.calibration.fraction = 0.60;
cfg.calibration.minCalibrationEpochs = 8;
cfg.calibration.minValidationEpochs = 5;
cfg.calibration.useRobustFit = true;

cfg.figure.width = 1500;
cfg.figure.height = 1050;
cfg.figure.fontName = 'Times New Roman';
cfg.figure.fontSize = 15;
cfg.figure.lineWidthGNSS = 1.8;
cfg.figure.lineWidthInSAR = 2.0;
cfg.figure.showRawInSAR = false;
cfg.figure.showCalibrated = true;
cfg.figure.showMetrics = true;
cfg.figure.dpi = 600;

end
