function y = smooth_display_series_v4(t, x, windowDays)

y = x;
valid = ~isnat(t) & isfinite(x);
if nnz(valid) < 5, return; end

tv = datenum(t(valid));
xv = x(valid);

gridDay = (floor(min(tv)):ceil(max(tv)))';
xDaily = interp1(tv, xv, gridDay, 'linear', NaN);

w = max(3, round(windowDays));
xSmooth = movmedian(xDaily, w, 'omitnan');
xSmooth = movmean(xSmooth, w, 'omitnan');

y(valid) = interp1(gridDay, xSmooth, tv, 'linear', 'extrap');

end
