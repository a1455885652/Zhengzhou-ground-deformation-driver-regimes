function y = apply_calibration_v4(x, intercept, slope)
y = intercept + slope .* x;
end
