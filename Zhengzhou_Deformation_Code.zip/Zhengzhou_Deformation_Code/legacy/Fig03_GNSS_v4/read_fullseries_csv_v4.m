function D = read_fullseries_csv_v4(filePath)

T = readtable(filePath, 'VariableNamingRule', 'preserve');
names = string(T.Properties.VariableNames);

gnssTimeName = pick_name_v4(names, ["GNSS_DateTime","GNSSTime","GNSS_Time"]);
gnssValName  = pick_name_v4(names, ["GNSS_mm","GNSS","GNSSVertical_mm"]);
insarTimeName = pick_name_v4(names, ["InSAR_DateTime","InSARTime","InSAR_Time"]);
insarValName  = pick_name_v4(names, ["InSAR_3x3_mm","InSAR_mm","InSAR"]);

D.GNSSTime = to_datetime_v4(T.(gnssTimeName));
D.GNSSmm = double(T.(gnssValName));
D.InSARTime = to_datetime_v4(T.(insarTimeName));
D.InSARmm = double(T.(insarValName));

end
