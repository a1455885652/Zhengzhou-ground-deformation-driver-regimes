function [G, I] = common_reference_v4(G, I, cfg)

validI = isfinite(I.Clean);
if ~any(validI), return; end

insarTimes = I.Time(validI);
insarVals = I.Clean(validI);

gnssAtInsar = interp1(datenum(G.Time), G.Clean, datenum(insarTimes), 'linear', NaN);

for k = 1:numel(insarTimes)
    if ~isfinite(gnssAtInsar(k)), continue; end
    dtHours = min(abs(hours(G.Time - insarTimes(k))));
    if dtHours <= cfg.reference.maxGNSSDistanceHours
        refI = insarVals(k);
        refG = gnssAtInsar(k);

        G.Raw = G.Raw - refG;
        G.Clean = G.Clean - refG;
        I.Raw = I.Raw - refI;
        I.Clean = I.Clean - refI;
        return;
    end
end

end
