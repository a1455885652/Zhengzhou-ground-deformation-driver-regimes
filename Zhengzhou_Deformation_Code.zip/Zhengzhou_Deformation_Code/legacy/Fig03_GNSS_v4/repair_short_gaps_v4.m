function y = repair_short_gaps_v4(t, x, maxGapDays)

y = x;
bad = ~isfinite(y);
if ~any(bad), return; end

good = isfinite(y);
if nnz(good) < 2, return; end

tg = datenum(t(good));
yg = y(good);

badIdx = find(bad);
for ii = 1:numel(badIdx)
    i = badIdx(ii);
    ti = datenum(t(i));
    left = find(tg < ti, 1, 'last');
    right = find(tg > ti, 1, 'first');
    if isempty(left) || isempty(right), continue; end
    if (tg(right)-tg(left)) <= maxGapDays
        y(i) = interp1(tg([left right]), yg([left right]), ti, 'linear');
    end
end

end
