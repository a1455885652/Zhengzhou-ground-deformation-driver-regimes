function M = one_metrics_v4(y, x)

v = isfinite(y) & isfinite(x);
y = y(v);
x = x(v);

M.N = numel(y);

if M.N < 3
    M.R = NaN;
    M.RMSE = NaN;
    M.MAE = NaN;
    M.Bias = NaN;
    return;
end

M.R = corr(x, y, 'Rows','complete');
e = x-y;
M.RMSE = sqrt(mean(e.^2));
M.MAE = mean(abs(e));
M.Bias = mean(e);

end
