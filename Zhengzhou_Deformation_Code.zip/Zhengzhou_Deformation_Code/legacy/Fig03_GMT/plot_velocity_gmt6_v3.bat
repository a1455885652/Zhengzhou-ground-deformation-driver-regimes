@echo off
chcp 65001 >nul
setlocal EnableExtensions
call "%~dp0..\..\runtime\zz_paths.bat"
if errorlevel 1 exit /b 1

REM Vertical deformation map with relief shading and station locations.

set "OUTDIR=%ZZ_FIGURE_OUTPUT%\legacy_Fig03"
set "WORK=%OUTDIR%\work_v3"

REM Original vertical-deformation raster.
REM The raster supplies mapped values; TXT is the tabular export.
set "VEL_TIF=%ZZ_VELOCITY_TIF%"
set "VEL_TXT=%ZZ_VELOCITY_XYZ%"

REM Zhengzhou municipal boundary
set "SHP=%ZZ_BOUNDARY%"

REM GNSS coordinate file
set "GNSS=%ZZ_PROJECT_ROOT%\GNSS\坐标.txt"

REM GMT global relief background
REM Change 03s to 15s only if downloading 03s is too slow.
set "DEM=%ZZ_DEM%"

REM Map region
set "R=-R112.55/114.32/34.05/35.10"
set "J=-JM18c"

if not exist "%OUTDIR%" mkdir "%OUTDIR%"
if not exist "%WORK%" mkdir "%WORK%"

where gmt >nul 2>nul
if errorlevel 1 (
    echo [ERROR] GMT6 was not found in PATH.
    pause
    exit /b 1
)

if not exist "%VEL_TIF%" (
    echo [ERROR] Missing deformation GeoTIFF:
    echo %VEL_TIF%
    pause
    exit /b 1
)

if not exist "%VEL_TXT%" (
    echo [ERROR] Missing deformation TXT:
    echo %VEL_TXT%
    pause
    exit /b 1
)

if not exist "%SHP%" (
    echo [ERROR] Missing Zhengzhou shapefile:
    echo %SHP%
    pause
    exit /b 1
)

if not exist "%GNSS%" (
    echo [ERROR] Missing GNSS coordinate file:
    echo %GNSS%
    pause
    exit /b 1
)

REM 1. Convert GNSS DMS/decimal coordinates and remove one station
REM    Removed station:
REM       113°58'04"E, 34°22'29"N
powershell -NoProfile -ExecutionPolicy Bypass ^
    -File "%~dp0prepare_gnss_v3.ps1" ^
    -InputFile "%GNSS%" ^
    -OutputFile "%WORK%\gnss_lonlat.txt"

if errorlevel 1 (
    echo [ERROR] GNSS coordinate conversion failed.
    pause
    exit /b 1
)

REM 2. Deformation discrete CPT
set "CPT=%WORK%\velocity_discrete.cpt"

> "%CPT%" (
echo # COLOR_MODEL = RGB
echo -28 255/0/0      -15 255/0/0
echo -15 255/165/0    -10 255/165/0
echo -10 252/245/45   -6  252/245/45
echo -6  90/220/198   0   90/220/198
echo 0   55/165/225   5   55/165/225
echo 5   25/72/215    10  25/72/215
echo B 255/0/0
echo F 25/72/215
echo N 255/255/255
)

REM 3. Very light grayscale DEM CPT
set "DEM_CPT=%WORK%\dem_light.cpt"

> "%DEM_CPT%" (
echo # COLOR_MODEL = RGB
echo -500 252/252/252 0    250/250/250
echo 0    250/250/250 100  247/247/247
echo 100  247/247/247 300  243/243/243
echo 300  243/243/243 600  238/238/238
echo 600  238/238/238 1000 233/233/233
echo 1000 233/233/233 1500 228/228/228
echo 1500 228/228/228 2500 222/222/222
echo 2500 222/222/222 4000 216/216/216
echo 4000 216/216/216 7000 210/210/210
echo B 252/252/252
echo F 205/205/205
echo N 255/255/255
)

REM 4. Five deformation zones
REM    Subsidence = black dashed
REM    Uplift     = red dashed

REM Sub_zone1
> "%WORK%\sub_zone1.txt" (
echo 113.460 34.660
echo 113.760 34.660
echo 113.760 34.840
echo 113.460 34.840
echo 113.460 34.660
)

REM Sub_zone2
> "%WORK%\sub_zone2.txt" (
echo 113.698 34.484
echo 113.871 34.484
echo 113.871 34.606
echo 113.698 34.606
echo 113.698 34.484
)

REM Upl_zone1
> "%WORK%\upl_zone1.txt" (
echo 112.777 34.709
echo 113.094 34.709
echo 113.094 34.891
echo 112.777 34.891
echo 112.777 34.709
)

REM Upl_zone2
> "%WORK%\upl_zone2.txt" (
echo 112.702 34.276
echo 112.942 34.276
echo 112.942 34.512
echo 112.702 34.512
echo 112.702 34.276
)

REM Upl_zone3
> "%WORK%\upl_zone3.txt" (
echo 113.893 34.583
echo 114.182 34.583
echo 114.182 34.971
echo 113.893 34.971
echo 113.893 34.583
)

REM Zone labels: placed near upper-left corners, close to reference style
> "%WORK%\zone_labels.txt" (
echo 113.468 34.850 Sub_zone1
echo 113.706 34.611 Sub_zone2
echo 112.785 34.898 Upl_zone1
echo 112.710 34.520 Upl_zone2
echo 113.900 34.980 Upl_zone3
)

REM Yellow River label
> "%WORK%\yellow_river_label.txt" (
echo 113.43 34.997 Yellow River
)

REM 5. Clean legend: GNSS + River
REM    Large dx2 avoids line/text overlap.
> "%WORK%\map_legend.txt" (
echo S 0.20c t 0.27c black 0.25p,black 0.82c GNSS station
echo S 0.20c - 0.85c - 3.0p,30/105/225 1.25c River
)

REM 6. Two-tone north arrow, closer to reference style

REM Outer white arrow/kite
> "%WORK%\north_outer.txt" (
echo 114.205 35.055
echo 114.177 34.980
echo 114.205 35.004
echo 114.233 34.980
echo 114.205 35.055
)

REM Black left half
> "%WORK%\north_black.txt" (
echo 114.205 35.055
echo 114.177 34.980
echo 114.205 35.004
echo 114.205 35.055
)

> "%WORK%\north_label.txt" (
echo 114.205 35.077 N
)

REM 7. Compact colorbar title, similar to reference Fig. 2
> "%WORK%\cb_title.txt" (
echo 113.530 34.186 Zhengzhou ground vertical deformation
echo 113.530 34.157 rates (mm/yr)
)

REM White panel behind colorbar only
> "%WORK%\cb_panel.txt" (
echo 113.500 34.075
echo 114.295 34.075
echo 114.295 34.225
echo 113.500 34.225
echo 113.500 34.075
)

REM 8. Plot
pushd "%OUTDIR%"

gmt begin Zhengzhou_velocity_GMT_V3 png,pdf

    REM ---------- global typography ----------
    gmt set MAP_FRAME_TYPE plain
    gmt set MAP_FRAME_PEN 1.1p,black
    gmt set MAP_TICK_PEN_PRIMARY 0.9p,black
    gmt set MAP_TICK_LENGTH_PRIMARY 0.13c
    gmt set FONT_ANNOT_PRIMARY 9.5p,Times-Roman
    gmt set FONT_LABEL 10p,Times-Roman
    gmt set FONT_TITLE 11p,Times-Bold
    gmt set FORMAT_GEO_MAP ddd:mmF
    gmt set GMT_GRAPHICS_DPU 600

    REM ========================================================
    REM A. Light DEM background
    REM ========================================================
    echo [1/10] Preparing DEM background...

    gmt grdcut %DEM% %R% -G"%WORK%\dem_map.nc"

    REM Gentle hillshade: low contrast to match the reference map.
    gmt grdgradient "%WORK%\dem_map.nc" ^
        -G"%WORK%\dem_map_intensity.nc" ^
        -A315 -Ne0.18

    gmt grdimage "%WORK%\dem_map.nc" %R% %J% ^
        -C"%DEM_CPT%" ^
        -I"%WORK%\dem_map_intensity.nc"

    REM ========================================================
    REM B. Prepare DEM hillshade at EXACT deformation-grid geometry
    REM
    REM -Rgridfile copies domain, spacing and registration from VEL_TIF.
    REM This creates a co-registered illumination grid.
    REM ========================================================
    echo [2/10] Matching terrain hillshade to deformation grid...

    gmt grdsample "%WORK%\dem_map_intensity.nc" ^
        -R"%VEL_TIF%" ^
        -G"%WORK%\terrain_intensity_on_velocity.nc" ^
        -nl

    REM Reduce hillshade strength, so the deformation colors remain clear.
    gmt grdmath "%WORK%\terrain_intensity_on_velocity.nc" 0.38 MUL ^
        = "%WORK%\terrain_intensity_soft.nc"

    REM ========================================================
    REM C. Yellow River beneath deformation layer
    REM ========================================================
    echo [3/10] Drawing Yellow River...

    gmt coast %R% %J% -Df -A100 ^
        -I1/3.2p,30/105/225

    REM ========================================================
    REM D. Deformation surface
    REM
    REM IMPORTANT:
    REM -Q  => NaN pixels are transparent.
    REM -I  => deformation colors receive DEM hillshade.
    REM -nn => nearest-neighbor rendering keeps discrete color classes crisp.
    REM
    REM Therefore:
    REM   * no white rectangular NaN footprint;
    REM   * underlying DEM remains visible through missing-data areas;
    REM   * valid deformation colors visually follow terrain relief.
    REM ========================================================
    echo [4/10] Draping deformation colors over terrain...

    gmt grdimage "%VEL_TIF%" %R% %J% ^
        -C"%CPT%" ^
        -I"%WORK%\terrain_intensity_soft.nc" ^
        -Q ^
        -nn

    REM Replot river above deformation for clear visibility.
    gmt coast %R% %J% -Df -A100 ^
        -I1/2.8p,30/105/225

    REM ========================================================
    REM E. Zhengzhou municipal boundary
    REM ========================================================
    echo [5/10] Drawing Zhengzhou municipal boundary...

    gmt plot "%SHP%" %R% %J% ^
        -W1.15p,65/65/65

    REM ========================================================
    REM F. Five zones
    REM ========================================================
    echo [6/10] Drawing deformation zones...

    REM Subsidence: black dashed
    gmt plot "%WORK%\sub_zone1.txt" %R% %J% -W1.15p,black,--
    gmt plot "%WORK%\sub_zone2.txt" %R% %J% -W1.15p,black,--

    REM Uplift: red dashed
    gmt plot "%WORK%\upl_zone1.txt" %R% %J% -W1.15p,210/0/0,--
    gmt plot "%WORK%\upl_zone2.txt" %R% %J% -W1.15p,210/0/0,--
    gmt plot "%WORK%\upl_zone3.txt" %R% %J% -W1.15p,210/0/0,--

    REM Labels: no large white label boxes
    gmt text "%WORK%\zone_labels.txt" %R% %J% ^
        -F+f9.5p,Times-Bold,black+jBL

    REM ========================================================
    REM G. River text + GNSS
    REM ========================================================
    echo [7/10] Drawing labels and GNSS stations...

    gmt text "%WORK%\yellow_river_label.txt" %R% %J% ^
        -F+f13p,Times-Italic,80/80/80+jCM+a-7

    gmt plot "%WORK%\gnss_lonlat.txt" %R% %J% ^
        -St0.24c -Gblack -W0.25p,black

    REM ========================================================
    REM H. Improved north arrow
    REM ========================================================
    echo [8/10] Drawing north arrow...

    gmt plot "%WORK%\north_outer.txt" %R% %J% ^
        -Gwhite -W1.0p,black

    gmt plot "%WORK%\north_black.txt" %R% %J% ^
        -Gblack -W0.8p,black

    gmt text "%WORK%\north_label.txt" %R% %J% ^
        -F+f13p,Times-Bold,black+jCM

    REM ========================================================
    REM I. Legend + scale
    REM ========================================================
    echo [9/10] Drawing legend and scale...

    gmt legend "%WORK%\map_legend.txt" %R% %J% ^
        -DjBL+o0.38c/1.43c+w3.75c ^
        -F+gwhite@8+p0.45p,90/90/90

    gmt basemap %R% %J% ^
        -LjBL+c34.22+w100k+f+o0.40c/0.35c+lkm

    REM ========================================================
    REM J. Reference-style compact colorbar
    REM ========================================================
    echo [10/10] Drawing colorbar...

    REM Small white panel only behind the colorbar region.
    gmt plot "%WORK%\cb_panel.txt" %R% %J% ^
        -Gwhite -W0.55p,90/90/90

    REM Two-line bold title ABOVE the color boxes, like reference Fig. 2.
    gmt text "%WORK%\cb_title.txt" %R% %J% ^
        -F+f9.3p,Times-Bold,black+jBL

    REM Equal-width discrete boxes.
    REM -Li annotates each interval range.
    REM -Np forces discrete polygon rectangles.
    REM No large GMT-generated background frame is used here.
    gmt colorbar -C"%CPT%" ^
        -Dg113.535/34.094+w7.25c/0.43c+h+jBL ^
        -Li0.025c ^
        -Np

    REM ========================================================
    REM K. Map frame
    REM
    REM Deliberately no huge title above the map.
    REM For a journal figure, use the manuscript caption instead.
    REM If you really want an in-map title, uncomment:
    REM -BWSne+t"Vertical Ground Deformation Rates in Zhengzhou"
    REM ========================================================
    gmt basemap %R% %J% ^
        -Bxa0.5f0.1 -Bya0.5f0.1 ^
        -BWSne

gmt end show

popd

echo.
echo ============================================================
echo Finished.
echo.
echo PNG:
echo %OUTDIR%\Zhengzhou_velocity_GMT_V3.png
echo.
echo PDF:
echo %OUTDIR%\Zhengzhou_velocity_GMT_V3.pdf
echo ============================================================
pause
