# Fig03_GMT

Candidate velocity map with terrain, boundary and GNSS stations. The recovered prepare_gnss_v3.ps1 helper is included. The full final manuscript composite is not recovered. Run plot_velocity_gmt6_v3.bat after setting the external paths; GMT 6, GDAL and PowerShell are required.

These files are not invoked by the final-figure registry.

Available scripts:

- `plot_velocity_gmt6_v3.bat`
- `prepare_gnss_v3.ps1`
