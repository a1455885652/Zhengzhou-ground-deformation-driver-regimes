param(
    [Parameter(Mandatory=$true)]
    [string]$InputFile,

    [Parameter(Mandatory=$true)]
    [string]$OutputFile
)

$ErrorActionPreference = "Stop"
$culture = [System.Globalization.CultureInfo]::InvariantCulture

function To-Number([string]$s) {
    return [double]::Parse($s, $culture)
}

# User-requested station to remove:
# 113°58'04"E, 34°22'29"N
$excludeLon = 113.0 + 58.0/60.0 + 4.0/3600.0
$excludeLat = 34.0  + 22.0/60.0 + 29.0/3600.0

# About 0.3 arc-second tolerance
$tolerance = 0.00008

$lines = Get-Content -LiteralPath $InputFile -Encoding UTF8

$result  = New-Object System.Collections.Generic.List[string]
$removed = 0

foreach ($line in $lines) {

    if ([string]::IsNullOrWhiteSpace($line)) {
        continue
    }

    $matches = [regex]::Matches($line, '[-+]?\d+(?:\.\d+)?')

    if ($matches.Count -lt 2) {
        continue
    }

    $v = @()
    foreach ($m in $matches) {
        $v += To-Number $m.Value
    }

    $lon = $null
    $lat = $null

    # ----------------------------------------------------------
    # First try DMS sequence:
    # lon_deg lon_min lon_sec lat_deg lat_min lat_sec
    # ----------------------------------------------------------
    if ($v.Count -ge 6) {

        for ($i = 0; $i -le $v.Count - 6; $i++) {

            $lonDeg = $v[$i]
            $lonMin = $v[$i + 1]
            $lonSec = $v[$i + 2]

            $latDeg = $v[$i + 3]
            $latMin = $v[$i + 4]
            $latSec = $v[$i + 5]

            if (
                $lonDeg -ge 100 -and $lonDeg -le 130 -and
                $latDeg -ge 20  -and $latDeg -le 50  -and
                $lonMin -ge 0 -and $lonMin -lt 60 -and
                $lonSec -ge 0 -and $lonSec -lt 60 -and
                $latMin -ge 0 -and $latMin -lt 60 -and
                $latSec -ge 0 -and $latSec -lt 60
            ) {
                $lon = $lonDeg + $lonMin / 60.0 + $lonSec / 3600.0
                $lat = $latDeg + $latMin / 60.0 + $latSec / 3600.0
                break
            }
        }
    }

    # ----------------------------------------------------------
    # Otherwise try decimal degrees.
    # ----------------------------------------------------------
    if ($null -eq $lon) {

        for ($i = 0; $i -le $v.Count - 2; $i++) {

            if (
                $v[$i] -ge 100 -and $v[$i] -le 130 -and
                $v[$i + 1] -ge 20 -and $v[$i + 1] -le 50
            ) {
                $lon = $v[$i]
                $lat = $v[$i + 1]
                break
            }
        }
    }

    if ($null -eq $lon -or $null -eq $lat) {
        continue
    }

    # ----------------------------------------------------------
    # Remove the specified station.
    # ----------------------------------------------------------
    if (
        [math]::Abs($lon - $excludeLon) -le $tolerance -and
        [math]::Abs($lat - $excludeLat) -le $tolerance
    ) {
        $removed++
        Write-Host (
            "Removed GNSS station: Lon={0:F8}, Lat={1:F8}" -f $lon, $lat
        )
        continue
    }

    $result.Add(("{0:F10}`t{1:F10}" -f $lon, $lat))
}

if ($result.Count -eq 0) {
    throw "No valid GNSS coordinates were parsed from: $InputFile"
}

Set-Content -LiteralPath $OutputFile -Value $result -Encoding ASCII

Write-Host ("GNSS stations retained: {0}" -f $result.Count)
Write-Host ("Specified stations removed: {0}" -f $removed)
Write-Host ("Output: {0}" -f $OutputFile)
