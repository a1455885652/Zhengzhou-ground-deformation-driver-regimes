@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
call "%~dp0..\..\runtime\zz_paths.bat"
if errorlevel 1 exit /b 1

REM GMT6 - Zhengzhou cumulative deformation 3x3 figure
REM 8 cumulative-deformation TXT panels; bottom-right panel intentionally empty
REM
REM Layout:
REM   2018-12 | 2019-12 | 2020-12
REM   2021-06 | 2022-02 | 2023-12
REM   2024-12 | 2025-12 | (empty)
REM
REM TXT format:
REM   column 1 = longitude
REM   column 2 = latitude
REM   column 3 = cumulative displacement (mm)
REM
REM The script:
REM   - reconstructs the regular raster from TXT with xyz2grd
REM   - uses DEM hillshade to illuminate deformation colors
REM   - keeps NaN cells transparent
REM   - draws Zhengzhou boundary, Yellow River, 5 zones, north arrow
REM   - no scale bar
REM   - longitude annotations only on the TOP row (north axes)
REM   - latitude annotations only on the LEFT column (west axes)
REM   - all other panel sides keep borders only, without geographic annotations

set "OUTDIR=%ZZ_FIGURE_OUTPUT%\legacy_Fig03"
set "WORK=%OUTDIR%\work_cumulative_3x3_gmt"

set "TXTDIR=%ZZ_CUMULATIVE_XYZ%"
set "SHP=%ZZ_BOUNDARY%"

REM Current Zhengzhou map region and panel projection
set "R=-R112.55/114.32/34.20/35.10"
set "J=-JM5.45c"

REM DEM
set "DEM=%ZZ_DEM%"

REM 0. 强制清理旧缓存，确保修改绝对生效
echo Cleaning old work directory and sessions...
if exist "%WORK%" rmdir /s /q "%WORK%" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v5.png" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v5.pdf" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v6.png" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v8.png" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v6.pdf" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v8.pdf" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v10_axes_fixed.png" 2>nul
del "%OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v10_axes_fixed.pdf" 2>nul

mkdir "%OUTDIR%" 2>nul
mkdir "%WORK%" 2>nul

where gmt >nul 2>nul
if errorlevel 1 (
    echo [ERROR] GMT6 was not found in PATH.
    pause
    exit /b 1
)

if not exist "%TXTDIR%" (
    echo [ERROR] TXT folder does not exist:
    echo %TXTDIR%
    pause
    exit /b 1
)

if not exist "%SHP%" (
    echo [ERROR] Zhengzhou shapefile does not exist:
    echo %SHP%
    pause
    exit /b 1
)

REM 1. Find the 8 TXT files

call :FindTxt 201812 TXT1
call :FindTxt 201912 TXT2
call :FindTxt 202012 TXT3
call :FindTxt 202106 TXT4
call :FindTxt 202202 TXT5
call :FindTxt 202312 TXT6
call :FindTxt 202412 TXT7
call :FindTxt 202512 TXT8

call :CheckFound TXT1 2018-12
call :CheckFound TXT2 2019-12
call :CheckFound TXT3 2020-12
call :CheckFound TXT4 2021-06
call :CheckFound TXT5 2022-02
call :CheckFound TXT6 2023-12
call :CheckFound TXT7 2024-12
call :CheckFound TXT8 2025-12

echo.
echo ============================================================
echo Found TXT files
echo ============================================================
echo 2018-12: !TXT1!
echo 2019-12: !TXT2!
echo 2020-12: !TXT3!
echo 2021-06: !TXT4!
echo 2022-02: !TXT5!
echo 2023-12: !TXT6!
echo 2024-12: !TXT7!
echo 2025-12: !TXT8!
echo.

REM 2. Infer the original regular TXT grid geometry
REM    Uses streaming PowerShell: very low memory.

set "PSGRID=%WORK%\infer_grid.ps1"

> "%PSGRID%" (
echo param^(
echo   [Parameter^(Mandatory=$true^)][string]$InputFile,
echo   [Parameter^(Mandatory=$true^)][string]$OutputFile
echo ^)
echo $culture = [System.Globalization.CultureInfo]::InvariantCulture
echo $minX = [double]::PositiveInfinity
echo $maxX = [double]::NegativeInfinity
echo $minY = [double]::PositiveInfinity
echo $maxY = [double]::NegativeInfinity
echo $dx = [double]::PositiveInfinity
echo $dy = [double]::PositiveInfinity
echo $prevX = $null
echo $prevY = $null
echo foreach ^($line in [System.IO.File]::ReadLines^($InputFile^)^) ^{
echo   if ^([string]::IsNullOrWhiteSpace^($line^)^) ^{ continue ^}
echo   $p = $line.Trim^(^) -split '\s+'
echo   if ^($p.Count -lt 2^) ^{ continue ^}
echo   $x = 0.0
echo   $y = 0.0
echo   if ^(-not [double]::TryParse^($p[0], [System.Globalization.NumberStyles]::Float, $culture, [ref]$x^)^) ^{ continue ^}
echo   if ^(-not [double]::TryParse^($p[1], [System.Globalization.NumberStyles]::Float, $culture, [ref]$y^)^) ^{ continue ^}
echo   if ^($x -lt $minX^) ^{ $minX = $x ^}
echo   if ^($x -gt $maxX^) ^{ $maxX = $x ^}
echo   if ^($y -lt $minY^) ^{ $minY = $y ^}
echo   if ^($y -gt $maxY^) ^{ $maxY = $y ^}
echo   if ^($null -ne $prevX^) ^{
echo      $tx = [math]::Abs^($x - $prevX^)
echo      $ty = [math]::Abs^($y - $prevY^)
echo      if ^($tx -gt 1e-10 -and $tx -lt $dx^) ^{ $dx = $tx ^}
echo      if ^($ty -gt 1e-10 -and $ty -lt $dy^) ^{ $dy = $ty ^}
echo   ^}
echo   $prevX = $x
echo   $prevY = $y
echo ^}
echo if ^([double]::IsInfinity^($dx^) -or [double]::IsInfinity^($dy^)^) ^{
echo   throw "Could not infer regular longitude/latitude spacing."
echo ^}
echo $s = "{0:G17} {1:G17} {2:G17} {3:G17} {4:G17} {5:G17}" -f $minX,$maxX,$minY,$maxY,$dx,$dy
echo [System.IO.File]::WriteAllText^($OutputFile,$s,[System.Text.Encoding]::ASCII^)
)

powershell -NoProfile -ExecutionPolicy Bypass ^
    -File "%PSGRID%" ^
    -InputFile "!TXT1!" ^
    -OutputFile "%WORK%\grid_info.txt"

if errorlevel 1 (
    echo [ERROR] Could not infer TXT grid spacing.
    pause
    exit /b 1
)

if not exist "%WORK%\grid_info.txt" (
    echo [ERROR] grid_info.txt was not created.
    echo Please send me the PowerShell error above this message.
    pause
    exit /b 1
)

for /f "tokens=1-6" %%a in (%WORK%\grid_info.txt) do (
    set "XMIN=%%a"
    set "XMAX=%%b"
    set "YMIN=%%c"
    set "YMAX=%%d"
    set "DX=%%e"
    set "DY=%%f"
)

if "!XMIN!"=="" (
    echo [ERROR] Failed to parse XMIN from grid_info.txt.
    type "%WORK%\grid_info.txt"
    pause
    exit /b 1
)
if "!DX!"=="" (
    echo [ERROR] Failed to parse grid spacing from grid_info.txt.
    type "%WORK%\grid_info.txt"
    pause
    exit /b 1
)

echo TXT grid:
echo   X = !XMIN! / !XMAX!
echo   Y = !YMIN! / !YMAX!
echo   dX = !DX!
echo   dY = !DY!
echo.

set "GRID_R=-R!XMIN!/!XMAX!/!YMIN!/!YMAX!"
set "GRID_I=-I!DX!/!DY!"

REM 3. Rebuild the eight deformation grids from TXT

echo [1/8] Reconstructing cumulative deformation grids...

gmt xyz2grd "!TXT1!" !GRID_R! !GRID_I! -G"%WORK%\cum_201812.nc"
if errorlevel 1 goto :GridError
gmt xyz2grd "!TXT2!" !GRID_R! !GRID_I! -G"%WORK%\cum_201912.nc"
if errorlevel 1 goto :GridError
gmt xyz2grd "!TXT3!" !GRID_R! !GRID_I! -G"%WORK%\cum_202012.nc"
if errorlevel 1 goto :GridError
gmt xyz2grd "!TXT4!" !GRID_R! !GRID_I! -G"%WORK%\cum_202106.nc"
if errorlevel 1 goto :GridError
gmt xyz2grd "!TXT5!" !GRID_R! !GRID_I! -G"%WORK%\cum_202202.nc"
if errorlevel 1 goto :GridError
gmt xyz2grd "!TXT6!" !GRID_R! !GRID_I! -G"%WORK%\cum_202312.nc"
if errorlevel 1 goto :GridError
gmt xyz2grd "!TXT7!" !GRID_R! !GRID_I! -G"%WORK%\cum_202412.nc"
if errorlevel 1 goto :GridError
gmt xyz2grd "!TXT8!" !GRID_R! !GRID_I! -G"%WORK%\cum_202512.nc"
if errorlevel 1 goto :GridError

REM 4. DEM CPT
REM    Keep white lowlands light, make already-dark terrain darker.

set "DEM_CPT=%WORK%\dem_gray.cpt"

> "%DEM_CPT%" (
echo # COLOR_MODEL = RGB
echo -500 250/250/250 0    248/248/248
echo 0    248/248/248 100  242/242/242
echo 100  242/242/242 300  235/235/235
echo 300  235/235/235 600  220/220/220
echo 600  220/220/220 1000 198/198/198
echo 1000 198/198/198 1500 168/168/168
echo 1500 168/168/168 2500 132/132/132
echo 2500 132/132/132 4000 96/96/96
echo 4000 96/96/96 7000 68/68/68
echo B 250/250/250
echo F 62/62/62
echo N 255/255/255
)

REM 5. Cumulative deformation CPT
REM
REM Figure classes requested:
REM -130 to -57 : red
REM  -56 to -31 : orange
REM  -30 to -18 : yellow
REM  -17 to  -6 : yellow-green
REM   -5 to   5 : mint-green
REM    6 to  13 : cyan
REM   14 to  29 : blue
REM   30 to  93 : dark blue
REM
REM Data are continuous decimals, so mid-point class boundaries are used
REM internally to avoid artificial gaps between integer labels.

set "DEF_CPT=%WORK%\cumulative_discrete.cpt"

> "%DEF_CPT%" (
echo # COLOR_MODEL = RGB
echo -130.0 255/10/10     -56.5 255/10/10
echo -56.5  255/135/0     -30.5 255/135/0
echo -30.5  255/215/0     -17.5 255/215/0
echo -17.5  205/240/70    -5.5  205/240/70
echo -5.5   105/225/180    5.5  105/225/180
echo 5.5     45/195/225   13.5   45/195/225
echo 13.5    55/115/225   29.5   55/115/225
echo 29.5     0/35/200    93.0    0/35/200
echo B 255/10/10
echo F 0/35/200
echo N 255/255/255
)

REM 6. Five deformation zones

> "%WORK%\sub_zone1.txt" (
echo 113.460 34.660
echo 113.760 34.660
echo 113.760 34.840
echo 113.460 34.840
echo 113.460 34.660
)

> "%WORK%\sub_zone2.txt" (
echo 113.698 34.484
echo 113.871 34.484
echo 113.871 34.606
echo 113.698 34.606
echo 113.698 34.484
)

> "%WORK%\upl_zone1.txt" (
echo 112.777 34.709
echo 113.094 34.709
echo 113.094 34.891
echo 112.777 34.891
echo 112.777 34.709
)

> "%WORK%\upl_zone2.txt" (
echo 112.702 34.276
echo 112.942 34.276
echo 112.942 34.512
echo 112.702 34.512
echo 112.702 34.276
)

> "%WORK%\upl_zone3.txt" (
echo 113.893 34.583
echo 114.182 34.583
echo 114.182 34.971
echo 113.893 34.971
echo 113.893 34.583
)

> "%WORK%\zone_labels.txt" (
echo 113.468 34.850 Sub_zone1
echo 113.706 34.611 Sub_zone2
echo 112.785 34.898 Upl_zone1
echo 112.710 34.520 Upl_zone2
echo 113.900 34.980 Upl_zone3
)

REM 7. Yellow River label and north arrow

> "%WORK%\yellow_river_label.txt" (
echo 113.43 34.997 Yellow River
)

> "%WORK%\north_outer.txt" (
echo 114.205 35.055
echo 114.181 34.992
echo 114.205 35.012
echo 114.229 34.992
echo 114.205 35.055
)

> "%WORK%\north_black.txt" (
echo 114.205 35.055
echo 114.181 34.992
echo 114.205 35.012
echo 114.205 35.055
)

> "%WORK%\north_label.txt" (
echo 114.205 35.073 N
)

REM 8. Date labels

> "%WORK%\date_201812.txt" echo 112.615 35.055 2018-12
> "%WORK%\date_201912.txt" echo 112.615 35.055 2019-12
> "%WORK%\date_202012.txt" echo 112.615 35.055 2020-12
> "%WORK%\date_202106.txt" echo 112.615 35.055 2021-06
> "%WORK%\date_202202.txt" echo 112.615 35.055 2022-02
> "%WORK%\date_202312.txt" echo 112.615 35.055 2023-12
> "%WORK%\date_202412.txt" echo 112.615 35.055 2024-12
> "%WORK%\date_202512.txt" echo 112.615 35.055 2025-12

REM 9. Prepare DEM and terrain illumination

echo [2/8] Preparing DEM and hillshade...

gmt grdcut %DEM% %R% -G"%WORK%\dem_map.nc"
if errorlevel 1 (
    echo [ERROR] DEM preparation failed.
    pause
    exit /b 1
)

gmt grdgradient "%WORK%\dem_map.nc" ^
    -G"%WORK%\dem_bg_I.nc" ^
    -A315 -Ne0.16

REM Resample DEM to EXACT deformation grid geometry.
gmt grdsample "%WORK%\dem_map.nc" ^
    -R"%WORK%\cum_201812.nc" ^
    -G"%WORK%\dem_on_def.nc" ^
    -nl

gmt grdgradient "%WORK%\dem_on_def.nc" ^
    -G"%WORK%\def_drape_I.nc" ^
    -A315 -Ne0.34

REM 11. Draw 3x3 figure

echo [3/8] Drawing 3x3 figure...

pushd "%OUTDIR%"

gmt begin Zhengzhou_Cumulative_3x3_GMT_v10_axes_fixed png,pdf

    gmt set MAP_FRAME_TYPE plain
    gmt set MAP_FRAME_PEN 0.5p,black
    gmt set MAP_TICK_PEN_PRIMARY 0.5p,black
    gmt set MAP_TICK_LENGTH_PRIMARY 0.04c
    gmt set MAP_TICK_LENGTH_SECONDARY 0c
    gmt set FONT_ANNOT_PRIMARY 7p,Times-Roman
    gmt set FONT_LABEL 8p,Times-Roman
    gmt set GMT_GRAPHICS_DPU 600

    REM 面板间距 0.04c，让 3x3 网格保持紧凑
    gmt subplot begin 3x3 ^
        -Fs5.45c/4.05c ^
        -M0.04c/0.04c

        call :PlotPanel 0 0 "%WORK%\cum_201812.nc" "%WORK%\date_201812.txt" TL
        call :PlotPanel 0 1 "%WORK%\cum_201912.nc" "%WORK%\date_201912.txt" T
        call :PlotPanel 0 2 "%WORK%\cum_202012.nc" "%WORK%\date_202012.txt" T

        call :PlotPanel 1 0 "%WORK%\cum_202106.nc" "%WORK%\date_202106.txt" L
        call :PlotPanel 1 1 "%WORK%\cum_202202.nc" "%WORK%\date_202202.txt" N
        call :PlotPanel 1 2 "%WORK%\cum_202312.nc" "%WORK%\date_202312.txt" N

        call :PlotPanel 2 0 "%WORK%\cum_202412.nc" "%WORK%\date_202412.txt" L
        call :PlotPanel 2 1 "%WORK%\cum_202512.nc" "%WORK%\date_202512.txt" N

    gmt subplot end

gmt end show

popd

echo.
echo ============================================================
echo Finished.
echo PNG:
echo %OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v10_axes_fixed.png
echo.
echo PDF:
echo %OUTDIR%\Zhengzhou_Cumulative_3x3_GMT_v10_axes_fixed.pdf
echo ============================================================
pause
exit /b 0

REM Find TXT by YYYYMM
:FindTxt
set "%~2="
for %%F in ("%TXTDIR%\*%~1*.txt") do (
    if exist "%%~fF" (
        set "%~2=%%~fF"
        goto :eof
    )
)
goto :eof

:CheckFound
if not defined %~1 (
    echo [ERROR] TXT for %~2 was not found.
    echo Folder:
    echo %TXTDIR%
    pause
    exit /b 1
)
goto :eof

:GridError
echo [ERROR] xyz2grd failed while reconstructing TXT raster.
echo Please send me the first GMT error line above this message.
pause
exit /b 1

REM Plot one cumulative deformation panel
REM %1 row
REM %2 col
REM %3 cumulative grid
REM %4 date-label file
:PlotPanel

gmt subplot set %1,%2

REM IMPORTANT: In GMT subplot mode, the FIRST plotting command in
REM each panel establishes the frame.  Therefore the required -B
REM settings MUST be attached to this first grdimage command.
REM Otherwise GMT first creates its default annotated frame and a
REM later basemap adds a second frame, causing duplicate labels.
REM
REM TL : annotate TOP longitude + LEFT latitude
REM T  : annotate TOP longitude only
REM L  : annotate LEFT latitude only
REM N  : border only
REM
REM Uppercase W/N = annotations + ticks.
REM l/r/b/t        = border line only, no ticks, no annotations.
set "FRAME_AXES=lrtb"
if /I "%~5"=="TL" set "FRAME_AXES=WNbr"
if /I "%~5"=="T"  set "FRAME_AXES=Nlrb"
if /I "%~5"=="L"  set "FRAME_AXES=Wtrb"

REM DEM background + the ONLY geographic frame/annotations for this panel
gmt grdimage "%WORK%\dem_map.nc" %R% %J% ^
    -C"%DEM_CPT%" ^
    -I"%WORK%\dem_bg_I.nc" ^
    -Bxa0.5f0.1 -Bya0.25f0.05 ^
    -B!FRAME_AXES!

REM Yellow River under deformation
gmt coast %R% %J% -Df -A100 -I1/1.9p,30/105/225

REM Cumulative deformation draped on terrain
REM -Q = NaN transparent
REM -I = terrain illumination
REM -nn = nearest-neighbor image resampling, retaining discrete classes
REM -t12 = slight transparency so DEM texture remains visible
gmt grdimage "%~3" %R% %J% ^
    -C"%DEF_CPT%" ^
    -I"%WORK%\def_drape_I.nc" ^
    -Q ^
    -nn ^
    -t12

REM Replot Yellow River on top
gmt coast %R% %J% -Df -A100 -I1/1.65p,30/105/225

REM Zhengzhou boundary
gmt plot "%SHP%" %R% %J% -W0.80p,65/65/65

REM Five zones
gmt plot "%WORK%\sub_zone1.txt" %R% %J% -W0.80p,black,--
gmt plot "%WORK%\sub_zone2.txt" %R% %J% -W0.80p,black,--
gmt plot "%WORK%\upl_zone1.txt" %R% %J% -W0.80p,210/0/0,--
gmt plot "%WORK%\upl_zone2.txt" %R% %J% -W0.80p,210/0/0,--
gmt plot "%WORK%\upl_zone3.txt" %R% %J% -W0.80p,210/0/0,--

REM Zone labels (small offset upward to avoid overlapping zone lines)
gmt text "%WORK%\zone_labels.txt" %R% %J% ^
    -F+f6.5p,Times-Bold,black+jCM -D0c/0.12c

REM Date in upper-left
gmt text "%~4" %R% %J% ^
    -F+f8.7p,Times-Bold,black+jTL

REM Yellow River label
gmt text "%WORK%\yellow_river_label.txt" %R% %J% ^
    -F+f7.2p,Times-Italic,75/75/75+jCM+a-7

REM North arrow: ONLY in the first panel (0,0) to avoid clutter
if %1==0 if %2==0 (
    gmt plot "%WORK%\north_outer.txt" %R% %J% -Gwhite -W0.65p,black
    gmt plot "%WORK%\north_black.txt" %R% %J% -Gblack -W0.50p,black
    gmt text "%WORK%\north_label.txt" %R% %J% ^
        -F+f7.5p,Times-Bold,black+jCM
)

REM Geographic frame/annotations were already drawn by the FIRST
REM grdimage command above.  Do NOT call basemap with -B here, or
REM subplot axes may be duplicated.


goto :eof
