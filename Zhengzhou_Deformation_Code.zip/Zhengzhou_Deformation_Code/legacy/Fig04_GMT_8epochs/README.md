# Fig04_GMT_8epochs

Recovered cumulative-deformation map candidate. It plots eight epochs, whereas the revised manuscript has nine panels. Its date selection is preserved and is not claimed to reproduce the final layout. External cumulative XYZ files, study boundary and GMT are required.

These files are not invoked by the final-figure registry.

Available scripts:

- `plot_cumulative_3x3_GMT6_from_TXT_v10_axes_fixed.bat`
