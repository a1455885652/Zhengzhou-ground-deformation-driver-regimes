function values = load_mechanism_composition()
% Mean of location-wise normalized absolute SHAP contributions, in percent.
file = zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output/Python_Output/K4_Mechanism_Profile_Long.csv');
tbl = readtable(file, 'VariableNamingRule', 'preserve');
order = {'GWS','SurfaceRunoff','DEM','SkinReservoir','BuiltSurface', ...
    'SubsurfaceRunoff','GUM','TotalPrecipitation','NighttimeLight', ...
    'TotalLooseThickness','Silt','RoadDensity','NDVI','Population','GLHYMPS_Permeability'};
values = nan(4, numel(order));
for k = 1:4
    for j = 1:numel(order)
        mask = tbl.MechanismCluster == k & strcmp(string(tbl.Driver), order{j});
        assert(nnz(mask) == 1, 'Missing or duplicated mechanism/driver row.');
        values(k,j) = 100 * tbl.MeanComposition(mask);
    end
end
end
