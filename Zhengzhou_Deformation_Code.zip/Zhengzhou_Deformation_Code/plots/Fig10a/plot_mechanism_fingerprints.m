% Driver-composition fingerprints of the four mechanism types
% Improved journal-style heatmap

clear;
clc;
% Keep existing figure windows open.


% 1. Data

drivers = { ...
    'GWS', ...
    'Surface runoff', ...
    'DEM', ...
    'Skin reservoir', ...
    'Built surface', ...
    'Subsurface runoff', ...
    'GUM', ...
    'Total precipitation', ...
    'Nighttime light', ...
    'Loose-layer thickness', ...
    'Silt', ...
    'Road density', ...
    'NDVI', ...
    'Population', ...
    'Permeability'};

mechanisms = {'M1','M2','M3','M4'};

data = load_mechanism_composition();


% 2. Figure

fig = figure( ...
    'Color','w', ...
    'Units','centimeters', ...
    'Position',[2 2 32 12]);

ax = axes(fig);

imagesc(ax, data);

axis(ax,'tight');
axis(ax,'ij');

box(ax,'on');

ax.LineWidth = 1.2;
ax.TickDir = 'out';
ax.Layer = 'top';


% 3. Colormap

nColor = 256;

c1 = [247 251 255] / 255;
c2 = [198 219 239] / 255;
c3 = [107 174 214] / 255;
c4 = [33 113 181] / 255;
c5 = [8 48 107] / 255;

x0 = linspace(0,1,5);
xq = linspace(0,1,nColor);

cmap = zeros(nColor,3);

for k = 1:3
    cmap(:,k) = interp1( ...
        x0, ...
        [c1(k),c2(k),c3(k),c4(k),c5(k)], ...
        xq, ...
        'pchip');
end

cmap = max(0,min(1,cmap));

colormap(ax,cmap);

clim(ax,[0 32]);


% 4. Axis labels

ax.XTick = 1:numel(drivers);
ax.XTickLabel = drivers;

ax.YTick = 1:numel(mechanisms);
ax.YTickLabel = mechanisms;

ax.FontName = 'Times New Roman';

% Compared with the previous version, enlarged by ~5 pt
ax.FontSize = 16;

ax.XTickLabelRotation = 38;


xlabel(ax, ...
    'Driving factor', ...
    'FontName','Times New Roman', ...
    'FontSize',11, ...
    'FontWeight','normal');

ylabel(ax, ...
    'Mechanism type', ...
    'FontName','Times New Roman', ...
    'FontSize',11, ...
    'FontWeight','normal');


% 5. Title

title(ax, ...
    '(a) Driver-composition fingerprints of the four mechanism types', ...
    'FontName','Times New Roman', ...
    'FontSize',12, ...
    'FontWeight','bold');


% 6. Grid lines between cells

hold(ax,'on');

for x = 0.5:1:(size(data,2)+0.5)

    plot(ax, ...
        [x x], ...
        [0.5 size(data,1)+0.5], ...
        '-', ...
        'Color',[1 1 1 0.45], ...
        'LineWidth',0.6);

end

for y = 0.5:1:(size(data,1)+0.5)

    plot(ax, ...
        [0.5 size(data,2)+0.5], ...
        [y y], ...
        '-', ...
        'Color',[1 1 1 0.45], ...
        'LineWidth',0.6);

end


% 7. Numeric annotations

for i = 1:size(data,1)

    for j = 1:size(data,2)

        val = data(i,j);

        % Automatically switch text color
        if val >= 17
            txtColor = [1 1 1];
        else
            txtColor = [0.12 0.12 0.12];
        end

        text(ax, ...
            j, ...
            i, ...
            sprintf('%.1f',val), ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontName','Times New Roman', ...
            'FontSize',14, ...
            'FontWeight','normal', ...
            'Color',txtColor);

    end

end


% 8. Colorbar

cb = colorbar(ax);

cb.FontName = 'Times New Roman';
cb.FontSize = 12;

cb.LineWidth = 1.0;

cb.Ticks = 0:5:30;

cb.Label.String = ...
    'Mean relative |SHAP| contribution (%)';

cb.Label.FontName = 'Times New Roman';
cb.Label.FontSize = 12;
cb.Label.FontWeight = 'normal';


% 9. Fine layout

ax.Position = [ ...
    0.07, ...
    0.27, ...
    0.83, ...
    0.63];

cb.Position(1) = 0.915;
cb.Position(2) = 0.27;
cb.Position(3) = 0.018;
cb.Position(4) = 0.63;


% 10. Export

outDir = zz_figure_dir('Fig10a');
if ~isfolder(outDir), mkdir(outDir); end
exportgraphics( ...
    fig, ...
    fullfile(outDir,'(a) Fig10a_Mechanism_Fingerprints.png'), ...
    'Resolution',600);

exportgraphics( ...
    fig, ...
    fullfile(outDir,'Fig10a_Mechanism_Fingerprints.pdf'), ...
    'ContentType','vector');

fprintf('\nFinished.\n');
fprintf('PNG: Fig10a_Mechanism_Fingerprints.png\n');
fprintf('PDF: Fig10a_Mechanism_Fingerprints.pdf\n');
