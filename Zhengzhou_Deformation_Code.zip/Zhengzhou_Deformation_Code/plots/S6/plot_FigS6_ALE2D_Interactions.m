%% plot_FigS6_ALE2D_Interactions_Intuitive.m
% Fig. S6 - Representative two-dimensional ALE interaction surfaces
% More intuitive / publication-oriented version
%
% Key design:
%   1) Axes use the actual XCenter / YCenter values stored in each ALE2D CSV.
%   2) All panels share the same symmetric color scale.
%   3) Blue = toward uplift; Red = toward subsidence.
%   4) Gray blank regions = unsupported variable combinations.
%   5) A light dashed contour marks ALE = 0.
%
% Input directory:
%
% Output directory:

clear;
clc;
% Keep existing figure windows open.

% 1. Path settings

rootDir = zz_project_path('K4_ALE_Threshold_Interaction_Output_v1_5');

inputDir  = fullfile(rootDir, '02_Interactions', 'ALE2D');
outputDir = zz_figure_dir('S6');

if ~exist(inputDir, 'dir')
    error('Input directory does not exist:\n%s', inputDir);
end

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

% 2. File list and panel metadata

panelFiles = {
    'ALE2D_All__GWS__BuiltSurface.csv'
    'ALE2D_M1__GWS__BuiltSurface.csv'
    'ALE2D_M2__TotalPrecipitation__SurfaceRunoff.csv'
    'ALE2D_M3__SurfaceRunoff__SubsurfaceRunoff.csv'
    'ALE2D_M3__GWS__SurfaceRunoff.csv'
    'ALE2D_M4__SkinReservoir__BuiltSurface.csv'
    };

panelMainTitle = {
    '(a) All'
    '(b) M1'
    '(c) M2'
    '(d) M3'
    '(e) M3'
    '(f) M4'
    };

panelSubTitle = {
    'GWS × Built surface'
    'GWS × Built surface'
    'Total precipitation × Surface runoff'
    'Surface runoff × Subsurface runoff'
    'GWS × Surface runoff'
    'Skin reservoir × Built surface'
    };

xAxisLabel = {
    'GWS trend'
    'GWS trend'
    'Total precipitation trend'
    'Surface runoff trend'
    'GWS trend'
    'Skin reservoir trend'
    };

yAxisLabel = {
    'Built surface'
    'Built surface'
    'Surface runoff trend'
    'Subsurface runoff trend'
    'Surface runoff trend'
    'Built surface'
    };

nPanel = numel(panelFiles);

% 3. Read all panels and reconstruct 2D ALE grids

xValsCell = cell(nPanel,1);
yValsCell = cell(nPanel,1);
zGridCell = cell(nPanel,1);

allFiniteZ = [];

for i = 1:nPanel

    thisFile = fullfile(inputDir, panelFiles{i});

    if ~isfile(thisFile)
        error('Missing file:\n%s', thisFile);
    end

    T = readtable(thisFile, 'VariableNamingRule', 'preserve');

    requiredVars = {'XCenter', 'YCenter', 'ALE2D'};
    for j = 1:numel(requiredVars)
        if ~ismember(requiredVars{j}, T.Properties.VariableNames)
            error('Missing variable "%s" in file:\n%s', requiredVars{j}, thisFile);
        end
    end

    xVals = unique(T.XCenter, 'sorted');
    yVals = unique(T.YCenter, 'sorted');

    Z = nan(numel(yVals), numel(xVals));

    % Determine whether a cell is reliable enough to display
    if ismember('DisplaySupported', T.Properties.VariableNames)
        supportRaw = string(T.DisplaySupported);
        displaySupported = false(height(T),1);

        for k = 1:height(T)
            s = lower(strtrim(supportRaw(k)));
            if s == "true" || s == "1" || s == "yes"
                displaySupported(k) = true;
            end
        end
    else
        displaySupported = true(height(T),1);
    end

    for r = 1:height(T)

        [~, ix] = min(abs(xVals - T.XCenter(r)));
        [~, iy] = min(abs(yVals - T.YCenter(r)));

        if displaySupported(r) && isfinite(T.ALE2D(r))
            Z(iy, ix) = T.ALE2D(r);
        end
    end

    xValsCell{i} = xVals;
    yValsCell{i} = yVals;
    zGridCell{i} = Z;

    thisFinite = Z(isfinite(Z));
    if ~isempty(thisFinite)
        allFiniteZ = [allFiniteZ; thisFinite(:)]; %#ok<AGROW>
    end
end

if isempty(allFiniteZ)
    error('No finite ALE2D values were found.');
end

% 4. Shared color scale (robust, easier to read)
% Use the 98th percentile of |ALE| to avoid one or two extreme cells
% flattening the rest of the figure.

absZ = sort(abs(allFiniteZ));
nAbs = numel(absZ);
idx98 = max(1, round(0.98 * nAbs));
sharedCLim = absZ(idx98);

if sharedCLim <= 0
    sharedCLim = max(absZ);
end

if sharedCLim <= 0
    sharedCLim = 1;
end

% Round to a cleaner number
pow10v = 10^floor(log10(sharedCLim));
sharedCLim = ceil(sharedCLim / pow10v * 10) / 10 * pow10v;

% 5. Scientific diverging colormap

blueColor  = [49, 106, 174] / 255;
whiteColor = [1, 1, 1];
redColor   = [208, 55, 45] / 255;

nHalf = 128;

blueToWhite = [ ...
    linspace(blueColor(1),  whiteColor(1), nHalf)', ...
    linspace(blueColor(2),  whiteColor(2), nHalf)', ...
    linspace(blueColor(3),  whiteColor(3), nHalf)'  ...
    ];

whiteToRed = [ ...
    linspace(whiteColor(1), redColor(1), nHalf)', ...
    linspace(whiteColor(2), redColor(2), nHalf)', ...
    linspace(whiteColor(3), redColor(3), nHalf)'  ...
    ];

cmap = [blueToWhite; whiteToRed(2:end,:)];

% 6. Create figure

fig = figure( ...
    'Color', 'w', ...
    'Position', [60 40 1580 900], ...
    'Renderer', 'painters');

tl = tiledlayout(fig, 2, 3, ...
    'TileSpacing', 'compact', ...
    'Padding', 'compact');

ax = gobjects(nPanel,1);

for i = 1:nPanel

    ax(i) = nexttile(tl, i);
    hold(ax(i), 'on');

    xVals = xValsCell{i};
    yVals = yValsCell{i};
    Z     = zGridCell{i};

    nX = numel(xVals);
    nY = numel(yVals);

    % Plot in the original model-input coordinates. The ALE2D bins may be
    % unevenly spaced, so rank coordinates would distort the axis meaning.
    [XGrid, YGrid] = meshgrid(xVals, yVals);

    % Gray background = unsupported / insufficiently represented combinations
    ax(i).Color = [0.93 0.93 0.93];

    % Filled contours in the actual ALE2D bin-center coordinates
    contourf(ax(i), XGrid, YGrid, Z, 20, 'LineStyle', 'none');

    % Light zero contour: easier to read than thick black boundary-like lines
    zMin = min(Z(:), [], 'omitnan');
    zMax = max(Z(:), [], 'omitnan');

    if isfinite(zMin) && isfinite(zMax) && zMin < 0 && zMax > 0
        contour(ax(i), XGrid, YGrid, Z, [0 0], ...
            'LineColor', [0.20 0.20 0.20], ...
            'LineStyle', '--', ...
            'LineWidth', 0.8);
    end

    caxis(ax(i), [-sharedCLim, sharedCLim]);

    % Three representative ticks selected from the saved ALE2D bin centers.
    % Labels contain only actual numeric values; no Low/Median/High relabeling.
    xTickIndex = unique(round(linspace(1, nX, min(3,nX))));
    yTickIndex = unique(round(linspace(1, nY, min(3,nY))));

    xTickValues = xVals(xTickIndex);
    yTickValues = yVals(yTickIndex);

    xTickLab = arrayfun(@(v) sprintf('%.4g',v), ...
        xTickValues, 'UniformOutput', false);
    yTickLab = arrayfun(@(v) sprintf('%.4g',v), ...
        yTickValues, 'UniformOutput', false);

    set(ax(i), ...
        'XTick', xTickValues, ...
        'XTickLabel', xTickLab, ...
        'YTick', yTickValues, ...
        'YTickLabel', yTickLab, ...
        'FontName', 'Arial', ...
        'FontSize', 9.3, ...
        'LineWidth', 0.85, ...
        'TickDir', 'out', ...
        'Box', 'on', ...
        'Layer', 'top');

    xlabel(ax(i), xAxisLabel{i}, ...
        'FontName', 'Arial', ...
        'FontSize', 10.5);

    ylabel(ax(i), yAxisLabel{i}, ...
        'FontName', 'Arial', ...
        'FontSize', 10.5);

    title(ax(i), ...
        {panelMainTitle{i}, panelSubTitle{i}}, ...
        'FontName', 'Arial', ...
        'FontSize', 11, ...
        'FontWeight', 'bold');

    axis(ax(i), 'tight');
end

colormap(fig, cmap);

% 7. Shared colorbar

cb = colorbar(ax(end));
cb.Layout.Tile = 'east';
cb.FontName = 'Arial';
cb.FontSize = 9.5;
cb.LineWidth = 0.8;
cb.Label.String = 'Joint 2D ALE effect on deformation';
cb.Label.FontName = 'Arial';
cb.Label.FontSize = 11;

cb.Ticks = [-sharedCLim, 0, sharedCLim];

% 8. Figure-level annotations

sgtitle(tl, ...
    'Representative two-dimensional ALE interaction surfaces', ...
    'FontName', 'Arial', ...
    'FontSize', 15, ...
    'FontWeight', 'bold');

annotation(fig, 'textbox', [0.84 0.86 0.14 0.05], ...
    'String', 'Toward subsidence', ...
    'LineStyle', 'none', ...
    'FontName', 'Arial', ...
    'FontSize', 10, ...
    'FontWeight', 'bold', ...
    'Color', redColor, ...
    'HorizontalAlignment', 'center');

annotation(fig, 'textbox', [0.84 0.09 0.14 0.05], ...
    'String', 'Toward uplift', ...
    'LineStyle', 'none', ...
    'FontName', 'Arial', ...
    'FontSize', 10, ...
    'FontWeight', 'bold', ...
    'Color', blueColor, ...
    'HorizontalAlignment', 'center');

annotation(fig, 'textbox', [0.16 0.005 0.70 0.05], ...
    'String', ['Gray areas indicate unsupported or sparsely sampled variable combinations; ', ...
               'the dashed contour denotes zero ALE effect. Axis ticks are actual ALE2D ', ...
               'bin-center values on the model-input scale; dynamic variables are trend features.'], ...
    'LineStyle', 'none', ...
    'FontName', 'Arial', ...
    'FontSize', 9.5, ...
    'Color', [0.25 0.25 0.25], ...
    'HorizontalAlignment', 'center');

% 9. Export

outStem = fullfile(outputDir, 'FigS6_ALE2D_Interactions');

exportgraphics(fig, [outStem '.png'], 'Resolution', 600);
exportgraphics(fig, [outStem '.tif'], 'Resolution', 600);
exportgraphics(fig, [outStem '.pdf'], 'ContentType', 'vector');

fprintf('\nFinished.\n');
fprintf('Output files:\n%s.png\n%s.tif\n%s.pdf\n', outStem, outStem, outStem);
