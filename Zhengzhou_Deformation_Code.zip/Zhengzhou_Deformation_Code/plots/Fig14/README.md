# 图 14

曲线带是逐点 95% ALE 区间，垂直阴影是固定模型的 95% 转折区间；纵轴保留形变速率单位。

输入：ALE_Threshold_Breakpoints.csv 与 Curves/ALE_*.csv。具体路径相对于 `config/paths.json` 中的 `project_root`。

在代码包根目录的 MATLAB 中调用：

```matlab
run_figure('Fig14')
```

也可使用根目录的 `run.py figure <图号>`。MATLAB 图需要本机安装 MATLAB；Python 图由统一配置指定的解释器执行。

输出位于 `figure_output` 对应子目录。目录和现稿编号对照见 `../../docs/FIGURES.md`。单位标签不承担数据单位换算。
