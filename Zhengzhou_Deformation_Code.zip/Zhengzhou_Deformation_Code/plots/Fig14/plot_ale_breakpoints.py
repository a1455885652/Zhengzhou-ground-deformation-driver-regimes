"""Plot representative ALE responses and bootstrap breakpoint intervals."""

from __future__ import annotations
import argparse
import csv
import json
import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "runtime"))
from zz_paths import project_path, figure_path, show_figures, REPOSITORY
from zz_plotting import save_figure


def draw(root: Path, output: Path):
    bp = list(csv.DictReader((root / "ALE_Threshold_Breakpoints.csv").open()))
    plt.rcParams.update(
        {
            "font.family": "DejaVu Serif",
            "font.size": 10,
            "axes.titlesize": 12,
            "axes.labelsize": 10,
            "axes.linewidth": 0.75,
            "pdf.fonttype": 42,
            "savefig.facecolor": "white",
        }
    )
    fig, axes = plt.subplots(2, 2, figsize=(10.7, 7.9))
    fig.subplots_adjust(
        left=0.09, right=0.98, bottom=0.16, top=0.94, wspace=0.25, hspace=0.43
    )
    pairs = [
        ("M1", "GWS", "GWS", "mm"),
        ("M2", "SkinReservoir", "Skin reservoir", "mm"),
        ("M3", "SubsurfaceRunoff", "Subsurface runoff", "m"),
        ("M4", "TotalPrecipitation", "Total precipitation", "m"),
    ]
    units = json.loads((REPOSITORY / "config/feature_units.json").read_text())
    colors = ["#4477AA", "#D99725", "#55A868", "#9961BD"]
    red = "#B81F1F"
    for i, (ax, (region, driver, label, unit)) in enumerate(zip(axes.flat, pairs)):
        unit = units[driver]["plot_base_unit"]
        rows = list(
            csv.DictReader((root / "Curves" / f"ALE_{region}_{driver}.csv").open())
        )
        x, y, lo, hi = [
            np.array([float(r[c]) for r in rows])
            for c in ["XCenter", "ALE", "CI95_Low", "CI95_High"]
        ]
        dy = np.max(hi) - np.min(lo)
        yr = (np.min(lo) - 0.1 * dy, np.max(hi) + 0.29 * dy)
        bb = sorted(
            [r for r in bp if r["Region"] == region and r["Driver"] == driver],
            key=lambda r: int(r["BreakpointIndex"]),
        )
        for b in bb:
            l, h = float(b["FixedCI95_Low"]), float(b["FixedCI95_High"])
            if h > l:
                ax.axvspan(l, h, color=red, alpha=0.08, zorder=0, lw=0)
        ax.fill_between(x, lo, hi, color=colors[i], alpha=0.18, lw=0)
        ax.plot(x, y, "-o", color=colors[i], lw=1.6, ms=3.3, mec="white", mew=0.5)
        ax.axhline(0, color=".55", ls=":", lw=0.65)
        for j, b in enumerate(bb):
            v = float(b["Threshold"])
            ax.axvline(v, color=red, ls="--", lw=1)
            val = f"{v:.2f}" if i == 0 else f"{v:.3g}"
            # An arrow connects each label to its own breakpoint, preventing ambiguity.
            ypos = yr[1] - (0.065 + 0.125 * j) * (yr[1] - yr[0])
            ax.annotate(
                rf"$b_{{{int(b['BreakpointIndex'])}}}$ = {val}",
                xy=(v, ypos - 0.06 * (yr[1] - yr[0])),
                xytext=(v, ypos),
                ha="center",
                va="top",
                fontsize=9,
                color=red,
                arrowprops={"arrowstyle": "-", "lw": 0.6, "color": red},
            )
        ax.set(
            xlim=(x.min(), x.max()),
            ylim=yr,
            xlabel=rf"{label} trend ({unit} yr$^{{-1}}$)",
            ylabel=r"ALE effect (mm yr$^{-1}$)",
        )
        ax.set_title(
            f"({chr(97 + i)}) {region} – {label}", loc="left", fontweight="bold"
        )
        if i in [1, 2]:
            ax.ticklabel_format(
                axis="x", style="sci", scilimits=(-3, 3), useMathText=True
            )
    handles = [
        Line2D([], [], color=".3", marker="o", lw=1.6, ms=3.5),
        Patch(fc="#668099", alpha=0.18),
        Line2D([], [], color=red, ls="--", lw=1),
        Patch(fc=red, alpha=0.08),
    ]
    fig.legend(
        handles,
        ["ALE response", "Pointwise 95% ALE CI", "Breakpoint", "95% breakpoint CI"],
        loc="lower center",
        ncol=2,
        frameon=False,
        bbox_to_anchor=(0.5, 0.02),
    )
    save_figure(fig, output, "Fig14_ALE_Breakpoints")
    return fig


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=project_path("K4_ALE_Threshold_Interaction_Output_v1_5/01_Thresholds"),
    )
    parser.add_argument("--output-dir", type=Path, default=figure_path("Fig14"))
    args = parser.parse_args()
    draw(args.input_dir, args.output_dir)
    if show_figures():
        plt.show(block=True)


if __name__ == "__main__":
    main()
