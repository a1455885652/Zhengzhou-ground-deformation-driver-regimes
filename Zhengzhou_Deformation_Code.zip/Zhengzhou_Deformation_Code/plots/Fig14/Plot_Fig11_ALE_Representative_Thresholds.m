function Plot_Fig11_ALE_Representative_Thresholds()
% Compatibility entry for the final Fig14 implementation.
run_figure('Fig14');
end
