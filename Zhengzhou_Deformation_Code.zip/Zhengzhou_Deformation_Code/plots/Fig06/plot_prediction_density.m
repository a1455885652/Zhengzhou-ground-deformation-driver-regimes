%  Publication-quality XGBoost Observed vs Predicted density scatter plot
%
%  Recommended for manuscript:
%     - Original test samples only
%     - No artificial sample interpolation
%     - Smooth 2-D density background
%     - True samples overlaid
%     - 1:1 line
%     - Linear regression line
%     - R2 / RMSE / MAE / Bias / Pearson R
%

clear;
clc;
% Keep existing figure windows open.

%  1. File paths

inputFile = ...
    zz_project_path('XGBoost_SHAP_Latest1km_ReferenceSimple_Output/Python_Output/Test_Predictions.csv');

outputDir = zz_figure_dir('Fig06');

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

%  2. Read test results

T = readtable(inputFile);

observed  = double(T.Target);
predicted = double(T.Prediction);

valid = isfinite(observed) & isfinite(predicted);

observed  = observed(valid);
predicted = predicted(valid);

%  3. Accuracy statistics

residual = predicted - observed;

SSres = sum(residual.^2);
SStot = sum((observed - mean(observed)).^2);

R2   = 1 - SSres / SStot;
RMSE = sqrt(mean(residual.^2));
MAE  = mean(abs(residual));
Bias = mean(residual);

C = corrcoef(observed, predicted);
PearsonR = C(1,2);

fprintf('R2        = %.4f\n', R2);
fprintf('RMSE      = %.4f mm/yr\n', RMSE);
fprintf('MAE       = %.4f mm/yr\n', MAE);
fprintf('Bias      = %.4f mm/yr\n', Bias);
fprintf('Pearson R = %.4f\n\n', PearsonR);

%  4. Common plotting limits

allValue = [observed; predicted];

rawMin = min(allValue);
rawMax = max(allValue);

dataRange = rawMax - rawMin;

plotMin = rawMin - 0.045 * dataRange;
plotMax = rawMax + 0.045 * dataRange;

% Cleaner axis limits
plotMin = floor(plotMin / 5) * 5;
plotMax = ceil(plotMax / 5) * 5;

%  5. Build high-resolution 2-D density field
%
%  Important:
%  This does NOT generate new observations.
%  It only estimates the visual density of the real observations.

nBins = 150;

edgesX = linspace(plotMin, plotMax, nBins + 1);
edgesY = linspace(plotMin, plotMax, nBins + 1);

% 2-D histogram
H = histcounts2(observed, predicted, edgesX, edgesY);

% histcounts2:
% rows = X bins
% cols = Y bins
% transpose for plotting
H = H';

%  6. Smooth density field with Gaussian kernel
%
%  Implemented manually using conv2, therefore no Image Processing
%  Toolbox is required.

sigma = 2.2;
kernelHalfSize = 7;

[xKernel, yKernel] = meshgrid( ...
    -kernelHalfSize:kernelHalfSize, ...
    -kernelHalfSize:kernelHalfSize);

G = exp(-(xKernel.^2 + yKernel.^2) / (2 * sigma^2));

G = G ./ sum(G(:));

Hdensity = conv2(H, G, 'same');

% Nonlinear enhancement:
% Makes low-density regions more visible without changing samples
HdensityDisplay = log1p(Hdensity);

% Empty/background areas -> NaN
HdensityDisplay(HdensityDisplay <= 0) = NaN;

%  7. Grid centres

xCenter = (edgesX(1:end-1) + edgesX(2:end)) / 2;
yCenter = (edgesY(1:end-1) + edgesY(2:end)) / 2;

%  8. Regression

p = polyfit(observed, predicted, 1);

xFit = linspace(plotMin, plotMax, 500);
yFit = polyval(p, xFit);

%  9. Figure

fig = figure( ...
    'Color', 'w', ...
    'Units', 'centimeters', ...
    'Position', [5 4 15.2 13.2], ...
    'Renderer', 'painters');

ax = axes(fig);

hold(ax, 'on');

%  10. Density background

hDensity = imagesc( ...
    ax, ...
    xCenter, ...
    yCenter, ...
    HdensityDisplay);

set(ax, 'YDir', 'normal');

% Transparent density layer
alphaData = HdensityDisplay;

alphaData = alphaData ./ max(alphaData(:), [], 'omitnan');

% Make weak-density pixels more transparent
alphaData = alphaData.^0.70;

alphaData(isnan(alphaData)) = 0;

set(hDensity, ...
    'AlphaData', 0.72 .* alphaData);

%  11. Publication-style colormap
%
%  White -> light blue -> cyan -> yellow -> orange -> dark red

c1 = [255 255 255] ./ 255;
c2 = [218 235 247] ./ 255;
c3 = [158 202 225] ./ 255;
c4 = [107 174 214] ./ 255;
c5 = [49 130 189] ./ 255;
c6 = [253 219 118] ./ 255;
c7 = [253 141 60] ./ 255;
c8 = [215 48 31] ./ 255;
c9 = [103 0 31] ./ 255;

baseMap = [
    c1
    c2
    c3
    c4
    c5
    c6
    c7
    c8
    c9
];

xBase = linspace(0, 1, size(baseMap,1));
xFine = linspace(0, 1, 256);

customMap = interp1( ...
    xBase, ...
    baseMap, ...
    xFine, ...
    'pchip');

customMap(customMap < 0) = 0;
customMap(customMap > 1) = 1;

colormap(ax, customMap);

%  12. True observations
%
%  These are the REAL samples.
%  Small semi-transparent points make the distribution visually smoother.

scatter( ...
    ax, ...
    observed, ...
    predicted, ...
    7, ...
    [0.12 0.20 0.28], ...
    'filled', ...
    'MarkerFaceAlpha', 0.20, ...
    'MarkerEdgeAlpha', 0);

%  13. 1:1 reference line

hOne = plot( ...
    ax, ...
    [plotMin plotMax], ...
    [plotMin plotMax], ...
    '--', ...
    'Color', [0.15 0.15 0.15], ...
    'LineWidth', 1.35);

%  14. Regression line

hFit = plot( ...
    ax, ...
    xFit, ...
    yFit, ...
    '-', ...
    'Color', [0.75 0.08 0.10], ...
    'LineWidth', 1.85);

%  15. Axis formatting

xlim(ax, [plotMin plotMax]);
ylim(ax, [plotMin plotMax]);

axis(ax, 'square');

xlabel( ...
    ax, ...
    'Observed deformation rate (mm/yr)', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 11.5);

ylabel( ...
    ax, ...
    'Predicted deformation rate (mm/yr)', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 11.5);

set(ax, ...
    'FontName', 'Times New Roman', ...
    'FontSize', 10.5, ...
    'LineWidth', 0.85, ...
    'TickDir', 'out', ...
    'TickLength', [0.018 0.018], ...
    'Box', 'on', ...
    'Layer', 'top');

%  16. Grid

grid(ax, 'on');

ax.GridColor = [0.65 0.65 0.65];
ax.GridAlpha = 0.12;
ax.GridLineStyle = '-';

%  17. Regression equation

if p(2) >= 0
    eqText = sprintf( ...
        '\\ity\\rm = %.3f\\itx\\rm + %.3f', ...
        p(1), p(2));
else
    eqText = sprintf( ...
        '\\ity\\rm = %.3f\\itx\\rm - %.3f', ...
        p(1), abs(p(2)));
end

text( ...
    ax, ...
    0.045, ...
    0.950, ...
    eqText, ...
    'Units', 'normalized', ...
    'HorizontalAlignment', 'left', ...
    'VerticalAlignment', 'top', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 20, ...
    'FontWeight', 'bold', ...
    'Color', [0.10 0.10 0.10]);

%  18. Statistics box

metricsText = sprintf([ ...
    '\\itR\\rm^2 = %.3f\n' ...
    'RMSE = %.2f mm/yr\n' ...
    'MAE = %.2f mm/yr\n' ...
    'Bias = %.2f mm/yr\n' ...
    '\\itR\\rm = %.3f'], ...
    R2, RMSE, MAE, Bias, PearsonR);

text( ...
    ax, ...
    0.955, ...
    0.055, ...
    metricsText, ...
    'Units', 'normalized', ...
    'HorizontalAlignment', 'right', ...
    'VerticalAlignment', 'bottom', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 20, ...
    'FontWeight', 'bold', ...
    'Color', [0.08 0.08 0.08], ...
    'BackgroundColor', [1 1 1], ...
    'EdgeColor', [0.65 0.65 0.65], ...
    'LineWidth', 0.9, ...
    'Margin', 8);

%  19. Legend

lgd = legend( ...
    ax, ...
    [hOne, hFit], ...
    {'1:1 line', 'Linear fit'}, ...
    'Location', 'northwest');

set(lgd, ...
    'FontName', 'Times New Roman', ...
    'FontSize', 9.3, ...
    'Box', 'off');

%  20. Optional density colorbar
%
%  I recommend NOT showing the colorbar in the final main-text figure,
%  because density only serves visual presentation.
%
%  To show it, uncomment the following block.

% cb = colorbar(ax);
% cb.Label.String = 'Sample density';
% cb.Label.FontName = 'Times New Roman';
% cb.Label.FontSize = 10;
% cb.FontName = 'Times New Roman';
% cb.FontSize = 9;

%  21. Export

pngFile = fullfile( ...
    outputDir, ...
    'Fig06b_Observed_Predicted.png');

tifFile = fullfile( ...
    outputDir, ...
    'Fig06b_Observed_Predicted.tif');

pdfFile = fullfile( ...
    outputDir, ...
    'Fig06b_Observed_Predicted.pdf');

exportgraphics( ...
    fig, ...
    pngFile, ...
    'Resolution', 600);

exportgraphics( ...
    fig, ...
    tifFile, ...
    'Resolution', 600);

exportgraphics( ...
    fig, ...
    pdfFile, ...
    'ContentType', 'vector');

fprintf('\n============================================================\n');
fprintf('Finished.\n\n');

fprintf('PNG:\n%s\n\n', pngFile);
fprintf('TIFF:\n%s\n\n', tifFile);
fprintf('PDF:\n%s\n', pdfFile);

fprintf('============================================================\n');
