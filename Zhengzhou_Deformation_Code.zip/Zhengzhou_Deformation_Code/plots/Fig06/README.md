# 图 6

分别输出累计排序比例图和观测—预测密度散点图。

输入：模型 Python_Output/Test_Predictions.csv。具体路径相对于 `config/paths.json` 中的 `project_root`。

在代码包根目录的 MATLAB 中调用：

```matlab
run_figure('Fig06')
```

也可使用根目录的 `run.py figure <图号>`。MATLAB 图需要本机安装 MATLAB；Python 图由统一配置指定的解释器执行。

输出位于 `figure_output` 对应子目录。目录和现稿编号对照见 `../../docs/FIGURES.md`。单位标签不承担数据单位换算。
