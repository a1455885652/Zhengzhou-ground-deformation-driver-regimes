function varName = findVarName(T, candidates)
vars = T.Properties.VariableNames;
varName = '';
for i = 1:numel(candidates)
    idx = find(strcmpi(vars,candidates{i}),1);
    if ~isempty(idx)
        varName = vars{idx};
        return;
    end
end
error('未找到需要的列名。');
end
