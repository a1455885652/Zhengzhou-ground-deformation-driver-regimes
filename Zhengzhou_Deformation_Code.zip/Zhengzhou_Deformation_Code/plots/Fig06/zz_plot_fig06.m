function zz_plot_fig06()
plot_ordered_predictions();
zz_invoke('plot_prediction_density',false);
fprintf('Two component figures were exported. Assemble them as in manuscript Fig. 6.\n');
end
