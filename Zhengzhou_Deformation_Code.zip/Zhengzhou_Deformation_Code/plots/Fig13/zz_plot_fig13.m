function zz_plot_fig13()
cfg = get_temporal_lag_paper_config();
if ~isfolder(cfg.outputDir), mkdir(cfg.outputDir); end
T = load_temporal_lag_summary(cfg);
plot_fig_temporal_lag_overview(T, cfg);
end
