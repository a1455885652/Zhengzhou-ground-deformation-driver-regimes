"""Plot hydrologic lag estimates, discovery windows and phase-quality fractions."""

from __future__ import annotations
import argparse
import csv
import datetime
import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "runtime"))
from zz_paths import project_path, figure_path, show_figures
from zz_plotting import save_figure


def draw(root: Path, output: Path):
    rs = list(
        csv.DictReader(
            (
                root
                / "M124_HydrologicLag_SpatialHoldout_Output/FINAL_M124_HYDROLOGIC_HOLDOUT_INFERENCE.csv"
            ).open()
        )
    )
    rs3 = list(
        csv.DictReader(
            (
                root
                / "M3_Runoff_SpatialHoldout_Output/FINAL_M3_RUNOFF_HOLDOUT_INFERENCE.csv"
            ).open()
        )
    )
    for r in rs3:
        r["Mechanism"] = "3"
    data = {(r["Mechanism"], r["Driver"]): r for r in rs + rs3}
    pairs = [
        ("2", "SkinReservoir", "Skin reservoir", True),
        ("3", "SubsurfaceRunoff", "Subsurface runoff", True),
        ("3", "SurfaceRunoff", "Surface runoff", False),
        ("4", "TotalPrecipitation", "Total precipitation", True),
        ("4", "SkinReservoir", "Skin reservoir", False),
    ]
    colors = {"2": "#4477AA", "3": "#D47523", "4": "#328366"}
    plt.rcParams.update(
        {
            "font.family": "DejaVu Serif",
            "font.size": 9,
            "axes.titlesize": 10,
            "axes.labelsize": 9,
            "pdf.fonttype": 42,
        }
    )
    fig, axs = plt.subplots(
        1, 3, figsize=(12.9, 4.65), gridspec_kw={"width_ratios": [1.0, 1.03, 1.04]}
    )
    fig.subplots_adjust(left=0.20, right=0.985, bottom=0.25, top=0.84, wspace=0.18)
    labels = []
    for i, (m, d, n, sel) in enumerate(pairs):
        y = len(pairs) - 1 - i
        r = data[(m, d)]
        c = colors[m]
        labels.append(f"M{m} – {n}")
        lag, lo, hi = [
            float(r[k])
            for k in ["ValidationMedianLagMonths", "LagCI95_Low", "LagCI95_High"]
        ]
        axs[0].errorbar(
            lag,
            y,
            xerr=np.array([[lag - lo], [hi - lag]]),
            fmt="o",
            ms=5.8,
            mfc=c if sel else "white",
            mec=c,
            ecolor=c,
            capsize=3,
            elinewidth=1.1,
        )
        start, end = [
            datetime.datetime.strptime(r[k], "%Y-%m-%d")
            for k in ["DiscoveryStartMonth", "DiscoveryEndMonth"]
        ]
        axs[1].plot([start, end], [y, y], color=c, lw=3, solid_capstyle="round")
        axs[1].text(
            end,
            y - 0.20,
            f"{float(r['DiscoveryPeriodMinMonths']):.1f}–{float(r['DiscoveryPeriodMaxMonths']):.1f} mo",
            ha="right",
            va="top",
            fontsize=7,
        )
        quality = 100 * float(r["ValidationSupportFraction"])
        lead = 100 * float(r["ValidationLeadFraction"])
        axs[2].plot([lead, quality], [y, y], color=".6", lw=0.7)
        axs[2].plot(quality, y, "o", mfc=c, mec=c, ms=5.5)
        axs[2].plot(lead, y, "s", mfc="white", mec=c, ms=4.5)
    for ax in axs:
        ax.set_ylim(-0.65, 4.55)
        ax.grid(axis="x", color=".90", lw=0.6)
        ax.set_yticks(range(5))
        ax.tick_params(axis="y", length=0)
        for spine in ax.spines.values():
            spine.set_linewidth(0.6)
    axs[0].set_yticklabels(labels[::-1])
    axs[0].set_xlim(0, 1.22)
    axs[0].axvline(0, color=".5", ls=":", lw=0.7)
    axs[0].set_xlabel("Validation median lag (months)")
    axs[1].set_yticklabels([])
    axs[1].set_xlim(datetime.datetime(2019, 1, 1), datetime.datetime(2024, 6, 1))
    axs[1].xaxis.set_major_locator(mdates.YearLocator())
    axs[1].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    axs[1].set_xlabel("Discovery window and period band")
    axs[2].set_yticklabels([])
    axs[2].set_xlim(68, 102)
    axs[2].set_xticks([70, 80, 90, 100])
    axs[2].set_xlabel("Validation-block phase metrics (%)")
    for ax, title in zip(
        axs,
        [
            "(a) Lag estimate",
            "(b) Locked discovery window",
            "(c) Phase-quality and lead fractions",
        ],
    ):
        ax.set_title(title, pad=10)
    axs[0].legend(
        [
            Line2D([], [], color=".35", lw=1),
            Line2D([], [], marker="o", mfc=".35", mec=".35", ls=""),
            Line2D([], [], marker="o", mfc="white", mec=".35", ls=""),
        ],
        [
            "95% bootstrap interval",
            "Selected relationships",
            "Other displayed relationships",
        ],
        loc="upper center",
        bbox_to_anchor=(0.5, -0.21),
        frameon=False,
        fontsize=8,
    )
    axs[2].legend(
        [
            Line2D([], [], marker="o", mfc=".35", mec=".35", ls=""),
            Line2D([], [], marker="s", mfc="white", mec=".35", ls=""),
        ],
        ["Quality-passing / valid blocks", "Driver-leading / quality-passing blocks"],
        loc="upper center",
        bbox_to_anchor=(0.5, -0.21),
        frameon=False,
        fontsize=8,
    )
    save_figure(fig, output, "Fig13_Hydrologic_Lags")
    return fig


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, default=project_path())
    parser.add_argument("--output-dir", type=Path, default=figure_path("Fig13"))
    args = parser.parse_args()
    draw(args.input_root, args.output_dir)
    if show_figures():
        plt.show(block=True)


if __name__ == "__main__":
    main()
