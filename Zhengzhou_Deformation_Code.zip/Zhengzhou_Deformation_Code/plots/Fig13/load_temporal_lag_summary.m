function T = load_temporal_lag_summary(cfg)

fileM124 = fullfile(cfg.m124Dir, 'FINAL_M124_HYDROLOGIC_HOLDOUT_INFERENCE.csv');
T124 = readtable(fileM124, 'TextType', 'string');
T124.MechanismLabel = "M" + string(T124.Mechanism);
T124.Source = repmat("M124", height(T124), 1);

fileM3 = fullfile(cfg.m3Dir, 'FINAL_M3_RUNOFF_HOLDOUT_INFERENCE.csv');
T3 = readtable(fileM3, 'TextType', 'string');
T3.Mechanism = repmat(3, height(T3), 1);
T3.MechanismLabel = repmat("M3", height(T3), 1);
T3.Family = repmat("TargetedValidation", height(T3), 1);
T3.WithinMechanismAdjustedP = T3.HolmP;
T3.GlobalCoreHolmP = nan(height(T3), 1);
T3.Source = repmat("M3", height(T3), 1);

neededVars = { ...
    'Mechanism','MechanismLabel','Driver','Family', ...
    'DiscoveryClusterP','DiscoveryStartMonth','DiscoveryEndMonth', ...
    'DiscoveryPeriodMinMonths','DiscoveryPeriodMaxMonths', ...
    'DiscoveryLagMonths','ValidationLeadP','WithinMechanismAdjustedP', ...
    'GlobalCoreHolmP','ValidationNBlocks','ValidationNSupport', ...
    'ValidationSupportFraction','ValidationPhaseConcentration', ...
    'ValidationLeadFraction','ValidationMedianLagMonths', ...
    'LagCI95_Low','LagCI95_High','LagCI90_Low','LagCI90_High', ...
    'DiscoveryValidationLagDifference','ClaimClass','Source'};

T124 = T124(:, neededVars);
T3   = T3(:, neededVars);

T = [T124; T3];

end
