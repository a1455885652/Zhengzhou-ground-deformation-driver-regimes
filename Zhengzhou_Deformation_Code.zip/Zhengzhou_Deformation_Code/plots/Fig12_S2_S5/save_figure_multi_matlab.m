function save_figure_multi_matlab(fig, outStem)

exportgraphics(fig, [outStem '.png'], 'Resolution', 600);
exportgraphics(fig, [outStem '.pdf'], 'ContentType', 'vector');
exportgraphics(fig, [outStem '.tif'], 'Resolution', 600);

end
