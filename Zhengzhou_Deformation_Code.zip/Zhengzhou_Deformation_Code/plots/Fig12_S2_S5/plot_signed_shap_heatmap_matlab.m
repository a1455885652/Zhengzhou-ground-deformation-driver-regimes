function plot_signed_shap_heatmap_matlab(tblSHAP, outDir)

driverOrder = { ...
    'GWS', 'SurfaceRunoff', 'SkinReservoir', ...
    'SubsurfaceRunoff', 'TotalPrecipitation', ...
    'BuiltSurface', 'NighttimeLight', ...
    'RoadDensity', 'Population', ...
    'DEM', 'GUM', 'TotalLooseThickness', ...
    'Silt', 'GLHYMPS_Permeability', ...
    'NDVI'};

groupNames = { ...
    'Hydrological', ...
    'Urbanization', ...
    'Terrain-geology', ...
    'Vegetation'};

groupSizes = [5 4 5 1];

tblSHAP = sortrows(tblSHAP, 'MechanismCluster', 'ascend');

data = nan(4, numel(driverOrder));

for j = 1:numel(driverOrder)
    varName = driverOrder{j};
    if ismember(varName, tblSHAP.Properties.VariableNames)
        data(:, j) = tblSHAP.(varName);
    else
        warning('Missing variable in Table_S4: %s', varName);
    end
end

fig = figure('Color', 'w', 'Position', [60 80 1250 480]);
ax = axes(fig);

imagesc(ax, data);

% 自定义蓝-白-红发散色带
n = 256;
c1 = [33 102 172]/255;
c2 = [146 197 222]/255;
c3 = [247 247 247]/255;
c4 = [244 165 130]/255;
c5 = [178 24 43]/255;

cmap = [ ...
    [linspace(c1(1),c2(1),64)', linspace(c1(2),c2(2),64)', linspace(c1(3),c2(3),64)']; ...
    [linspace(c2(1),c3(1),64)', linspace(c2(2),c3(2),64)', linspace(c2(3),c3(3),64)']; ...
    [linspace(c3(1),c4(1),64)', linspace(c3(2),c4(2),64)', linspace(c3(3),c4(3),64)']; ...
    [linspace(c4(1),c5(1),64)', linspace(c4(2),c5(2),64)', linspace(c4(3),c5(3),64)'] ...
    ];

colormap(ax, cmap);

vmax = max(abs(data(:)));
if isempty(vmax) || isnan(vmax) || vmax == 0
    vmax = 1;
end
caxis(ax, [-vmax vmax]);

set(ax, 'XTick', 1:numel(driverOrder), ...
    'XTickLabel', driverOrder, ...
    'XTickLabelRotation', 45, ...
    'YTick', 1:4, ...
    'YTickLabel', {'M1','M2','M3','M4'}, ...
    'FontName', 'Arial', ...
    'FontSize', 9.5);

ax.TickDir = 'out';
ax.LineWidth = 0.8;
ax.Box = 'on';

% 白色网格线
hold(ax, 'on');
for x = 0.5:1:(numel(driverOrder)+0.5)
    plot(ax, [x x], [0.5 4.5], 'w-', 'LineWidth', 0.8);
end
for y = 0.5:1:4.5
    plot(ax, [0.5 numel(driverOrder)+0.5], [y y], ...
        'w-', 'LineWidth', 0.8);
end

% 分组分隔线
groupEnds = cumsum(groupSizes);
for k = 1:numel(groupEnds)-1
    x = groupEnds(k) + 0.5;
    plot(ax, [x x], [0.5 4.5], ...
        '-', 'Color', [0.35 0.35 0.35], 'LineWidth', 1.2);
end

% 顶部分组标题
groupStarts = [1, groupEnds(1:end-1)+1];
groupCenters = (groupStarts + groupEnds)/2;
for k = 1:numel(groupNames)
    text(ax, groupCenters(k), 0.15, groupNames{k}, ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', 10, ...
        'FontWeight', 'bold', ...
        'FontName', 'Arial', ...
        'Clipping', 'off');
end

% 标注绝对值较大的格子
threshold = 0.25;
for i = 1:size(data,1)
    for j = 1:size(data,2)
        v = data(i,j);
        if ~isnan(v) && abs(v) >= threshold
            if abs(v) >= 0.9
                txtColor = 'w';
            else
                txtColor = [0.15 0.15 0.15];
            end
            text(ax, j, i, sprintf('%+.2f', v), ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'FontSize', 8.2, ...
                'FontWeight', 'bold', ...
                'Color', txtColor, ...
                'FontName', 'Arial');
        end
    end
end

% 色标
cb = colorbar(ax, 'southoutside');
cb.FontName = 'Arial';
cb.FontSize = 8.5;
cb.Label.String = 'Mean signed SHAP value';
cb.Label.FontName = 'Arial';
cb.Label.FontSize = 10;

title(ax, 'Signed SHAP heatmap of mechanism-specific driver effects', ...
    'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');

annotation(fig, 'textbox', [0.18 0.005 0.64 0.04], ...
    'String', ['Negative values indicate uplift-oriented contributions; ', ...
               'positive values indicate subsidence-oriented contributions.'], ...
    'LineStyle', 'none', ...
    'HorizontalAlignment', 'center', ...
    'FontName', 'Arial', ...
    'FontSize', 9.2, ...
    'Color', [0.28 0.28 0.28]);

% 给顶部标题和底部色标留空间
set(ax, 'Position', [0.07 0.24 0.90 0.63]);

save_figure_multi_matlab(fig, ...
    fullfile(outDir, 'Fig12_Signed_SHAP'));

end
