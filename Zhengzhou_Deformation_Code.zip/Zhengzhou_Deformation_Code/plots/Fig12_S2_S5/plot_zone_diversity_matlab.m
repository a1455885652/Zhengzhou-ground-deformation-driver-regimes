function plot_zone_diversity_matlab(tblZone, outDir)

tblZone = sortrows(tblZone, 'NormalizedShannonDiversity', 'ascend');

y = 1:height(tblZone);

fig = figure('Color', 'w', 'Position', [100 100 760 460]);
ax = axes(fig);
hold(ax, 'on');

x = tblZone.NormalizedShannonDiversity;
xlow = tblZone.Diversity_CI025;
xhigh = tblZone.Diversity_CI975;

for i = 1:height(tblZone)
    plot(ax, [xlow(i) xhigh(i)], [y(i) y(i)], ...
        '-', 'Color', [76 114 176]/255, 'LineWidth', 1.5);

    plot(ax, x(i), y(i), 'o', ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', [76 114 176]/255, ...
        'MarkerEdgeColor', 'w', ...
        'LineWidth', 0.8);

    txt = sprintf('%s (%.1f%%)', ...
        char(tblZone.DominantMechanism(i)), ...
        tblZone.DominantMechanismFraction(i)*100);

    text(ax, xhigh(i)+0.02, y(i), txt, ...
        'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'middle', ...
        'FontName', 'Arial', ...
        'FontSize', 9.2);
end

set(ax, 'YTick', y, ...
    'YTickLabel', tblZone.Zone, ...
    'FontName', 'Arial', ...
    'FontSize', 10.5);

xlim(ax, [0 0.92]);
xlabel(ax, 'Normalized Shannon mechanism diversity', ...
    'FontName', 'Arial', 'FontSize', 11);

grid(ax, 'on');
ax.GridAlpha = 0.18;
ax.YGrid = 'off';
ax.Box = 'off';
ax.LineWidth = 0.8;
ax.TickDir = 'out';

title(ax, 'Mechanism diversity of representative zones', ...
    'FontName', 'Arial', 'FontSize', 12, 'FontWeight', 'bold');

save_figure_multi_matlab(fig, ...
    fullfile(outDir, 'FigS4_Regional_Diversity'));

end
