%% run_mechanism_figures_matlab.m
clear;
clc;
% Keep existing figure windows open.

%% 1. 项目根目录
projectRoot = ...
    zz_project_path('SHAP_Mechanism_K4_K5_Comparison_Output');

suppDir = fullfile(projectRoot, 'Discussion_Supplement');
outDir = zz_figure_dir('Fig12_S2_S5');

if ~exist(outDir, 'dir')
    mkdir(outDir);
end

%% 2. 检查输入文件
requiredFiles = {
    'Table_S1_Mechanism_Response_Association.csv'
    'Table_S1b_Mechanism_Response_Percent.csv'
    'Table_S2_Boundary_Uncertainty_Sensitivity.csv'
    'Table_S3_ManualZone_Mechanism_Diversity.csv'
    'Table_S4_MeanSignedSHAP_MechanismFingerprint.csv'
    };

for i = 1:numel(requiredFiles)
    f = fullfile(suppDir, requiredFiles{i});
    if ~isfile(f)
        error('Missing file:\n%s', f);
    end
end

%% 3. 读取表
tblAssoc = readtable(fullfile(suppDir, ...
    'Table_S1_Mechanism_Response_Association.csv'), ...
    'VariableNamingRule', 'preserve');

tblPct = readtable(fullfile(suppDir, ...
    'Table_S1b_Mechanism_Response_Percent.csv'), ...
    'VariableNamingRule', 'preserve');

tblBoundary = readtable(fullfile(suppDir, ...
    'Table_S2_Boundary_Uncertainty_Sensitivity.csv'), ...
    'VariableNamingRule', 'preserve');

tblZone = readtable(fullfile(suppDir, ...
    'Table_S3_ManualZone_Mechanism_Diversity.csv'), ...
    'VariableNamingRule', 'preserve');

tblSHAP = readtable(fullfile(suppDir, ...
    'Table_S4_MeanSignedSHAP_MechanismFingerprint.csv'), ...
    'VariableNamingRule', 'preserve');

%% 4. 画图
plot_mechanism_vs_state_matlab(tblPct, tblAssoc, outDir);
plot_boundary_uncertainty_matlab(tblBoundary, outDir);
plot_zone_diversity_matlab(tblZone, outDir);
plot_signed_shap_heatmap_matlab(tblSHAP, outDir);

fprintf('\nFinished.\n');
fprintf('Output folder:\n%s\n', outDir);
