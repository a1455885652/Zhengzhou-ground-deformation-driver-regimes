%% RUN_VARIABLE_SCREENING_FIGURES_BEAUTY.m
% 郑州市长期形变驱动因素筛选论文制图主脚本
% MATLAB R2023b
% 所有函数均为独立 .m 文件，无局部/嵌套函数。

clear; clc; % Keep existing figure windows open.

cfg = CONFIG_VARIABLE_SCREENING_FIGURES();
ensure_folder_vs(cfg.outputDir);

fprintf('============================================================\n');
fprintf(' Zhengzhou variable-screening paper figures (Beauty v2)\n');
fprintf('============================================================\n');
fprintf('Input : %s\n', cfg.inputDir);
fprintf('Output: %s\n\n', cfg.outputDir);

assert(isfile(cfg.rankingCsv), '找不到文件：%s', cfg.rankingCsv);
assert(isfile(cfg.subsetCvCsv), '找不到文件：%s', cfg.subsetCvCsv);

fprintf('[1/3] Drawing integrated screening ranking...\n');
plot_driver_ranking(cfg);

fprintf('[2/3] Drawing ranked-subset spatial-CV curve...\n');
plot_subset_curve(cfg);

fprintf('[3/3] Drawing optional combined two-panel figure...\n');
plot_screening_summary(cfg);

fprintf('\nFinished.\n');
fprintf('Figures saved to:\n%s\n', cfg.outputDir);
