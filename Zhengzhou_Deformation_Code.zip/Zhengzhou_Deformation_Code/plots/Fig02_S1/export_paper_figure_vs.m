function export_paper_figure_vs(fig,outputDir,baseName,dpi)
%EXPORT_PAPER_FIGURE_VS 同时输出 PNG、TIFF 与矢量 PDF。

pngFile = fullfile(outputDir,[baseName '.png']);
tifFile = fullfile(outputDir,[baseName '.tif']);
pdfFile = fullfile(outputDir,[baseName '.pdf']);

exportgraphics(fig,pngFile,'Resolution',dpi);
exportgraphics(fig,tifFile,'Resolution',dpi);
exportgraphics(fig,pdfFile,'ContentType','vector');

fprintf('  -> %s\n',pngFile);

end
