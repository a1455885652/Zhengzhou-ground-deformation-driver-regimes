function varName = pick_varname_vs(T,candidates)
%PICK_VARNAME_VS 从若干候选字段名中寻找实际表字段名。

names = string(T.Properties.VariableNames);
normNames = lower(regexprep(names,'[^a-zA-Z0-9]',''));

for i = 1:numel(candidates)
    c = lower(regexprep(string(candidates{i}),'[^a-zA-Z0-9]',''));
    idx = find(normNames == c,1);
    if ~isempty(idx)
        varName = char(names(idx));
        return;
    end
end

error('输入表缺少所需字段。现有字段：%s',strjoin(names,', '));

end
