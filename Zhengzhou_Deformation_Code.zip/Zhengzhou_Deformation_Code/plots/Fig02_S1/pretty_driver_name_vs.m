function out = pretty_driver_name_vs(in)
%PRETTY_DRIVER_NAME_VS 论文图中使用的变量显示名。

key = lower(regexprep(char(in),'[^a-zA-Z0-9]',''));

switch key
    case 'population'
        out = "Population";
    case 'dem'
        out = "DEM";
    case 'tws'
        out = "TWS";
    case 'surfacerunoff'
        out = "Surface runoff";
    case 'builtsurface'
        out = "Built surface";
    case 'relief'
        out = "Relief";
    case 'ndvi'
        out = "NDVI";
    case 'nighttimelight'
        out = "Nighttime light";
    case 'gws'
        out = "GWS";
    case 'silt'
        out = "Silt";
    case 'gum'
        out = "GUM";
    case 'dewpoint'
        out = "Dewpoint";
    case 'roaddensity'
        out = "Road density";
    case 'skinreservoir'
        out = "Skin reservoir";
    case 'subsurfacerunoff'
        out = "Subsurface runoff";
    case 'depthtobedrock'
        out = "Depth to bedrock";
    case 'slope'
        out = "Slope";
    case 'soilwater0289cm'
        out = "Soil water (0–289 cm)";
    case 'totalprecipitation'
        out = "Total precipitation";
    case 'totalevaporation'
        out = "Total evaporation";
    case 'totalloosethickness'
        out = "Total loose thickness";
    case 'glhympspermeability'
        out = "GLHYMPS permeability";
    case 'bdod'
        out = "BDOD";
    case 'glhympsporosity'
        out = "GLHYMPS porosity";
    case 'clay'
        out = "Clay";
    otherwise
        out = string(in);
end

end
