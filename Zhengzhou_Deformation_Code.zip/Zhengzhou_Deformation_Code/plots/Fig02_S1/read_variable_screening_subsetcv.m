function D = read_variable_screening_subsetcv(csvPath)
%READ_VARIABLE_SCREENING_SUBSETCV 读取 V2 ranked-subset spatial-CV 结果。

T = readtable(csvPath,'VariableNamingRule','preserve');

vN     = pick_varname_vs(T, {'NDrivers','N','TopN','NumDrivers'});
vMean  = pick_varname_vs(T, {'MeanRMSE','RMSEMean'});
vSE    = pick_varname_vs(T, {'SERMSE','RMSESE','SE_RMSE'});
v1SE   = pick_varname_vs_optional(T, {'SelectedBy1SE','Selected_1SE'});

N = double(T.(vN));
mu = double(T.(vMean));
se = double(T.(vSE));

if isempty(v1SE)
    selected = false(size(N));
else
    selected = logical(T.(v1SE));
end

[N,idx] = sort(N);
mu = mu(idx);
se = se(idx);
selected = selected(idx);

D = struct();
D.NDrivers = N;
D.MeanRMSE = mu;
D.SERMSE = se;
D.SelectedBy1SE = selected;

end
