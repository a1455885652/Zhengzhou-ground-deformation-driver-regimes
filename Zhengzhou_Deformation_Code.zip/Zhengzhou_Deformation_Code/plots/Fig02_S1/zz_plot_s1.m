function zz_plot_s1()
cfg = CONFIG_VARIABLE_SCREENING_FIGURES();
ensure_folder_vs(cfg.outputDir);
plot_subset_curve(cfg);
end
