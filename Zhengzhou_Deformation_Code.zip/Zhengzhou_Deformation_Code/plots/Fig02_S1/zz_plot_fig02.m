function zz_plot_fig02()
cfg = CONFIG_VARIABLE_SCREENING_FIGURES();
ensure_folder_vs(cfg.outputDir);
plot_driver_ranking(cfg);
end
