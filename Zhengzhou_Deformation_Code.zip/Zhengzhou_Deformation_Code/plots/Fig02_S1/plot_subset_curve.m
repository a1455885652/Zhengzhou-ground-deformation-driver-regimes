function plot_subset_curve(cfg)
%PLOT_FIG_VARIABLE_SCREENING_SUBSETCV_BEAUTY
% 用半透明 SE ribbon 代替密集误差棒，并突出 1-SE 与最小 RMSE。

D = read_variable_screening_subsetcv(cfg.subsetCvCsv);

N = D.NDrivers;
meanRMSE = D.MeanRMSE;
seRMSE = D.SERMSE;
lo = meanRMSE - seRMSE;
hi = meanRMSE + seRMSE;

[rmseMin, idxMin] = min(meanRMSE);
Nmin = N(idxMin);

if any(D.SelectedBy1SE)
    idx1SE = find(D.SelectedBy1SE,1,'first');
else
    threshold = rmseMin + seRMSE(idxMin);
    idx1SE = find(meanRMSE <= threshold,1,'first');
end
N1SE = N(idx1SE);

lineColor   = [49, 90, 143]/255;
ribbonColor = [151, 183, 218]/255;
minColor    = [45, 142, 82]/255;
oneSEColor  = [215, 119, 47]/255;
axisColor   = [45, 45, 45]/255;
gridColor   = [222, 222, 222]/255;

fig = figure('Color','w','Units','pixels','Position',[90 70 1280 820]);
ax = axes(fig,'Position',[0.11 0.13 0.84 0.82]);
hold(ax,'on');

% background grid first
xTicks = 5:2:25;
yMin = floor((min(lo)-0.05)*10)/10;
yMax = ceil((max(hi)+0.05)*10)/10;
yTicks = yMin:0.2:yMax;
for k = 1:numel(yTicks)
    plot(ax,[min(N)-0.5 max(N)+0.5],[yTicks(k) yTicks(k)],'-', ...
        'Color',gridColor,'LineWidth',0.8,'HandleVisibility','off');
end

% SE ribbon
hBand = patch(ax,[N; flipud(N)],[lo; flipud(hi)],ribbonColor, ...
    'EdgeColor','none','FaceAlpha',0.28);

% mean curve
hMean = plot(ax,N,meanRMSE,'-o', ...
    'Color',lineColor,'LineWidth',2.7, ...
    'MarkerSize',7.5,'MarkerFaceColor','w', ...
    'MarkerEdgeColor',lineColor,'LineWidth',1.4);

% vertical guides
plot(ax,[N1SE N1SE],[yMin yMax],'--','Color',oneSEColor,'LineWidth',1.2,'HandleVisibility','off');
plot(ax,[Nmin Nmin],[yMin yMax],'--','Color',minColor,'LineWidth',1.2,'HandleVisibility','off');

% selected points
h1 = scatter(ax,N1SE,meanRMSE(idx1SE),155,'s', ...
    'MarkerFaceColor',oneSEColor,'MarkerEdgeColor','w','LineWidth',1.2);
h2 = scatter(ax,Nmin,meanRMSE(idxMin),170,'d', ...
    'MarkerFaceColor',minColor,'MarkerEdgeColor','w','LineWidth',1.2);

% concise callouts
text(ax,N1SE+0.35,meanRMSE(idx1SE)+0.08,sprintf('1-SE: N = %d',N1SE), ...
    'FontName',cfg.fontName,'FontSize',15,'FontWeight','bold', ...
    'Color',oneSEColor,'VerticalAlignment','bottom');
text(ax,Nmin+0.35,meanRMSE(idxMin)-0.08,sprintf('Minimum: N = %d',Nmin), ...
    'FontName',cfg.fontName,'FontSize',15,'FontWeight','bold', ...
    'Color',minColor,'VerticalAlignment','top');

ax.FontName = cfg.fontName;
ax.FontSize = 16;
ax.LineWidth = 1.0;
ax.XColor = axisColor;
ax.YColor = axisColor;
ax.TickDir = 'out';
ax.TickLength = [0.007 0.007];
ax.Box = 'off';
ax.XTick = xTicks;
ax.YTick = yTicks;
ax.XGrid = 'off';
ax.YGrid = 'off';

xlim(ax,[min(N)-0.5 max(N)+0.5]);
ylim(ax,[yMin yMax]);

xlabel(ax,'Number of top-ranked drivers', ...
    'FontName',cfg.fontName,'FontSize',20);
ylabel(ax,'Spatial-CV RMSE (mm yr^{-1})', ...
    'FontName',cfg.fontName,'FontSize',20);

lgd = legend(ax,[hMean hBand h1 h2], ...
    {'Mean RMSE','Mean \pm SE','1-SE subset','Minimum-RMSE subset'}, ...
    'Location','northwest','Box','off', ...
    'FontName',cfg.fontName,'FontSize',13.5);
lgd.ItemTokenSize = [19 11];

export_paper_figure_vs(fig,cfg.outputDir, ...
    'Fig_RankedSubset_SpatialCV_Beauty_v2',cfg.pngDPI);
drawnow; % Keep the exported figure open for preview.
end
