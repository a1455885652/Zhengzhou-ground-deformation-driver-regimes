function plot_driver_ranking(cfg)
%PLOT_FIG_VARIABLE_SCREENING_RANKING_BEAUTY
% 期刊风格的“棒棒糖”排序图：避免传统粗柱状图的工程感。

S = read_variable_screening_ranking(cfg.rankingCsv, cfg.retainedDrivers);

% restrained journal palette
retainedColor = [43, 104, 162] / 255;
excludedColor = [184, 184, 184] / 255;
axisColor     = [45, 45, 45] / 255;
gridColor     = [218, 218, 218] / 255;
bandColor     = [248, 248, 248] / 255;

n = height(S);
xMaxData = max(S.Score);
xRight = xMaxData + 0.075;

fig = figure('Color','w', 'Units','pixels', 'Position',[80 40 1320 1060]);
ax = axes(fig, 'Position',[0.255 0.085 0.70 0.875]);
hold(ax,'on');

% very subtle alternating row bands
for i = 1:n
    if mod(i,2) == 0
        patch(ax, [0 xRight xRight 0], [i-0.48 i-0.48 i+0.48 i+0.48], ...
            bandColor, 'EdgeColor','none', 'HandleVisibility','off');
    end
end

% light vertical reference grid (draw manually so it stays behind symbols)
xTicks = 0:0.1:ceil(xRight*10)/10;
for k = 1:numel(xTicks)
    plot(ax, [xTicks(k) xTicks(k)], [0.45 n+0.55], '-', ...
        'Color',gridColor, 'LineWidth',0.75, 'HandleVisibility','off');
end

% lollipop stems + end markers + numeric labels
for i = 1:n
    if S.IsRetained(i)
        c = retainedColor;
        face = retainedColor;
        edge = retainedColor;
        lw = 2.8;
    else
        c = excludedColor;
        face = [1 1 1];
        edge = [125 125 125]/255;
        lw = 2.0;
    end

    plot(ax, [0 S.Score(i)], [i i], '-', ...
        'Color',c, 'LineWidth',lw, 'HandleVisibility','off');

    scatter(ax, S.Score(i), i, 82, ...
        'MarkerFaceColor',face, ...
        'MarkerEdgeColor',edge, ...
        'LineWidth',1.0, ...
        'HandleVisibility','off');

    text(ax, S.Score(i)+0.012, i, sprintf('%.2f',S.Score(i)), ...
        'FontName',cfg.fontName, 'FontSize',12.5, ...
        'Color',[75 75 75]/255, ...
        'VerticalAlignment','middle', ...
        'HorizontalAlignment','left');
end

% invisible handles only for legend
hRet = scatter(ax, nan, nan, 82, ...
    'MarkerFaceColor',retainedColor, 'MarkerEdgeColor',retainedColor);
hExc = scatter(ax, nan, nan, 82, ...
    'MarkerFaceColor','w', 'MarkerEdgeColor',[125 125 125]/255, 'LineWidth',1.0);

ax.YDir = 'reverse';
ax.YTick = 1:n;
ax.YTickLabel = cellstr(S.DriverPretty);
ax.XTick = xTicks;
ax.TickDir = 'out';
ax.TickLength = [0.006 0.006];
ax.FontName = cfg.fontName;
ax.FontSize = 15.5;
ax.LineWidth = 1.0;
ax.XColor = axisColor;
ax.YColor = axisColor;
ax.Box = 'off';
ax.XGrid = 'off';
ax.YGrid = 'off';

xlim(ax,[0 xRight]);
ylim(ax,[0.45 n+0.55]);

xlabel(ax,'Composite screening score', ...
    'FontName',cfg.fontName, 'FontSize',19.5);
ylabel(ax,'Candidate driver', ...
    'FontName',cfg.fontName, 'FontSize',19.5);

lgd = legend(ax,[hRet hExc],{'Retained','Excluded'}, ...
    'Location','southeast', 'Box','off', ...
    'FontName',cfg.fontName, 'FontSize',14.5);
lgd.ItemTokenSize = [16 12];

% no in-panel title: journal caption carries the title
export_paper_figure_vs(fig, cfg.outputDir, ...
    'Fig_Variable_Screening_Ranking_Beauty_v2', cfg.pngDPI);
drawnow; % Keep the exported figure open for preview.
end
