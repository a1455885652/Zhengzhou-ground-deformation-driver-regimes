function varName = pick_varname_vs_optional(T,candidates)
%PICK_VARNAME_VS_OPTIONAL 可选字段名查找；不存在时返回空字符。

names = string(T.Properties.VariableNames);
normNames = lower(regexprep(names,'[^a-zA-Z0-9]',''));

for i = 1:numel(candidates)
    c = lower(regexprep(string(candidates{i}),'[^a-zA-Z0-9]',''));
    idx = find(normNames == c,1);
    if ~isempty(idx)
        varName = char(names(idx));
        return;
    end
end

varName = '';

end
