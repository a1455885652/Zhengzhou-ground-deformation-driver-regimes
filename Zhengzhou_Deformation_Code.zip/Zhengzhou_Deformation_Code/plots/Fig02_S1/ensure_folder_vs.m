function ensure_folder_vs(folderPath)
%ENSURE_FOLDER_VS 若输出目录不存在则创建。

if ~exist(folderPath,'dir')
    mkdir(folderPath);
end

end
