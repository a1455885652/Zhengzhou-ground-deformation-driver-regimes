function plot_screening_summary(cfg)
%PLOT_FIG_VARIABLE_SCREENING_COMBINED_BEAUTY
% 可选的双面板版本，便于需要合并成一幅图时使用。

S = read_variable_screening_ranking(cfg.rankingCsv, cfg.retainedDrivers);
D = read_variable_screening_subsetcv(cfg.subsetCvCsv);

retainedColor = [43, 104, 162]/255;
excludedColor = [184, 184, 184]/255;
axisColor     = [45, 45, 45]/255;
gridColor     = [222, 222, 222]/255;
ribbonColor   = [151, 183, 218]/255;
minColor      = [45, 142, 82]/255;
oneSEColor    = [215, 119, 47]/255;

fig = figure('Color','w','Units','pixels','Position',[60 40 1580 980]);
tl = tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact');

% ---------- (a) ranking ----------
ax1 = nexttile(tl,1);
hold(ax1,'on');
n = height(S);
xRight = max(S.Score)+0.08;
for x = 0:0.1:ceil(xRight*10)/10
    plot(ax1,[x x],[0.45 n+0.55],'-','Color',[230 230 230]/255, ...
        'LineWidth',0.6,'HandleVisibility','off');
end
for i = 1:n
    if S.IsRetained(i)
        c = retainedColor; face = retainedColor; edge = retainedColor; lw = 2.4;
    else
        c = excludedColor; face = 'w'; edge = [125 125 125]/255; lw = 1.7;
    end
    plot(ax1,[0 S.Score(i)],[i i],'-','Color',c,'LineWidth',lw,'HandleVisibility','off');
    scatter(ax1,S.Score(i),i,50,'MarkerFaceColor',face,'MarkerEdgeColor',edge, ...
        'LineWidth',0.8,'HandleVisibility','off');
end
ax1.YDir='reverse';
ax1.YTick=1:n;
ax1.YTickLabel=cellstr(S.DriverPretty);
ax1.FontName=cfg.fontName;
ax1.FontSize=11.5;
ax1.Box='off';
ax1.TickDir='out';
ax1.XColor=axisColor;
ax1.YColor=axisColor;
xlim(ax1,[0 xRight]);
ylim(ax1,[0.45 n+0.55]);
xlabel(ax1,'Composite screening score','FontName',cfg.fontName,'FontSize',15);
text(ax1,0.01,0.99,'(a)','Units','normalized','FontName',cfg.fontName, ...
    'FontSize',17,'FontWeight','bold','VerticalAlignment','top');

% ---------- (b) subset CV ----------
ax2 = nexttile(tl,2);
hold(ax2,'on');
N = D.NDrivers;
mu = D.MeanRMSE;
se = D.SERMSE;
lo = mu-se; hi=mu+se;
[~,idxMin]=min(mu);
if any(D.SelectedBy1SE)
    idx1=find(D.SelectedBy1SE,1,'first');
else
    thr=mu(idxMin)+se(idxMin);
    idx1=find(mu<=thr,1,'first');
end
yMin=floor((min(lo)-0.05)*10)/10;
yMax=ceil((max(hi)+0.05)*10)/10;
for y=yMin:0.2:yMax
    plot(ax2,[min(N)-0.5 max(N)+0.5],[y y],'-','Color',gridColor, ...
        'LineWidth',0.7,'HandleVisibility','off');
end
patch(ax2,[N;flipud(N)],[lo;flipud(hi)],ribbonColor,'EdgeColor','none','FaceAlpha',0.28);
plot(ax2,N,mu,'-o','Color',retainedColor,'LineWidth',2.4,'MarkerSize',6.5, ...
    'MarkerFaceColor','w','MarkerEdgeColor',retainedColor);
plot(ax2,[N(idx1) N(idx1)],[yMin yMax],'--','Color',oneSEColor,'LineWidth',1.0);
plot(ax2,[N(idxMin) N(idxMin)],[yMin yMax],'--','Color',minColor,'LineWidth',1.0);
scatter(ax2,N(idx1),mu(idx1),125,'s','MarkerFaceColor',oneSEColor,'MarkerEdgeColor','w','LineWidth',1.0);
scatter(ax2,N(idxMin),mu(idxMin),135,'d','MarkerFaceColor',minColor,'MarkerEdgeColor','w','LineWidth',1.0);
text(ax2,N(idx1)+0.3,mu(idx1)+0.08,sprintf('1-SE: N=%d',N(idx1)), ...
    'FontName',cfg.fontName,'FontSize',12.5,'FontWeight','bold','Color',oneSEColor);
text(ax2,N(idxMin)+0.3,mu(idxMin)-0.08,sprintf('Minimum: N=%d',N(idxMin)), ...
    'FontName',cfg.fontName,'FontSize',12.5,'FontWeight','bold','Color',minColor, ...
    'VerticalAlignment','top');
ax2.FontName=cfg.fontName;
ax2.FontSize=13;
ax2.Box='off';
ax2.TickDir='out';
ax2.XColor=axisColor;
ax2.YColor=axisColor;
xlim(ax2,[min(N)-0.5 max(N)+0.5]);
ylim(ax2,[yMin yMax]);
ax2.XTick=5:2:25;
xlabel(ax2,'Number of top-ranked drivers','FontName',cfg.fontName,'FontSize',15);
ylabel(ax2,'Spatial-CV RMSE (mm yr^{-1})','FontName',cfg.fontName,'FontSize',15);
text(ax2,0.01,0.99,'(b)','Units','normalized','FontName',cfg.fontName, ...
    'FontSize',17,'FontWeight','bold','VerticalAlignment','top');

export_paper_figure_vs(fig,cfg.outputDir, ...
    'Fig_Variable_Screening_Combined_Beauty_v2',cfg.pngDPI);
drawnow; % Keep the exported figure open for preview.
end
