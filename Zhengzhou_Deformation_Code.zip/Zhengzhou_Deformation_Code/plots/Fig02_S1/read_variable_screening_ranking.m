function S = read_variable_screening_ranking(csvPath, retainedDrivers)
%READ_VARIABLE_SCREENING_RANKING 读取最终 V2 综合排名并标记保留变量。

T = readtable(csvPath,'VariableNamingRule','preserve');

vDriver = pick_varname_vs(T, {'Driver','Variable','Feature'});
vScore  = pick_varname_vs(T, {'CompositeScore','Composite_Score'});

driverRaw = string(T.(vDriver));
score = double(T.(vScore));

[score,idx] = sort(score,'descend');
driverRaw = driverRaw(idx);

isRetained = ismember(driverRaw, retainedDrivers);
driverPretty = strings(size(driverRaw));
for i = 1:numel(driverRaw)
    driverPretty(i) = pretty_driver_name_vs(driverRaw(i));
end

S = table((1:numel(driverRaw))',driverRaw,driverPretty,score,isRetained, ...
    'VariableNames',{'Rank','DriverRaw','DriverPretty','Score','IsRetained'});

end
