# 图 11

绘制不同形变状态和典型区的机制组成。

输入：Response_Mechanism_Crosstab_K4.csv、ManualZone_SignConsistent_Overlap_K4.csv。具体路径相对于 `config/paths.json` 中的 `project_root`。

在代码包根目录的 MATLAB 中调用：

```matlab
run_figure('Fig11')
```

也可使用根目录的 `run.py figure <图号>`。MATLAB 图需要本机安装 MATLAB；Python 图由统一配置指定的解释器执行。

输出位于 `figure_output` 对应子目录。目录和现稿编号对照见 `../../docs/FIGURES.md`。单位标签不承担数据单位换算。
