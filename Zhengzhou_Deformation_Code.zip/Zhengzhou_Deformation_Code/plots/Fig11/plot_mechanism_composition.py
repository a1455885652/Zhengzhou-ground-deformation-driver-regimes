"""Plot deformation-state and regional mechanism compositions."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "runtime"))
from zz_paths import show_figures
from zz_plotting import choose_font

import os
import argparse
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, FancyBboxPatch, Rectangle

mpl.rcParams["font.family"] = choose_font("Times New Roman")
mpl.rcParams["axes.unicode_minus"] = False
mpl.rcParams["font.size"] = 12
mpl.rcParams["axes.linewidth"] = 0.9
mpl.rcParams["xtick.direction"] = "out"
mpl.rcParams["ytick.direction"] = "out"
mpl.rcParams["savefig.facecolor"] = "white"

MECH_COLORS = ["#3C84C6", "#E6A033", "#56A76B", "#A168C0"]
SUB_COLOR = "#D85F62"
UPL_COLOR = "#4D7FAF"
GRID_COLOR = "#BFC6CE"
TEXT_COLOR = "#222222"


def load_response_composition(path):
    t = pd.read_csv(path)
    required = ["MechanismCluster", "ResponseState", "FractionWithinMechanism"]
    missing = [x for x in required if x not in t.columns]
    if missing:
        raise ValueError(f"{os.path.basename(path)} missing columns: {missing}")

    out = []
    for k in range(1, 5):
        tk = t[pd.to_numeric(t["MechanismCluster"], errors="coerce") == k]

        def frac(state):
            s = tk[tk["ResponseState"].astype(str).str.lower() == state.lower()]
            return (
                float(
                    pd.to_numeric(s["FractionWithinMechanism"], errors="coerce").iloc[0]
                )
                * 100
                if len(s)
                else 0.0
            )

        out.append((frac("Subsidence"), frac("Uplift")))
    return np.array(out, dtype=float)


def load_zone_composition(path):
    t = pd.read_csv(path)
    required = ["Zone", "MechanismCluster", "FractionWithinZone"]
    missing = [x for x in required if x not in t.columns]
    if missing:
        raise ValueError(f"{os.path.basename(path)} missing columns: {missing}")

    zones = ["Sub1", "Sub2", "Upl1", "Upl2", "Upl3"]
    mat = np.zeros((len(zones), 4), dtype=float)
    for i, z in enumerate(zones):
        tz = t[t["Zone"].astype(str) == z]
        if tz.empty:
            raise ValueError(f"Zone {z} is missing from {os.path.basename(path)}")
        for k in range(1, 5):
            row = tz[pd.to_numeric(tz["MechanismCluster"], errors="coerce") == k]
            if not row.empty:
                mat[i, k - 1] = (
                    float(
                        pd.to_numeric(row["FractionWithinZone"], errors="coerce").iloc[
                            0
                        ]
                    )
                    * 100
                )
    return zones, mat


def style_clean_axis(ax):
    ax.set_facecolor("#FCFCFD")
    ax.grid(True, axis="x", linestyle=":", linewidth=0.65, color=GRID_COLOR, alpha=0.32)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#5A5A5A")
    ax.spines["bottom"].set_color("#5A5A5A")
    ax.tick_params(labelsize=11.5, colors=TEXT_COLOR)


def draw_butterfly_response(ax, response):
    names = ["M1", "M2", "M3", "M4"]
    y = np.arange(4)
    subs = response[:, 0]
    upl = response[:, 1]

    # Quiet guide lines make the chart read as a designed panel rather than a heavy bar chart.
    for yi in y:
        ax.hlines(yi, -100, 100, color="#E8EAED", linewidth=1.0, zorder=0)

    # Thick rounded lines create a clean "pill / butterfly" appearance.
    for i, yi in enumerate(y):
        ax.plot(
            [-subs[i], 0],
            [yi, yi],
            color=SUB_COLOR,
            linewidth=15,
            solid_capstyle="round",
            zorder=3,
        )
        ax.plot(
            [0, upl[i]],
            [yi, yi],
            color=UPL_COLOR,
            linewidth=15,
            solid_capstyle="round",
            zorder=3,
        )

        # Main percentages: inside when there is room, otherwise just outside the short segment.
        if subs[i] >= 16:
            ax.text(
                -subs[i] / 2,
                yi,
                f"{subs[i]:.1f}%",
                ha="center",
                va="center",
                color="white",
                fontsize=11.2,
                fontweight="bold",
                zorder=4,
            )
        else:
            ax.text(
                -subs[i] - 4.0,
                yi,
                f"{subs[i]:.1f}%",
                ha="right",
                va="center",
                color=SUB_COLOR,
                fontsize=10.8,
                fontweight="bold",
                zorder=4,
            )

        if upl[i] >= 16:
            ax.text(
                upl[i] / 2,
                yi,
                f"{upl[i]:.1f}%",
                ha="center",
                va="center",
                color="white",
                fontsize=11.2,
                fontweight="bold",
                zorder=4,
            )
        else:
            ax.text(
                upl[i] + 4.0,
                yi,
                f"{upl[i]:.1f}%",
                ha="left",
                va="center",
                color=UPL_COLOR,
                fontsize=10.8,
                fontweight="bold",
                zorder=4,
            )

    ax.axvline(0, color="#505050", linewidth=1.1, zorder=2)
    ax.set_xlim(-108, 108)
    ax.set_ylim(3.55, -0.55)
    ax.set_yticks(y)
    ax.set_yticklabels(names, fontsize=12.5)
    ax.set_xticks([-100, -50, 0, 50, 100])
    ax.set_xticklabels(["100", "50", "0", "50", "100"])
    ax.set_xlabel("Fraction within mechanism (%)", fontsize=12.8)
    style_clean_axis(ax)

    # Small orientation cues inside the panel, deliberately separate from the title.
    ax.text(
        0.18,
        0.98,
        "Subsidence",
        transform=ax.transAxes,
        color=SUB_COLOR,
        ha="center",
        va="top",
        fontsize=10.5,
        fontweight="bold",
    )
    ax.text(
        0.82,
        0.98,
        "Uplift",
        transform=ax.transAxes,
        color=UPL_COLOR,
        ha="center",
        va="top",
        fontsize=10.5,
        fontweight="bold",
    )


def draw_rounded_stacked_zones(ax, zones, comp):
    y = np.arange(len(zones))
    h = 0.52

    for i, yi in enumerate(y):
        # Rounded outer container.
        clip = FancyBboxPatch(
            (0, yi - h / 2),
            100,
            h,
            boxstyle="round,pad=0,rounding_size=1.2",
            facecolor="none",
            edgecolor="none",
            transform=ax.transData,
        )
        ax.add_patch(clip)

        left = 0.0
        boundaries = []
        for k in range(4):
            v = float(comp[i, k])
            if v <= 0:
                continue
            rect = Rectangle(
                (left, yi - h / 2),
                v,
                h,
                facecolor=MECH_COLORS[k],
                edgecolor="none",
                zorder=3,
            )
            rect.set_clip_path(clip)
            ax.add_patch(rect)
            left2 = left + v
            boundaries.append(left2)

            if v >= 12.0:
                color = "white" if k in [0, 2, 3] else "#242424"
                ax.text(
                    left + v / 2,
                    yi,
                    f"{v:.1f}%",
                    ha="center",
                    va="center",
                    fontsize=11.0,
                    fontweight="bold",
                    color=color,
                    zorder=5,
                )
            left = left2

        # Fine white separators between mechanism segments.
        for xb in boundaries[:-1]:
            ax.vlines(
                xb,
                yi - h / 2 + 0.015,
                yi + h / 2 - 0.015,
                color="white",
                linewidth=1.3,
                zorder=4,
            )

        # Thin rounded outline for the whole 100% bar.
        outline = FancyBboxPatch(
            (0, yi - h / 2),
            100,
            h,
            boxstyle="round,pad=0,rounding_size=1.2",
            facecolor="none",
            edgecolor="#E3E5E8",
            linewidth=0.8,
            zorder=6,
        )
        ax.add_patch(outline)

    ax.set_xlim(0, 100)
    ax.set_ylim(len(zones) - 0.45, -0.55)
    ax.set_yticks(y)
    ax.set_yticklabels(zones, fontsize=12.3)
    ax.set_xlabel("Mechanism composition within zone (%)", fontsize=12.8)
    ax.set_xticks(np.arange(0, 101, 20))
    style_clean_axis(ax)


def plot_composition_figure(response_csv, zone_csv, out_dir):
    response = load_response_composition(response_csv)
    zones, comp = load_zone_composition(zone_csv)

    fig = plt.figure(figsize=(17.8, 7.0), facecolor="white")
    gs = fig.add_gridspec(
        2,
        2,
        height_ratios=[20.0, 2.3],
        width_ratios=[1.0, 1.32],
        left=0.055,
        right=0.985,
        top=0.89,
        bottom=0.10,
        wspace=0.18,
        hspace=0.16,
    )
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    leg1 = fig.add_subplot(gs[1, 0])
    leg2 = fig.add_subplot(gs[1, 1])
    leg1.set_axis_off()
    leg2.set_axis_off()

    draw_butterfly_response(ax1, response)
    draw_rounded_stacked_zones(ax2, zones, comp)

    ax1.set_title(
        "(a) Deformation response within mechanisms",
        loc="left",
        fontsize=15.5,
        fontweight="bold",
        pad=18,
    )
    ax2.set_title(
        "(b) Mechanism composition of typical zones",
        loc="left",
        fontsize=15.5,
        fontweight="bold",
        pad=18,
    )

    leg1.legend(
        handles=[
            Patch(facecolor=SUB_COLOR, edgecolor="none", label="Subsidence"),
            Patch(facecolor=UPL_COLOR, edgecolor="none", label="Uplift"),
        ],
        loc="center",
        ncol=2,
        frameon=False,
        fontsize=12.1,
        columnspacing=2.2,
    )
    leg2.legend(
        handles=[
            Patch(facecolor=MECH_COLORS[i], edgecolor="none", label=f"M{i + 1}")
            for i in range(4)
        ],
        loc="center",
        ncol=4,
        frameon=False,
        fontsize=12.1,
        columnspacing=2.0,
    )

    out_png = os.path.join(out_dir, "Fig11_Mechanism_Composition.png")
    out_tif = os.path.join(out_dir, "Fig11_Mechanism_Composition.tif")
    fig.savefig(out_png, dpi=600, bbox_inches="tight")
    fig.savefig(out_tif, dpi=600, bbox_inches="tight")
    fig.savefig(
        os.path.join(out_dir, "Fig11_Mechanism_Composition.pdf"), bbox_inches="tight"
    )
    # Keep the figure open until the user closes its preview.
    print(f"[OK] {out_png}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    plot_composition_figure(
        os.path.join(args.input_dir, "Response_Mechanism_Crosstab_K4.csv"),
        os.path.join(args.input_dir, "ManualZone_SignConsistent_Overlap_K4.csv"),
        args.output_dir,
    )
    if show_figures():
        plt.show(block=True)
