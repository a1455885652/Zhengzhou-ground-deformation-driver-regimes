"""Compare GWS ALE responses and between-region breakpoint differences."""

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "runtime"))
from zz_paths import project_path, figure_path, show_figures, REPOSITORY
from zz_plotting import save_figure

import pandas as pd


def read_curve(root, region, driver):
    table = pd.read_csv(root / "Curves" / f"ALE_{region}_{driver}.csv").sort_values(
        "XCenter"
    )
    x, y, low, high = (
        table[c].to_numpy(float) for c in ("XCenter", "ALE", "CI95_Low", "CI95_High")
    )
    if not np.all(low <= high):
        raise ValueError("ALE interval bounds are reversed.")
    return x, y, low, high


def draw(root: Path, output: Path):
    unit = json.loads((REPOSITORY / "config/feature_units.json").read_text())["GWS"][
        "plot_base_unit"
    ]
    B = pd.read_csv(root / "ALE_Threshold_Breakpoints.csv")
    C = pd.read_csv(root / "Threshold_Mechanism_Contrasts.csv")
    COLORS = (
        np.array([[68, 119, 170], [237, 158, 47], [85, 168, 104], [155, 97, 190]]) / 255
    )
    plt.rcParams.update(
        {
            "font.family": "DejaVu Serif",
            "font.size": 10,
            "axes.titlesize": 12,
            "axes.labelsize": 11,
            "pdf.fonttype": 42,
        }
    )
    fig7, (a, b) = plt.subplots(
        1, 2, figsize=(11.7, 5.35), gridspec_kw={"width_ratios": [1.65, 1]}
    )
    fig7.subplots_adjust(left=0.075, right=0.985, top=0.91, bottom=0.21, wspace=0.24)
    xs = []
    ys = []
    for r, (region, color) in enumerate(
        zip(["All", "M1", "M2", "M3", "M4"], np.vstack(([0.14, 0.14, 0.14], COLORS)))
    ):
        x, y, lo, hi = read_curve(root, region, "GWS")
        xs.extend(x)
        ys.extend(np.r_[y, lo, hi])
        a.fill_between(x, lo, hi, color=color, alpha=0.11, lw=0)
        a.plot(
            x,
            y,
            "--" if r == 0 else "-",
            color=color,
            lw=2.1 if r == 0 else 1.7,
            label=region,
        )
        bp = B.loc[(B.Region == region) & (B.Driver == "GWS")]
        for _, row in bp.iterrows():
            a.axvline(row.Threshold, color=color, ls=":", lw=0.85, alpha=0.8)
            if x.min() <= row.Threshold <= x.max():
                a.plot(
                    row.Threshold,
                    np.interp(row.Threshold, x, y),
                    "o",
                    mfc="white",
                    mec=color,
                    ms=6,
                    mew=1.3,
                )
    a.axhline(0, color=".6", ls=":", lw=0.8)
    dy = np.nanmax(ys) - np.nanmin(ys)
    a.set(
        xlim=(min(xs), max(xs)),
        ylim=(np.nanmin(ys) - 0.05 * dy, np.nanmax(ys) + 0.14 * dy),
        xlabel=rf"GWS trend ({unit} yr$^{{-1}}$)",
        ylabel=r"ALE effect (mm yr$^{-1}$)",
    )
    a.set_title("(a) GWS responses", loc="left", weight="bold")
    a.legend(
        loc="upper left",
        ncol=5,
        frameon=False,
        fontsize=9,
        columnspacing=0.7,
        handlelength=1.6,
    )
    for k, (ra, rb) in enumerate([("M1", "M2"), ("M1", "M3"), ("M2", "M3")]):
        rows = C.loc[
            (C.Driver == "GWS")
            & (C.BreakpointIndex == 1)
            & (C.RegionA == ra)
            & (C.RegionB == rb)
        ]
        assert len(rows) == 1
        row = rows.iloc[0]
        y = 3 - k
        e = row.Difference_AminusB
        assert np.isclose(e, row.ThresholdA - row.ThresholdB)
        b.plot(
            [row.FixedDiffCI95_Low, row.FixedDiffCI95_High],
            [y + 0.07] * 2,
            color=".15",
            lw=2.2,
        )
        b.plot(
            [row.RefitDiffCI90_Low, row.RefitDiffCI90_High],
            [y - 0.10] * 2,
            color=".45",
            lw=1.5,
            ls="--",
        )
        b.plot(e, y + 0.07, "o", mfc=".15", mec="white", ms=6)
        b.text(e, y + 0.28, f"{e:.2f}", ha="center", weight="bold", fontsize=10)
    b.axvline(0, color="#994040", ls=":", lw=1)
    b.set(
        xlim=(-1.7, 6.2),
        ylim=(0.55, 3.65),
        yticks=[1, 2, 3],
        yticklabels=["M2 − M3", "M1 − M3", "M1 − M2"],
        xlabel=rf"Breakpoint difference ({unit} yr$^{{-1}}$)",
    )
    b.set_title("(b) Breakpoint differences", loc="left", weight="bold")
    b.legend(
        [
            Line2D([], [], color=".15", lw=2.2, marker="o", ms=4),
            Line2D([], [], color=".45", lw=1.5, ls="--"),
        ],
        ["Fixed model: 95% CI", "Refit: 90% CI"],
        loc="upper center",
        bbox_to_anchor=(0.5, -0.18),
        frameon=False,
        fontsize=9,
    )
    save_figure(fig7, output, "FigS7_GWS_Comparison")
    return fig7


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=project_path("K4_ALE_Threshold_Interaction_Output_v1_5/01_Thresholds"),
    )
    parser.add_argument("--output-dir", type=Path, default=figure_path("FigS7"))
    args = parser.parse_args()
    draw(args.input_dir, args.output_dir)
    if show_figures():
        plt.show(block=True)


if __name__ == "__main__":
    main()
