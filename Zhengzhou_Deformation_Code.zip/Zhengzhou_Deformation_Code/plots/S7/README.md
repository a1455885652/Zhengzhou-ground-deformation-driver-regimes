# 图 S7

比较 GWS 响应；差异图分别展示固定模型 95% 区间与重拟合 90% 区间。

输入：All、M1—M4 的 GWS 曲线与 Threshold_Mechanism_Contrasts.csv。具体路径相对于 `config/paths.json` 中的 `project_root`。

在代码包根目录的 MATLAB 中调用：

```matlab
run_figure('S7')
```

也可使用根目录的 `run.py figure <图号>`。MATLAB 图需要本机安装 MATLAB；Python 图由统一配置指定的解释器执行。

输出位于 `figure_output` 对应子目录。目录和现稿编号对照见 `../../docs/FIGURES.md`。单位标签不承担数据单位换算。
