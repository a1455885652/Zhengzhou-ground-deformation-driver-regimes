import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "runtime"))
from zz_paths import project_path, figure_path, show_figures
from zz_plotting import choose_font
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.lines import Line2D

# Fig. 9
# Relative contributions of major driver categories
# Driver-category contributions as normalized stacked bars

# 1. 路径设置
root = project_path("XGBoost_SHAP_Latest1km_ReferenceSimple_Output")
input_dir = root / "Python_Output"
output_dir = figure_path("Fig09")
output_dir.mkdir(parents=True, exist_ok=True)

# 2. 输入文件
files = {
    "Full area": "SHAP_Importance_All.csv",
    "Subsidence": "SHAP_Importance_Subsidence.csv",
    "Uplift": "SHAP_Importance_Uplift.csv",
    "Sub1": "SHAP_Importance_Sub1.csv",
    "Sub2": "SHAP_Importance_Sub2.csv",
    "Upl1": "SHAP_Importance_Upl1.csv",
    "Upl2": "SHAP_Importance_Upl2.csv",
    "Upl3": "SHAP_Importance_Upl3.csv",
}

# 3. 驱动分类
categories = {
    "Hydrological": [
        "GWS",
        "SurfaceRunoff",
        "SkinReservoir",
        "SubsurfaceRunoff",
        "TotalPrecipitation",
    ],
    "Urbanization": ["BuiltSurface", "NighttimeLight", "RoadDensity", "Population"],
    "Terrain-geology": [
        "DEM",
        "GUM",
        "TotalLooseThickness",
        "Silt",
        "GLHYMPS_Permeability",
    ],
    "Vegetation": ["NDVI"],
}

# 4. 颜色设置（论文风格，简洁好看）
colors = {
    "Hydrological": "#2F6DB2",  # 深蓝
    "Urbanization": "#F28E2B",  # 橙色
    "Terrain-geology": "#59A14F",  # 绿色
    "Vegetation": "#D65A6F",  # 柔和玫红
}

text_colors = {
    "Hydrological": "white",
    "Urbanization": "black",
    "Terrain-geology": "white",
    "Vegetation": "white",
}

# 5. 读取并汇总数据
rows = []
for region, filename in files.items():
    df = pd.read_csv(input_dir / filename)
    row = {"Region": region}
    for cat, drivers in categories.items():
        row[cat] = 100 * df.loc[df["Driver"].isin(drivers), "RelativeImportance"].sum()
    rows.append(row)

summary = pd.DataFrame(rows)

# 固定顺序
region_order = [
    "Full area",
    "Subsidence",
    "Uplift",
    "Sub1",
    "Sub2",
    "Upl1",
    "Upl2",
    "Upl3",
]
summary = summary.set_index("Region").loc[region_order].reset_index()

# 保存汇总表
summary.to_csv(
    output_dir / "Driver_Category_Contribution.csv", index=False, encoding="utf-8-sig"
)

# 6. 画图参数
plt.rcParams.update(
    {
        "font.family": choose_font("Arial"),
        "font.size": 11,
        "axes.linewidth": 0.8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)

fig, ax = plt.subplots(figsize=(10.5, 7.2))
fig.patch.set_facecolor("white")
ax.set_facecolor("white")

# y位置：分组留大空隙
y_positions = {
    "Full area": 9.8,
    "Subsidence": 8.0,
    "Uplift": 7.0,
    "Sub1": 5.0,
    "Sub2": 4.0,
    "Upl1": 3.0,
    "Upl2": 2.0,
    "Upl3": 1.0,
}

bar_height = 0.62
rounding = bar_height / 2

# 7. 背景参考线
for x in [0, 20, 40, 60, 80, 100]:
    ax.axvline(x, color="#E6EAF0", linewidth=0.8, zorder=0)

# 8. 画每一行胶囊堆叠条
for _, row in summary.iterrows():
    region = row["Region"]
    y = y_positions[region]

    # 胶囊底轨
    track = FancyBboxPatch(
        (0, y - bar_height / 2),
        100,
        bar_height,
        boxstyle=f"round,pad=0,rounding_size={rounding}",
        linewidth=0,
        facecolor="#EEF2F7",
        zorder=1,
    )
    ax.add_patch(track)

    # 分段填充
    left = 0
    for cat in categories.keys():
        width = row[cat]

        seg = Rectangle(
            (left, y - bar_height / 2),
            width,
            bar_height,
            facecolor=colors[cat],
            edgecolor="none",
            zorder=2,
        )
        seg.set_clip_path(track)
        ax.add_patch(seg)

        # 仅较大部分标数值
        if width >= 7:
            ax.text(
                left + width / 2,
                y,
                f"{width:.1f}",
                ha="center",
                va="center",
                fontsize=10,
                fontweight="bold",
                color=text_colors[cat],
                zorder=3,
            )

        left += width

    # 外轮廓，让条更精致
    outline = FancyBboxPatch(
        (0, y - bar_height / 2),
        100,
        bar_height,
        boxstyle=f"round,pad=0,rounding_size={rounding}",
        linewidth=0.8,
        edgecolor="#D9E1EA",
        facecolor="none",
        zorder=4,
    )
    ax.add_patch(outline)

    # 左侧区域名
    ax.text(-2.2, y, region, ha="right", va="center", fontsize=12, color="#222222")

# 9. 分组标题（左侧小标签）
group_labels = [
    ("Study area", 10.55),
    ("Deformation classes", 8.75),
    ("Representative zones", 5.85),
]

for label, y in group_labels:
    ax.text(
        0,
        y,
        label,
        ha="left",
        va="center",
        fontsize=11.5,
        fontweight="bold",
        color="#1F2937",
        bbox=dict(
            boxstyle="round,pad=0.25,rounding_size=0.15",
            facecolor="#F3F5F8",
            edgecolor="none",
        ),
    )

# 10. 图例（更精致）
legend_handles = [
    Line2D(
        [0],
        [0],
        marker="o",
        color="w",
        markerfacecolor=colors[k],
        markeredgecolor="none",
        markersize=10,
        label=k,
    )
    for k in categories.keys()
]

ax.legend(
    handles=legend_handles,
    loc="upper center",
    bbox_to_anchor=(0.5, 1.05),
    ncol=4,
    frameon=False,
    fontsize=11,
    handletextpad=0.6,
    columnspacing=1.8,
)

# 11. 坐标轴美化
ax.set_xlim(-10, 102)
ax.set_ylim(0.2, 11.2)

ax.set_xticks([0, 20, 40, 60, 80, 100])
ax.set_xlabel("Relative contribution (%)", fontsize=12)

ax.set_yticks([])

for spine in ["top", "right", "left"]:
    ax.spines[spine].set_visible(False)

ax.spines["bottom"].set_color("#AAB4C0")
ax.spines["bottom"].set_linewidth(0.9)

ax.tick_params(axis="x", labelsize=11, colors="#333333")

# 12. 保存
plt.tight_layout()

png_file = output_dir / "Fig09_Driver_Category_Contribution.png"
pdf_file = output_dir / "Fig09_Driver_Category_Contribution.pdf"
svg_file = output_dir / "Fig09_Driver_Category_Contribution.svg"

plt.savefig(png_file, dpi=700, bbox_inches="tight", facecolor="white")
plt.savefig(pdf_file, bbox_inches="tight", facecolor="white")
plt.savefig(svg_file, bbox_inches="tight", facecolor="white")


print("Finished.")
print("PNG:", png_file)
print("PDF:", pdf_file)
print("SVG:", svg_file)

if show_figures():
    plt.show(block=True)
