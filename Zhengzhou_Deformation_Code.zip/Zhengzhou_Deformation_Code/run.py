"""Run registered analysis stages or regenerate manuscript figures."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

REPOSITORY = Path(__file__).resolve().parent
sys.path.insert(0, str(REPOSITORY / "runtime"))
from zz_paths import configuration, absolute_path, project_path, python_executable


def registry() -> list[dict]:
    return json.loads((REPOSITORY / "config/tasks.json").read_text(encoding="utf-8"))


def resolve_name(name: str, category: str | None = None) -> dict:
    for task in registry():
        names = [task["name"], *task.get("aliases", [])]
        if name.lower() in [n.lower() for n in names] and (
            category is None or category == task["category"]
        ):
            return task
    raise ValueError(
        f"Unknown task: {name}. Run 'python run.py list' for available entries."
    )


def expand(value, tokens: dict):
    if isinstance(value, dict):
        return {key: expand(item, tokens) for key, item in value.items()}
    if isinstance(value, list):
        return [expand(item, tokens) for item in value]
    if isinstance(value, str):
        for token, path in tokens.items():
            value = value.replace(token, str(path))
    return value


def run_task(task: dict, *, preview: bool | None = None, dry_run=False) -> int:
    environment = os.environ.copy()
    environment["PYTHONPATH"] = os.pathsep.join(
        [str(REPOSITORY / "runtime"), environment.get("PYTHONPATH", "")]
    )
    if preview is False:
        environment["ZZ_PREVIEW"] = "0"
        environment["MPLBACKEND"] = "Agg"
    elif preview is True:
        environment["ZZ_PREVIEW"] = "1"
    if task["engine"] == "python":
        executable = python_executable()
        tokens = {
            "{PROJECT}": project_path(),
            "{REPOSITORY}": REPOSITORY,
            "{PYTHON}": executable,
            "{FIGURES}": absolute_path(configuration()["figure_output"]),
        }
        if task.get("config"):
            template = json.loads(
                (REPOSITORY / task["config"]).read_text(encoding="utf-8")
            )
            output = REPOSITORY / "outputs/configs" / (task["name"] + ".json")
            tokens["{CONFIG}"] = output
            if not dry_run:
                output.parent.mkdir(parents=True, exist_ok=True)
                resolved = expand(template, tokens)
                if task["name"] in {
                    "ale_inputcheck",
                    "ale_realdatasmoke",
                    "ale_selftest",
                }:
                    check_root = REPOSITORY / "outputs/checks" / task["name"]
                    resolved["output_root"] = str(check_root)
                    for key, folder in {
                        "audit_dir": "audit",
                        "threshold_dir": "thresholds",
                        "interaction_dir": "interactions",
                        "figure_dir": "figures",
                        "checkpoint_dir": "checkpoints",
                    }.items():
                        resolved[key] = str(check_root / folder)
                output.write_text(
                    json.dumps(resolved, indent=2) + "\n",
                    encoding="utf-8",
                )
        command = [
            str(executable),
            str(REPOSITORY / task["script"]),
            *expand(task.get("args", []), tokens),
        ]
    else:
        executable = shutil.which("matlab")
        if not executable:
            raise FileNotFoundError(
                "MATLAB was not found on PATH. Open this repository in MATLAB and run "
                f"run_project('{task['name']}')."
            )
        folder = str(REPOSITORY).replace("'", "''")
        command = [
            executable,
            "-batch",
            f"cd('{folder}'); run_project('{task['name']}')",
        ]
    print(f"{task['name']}: {task['description']}", flush=True)
    if dry_run:
        print(json.dumps(command, ensure_ascii=False, indent=2))
        return 0
    return subprocess.run(
        command, cwd=REPOSITORY, env=environment, check=False
    ).returncode


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("list", help="List analysis and figure entry points.")
    for category in ("analysis", "figure", "task"):
        subparser = subparsers.add_parser(category)
        subparser.add_argument("name")
        subparser.add_argument("--no-preview", action="store_true")
        subparser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.command == "list":
        for task in registry():
            print(
                f"{task['category']:8} {task['name']:30} {task['engine']:6} {task['description']}"
            )
        return 0
    try:
        task = resolve_name(args.name, None if args.command == "task" else args.command)
        return run_task(
            task, preview=False if args.no_preview else None, dry_run=args.dry_run
        )
    except (ValueError, FileNotFoundError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
