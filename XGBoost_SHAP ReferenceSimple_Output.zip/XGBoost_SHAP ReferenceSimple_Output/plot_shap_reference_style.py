import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.colors import LinearSegmentedColormap
import shap


def pretty_name(x):
    mp = {
        "GWS": "GWS",
        "SurfaceRunoff": "Surface runoff",
        "SubsurfaceRunoff": "Subsurface runoff",
        "SkinReservoir": "Skin reservoir",
        "BuiltSurface": "Built surface",
        "TotalPrecipitation": "Total precipitation",
        "NighttimeLight": "Nighttime light",
        "TotalLooseThickness": "Loose-layer thickness",
        "RoadDensity": "Road density",
        "Population": "Population",
        "GLHYMPS_permeability": "Permeability",
        "DEM": "DEM",
        "GUM": "GUM",
        "NDVI": "NDVI",
        "Silt": "Silt",
    }
    return mp.get(x, x)


def get_mask(df, candidates):
    cols = {c.lower(): c for c in df.columns}
    for name in candidates:
        if name.lower() in cols:
            col = cols[name.lower()]
            x = df[col]
            if pd.api.types.is_bool_dtype(x):
                return x.values
            if pd.api.types.is_numeric_dtype(x):
                return x.values != 0
            s = x.astype(str).str.strip().str.lower()
            return s.isin(["true", "1", "yes"]).values
    raise ValueError(f"在 Manual_Zone_Assignment.csv 中未找到列: {candidates}")


def read_importance_table(csv_file):
    T = pd.read_csv(csv_file)
    driver_col = None
    for c in ["Driver", "Feature", "Variable"]:
        if c in T.columns:
            driver_col = c
            break
    if driver_col is None:
        raise ValueError(f"{csv_file} 缺少 Driver/Feature 列")

    imp_col = None
    for c in ["MeanAbsSHAP", "Importance", "RelativeImportance", "MeanSHAP"]:
        if c in T.columns:
            imp_col = c
            break
    if imp_col is None:
        raise ValueError(f"{csv_file} 缺少 Importance 列")

    Tout = pd.DataFrame({
        "Driver": T[driver_col].astype(str),
        "Importance": T[imp_col].astype(float)
    })
    Tout = Tout.sort_values("Importance", ascending=False).reset_index(drop=True)
    return Tout


def build_cmap():
    # 接近参考论文的 Low=蓝, High=红/粉
    colors = [
        (0.12, 0.46, 0.95),
        (0.55, 0.28, 0.78),
        (0.95, 0.10, 0.38),
    ]
    cmap = LinearSegmentedColormap.from_list("blue_purple_red", colors, N=256)
    return cmap


def align_tables(Tshap, Tdata, Tzone):
    a = Tshap[["SampleID"]].merge(Tdata[["SampleID"]], on="SampleID", how="inner")
    a = a.merge(Tzone[["SampleID"]], on="SampleID", how="inner")
    ids = a["SampleID"].tolist()

    Tshap = Tshap.set_index("SampleID").loc[ids].reset_index()
    Tdata = Tdata.set_index("SampleID").loc[ids].reset_index()
    Tzone = Tzone.set_index("SampleID").loc[ids].reset_index()

    return Tshap, Tdata, Tzone


def get_common_features(Tshap, Tdata):
    cols1 = set(Tshap.columns)
    cols2 = set(Tdata.columns)
    bad = {"SampleID"}
    feats = [c for c in Tshap.columns if (c in cols2 and c not in bad)]
    return feats


def subset_arrays(Tshap, Tdata, mask, feature_order=None, max_display=10):
    feats = get_common_features(Tshap, Tdata)

    shap_df = Tshap.loc[mask, feats].copy()
    data_df = Tdata.loc[mask, feats].copy()

    # 只保留数值列
    valid_feats = []
    for f in feats:
        try:
            shap_df[f] = pd.to_numeric(shap_df[f], errors="coerce")
            data_df[f] = pd.to_numeric(data_df[f], errors="coerce")
            valid_feats.append(f)
        except Exception:
            pass

    shap_df = shap_df[valid_feats]
    data_df = data_df[valid_feats]

    # 去除全NaN
    keep = []
    for f in valid_feats:
        if np.isfinite(shap_df[f].values).any() and np.isfinite(data_df[f].values).any():
            keep.append(f)

    shap_df = shap_df[keep]
    data_df = data_df[keep]

    # 按指定重要性顺序截取前 max_display 个
    if feature_order is not None:
        order = [f for f in feature_order if f in shap_df.columns]
        if len(order) > 0:
            order = order[:max_display]
            shap_df = shap_df[order]
            data_df = data_df[order]
            return shap_df.values, data_df.values, [pretty_name(x) for x in order]

    # 若没有给顺序，则自动按本区域 mean(|SHAP|) 排序
    scores = np.nanmean(np.abs(shap_df.values), axis=0)
    idx = np.argsort(scores)[::-1][:max_display]
    cols = list(shap_df.columns[idx])

    shap_df = shap_df[cols]
    data_df = data_df[cols]

    return shap_df.values, data_df.values, [pretty_name(x) for x in cols]


def draw_summary(ax, shap_values, feature_values, feature_names, title, cmap, xlim=None):
    plt.sca(ax)
    shap.summary_plot(
        shap_values,
        feature_values,
        feature_names=feature_names,
        max_display=len(feature_names),
        show=False,
        color_bar=False,
        plot_size=None,
        cmap=cmap
    )

    ax.set_title(title, fontsize=16, fontweight="bold", family="Times New Roman")
    ax.set_xlabel("SHAP value (impact on model output)", fontsize=14, family="Times New Roman")
    ax.set_ylabel("")

    ax.tick_params(labelsize=12)

    for label in ax.get_yticklabels():
        label.set_fontfamily("Times New Roman")
        label.set_fontsize(13)

    for label in ax.get_xticklabels():
        label.set_fontfamily("Times New Roman")
        label.set_fontsize(12)

    ax.grid(True, color=(0.88, 0.88, 0.88), alpha=0.35)
    ax.set_axisbelow(True)

    if xlim is not None:
        ax.set_xlim(xlim)

def add_shared_colorbar(fig, rect, cmap):
    cax = fig.add_axes(rect)
    norm = mpl.colors.Normalize(vmin=0, vmax=1)
    cb = mpl.colorbar.ColorbarBase(cax, cmap=cmap, norm=norm, orientation="vertical")
    cb.set_ticks([0, 1])
    cb.set_ticklabels(["Low", "High"])
    cb.set_label("Feature value", family="Times New Roman", fontsize=14)

    for t in cb.ax.get_yticklabels():
        t.set_fontfamily("Times New Roman")
        t.set_fontsize(12)


def draw_mean_impact(ax, Tall, Tsub, Tupl, top_n=10):
    top_n = min(top_n, len(Tall))
    drivers = Tall["Driver"].iloc[:top_n].tolist()

    def get_vals(T, drivers):
        mp = dict(zip(T["Driver"].astype(str), T["Importance"].astype(float)))
        return np.array([mp.get(d, 0.0) for d in drivers], dtype=float)

    v_all = get_vals(Tall, drivers)
    v_sub = get_vals(Tsub, drivers)
    v_upl = get_vals(Tupl, drivers)

    x = np.arange(top_n)
    w = 0.24

    ax.bar(x - w, v_all, width=w, color=(0.72, 0.84, 0.50), label="Whole area")
    ax.bar(x,     v_upl, width=w, color=(0.55, 0.74, 0.97), label="Uplift zone")
    ax.bar(x + w, v_sub, width=w, color=(0.93, 0.60, 0.60), label="Subsidence zone")

    ax.set_xticks(x)
    ax.set_xticklabels(
        [pretty_name(d) for d in drivers],
        rotation=35,
        ha="right",
        fontsize=12,
        family="Times New Roman"
    )

    ax.set_ylabel("Feature mean impact", fontsize=14, family="Times New Roman")
    ax.set_title("(d) Feature mean impact", fontsize=16, fontweight="bold", family="Times New Roman")

    ax.tick_params(labelsize=12)

    for label in ax.get_yticklabels():
        label.set_fontfamily("Times New Roman")
        label.set_fontsize(12)

    ax.grid(True, color=(0.88, 0.88, 0.88), alpha=0.35)
    ax.set_axisbelow(True)

    ax.legend(
        frameon=False,
        loc="upper right",
        fontsize=11,
        prop={"family": "Times New Roman", "size": 11}
    )


def main(py_out, fig_out):
    mpl.rcParams["font.family"] = "Times New Roman"
    mpl.rcParams["axes.unicode_minus"] = False
    mpl.rcParams["font.size"] = 12
    mpl.rcParams["axes.titlesize"] = 16
    mpl.rcParams["axes.labelsize"] = 14
    mpl.rcParams["xtick.labelsize"] = 12
    mpl.rcParams["ytick.labelsize"] = 12
    mpl.rcParams["legend.fontsize"] = 11

    shap_file = os.path.join(py_out, "SHAP_All_Driver_Values.csv")
    data_file = os.path.join(py_out, "SHAP_All_Driver_DataValues.csv")
    zone_file = os.path.join(py_out, "Manual_Zone_Assignment.csv")

    imp_all_file = os.path.join(py_out, "SHAP_Importance_All.csv")
    imp_sub_file = os.path.join(py_out, "SHAP_Importance_Subsidence.csv")
    imp_upl_file = os.path.join(py_out, "SHAP_Importance_Uplift.csv")

    imp_sub1_file = os.path.join(py_out, "SHAP_Importance_Sub1.csv")
    imp_sub2_file = os.path.join(py_out, "SHAP_Importance_Sub2.csv")
    imp_upl1_file = os.path.join(py_out, "SHAP_Importance_Upl1.csv")
    imp_upl2_file = os.path.join(py_out, "SHAP_Importance_Upl2.csv")
    imp_upl3_file = os.path.join(py_out, "SHAP_Importance_Upl3.csv")

    Tshap = pd.read_csv(shap_file)
    Tdata = pd.read_csv(data_file)
    Tzone = pd.read_csv(zone_file)

    Tshap, Tdata, Tzone = align_tables(Tshap, Tdata, Tzone)

    Tall = read_importance_table(imp_all_file)
    Tsub = read_importance_table(imp_sub_file)
    Tupl = read_importance_table(imp_upl_file)

    Tsub1 = read_importance_table(imp_sub1_file)
    Tsub2 = read_importance_table(imp_sub2_file)
    Tupl1 = read_importance_table(imp_upl1_file)
    Tupl2 = read_importance_table(imp_upl2_file)
    Tupl3 = read_importance_table(imp_upl3_file)

    mask_all = np.ones(len(Tzone), dtype=bool)
    mask_sub = get_mask(Tzone, ["Subsidence_All", "Subsidence", "SubsidenceZones"])
    mask_upl = get_mask(Tzone, ["Uplift_All", "Uplift", "UpliftZones"])

    mask_sub1 = get_mask(Tzone, ["Sub1"])
    mask_sub2 = get_mask(Tzone, ["Sub2"])
    mask_upl1 = get_mask(Tzone, ["Upl1"])
    mask_upl2 = get_mask(Tzone, ["Upl2"])
    mask_upl3 = get_mask(Tzone, ["Upl3"])

    cmap = build_cmap()

    # ========================= 图1：4 panel =========================
        # ========================= 图1：4 panel =========================
    fig1 = plt.figure(figsize=(18, 11), facecolor="white")
    gs1 = fig1.add_gridspec(
        2, 2,
        left=0.06, right=0.88,
        top=0.96, bottom=0.08,
        hspace=0.24, wspace=0.18
    )

    ax1 = fig1.add_subplot(gs1[0, 0])
    ax2 = fig1.add_subplot(gs1[0, 1])
    ax3 = fig1.add_subplot(gs1[1, 0])
    ax4 = fig1.add_subplot(gs1[1, 1])

    s_all, d_all, n_all = subset_arrays(Tshap, Tdata, mask_all, Tall["Driver"].tolist(), max_display=10)
    s_sub, d_sub, n_sub = subset_arrays(Tshap, Tdata, mask_sub, Tsub["Driver"].tolist(), max_display=10)
    s_upl, d_upl, n_upl = subset_arrays(Tshap, Tdata, mask_upl, Tupl["Driver"].tolist(), max_display=10)

    xmin = min(np.nanmin(s_all), np.nanmin(s_sub), np.nanmin(s_upl))
    xmax = max(np.nanmax(s_all), np.nanmax(s_sub), np.nanmax(s_upl))
    pad = 0.04 * (xmax - xmin)
    xlim = (xmin - pad, xmax + pad)

    draw_summary(ax1, s_all, d_all, n_all, "(a) Overall", cmap, xlim=xlim)
    draw_summary(ax2, s_sub, d_sub, n_sub, "(b) Subsidence zones", cmap, xlim=xlim)
    draw_summary(ax3, s_upl, d_upl, n_upl, "(c) Uplift zones", cmap, xlim=xlim)

    draw_mean_impact(ax4, Tall, Tsub, Tupl, top_n=10)

    # 图1共享色度带，放在整张图最右侧
    add_shared_colorbar(fig1, [0.90, 0.18, 0.018, 0.64], cmap)

    fig1.savefig(
        os.path.join(fig_out, "Fig_SHAP_Main_4Panel_ReferenceStyle.png"),
        dpi=600, bbox_inches="tight"
    )
    fig1.savefig(
        os.path.join(fig_out, "Fig_SHAP_Main_4Panel_ReferenceStyle.tif"),
        dpi=600, bbox_inches="tight"
    )
    plt.close(fig1)

    # ========================= 图2：5 zones 3x2 =========================
        # ========================= 图2：5 zones =========================
    # 不再保留 (f) 子图，色度带放在整张图右边
    fig2 = plt.figure(figsize=(18, 11), facecolor="white")
    gs2 = fig2.add_gridspec(
        2, 3,
        left=0.05, right=0.88,
        top=0.96, bottom=0.08,
        hspace=0.28, wspace=0.20
    )

    ax21 = fig2.add_subplot(gs2[0, 0])
    ax22 = fig2.add_subplot(gs2[0, 1])
    ax23 = fig2.add_subplot(gs2[0, 2])
    ax24 = fig2.add_subplot(gs2[1, 0])
    ax25 = fig2.add_subplot(gs2[1, 1])

    # 右下角不作为子图使用，直接空掉
    ax26 = fig2.add_subplot(gs2[1, 2])
    ax26.axis("off")

    s1, d1, n1 = subset_arrays(Tshap, Tdata, mask_sub1, Tsub1["Driver"].tolist(), max_display=10)
    s2, d2, n2 = subset_arrays(Tshap, Tdata, mask_sub2, Tsub2["Driver"].tolist(), max_display=10)
    s3, d3, n3 = subset_arrays(Tshap, Tdata, mask_upl1, Tupl1["Driver"].tolist(), max_display=10)
    s4, d4, n4 = subset_arrays(Tshap, Tdata, mask_upl2, Tupl2["Driver"].tolist(), max_display=10)
    s5, d5, n5 = subset_arrays(Tshap, Tdata, mask_upl3, Tupl3["Driver"].tolist(), max_display=10)

    xmin2 = min(np.nanmin(s1), np.nanmin(s2), np.nanmin(s3), np.nanmin(s4), np.nanmin(s5))
    xmax2 = max(np.nanmax(s1), np.nanmax(s2), np.nanmax(s3), np.nanmax(s4), np.nanmax(s5))
    pad2 = 0.04 * (xmax2 - xmin2)
    xlim2 = (xmin2 - pad2, xmax2 + pad2)

    draw_summary(ax21, s1, d1, n1, "(a) Sub1", cmap, xlim=xlim2)
    draw_summary(ax22, s2, d2, n2, "(b) Sub2", cmap, xlim=xlim2)
    draw_summary(ax23, s3, d3, n3, "(c) Upl1", cmap, xlim=xlim2)
    draw_summary(ax24, s4, d4, n4, "(d) Upl2", cmap, xlim=xlim2)
    draw_summary(ax25, s5, d5, n5, "(e) Upl3", cmap, xlim=xlim2)

    # 图2共享色度带，放最右边，不和子图重叠
    add_shared_colorbar(fig2, [0.90, 0.20, 0.018, 0.60], cmap)

    fig2.savefig(
        os.path.join(fig_out, "Fig_SHAP_FiveZones_ReferenceStyle.png"),
        dpi=600, bbox_inches="tight"
    )
    fig2.savefig(
        os.path.join(fig_out, "Fig_SHAP_FiveZones_ReferenceStyle.tif"),
        dpi=600, bbox_inches="tight"
    )
    plt.close(fig2)

    print("图件输出完成：")
    print(fig_out)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit("用法: python plot_shap_reference_style.py <Python_Output> <Paper_Figures_Final>")

    py_out = sys.argv[1]
    fig_out = sys.argv[2]

    if not os.path.isdir(fig_out):
        os.makedirs(fig_out, exist_ok=True)

    main(py_out, fig_out)